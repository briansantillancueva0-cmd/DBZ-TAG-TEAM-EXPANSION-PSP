import { parseParamSfo } from './sfo';
import { buildZipBlobAsync, type AsyncZipInputEntry } from './zipBuilder';
import type { SfoMetadata } from './types';

export type UniversalMediaCategory =
  | 'VIDEO'
  | 'TEXT'
  | 'AUDIO'
  | 'IMAGE'
  | 'MODEL3D'
  | 'EXECUTABLE_CONTAINER';

export interface UniversalSourceItem {
  id: string;
  name: string;
  path: string;
  size: number;
  origin: 'ISO' | 'FOLDER' | 'FILE';
  blob: Blob;
}

export type TranslationRole =
  | 'PRIMARY_TEXT'
  | 'FONT_TYPOGRAPHY'
  | 'IGNORE_NO_TEXT'
  | 'OTHER';

export interface UniversalClassifiedItem extends UniversalSourceItem {
  category: UniversalMediaCategory;
  formatCode: string;
  formatLabel: string;
  magicHex: string;
  magicAscii: string;
  compressionOrEncryption: string;
  canDecryptOrUnpack: boolean;
  canAnalyzeText: boolean;
  translationRole: TranslationRole;
  translationRoleLabel: string;
  translationAdvice: string;
  notes: string;
}

export interface AwbTrackEntry {
  index: number;
  cueId: number;
  offset: number;
  size: number;
  codecExt: string;
  codecLabel: string;
  magicHex: string;
}

export interface DatSignatureHit {
  index: number;
  offset: number;
  signature: string;
  category: UniversalMediaCategory;
  label: string;
  estimatedSize: number | null;
  suggestedExt: string;
  suggestedName?: string;
  canDecompress: 'zlib' | 'gzip' | 'blz4' | 'blz2' | null;
}

export interface PspHeaderBreakdown {
  magic: string;
  modAttr: number;
  compAttr: number;
  versionMajor: number;
  versionMinor: number;
  modName: string;
  elfSize: number;
  pspSize: number;
  devkitVersion: string;
  isGzipCompressed: boolean;
  isKirkEncrypted: boolean;
  gzipOffset: number | null;
  tagHex: string;
}

export interface PmfVideoInfo {
  version: string;
  streamOffset: number;
  streamSize: number;
  width: number | null;
  height: number | null;
  codecLabel: string;
}

export interface PgfSpanishGlyphStatus {
  char: string;
  codePointHex: string;
  supported: boolean | null;
}

export interface PgfFontInfo {
  headerSize: number;
  version: string;
  fontName: string;
  fontType: string;
  glyphCount: number;
  charMapLength: number;
  bpp: number;
  firstGlyph: number;
  lastGlyph: number;
  spanishAudit: PgfSpanishGlyphStatus[];
  spanishAuditSummary: string;
}

export interface ImageDecodeInfo {
  format: 'PNG' | 'TIM2' | 'GIM' | 'BMP' | 'JPG' | 'DDS' | 'UNKNOWN';
  width: number | null;
  height: number | null;
  bpp: number | null;
  pixelInfo: string;
  previewUrl: string | null;
}

export interface UniversalDecryptResult {
  fileName: string;
  filePath: string;
  fileSize: number;
  detectedKind:
    | 'PSP_MODULE'
    | 'AWB_AFS2'
    | 'DAT_CONTAINER'
    | 'PMF_VIDEO'
    | 'PGF_FONT'
    | 'IMAGE_ASSET'
    | 'PARAM_SFO'
    | 'UMD_DATA'
    | 'RAW_BINARY';
  summaryTitle: string;
  summaryStatus: 'DECRYPTED' | 'UNPACKED' | 'PARSED' | 'KIRK_HARDWARE_LOCKED' | 'PARTIAL';
  details: Array<{ label: string; value: string }>;
  notes: string[];
  pspInfo?: PspHeaderBreakdown;
  decompressedBytes?: Uint8Array | null;
  decompressedName?: string;
  awbTracks?: AwbTrackEntry[];
  awbOffsetSize?: number;
  awbAlignment?: number;
  datHits?: DatSignatureHit[];
  datScannedBytes?: number;
  datZeroRatio?: number;
  datPresEntryCount?: number;
  pmfInfo?: PmfVideoInfo;
  pgfInfo?: PgfFontInfo;
  imageInfo?: ImageDecodeInfo;
  sfoInfo?: SfoMetadata;
  sfoRawPairs?: Array<{ key: string; value: string }>;
  umdDataFields?: string[];
}

export const UNIVERSAL_CATEGORY_META: Record<
  UniversalMediaCategory,
  { label: string; shortLabel: string; description: string }
> = {
  VIDEO: {
    label: 'Videos',
    shortLabel: 'Videos',
    description: 'Streams PSMF (.PMF), MPS, MP4, AVI, Bink y PAM',
  },
  TEXT: {
    label: 'Textos y Fuentes',
    shortLabel: 'Textos',
    description: 'Diálogos, SFO, UMD_DATA, tablas TBL/TXT/XML y fuentes PGF',
  },
  AUDIO: {
    label: 'Audios',
    shortLabel: 'Audios',
    description: 'Bancos CRIWARE AFS2 (.AWB/.ACB), ADX, HCA, ATRAC3 y VAG',
  },
  IMAGE: {
    label: 'Imágenes y Texturas',
    shortLabel: 'Imágenes',
    description: 'PNG, GIM (MIG.00.1PSP), TIM2, DDS, BMP y JPG',
  },
  MODEL3D: {
    label: 'Modelos 3D',
    shortLabel: 'Modelos 3D',
    description: 'Mallas PSP GMO (OMG.00.1PSP), OBJ, DAE, FBX y BMD',
  },
  EXECUTABLE_CONTAINER: {
    label: 'Ejecutables / Contenedores (.DAT/.BIN)',
    shortLabel: 'Contenedores / BIN',
    description: 'EBOOT/BOOT/PRX (~PSP / ELF) y paquetes RES.DAT / DATA.BIN / PCK1',
  },
};

function readAscii(bytes: Uint8Array, start: number, len: number): string {
  const end = Math.min(bytes.length, start + len);
  if (end <= start) return '';
  let out = '';
  for (let i = start; i < end; i++) {
    const b = bytes[i];
    if (b === 0) break;
    out += b >= 32 && b <= 126 ? String.fromCharCode(b) : '.';
  }
  return out.trim();
}

function bytesToHex(bytes: Uint8Array, count = 16): string {
  const slice = bytes.subarray(0, Math.min(bytes.length, count));
  return Array.from(slice)
    .map((b) => b.toString(16).toUpperCase().padStart(2, '0'))
    .join(' ');
}

function hasSubarrayAt(buf: Uint8Array, offset: number, sig: number[]): boolean {
  if (offset < 0 || offset + sig.length > buf.length) return false;
  for (let i = 0; i < sig.length; i++) {
    if (buf[offset + i] !== sig[i]) return false;
  }
  return true;
}

function getExt(name: string): string {
  const idx = name.lastIndexOf('.');
  return idx >= 0 ? name.slice(idx).toLowerCase() : '';
}

function sniffTrackCodec(bytes: Uint8Array): { ext: string; label: string } {
  if (bytes.length >= 4) {
    if (hasSubarrayAt(bytes, 0, [0x48, 0x43, 0x41, 0x00]) || hasSubarrayAt(bytes, 0, [0xc8, 0xc3, 0xc1, 0x00])) {
      return { ext: '.hca', label: 'CRI HCA Audio' };
    }
    if (bytes[0] === 0x80 && bytes[1] === 0x00 && bytes.length >= 16) {
      return { ext: '.adx', label: 'CRI ADX Audio' };
    }
    if (hasSubarrayAt(bytes, 0, [0x52, 0x49, 0x46, 0x46])) {
      return { ext: '.at3', label: 'RIFF / ATRAC3 / WAV' };
    }
    if (hasSubarrayAt(bytes, 0, [0x56, 0x41, 0x47, 0x70])) {
      return { ext: '.vag', label: 'PlayStation ADPCM (.VAG)' };
    }
    if (hasSubarrayAt(bytes, 0, [0x4f, 0x67, 0x67, 0x53])) {
      return { ext: '.ogg', label: 'Ogg Vorbis' };
    }
  }
  return { ext: '.bin', label: 'Stream Audio Raw' };
}

export async function classifyUniversalBlob(
  item: UniversalSourceItem
): Promise<UniversalClassifiedItem> {
  const headLen = Math.min(4096, item.blob.size);
  const head = new Uint8Array(await item.blob.slice(0, headLen).arrayBuffer());
  const dv = head.length >= 4 ? new DataView(head.buffer, head.byteOffset, head.byteLength) : null;
  const ascii4 = readAscii(head, 0, 4);
  const ascii12 = readAscii(head, 0, 12);
  const ext = getExt(item.name);
  const upperName = item.name.toUpperCase();
  const magicHex = bytesToHex(head, 12);

  let category: UniversalMediaCategory = 'EXECUTABLE_CONTAINER';
  let formatCode = ext ? ext.slice(1).toUpperCase() : 'BIN';
  let formatLabel = 'Archivo binario PSP';
  let compressionOrEncryption = 'Sin cifrado detectado';
  let canDecryptOrUnpack = true;
  let canAnalyzeText = true;
  let notes = 'Listo para inspección binaria y extracción de cadenas.';

  // 1. Videos
  if (ascii4 === 'PSMF' || ext === '.pmf' || ext === '.mps') {
    category = 'VIDEO';
    formatCode = 'PSMF';
    formatLabel = 'Video PSP (.PMF / PSMF Stream)';
    compressionOrEncryption = 'H.264/AVC + ATRAC3+ multiplexado';
    canAnalyzeText = false;
    notes = 'Video nativo UMD PSP; permite extraer el stream MPEG/H.264.';
  } else if (ascii4 === 'PAMF' || ascii4 === 'BIKi' || ['.mp4', '.avi', '.mkv', '.bik'].includes(ext)) {
    category = 'VIDEO';
    formatCode = ascii4 || ext.slice(1).toUpperCase();
    formatLabel = `Video (${ext || ascii4})`;
    canAnalyzeText = false;
    notes = 'Flujo de video multimedia.';
  }
  // 2. Audios
  else if (ascii4 === 'AFS2' || ext === '.awb') {
    category = 'AUDIO';
    formatCode = 'AFS2';
    formatLabel = 'Banco de Audio CRIWARE (.AWB / AFS2)';
    compressionOrEncryption = 'Contenedor multi-pista (ADX/HCA/AT3)';
    notes = 'Contenedor de audio empaquetado; permite listar y extraer todas sus pistas.';
  } else if (ascii4 === 'AFS\0' || ascii4 === 'AFS' || ext === '.afs') {
    category = 'AUDIO';
    formatCode = 'AFS';
    formatLabel = 'Contenedor CRI AFS';
    notes = 'Archivo contenedor de pistas o recursos.';
  } else if (ascii4 === '@UTF' || ext === '.acb') {
    category = 'AUDIO';
    formatCode = 'ACB/@UTF';
    formatLabel = 'CueSheet CRIWARE (.ACB)';
    notes = 'Metadatos y pistas de audio CRIWARE.';
  } else if (
    ascii4 === 'RIFF' ||
    ascii4 === 'VAGp' ||
    ascii4 === 'HCA' ||
    ascii4 === 'OggS' ||
    ['.at3', '.adx', '.hca', '.vag', '.wav', '.ogg', '.mp3'].includes(ext) ||
    (head.length >= 2 && head[0] === 0x80 && head[1] === 0x00 && ext === '.adx')
  ) {
    category = 'AUDIO';
    formatCode = ascii4 || ext.slice(1).toUpperCase();
    formatLabel = 'Pista de Audio PSP';
    canAnalyzeText = false;
    notes = 'Archivo de audio listo para extracción.';
  }
  // 3. Images & Textures
  else if (hasSubarrayAt(head, 0, [0x89, 0x50, 0x4e, 0x47]) || ext === '.png') {
    category = 'IMAGE';
    formatCode = 'PNG';
    formatLabel = 'Imagen PNG estándar';
    canAnalyzeText = false;
    notes = 'Previsualizable directamente (ICON0.PNG / PIC1.PNG).';
  } else if (ascii12.startsWith('MIG.00.1PSP') || ext === '.gim') {
    category = 'IMAGE';
    formatCode = 'GIM';
    formatLabel = 'Textura PSP (.GIM / MIG.00.1PSP)';
    canAnalyzeText = false;
    notes = 'Textura oficial SDK de PSP; permite leer cabecera y formato de píxel.';
  } else if (ascii4 === 'TIM2' || ext === '.tm2' || ext === '.tim2') {
    category = 'IMAGE';
    formatCode = 'TIM2';
    formatLabel = 'Textura PlayStation TIM2';
    canAnalyzeText = false;
    notes = 'Textura TIM2 RGBA/Indexada compatible con vista previa.';
  } else if (
    hasSubarrayAt(head, 0, [0xff, 0xd8, 0xff]) ||
    ascii4 === 'DDS ' ||
    ['.jpg', '.jpeg', '.bmp', '.tga', '.dds', '.txp'].includes(ext)
  ) {
    category = 'IMAGE';
    formatCode = ext.slice(1).toUpperCase() || 'IMG';
    formatLabel = 'Imagen / Textura';
    canAnalyzeText = false;
    notes = 'Recurso gráfico raster.';
  }
  // 4. 3D Models
  else if (
    ascii12.startsWith('OMG.00.1PSP') ||
    ['.gmo', '.obj', '.dae', '.fbx', '.mdl', '.bmd', '.emd', '.amg', '.pmx', '.pmd'].includes(ext)
  ) {
    category = 'MODEL3D';
    formatCode = ascii12.startsWith('OMG.00.1PSP') ? 'GMO' : ext.slice(1).toUpperCase();
    formatLabel = ascii12.startsWith('OMG.00.1PSP')
      ? 'Modelo 3D PSP (.GMO / OMG.00.1PSP)'
      : `Modelo 3D (${ext.toUpperCase()})`;
    canAnalyzeText = ext === '.obj' || ext === '.dae';
    notes = 'Malla 3D, huesos y materiales del juego.';
  }
  // 5. Texts / Fonts / SFO / Metadata
  else if (ascii4 === 'PGF0' || ext === '.pgf') {
    category = 'TEXT';
    formatCode = 'PGF0';
    formatLabel = 'Fuente tipográfica PSP (.PGF)';
    compressionOrEncryption = 'Tabla de glifos raster PSP';
    notes = 'Fuente bitmap/vector del juego (ej. font.pgf); contiene metadatos y mapas de glifos.';
  } else if (hasSubarrayAt(head, 0, [0x00, 0x50, 0x53, 0x46]) || upperName === 'PARAM.SFO' || ext === '.sfo') {
    category = 'TEXT';
    formatCode = 'PSF/SFO';
    formatLabel = 'Tabla de Metadatos PSP (PARAM.SFO)';
    notes = 'Contiene TITLE, DISC_ID, PSP_SYSTEM_VER y textos de sistema.';
  } else if (upperName === 'UMD_DATA.BIN') {
    category = 'TEXT';
    formatCode = 'UMD_DATA';
    formatLabel = 'Identificador de Disco PSP (UMD_DATA.BIN)';
    notes = 'Descriptor textual con ID de región y metadatos de disco.';
  } else if (['.txt', '.csv', '.json', '.xml', '.ini', '.cfg', '.tbl', '.lua', '.msg', '.srt', '.sub'].includes(ext)) {
    category = 'TEXT';
    formatCode = ext.slice(1).toUpperCase();
    formatLabel = `Archivo de Texto (${ext})`;
    notes = 'Archivo textual legible en múltiples codificaciones.';
  }
  // 6. Executables & Binary Containers (~PSP, ELF, .PRX, .DAT, .BIN)
  else if (ascii4 === '~PSP') {
    category = 'EXECUTABLE_CONTAINER';
    formatCode = '~PSP';
    formatLabel = 'Ejecutable / Módulo Cifrado (~PSP)';
    const hasGzip = head.length > 0x152 && head[0x150] === 0x1f && head[0x151] === 0x8b;
    compressionOrEncryption = hasGzip
      ? '~PSP con payload GZIP descomprimible'
      : 'Cabecera ~PSP (cifrado Kirk / módulo PSP)';
    notes = hasGzip
      ? 'Contiene bloque GZIP embebido; el desencriptador puede descomprimir el ELF interno.'
      : 'Módulo ~PSP; el desencriptador extrae la cabecera completa y busca bloques GZIP/cadenas.';
  } else if (hasSubarrayAt(head, 0, [0x7f, 0x45, 0x4c, 0x46])) {
    category = 'EXECUTABLE_CONTAINER';
    formatCode = 'ELF32';
    formatLabel = 'Ejecutable ELF32 MIPS Descifrado';
    compressionOrEncryption = 'Descifrado (ELF estándar)';
    notes = 'Binario MIPS ya descifrado listo para edición HxD y análisis de textos.';
  } else if (hasSubarrayAt(head, 0, [0x00, 0x50, 0x42, 0x50])) {
    category = 'EXECUTABLE_CONTAINER';
    formatCode = 'PBP';
    formatLabel = 'Paquete Homebrew / Update (.PBP)';
    notes = 'Contenedor PBP con PARAM.SFO, ICON0 y ejecutable interno.';
  } else if (ascii4 === 'PCK1' || ext === '.pck') {
    category = 'EXECUTABLE_CONTAINER';
    formatCode = 'PCK1';
    formatLabel = 'Contenedor PCK1 PSP';
    compressionOrEncryption = 'Índice de subarchivos PSP';
    notes = 'Paquete de activos PCK1 desempaquetable.';
  } else if (ascii4 === 'PRES' || ascii4 === 'BLZ4' || ascii4 === 'BLZ2' || ascii4 === 'CPK ' || ascii4 === 'PACK') {
    category = 'EXECUTABLE_CONTAINER';
    formatCode = ascii4;
    formatLabel = `Contenedor ${ascii4} (.DAT/.BIN)`;
    compressionOrEncryption = `Empaquetado ${ascii4} + posible compresión zlib/LZ`;
    notes = 'Contenedor típico de Bandai Namco / PSP (RES.DAT, first.dat, DATA.BIN). Escaneo profundo de firmas activado.';
  } else if (ext === '.dat' || ext === '.bin' || ext === '.prx') {
    category = 'EXECUTABLE_CONTAINER';
    formatCode = ext.slice(1).toUpperCase() || 'BIN';
    const allZero = head.length > 0 && head.every((b) => b === 0);
    if (allZero && upperName.includes('DUMMY')) {
      formatLabel = 'Relleno de Sector UMD (DUMMY.DAT)';
      compressionOrEncryption = 'Relleno 0x00 para alinear LBA';
      canAnalyzeText = false;
      notes = 'Archivo de relleno LBA en disco UMD (ceros).';
    } else {
      const hasZlib =
        dv !== null &&
        (head[0] === 0x78 && (head[1] === 0x9c || head[1] === 0xda || head[1] === 0x01));
      formatLabel = ext === '.prx' ? 'Módulo Dinámico PSP (.PRX)' : 'Archivo de Datos / Contenedor (.DAT/.BIN)';
      compressionOrEncryption = hasZlib
        ? 'Flujo zlib (0x78 0x9C/DA) detectado'
        : 'Escaneable por bloques zlib/gzip y firmas internas';
      notes = 'El desencriptador analiza firmas embebidas (OMG, MIG, TIM2, PNG, PSMF, AFS2, zlib/gzip) y textos.';
    }
  } else {
    // Unknown extension: check if mostly printable UTF-8/Shift-JIS text
    let printable = 0;
    for (let i = 0; i < head.length; i++) {
      const b = head[i];
      if ((b >= 32 && b <= 126) || b === 9 || b === 10 || b === 13) printable++;
    }
    if (head.length > 16 && printable / head.length > 0.78) {
      category = 'TEXT';
      formatCode = 'TXT';
      formatLabel = 'Archivo Textual Detectado';
      notes = 'Contenido mayoritariamente imprimible.';
    }
  }

  // Classify Translation Role according to user's PSP resource taxonomy
  let translationRole: TranslationRole = 'OTHER';
  let translationRoleLabel = 'Otro recurso / librería';
  let translationAdvice = 'Archivo auxiliar del juego.';

  if (upperName === 'RES.DAT') {
    translationRole = 'PRIMARY_TEXT';
    translationRoleLabel = 'Objetivo Texto #1 · Guiones y Diálogos';
    translationAdvice =
      'Archivo principal de recursos: suele contener guiones, diálogos, tablas de texto y gráficos comprimidos (PRES / BLZ4 / ZLIB).';
  } else if (upperName === 'FIRST.DAT') {
    translationRole = 'PRIMARY_TEXT';
    translationRoleLabel = 'Objetivo Texto #2 · Textos Iniciales y UI';
    translationAdvice =
      'Almacena textos iniciales, configuraciones de interfaz, menús principales y datos cargados al arrancar.';
  } else if (upperName === 'DATA.BIN') {
    translationRole = 'PRIMARY_TEXT';
    translationRoleLabel = 'Objetivo Texto #3 · Datos de Instalación';
    translationAdvice =
      'Paquete adicional (INSDIR / UPDATE): contiene recursos instalados en memoria y posibles diálogos o descripciones.';
  } else if (upperName === 'EBOOT.BIN' || upperName === 'BOOT.BIN') {
    translationRole = 'PRIMARY_TEXT';
    translationRoleLabel = 'Objetivo Texto #4 · Ejecutable / Menús Sistema';
    translationAdvice =
      'Ejecutable principal: guarda textos del sistema, nombres de objetos, menús de guardado y mensajes de error.';
  } else if (upperName === 'FONT.PGF' || ext === '.pgf' || upperName === 'LIBFONT.PRX') {
    translationRole = 'FONT_TYPOGRAPHY';
    translationRoleLabel = 'Fuente / Tipografía';
    translationAdvice =
      upperName === 'LIBFONT.PRX'
        ? 'Módulo controlador de fuentes PSP (renderizado). No contiene diálogos; trabaja junto a font.pgf.'
        : 'Define los caracteres que el juego dibuja en pantalla. Audita si incluye ñ, á, é, í, ó, ú, ü, ¡, ¿ antes de traducir al español.';
  } else if (
    ext === '.awb' ||
    ext === '.pmf' ||
    ext === '.png' ||
    upperName === 'DUMMY.DAT' ||
    category === 'AUDIO' ||
    category === 'VIDEO' ||
    category === 'IMAGE'
  ) {
    translationRole = 'IGNORE_NO_TEXT';
    translationRoleLabel = 'Sin texto · Puedes ignorar';
    translationAdvice =
      upperName === 'DUMMY.DAT'
        ? 'Archivo de relleno vacío (ceros) usado para optimizar la lectura UMD.'
        : ext === '.awb'
        ? 'Contenedor de audio (música, voces, efectos). No contiene texto traducible.'
        : ext === '.pmf'
        ? 'Video cinemático PSP (.PMF). No contiene texto editable directo.'
        : 'Imagen de vista previa o textura (ICON0.PNG / PIC1.PNG). Sin cadenas de diálogo.';
  } else if (category === 'TEXT') {
    translationRole = 'PRIMARY_TEXT';
    translationRoleLabel = 'Archivo Textual / Metadatos';
    translationAdvice = 'Contiene cadenas de metadatos o texto legible.';
  }

  return {
    ...item,
    category,
    formatCode,
    formatLabel,
    magicHex: magicHex || '00',
    magicAscii: ascii4 || '—',
    compressionOrEncryption,
    canDecryptOrUnpack,
    canAnalyzeText,
    translationRole,
    translationRoleLabel,
    translationAdvice,
    notes,
  };
}

export async function scanUniversalItems(
  items: UniversalSourceItem[],
  onProgress?: (done: number, total: number) => void
): Promise<UniversalClassifiedItem[]> {
  const results: UniversalClassifiedItem[] = [];
  for (let i = 0; i < items.length; i++) {
    results.push(await classifyUniversalBlob(items[i]));
    if (i % 20 === 0 || i === items.length - 1) {
      onProgress?.(i + 1, items.length);
    }
  }
  return results;
}

// =============================================================================
// STREAMING DECOMPRESSORS & PARSERS
// =============================================================================

export async function decompressWithStream(
  bytes: Uint8Array,
  format: 'gzip' | 'deflate' | 'deflate-raw'
): Promise<Uint8Array> {
  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      controller.enqueue(bytes);
      controller.close();
    },
  });
  const ds = new DecompressionStream(format);
  const decompressedStream = stream.pipeThrough(ds as unknown as TransformStream<Uint8Array, Uint8Array>);
  const reader = decompressedStream.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    if (value) {
      chunks.push(value);
      total += value.length;
    }
    if (total > 128 * 1024 * 1024) {
      throw new Error('El flujo descomprimido supera el límite seguro de 128 MB.');
    }
  }
  const out = new Uint8Array(total);
  let pos = 0;
  for (const c of chunks) {
    out.set(c, pos);
    pos += c.length;
  }
  return out;
}

function parsePspModuleHeader(head: Uint8Array): PspHeaderBreakdown {
  const dv = new DataView(head.buffer, head.byteOffset, head.byteLength);
  const magic = readAscii(head, 0, 4);
  const modAttr = head.length >= 6 ? dv.getUint16(4, true) : 0;
  const compAttr = head.length >= 8 ? dv.getUint16(6, true) : 0;
  const versionMinor = head.length >= 9 ? head[8] : 0;
  const versionMajor = head.length >= 10 ? head[9] : 0;
  const modName = readAscii(head, 10, 28) || 'SIN_NOMBRE';
  const elfSize = head.length >= 44 ? dv.getUint32(40, true) : 0;
  const pspSize = head.length >= 48 ? dv.getUint32(44, true) : 0;
  const devkitRaw = head.length >= 0x80 ? dv.getUint32(0x7c, true) : 0;
  const devkitMajor = (devkitRaw >>> 24) & 0xff;
  const devkitMinor = (devkitRaw >>> 16) & 0xff;
  const devkitPatch = (devkitRaw >>> 8) & 0xff;
  const devkitVersion = devkitRaw
    ? `${devkitMajor}.${String(devkitMinor).padStart(2, '0')}.${String(devkitPatch).padStart(2, '0')}`
    : 'N/D';

  // Search for gzip signature (0x1F 0x8B 0x08) commonly at 0x150 in decrypted-kirk/gzip PRX/EBOOT
  let gzipOffset: number | null = null;
  const searchLimit = Math.min(head.length - 3, 0x400);
  for (let off = 0x40; off <= searchLimit; off++) {
    if (head[off] === 0x1f && head[off + 1] === 0x8b && head[off + 2] === 0x08) {
      gzipOffset = off;
      break;
    }
  }

  const tagHex = head.length >= 0x150 ? bytesToHex(head.subarray(0xd0, 0xe0), 16) : '';
  const isGzipCompressed = (compAttr & 0x0001) !== 0 || gzipOffset !== null;
  const isKirkEncrypted = magic === '~PSP' && gzipOffset === null;

  return {
    magic,
    modAttr,
    compAttr,
    versionMajor,
    versionMinor,
    modName,
    elfSize,
    pspSize,
    devkitVersion,
    isGzipCompressed,
    isKirkEncrypted,
    gzipOffset,
    tagHex,
  };
}

function readUintVariableLE(buf: Uint8Array, pos: number, byteLen: number): number {
  let val = 0;
  for (let i = 0; i < byteLen; i++) {
    val += (buf[pos + i] ?? 0) * Math.pow(256, i);
  }
  return val;
}

export async function parseAwbAfs2(blob: Blob): Promise<{
  tracks: AwbTrackEntry[];
  offsetSize: number;
  idSize: number;
  alignment: number;
}> {
  const headerSlice = new Uint8Array(await blob.slice(0, Math.min(blob.size, 64)).arrayBuffer());
  if (headerSlice.length < 16 || readAscii(headerSlice, 0, 4) !== 'AFS2') {
    throw new Error('El archivo no posee una cabecera CRIWARE AFS2 válida.');
  }

  const dv = new DataView(headerSlice.buffer, headerSlice.byteOffset, headerSlice.byteLength);
  const offsetSize = headerSlice[5] === 2 || headerSlice[5] === 4 || headerSlice[5] === 8 ? headerSlice[5] : 4;
  const idSize = headerSlice[6] === 2 || headerSlice[6] === 4 ? headerSlice[6] : 2;
  const entryCount = dv.getUint32(8, true);
  const alignment = dv.getUint32(12, true) || 32;

  if (entryCount === 0 || entryCount > 200000) {
    throw new Error(`Cantidad de pistas AFS2 fuera de rango seguro (${entryCount}).`);
  }

  const tableByteLen = 16 + entryCount * idSize + (entryCount + 1) * offsetSize;
  const tableBytes = new Uint8Array(
    await blob.slice(0, Math.min(blob.size, tableByteLen)).arrayBuffer()
  );

  const idsStart = 16;
  const offsetsStart = 16 + entryCount * idSize;

  const rawOffsets: number[] = [];
  for (let i = 0; i <= entryCount; i++) {
    rawOffsets.push(readUintVariableLE(tableBytes, offsetsStart + i * offsetSize, offsetSize));
  }

  const tracks: AwbTrackEntry[] = [];
  // Sniff track headers lazily for first 250 tracks to stay instantaneous even on 837 MB voice.awb
  const sniffLimit = Math.min(entryCount, 250);

  for (let i = 0; i < entryCount; i++) {
    const cueId = readUintVariableLE(tableBytes, idsStart + i * idSize, idSize);
    const rawStart = rawOffsets[i];
    const alignedStart = Math.ceil(rawStart / alignment) * alignment;
    const rawEnd = rawOffsets[i + 1] ?? blob.size;
    const clampedEnd = Math.min(blob.size, rawEnd);
    const size = Math.max(0, clampedEnd - alignedStart);

    let codecExt = '.bin';
    let codecLabel = 'Pista CRIWARE';
    let magicHex = '—';

    if (i < sniffLimit && size > 0 && alignedStart < blob.size) {
      const probe = new Uint8Array(
        await blob.slice(alignedStart, Math.min(blob.size, alignedStart + 16)).arrayBuffer()
      );
      magicHex = bytesToHex(probe, 8);
      const sniffed = sniffTrackCodec(probe);
      codecExt = sniffed.ext;
      codecLabel = sniffed.label;
    }

    tracks.push({
      index: i,
      cueId,
      offset: alignedStart,
      size,
      codecExt,
      codecLabel,
      magicHex,
    });
  }

  return { tracks, offsetSize, idSize, alignment };
}

export function extractAwbTrackBlob(awbBlob: Blob, track: AwbTrackEntry): Blob {
  return awbBlob.slice(track.offset, track.offset + track.size, 'application/octet-stream');
}

export async function extractAwbTracksToZip(
  awbBlob: Blob,
  awbName: string,
  tracks: AwbTrackEntry[],
  maxTracks = 500,
  onProgress?: (done: number, total: number, currentPath: string) => void
): Promise<Blob> {
  const subset = tracks.slice(0, maxTracks);
  const folderName = awbName.replace(/\.awb$/i, '');
  const entries: AsyncZipInputEntry[] = subset.map((t) => ({
    path: `${folderName}/track_${String(t.index).padStart(4, '0')}_cue_${t.cueId}${t.codecExt}`,
    data: awbBlob.slice(t.offset, t.offset + t.size),
  }));
  return buildZipBlobAsync(entries, onProgress);
}

const KNOWN_SIGS: Array<{
  bytes: number[];
  signature: string;
  category: UniversalMediaCategory;
  label: string;
  ext: string;
  canDecompress?: 'zlib' | 'gzip' | 'blz4' | 'blz2';
}> = [
  { bytes: [0x4f, 0x4d, 0x47, 0x2e, 0x30, 0x30, 0x2e, 0x31], signature: 'OMG.00.1PSP', category: 'MODEL3D', label: 'Modelo 3D PSP (.GMO)', ext: '.gmo' },
  { bytes: [0x4d, 0x49, 0x47, 0x2e, 0x30, 0x30, 0x2e, 0x31], signature: 'MIG.00.1PSP', category: 'IMAGE', label: 'Textura PSP (.GIM)', ext: '.gim' },
  { bytes: [0x54, 0x49, 0x4d, 0x32], signature: 'TIM2', category: 'IMAGE', label: 'Textura PlayStation TIM2', ext: '.tm2' },
  { bytes: [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a], signature: 'PNG', category: 'IMAGE', label: 'Imagen PNG embebida', ext: '.png' },
  { bytes: [0x50, 0x53, 0x4d, 0x46], signature: 'PSMF', category: 'VIDEO', label: 'Video PSP (.PMF / PSMF)', ext: '.pmf' },
  { bytes: [0x41, 0x46, 0x53, 0x32], signature: 'AFS2', category: 'AUDIO', label: 'Banco Audio CRI AFS2 (.AWB)', ext: '.awb' },
  { bytes: [0x48, 0x43, 0x41, 0x00], signature: 'HCA', category: 'AUDIO', label: 'Audio CRI HCA', ext: '.hca' },
  { bytes: [0x52, 0x49, 0x46, 0x46], signature: 'RIFF', category: 'AUDIO', label: 'Audio RIFF / ATRAC3 / WAV', ext: '.at3' },
  { bytes: [0x56, 0x41, 0x47, 0x70], signature: 'VAGp', category: 'AUDIO', label: 'Audio PlayStation VAG', ext: '.vag' },
  { bytes: [0x50, 0x47, 0x46, 0x30], signature: 'PGF0', category: 'TEXT', label: 'Fuente Tipográfica PGF', ext: '.pgf' },
  { bytes: [0x00, 0x50, 0x53, 0x46], signature: 'PSF', category: 'TEXT', label: 'Metadatos PARAM.SFO', ext: '.sfo' },
  { bytes: [0x7e, 0x50, 0x53, 0x50], signature: '~PSP', category: 'EXECUTABLE_CONTAINER', label: 'Módulo / Ejecutable ~PSP', ext: '.prx' },
  { bytes: [0x7f, 0x45, 0x4c, 0x46], signature: 'ELF', category: 'EXECUTABLE_CONTAINER', label: 'Binario ELF32 MIPS', ext: '.elf' },
  { bytes: [0x50, 0x52, 0x45, 0x53], signature: 'PRES', category: 'EXECUTABLE_CONTAINER', label: 'Contenedor Bandai Namco PRES', ext: '.pres' },
  { bytes: [0x42, 0x4c, 0x5a, 0x34], signature: 'BLZ4', category: 'EXECUTABLE_CONTAINER', label: 'Bloque Comprimido BLZ4 (Bandai Namco)', ext: '.blz4', canDecompress: 'blz4' },
  { bytes: [0x42, 0x4c, 0x5a, 0x32], signature: 'BLZ2', category: 'EXECUTABLE_CONTAINER', label: 'Bloque Comprimido BLZ2 (Bandai Namco)', ext: '.blz2', canDecompress: 'blz2' },
  { bytes: [0x50, 0x43, 0x4b, 0x31], signature: 'PCK1', category: 'EXECUTABLE_CONTAINER', label: 'Contenedor PCK1', ext: '.pck' },
  { bytes: [0x1f, 0x8b, 0x08], signature: 'GZIP', category: 'EXECUTABLE_CONTAINER', label: 'Flujo Comprimido GZIP', ext: '.gz', canDecompress: 'gzip' },
];

const SIG_FIRST_BYTE_MASK = (() => {
  const mask = new Uint8Array(256);
  for (const sig of KNOWN_SIGS) {
    mask[sig.bytes[0]] = 1;
  }
  mask[0x78] = 1; // ZLIB streams
  return mask;
})();

function readCStringSafe(buf: Uint8Array, off: number, maxLen = 96): string {
  if (off <= 0 || off >= buf.length) return '';
  let out = '';
  const end = Math.min(buf.length, off + maxLen);
  for (let i = off; i < end; i++) {
    const b = buf[i];
    if (b === 0) break;
    if (b < 32 || b > 126) return '';
    out += String.fromCharCode(b);
  }
  return out;
}

export async function tryParsePresTocEntries(blob: Blob): Promise<DatSignatureHit[]> {
  if (blob.size < 64) return [];
  const probeLen = Math.min(blob.size, 2 * 1024 * 1024);
  const buf = new Uint8Array(await blob.slice(0, probeLen).arrayBuffer());
  if (readAscii(buf, 0, 4) !== 'PRES') return [];

  const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  const hits: DatSignatureHit[] = [];
  const seenOffsets = new Set<number>();

  // Scan candidate TOC region in first 256 KB for Bandai Namco PRES 16-byte / 32-byte entries:
  // Pattern A: [rawOffOrFlags:u32, compSize:u32, nameOff:u32, uncompSize:u32]
  const scanTocEnd = Math.min(buf.length - 16, 256 * 1024);
  let validSequential = 0;
  const candidates: DatSignatureHit[] = [];

  for (let pos = 0x10; pos + 16 <= scanTocEnd; pos += 4) {
    const rawOff = dv.getUint32(pos, true);
    const dataOff = rawOff & 0x0fffffff;
    const compSize = dv.getUint32(pos + 4, true);
    const nameOff = dv.getUint32(pos + 8, true);
    const uncompSize = dv.getUint32(pos + 12, true);

    if (
      dataOff >= 0x40 &&
      dataOff < blob.size &&
      compSize > 0 &&
      compSize <= blob.size - dataOff &&
      compSize <= 64 * 1024 * 1024 &&
      uncompSize >= compSize &&
      uncompSize <= 128 * 1024 * 1024
    ) {
      let name = '';
      if (nameOff >= 0x10 && nameOff < scanTocEnd) {
        name = readCStringSafe(buf, nameOff, 80);
      }
      const hasSaneName = name.length >= 3 && /[a-zA-Z0-9_.-]/.test(name);
      if (hasSaneName || (rawOff !== 0 && dataOff % 16 === 0 && !seenOffsets.has(dataOff))) {
        const ext = name.includes('.') ? `.${name.split('.').pop()!.toLowerCase()}` : '.bin';
        let canDecompress: 'zlib' | 'gzip' | 'blz4' | 'blz2' | null = null;
        if (dataOff + 4 <= buf.length) {
          const m = readAscii(buf, dataOff, 4);
          if (m === 'BLZ4') canDecompress = 'blz4';
          else if (m === 'BLZ2') canDecompress = 'blz2';
          else if (buf[dataOff] === 0x1f && buf[dataOff + 1] === 0x8b) canDecompress = 'gzip';
          else if (buf[dataOff] === 0x78 && (buf[dataOff + 1] === 0x9c || buf[dataOff + 1] === 0xda)) canDecompress = 'zlib';
        }
        seenOffsets.add(dataOff);
        validSequential++;
        candidates.push({
          index: candidates.length + 1,
          offset: dataOff,
          signature: canDecompress ? canDecompress.toUpperCase() : 'PRES_TOC',
          category: 'EXECUTABLE_CONTAINER',
          label: name ? `Entrada PRES: ${name}` : `Subarchivo PRES TOC`,
          estimatedSize: compSize,
          suggestedExt: ext,
          suggestedName: name || undefined,
          canDecompress,
        });
        pos += 12; // advance full 16-byte record
      }
    }
  }

  if (validSequential >= 3) {
    hits.push(...candidates);
  }
  return hits;
}

export async function scanDatContainerSignatures(
  blob: Blob,
  maxScanBytes = 32 * 1024 * 1024,
  maxHits = 5000,
  onProgress?: (scanned: number, total: number, hitsFound: number) => void
): Promise<{
  hits: DatSignatureHit[];
  scannedBytes: number;
  zeroRatio: number;
  presTocCount: number;
}> {
  const limit = Math.min(blob.size, maxScanBytes);
  const CHUNK_SIZE = 2 * 1024 * 1024;
  const OVERLAP = 64;
  const hits: DatSignatureHit[] = [];
  const seenOffsets = new Set<number>();

  // First check if container has a structured PRES TOC
  const presEntries = await tryParsePresTocEntries(blob);
  for (const pe of presEntries) {
    if (hits.length >= maxHits) break;
    seenOffsets.add(pe.offset);
    hits.push(pe);
  }

  let zeroBytes = 0;
  let totalChecked = 0;

  for (let start = 0; start < limit && hits.length < maxHits; start += CHUNK_SIZE) {
    const end = Math.min(limit, start + CHUNK_SIZE + OVERLAP);
    const buf = new Uint8Array(await blob.slice(start, end).arrayBuffer());
    const effectiveLen = Math.min(buf.length, CHUNK_SIZE);

    for (let i = 0; i < effectiveLen && hits.length < maxHits; i++) {
      const b = buf[i];
      if (b === 0) zeroBytes++;

      // O(1) first-byte skip eliminates ~94% of positions on 201 MB RES.DAT
      if (SIG_FIRST_BYTE_MASK[b] === 0) continue;

      const absOff = start + i;
      if (seenOffsets.has(absOff)) continue;

      let matched = false;
      for (const sig of KNOWN_SIGS) {
        if (sig.bytes[0] !== b) continue;
        if (hasSubarrayAt(buf, i, sig.bytes)) {
          let estSize: number | null = null;
          if (sig.signature === 'RIFF' && i + 8 <= buf.length) {
            const dv = new DataView(buf.buffer, buf.byteOffset + i, 8);
            const riffLen = dv.getUint32(4, true) + 8;
            if (riffLen > 16 && riffLen < 128 * 1024 * 1024) estSize = riffLen;
          } else if (sig.signature === 'OMG.00.1PSP' || sig.signature === 'MIG.00.1PSP') {
            if (i + 24 <= buf.length) {
              const dv = new DataView(buf.buffer, buf.byteOffset + i, 24);
              const chunkSize = dv.getUint32(20, true) + 16;
              if (chunkSize > 32 && chunkSize < 32 * 1024 * 1024) estSize = chunkSize;
            }
          } else if (sig.signature === 'BLZ4' && i + 8 <= buf.length) {
            const dv = new DataView(buf.buffer, buf.byteOffset + i, 8);
            const decHint = dv.getUint32(4, true);
            if (decHint > 0 && decHint <= 64 * 1024 * 1024) {
              estSize = Math.min(decHint + 4096, blob.size - absOff);
            }
          }
          hits.push({
            index: hits.length + 1,
            offset: absOff,
            signature: sig.signature,
            category: sig.category,
            label: sig.label,
            estimatedSize: estSize,
            suggestedExt: sig.ext,
            canDecompress: sig.canDecompress ?? null,
          });
          seenOffsets.add(absOff);
          matched = true;
          break;
        }
      }

      // Also detect standard zlib streams aligned to 4 bytes (78 9C / 78 DA / 78 01 / 78 5E)
      if (
        !matched &&
        b === 0x78 &&
        absOff % 4 === 0 &&
        i + 2 < buf.length &&
        (buf[i + 1] === 0x9c || buf[i + 1] === 0xda || buf[i + 1] === 0x01 || buf[i + 1] === 0x5e)
      ) {
        hits.push({
          index: hits.length + 1,
          offset: absOff,
          signature: 'ZLIB',
          category: 'EXECUTABLE_CONTAINER',
          label: `Bloque comprimido ZLIB (0x78 0x${buf[i + 1].toString(16).toUpperCase()})`,
          estimatedSize: null,
          suggestedExt: '.zlib',
          canDecompress: 'zlib',
        });
        seenOffsets.add(absOff);
      }
    }

    totalChecked += effectiveLen;
    onProgress?.(Math.min(limit, start + effectiveLen), limit, hits.length);
    // Yield to UI thread so 201 MB scans remain responsive
    if (start % (8 * 1024 * 1024) === 0) {
      await new Promise((r) => setTimeout(r, 0));
    }
  }

  hits.sort((a, b) => a.offset - b.offset);
  for (let i = 0; i < hits.length; i++) {
    hits[i].index = i + 1;
    if (hits[i].estimatedSize === null) {
      const nextOff = i + 1 < hits.length ? hits[i + 1].offset : blob.size;
      const diff = nextOff - hits[i].offset;
      hits[i].estimatedSize =
        diff > 0 && diff <= 32 * 1024 * 1024
          ? diff
          : Math.min(256 * 1024, blob.size - hits[i].offset);
    }
  }

  return {
    hits,
    scannedBytes: limit,
    zeroRatio: totalChecked > 0 ? zeroBytes / totalChecked : 0,
    presTocCount: presEntries.length,
  };
}

export async function tryDecompressBlz2Bytes(slice: Uint8Array): Promise<Uint8Array | null> {
  if (slice.length < 16 || readAscii(slice, 0, 4) !== 'BLZ2') return null;
  const dv = new DataView(slice.buffer, slice.byteOffset, slice.byteLength);
  const declaredUncompressed = dv.getUint32(4, true);
  if (declaredUncompressed === 0 || declaredUncompressed > 64 * 1024 * 1024) return null;

  for (const startOff of [0x10, 0x08, 0x0c]) {
    if (startOff + 4 >= slice.length) continue;
    try {
      const chunks: Uint8Array[] = [];
      let totalOut = 0;
      let pos = startOff;
      let safety = 0;
      while (pos + 2 <= slice.length && totalOut < declaredUncompressed && safety < 4096) {
        safety++;
        const compLen = dv.getUint16(pos, true);
        pos += 2;
        if (compLen === 0 || pos + compLen > slice.length) break;
        const compSlice = slice.subarray(pos, pos + compLen);
        pos += compLen;
        const dec = await decompressWithStream(
          compSlice,
          compSlice[0] === 0x78 ? 'deflate' : 'deflate-raw'
        );
        chunks.push(dec);
        totalOut += dec.length;
      }
      if (totalOut > 0 && chunks.length > 0) {
        const out = new Uint8Array(totalOut);
        let wp = 0;
        for (const c of chunks) {
          out.set(c, wp);
          wp += c.length;
        }
        return out;
      }
    } catch {
      // try next start offset
    }
  }
  return null;
}

export async function tryDecompressBlz4Bytes(slice: Uint8Array): Promise<Uint8Array | null> {
  if (slice.length < 16 || readAscii(slice, 0, 4) !== 'BLZ4') return null;
  const dv = new DataView(slice.buffer, slice.byteOffset, slice.byteLength);
  const declaredUncompressed = dv.getUint32(4, true);
  if (declaredUncompressed === 0 || declaredUncompressed > 64 * 1024 * 1024) {
    return null;
  }

  // Some Bandai Namco BLZ4 streams start chunks at offset 0x08, 0x0c or 0x10
  const candidateStarts = [0x10, 0x08, 0x0c];
  for (const startOff of candidateStarts) {
    if (startOff + 4 >= slice.length) continue;
    try {
      const chunks: Uint8Array[] = [];
      let totalOut = 0;
      let pos = startOff;
      let safety = 0;

      while (pos + 2 <= slice.length && totalOut < declaredUncompressed && safety < 4096) {
        safety++;
        const compLen = dv.getUint16(pos, true);
        pos += 2;
        if (compLen === 0) {
          // Raw uncompressed 64KB chunk
          const rawLen = Math.min(65536, declaredUncompressed - totalOut, slice.length - pos);
          if (rawLen <= 0) break;
          chunks.push(slice.subarray(pos, pos + rawLen));
          pos += rawLen;
          totalOut += rawLen;
          continue;
        }
        if (pos + compLen > slice.length) break;
        const compSlice = slice.subarray(pos, pos + compLen);
        pos += compLen;
        let dec: Uint8Array;
        if (compSlice.length >= 2 && compSlice[0] === 0x78) {
          dec = await decompressWithStream(compSlice, 'deflate');
        } else {
          dec = await decompressWithStream(compSlice, 'deflate-raw');
        }
        chunks.push(dec);
        totalOut += dec.length;
      }

      if (totalOut > 0 && chunks.length > 0) {
        const out = new Uint8Array(totalOut);
        let writePos = 0;
        for (const c of chunks) {
          out.set(c, writePos);
          writePos += c.length;
        }
        return out;
      }
    } catch {
      // Try next header start offset
    }
  }
  return null;
}

function classifyDecompressedBytes(bytes: Uint8Array): {
  innerFormat: string;
  suggestedExt: string;
} {
  const ascii4 = readAscii(bytes, 0, 4);
  const ascii12 = readAscii(bytes, 0, 12);

  if (hasSubarrayAt(bytes, 0, [0x7f, 0x45, 0x4c, 0x46])) {
    return { innerFormat: 'Ejecutable ELF32 MIPS', suggestedExt: '.elf' };
  }
  if (ascii12.startsWith('OMG.00.1PSP')) {
    return { innerFormat: 'Modelo 3D PSP (.GMO)', suggestedExt: '.gmo' };
  }
  if (ascii12.startsWith('MIG.00.1PSP')) {
    return { innerFormat: 'Textura PSP (.GIM)', suggestedExt: '.gim' };
  }
  if (ascii4 === 'TIM2') {
    return { innerFormat: 'Textura TIM2', suggestedExt: '.tm2' };
  }
  if (hasSubarrayAt(bytes, 0, [0x89, 0x50, 0x4e, 0x47])) {
    return { innerFormat: 'Imagen PNG', suggestedExt: '.png' };
  }
  if (ascii4 === 'PGF0') {
    return { innerFormat: 'Fuente PGF', suggestedExt: '.pgf' };
  }
  if (ascii4 === 'PRES') {
    return { innerFormat: 'Subpaquete PRES', suggestedExt: '.pres' };
  }
  if (ascii4 === 'AFS2') {
    return { innerFormat: 'Banco Audio AFS2', suggestedExt: '.awb' };
  }
  if (ascii4 === 'RIFF') {
    return { innerFormat: 'Audio RIFF/AT3', suggestedExt: '.at3' };
  }
  if (readAscii(bytes, 0, 5) === '<?xml') {
    return { innerFormat: 'Documento XML', suggestedExt: '.xml' };
  }

  // Check if mostly printable UTF-8 / Shift-JIS text
  let printable = 0;
  const checkLen = Math.min(bytes.length, 512);
  for (let i = 0; i < checkLen; i++) {
    const b = bytes[i];
    if ((b >= 32 && b <= 126) || b === 9 || b === 10 || b === 13 || b >= 0x80) printable++;
  }
  if (checkLen > 16 && printable / checkLen > 0.85) {
    return { innerFormat: 'Tabla de Texto / Datos Legibles', suggestedExt: '.txt' };
  }

  return { innerFormat: 'Datos binarios descomprimidos', suggestedExt: '.bin' };
}

export async function decompressEmbeddedStreamAt(
  blob: Blob,
  offset: number,
  mode: 'zlib' | 'gzip' | 'blz4' | 'blz2',
  maxCompressedRead = 8 * 1024 * 1024
): Promise<{
  bytes: Uint8Array;
  innerFormat: string;
  suggestedExt: string;
}> {
  const slice = new Uint8Array(
    await blob.slice(offset, Math.min(blob.size, offset + maxCompressedRead)).arrayBuffer()
  );

  let bytes: Uint8Array;
  if (mode === 'blz4') {
    const blzDec = await tryDecompressBlz4Bytes(slice);
    if (!blzDec) {
      throw new Error('Variante BLZ4 no estándar o truncada en este bloque.');
    }
    bytes = blzDec;
  } else if (mode === 'blz2') {
    const blz2Dec = await tryDecompressBlz2Bytes(slice);
    if (!blz2Dec) {
      throw new Error('Variante BLZ2 no estándar o truncada en este bloque.');
    }
    bytes = blz2Dec;
  } else {
    bytes = await decompressWithStream(slice, mode === 'gzip' ? 'gzip' : 'deflate');
  }

  const detected = classifyDecompressedBytes(bytes);
  return { bytes, ...detected };
}

function parsePmfVideoHeader(head: Uint8Array): PmfVideoInfo {
  const dv = new DataView(head.buffer, head.byteOffset, head.byteLength);
  const version = readAscii(head, 4, 4) || '0014';
  const streamOffset = head.length >= 12 ? dv.getUint32(8, false) : 0x800;
  const streamSize = head.length >= 16 ? dv.getUint32(12, false) : 0;

  let width: number | null = null;
  let height: number | null = null;
  // Standard PSP PMF stores display width/height * 16 in bytes inside stream header around 0x80..0xB0 or 16-px units
  if (head.length >= 0x90) {
    const wCand = head[0x8e] * 16;
    const hCand = head[0x8f] * 16;
    if (wCand >= 128 && wCand <= 720 && hCand >= 64 && hCand <= 480) {
      width = wCand;
      height = hCand;
    }
  }
  if (width === null && head.length >= 0x50) {
    // Fallback common PSP video resolution hint
    width = 480;
    height = 272;
  }

  return {
    version,
    streamOffset,
    streamSize,
    width,
    height,
    codecLabel: 'H.264 / AVC Video + ATRAC3plus Audio (MPEG-PS UMD)',
  };
}

const SPANISH_AUDIT_CHARS = [
  'ñ',
  'Ñ',
  'á',
  'é',
  'í',
  'ó',
  'ú',
  'Á',
  'É',
  'Í',
  'Ó',
  'Ú',
  'ü',
  'Ü',
  '¡',
  '¿',
] as const;

function parsePgfFontHeader(fullOrHead: Uint8Array): PgfFontInfo {
  const dv = new DataView(fullOrHead.buffer, fullOrHead.byteOffset, fullOrHead.byteLength);
  // Sony PGF0 normally places magic "PGF0" at 0x04 (with headerOffset=0 at 0x00, headerSize at 0x02)
  const magicAt4 = readAscii(fullOrHead, 4, 4) === 'PGF0';
  const base = magicAt4 ? 0 : 0;

  let headerSize = 396;
  let version = '6.0';
  let charMapLength = 0;
  let charPtrLength = 0;
  let charMapBpe = 16;
  let bpp = 4;
  let fontName = 'PSP_FONT';
  let fontType = 'Standard PSP Bitmap/Glyph Font';
  let firstGlyph = 0x20;
  let lastGlyph = 0xffff;

  if (magicAt4 && fullOrHead.length >= 0x188) {
    headerSize = dv.getUint16(base + 2, true) || 396;
    const rev = dv.getUint32(base + 8, true);
    const ver = dv.getUint32(base + 12, true);
    version = `${ver}.${rev}`;
    charMapLength = dv.getUint32(base + 0x10, true);
    charPtrLength = dv.getUint32(base + 0x14, true);
    charMapBpe = dv.getUint32(base + 0x18, true) || 16;
    bpp = dv.getUint8(base + 0x20) || 4;
    fontName = readAscii(fullOrHead, base + 0x38, 64) || 'PSP_FONT';
    fontType = readAscii(fullOrHead, base + 0x78, 64) || 'PSP Glyph Font';
    firstGlyph = dv.getUint16(base + 0xb8, true);
    lastGlyph = dv.getUint16(base + 0xba, true);
  } else {
    headerSize = fullOrHead.length >= 8 ? dv.getUint16(4, true) : 0;
    const versionMajor = fullOrHead.length >= 10 ? dv.getUint16(6, true) : 0;
    const versionMinor = fullOrHead.length >= 12 ? dv.getUint16(8, true) : 0;
    charMapLength = fullOrHead.length >= 16 ? dv.getUint32(12, true) : 0;
    charPtrLength = fullOrHead.length >= 24 ? dv.getUint32(20, true) : 0;
    bpp = fullOrHead.length >= 28 ? dv.getUint32(24, true) : 4;
    fontName = readAscii(fullOrHead, 0x48, 64) || readAscii(fullOrHead, 0x20, 32) || 'PSP_FONT';
    fontType = readAscii(fullOrHead, 0x88, 64) || 'Standard PSP Bitmap/Glyph Font';
    version = `${versionMajor}.${versionMinor}`;
  }

  // Locate charmap table if standard 396-byte PSP PGF header is complete
  let charMapStart = -1;
  if (magicAt4 && fullOrHead.length >= 0x188) {
    const dimLen = dv.getUint16(0x144, true);
    const xAdjLen = dv.getUint16(0x146, true);
    const yAdjLen = dv.getUint16(0x148, true);
    const advLen = dv.getUint16(0x14a, true);
    const shadowMapLen = dv.getUint32(0x17c, true);
    const shadowMapBpe = dv.getUint32(0x180, true);
    const shadowBytes = Math.ceil((shadowMapLen * shadowMapBpe) / 8);
    const candidate =
      headerSize + (dimLen + xAdjLen + yAdjLen + advLen) * 8 + shadowBytes;
    if (candidate > 0 && candidate < fullOrHead.length) {
      charMapStart = candidate;
    }
  }

  const readBitPacked = (offsetBytes: number, bitIndex: number, bpe: number): number | null => {
    const totalBit = offsetBytes * 8 + bitIndex * bpe;
    const endByte = Math.floor((totalBit + bpe - 1) / 8);
    if (endByte >= fullOrHead.length || bpe <= 0 || bpe > 31) return null;
    let val = 0;
    for (let b = 0; b < bpe; b++) {
      const bitPos = totalBit + b;
      const byteVal = fullOrHead[bitPos >>> 3];
      const bit = (byteVal >>> (bitPos & 7)) & 1;
      val |= bit << b;
    }
    return val;
  };

  let verifiedCount = 0;
  let supportedCount = 0;
  const spanishAudit: PgfSpanishGlyphStatus[] = SPANISH_AUDIT_CHARS.map((ch) => {
    const cp = ch.codePointAt(0)!;
    const codePointHex = `U+${cp.toString(16).toUpperCase().padStart(4, '0')}`;
    let supported: boolean | null = null;

    if (cp < firstGlyph || cp > lastGlyph) {
      supported = false;
      verifiedCount++;
    } else if (charMapStart >= 0 && charMapBpe > 0 && charMapBpe <= 24) {
      const idx = cp - firstGlyph;
      if (idx < charMapLength) {
        const mapped = readBitPacked(charMapStart, idx, charMapBpe);
        if (mapped !== null) {
          const emptySentinel = (1 << charMapBpe) - 1;
          supported = mapped !== emptySentinel && mapped < Math.max(charPtrLength, 65535);
          verifiedCount++;
          if (supported) supportedCount++;
        }
      }
    }

    return { char: ch, codePointHex, supported };
  });

  const spanishAuditSummary =
    verifiedCount === SPANISH_AUDIT_CHARS.length
      ? supportedCount === SPANISH_AUDIT_CHARS.length
        ? `Soporte completo al Español (${supportedCount}/${SPANISH_AUDIT_CHARS.length} caracteres presentes: ñ, tildes, ü, ¡, ¿).`
        : supportedCount === 0
        ? `Alerta de traducción: 0/${SPANISH_AUDIT_CHARS.length} caracteres españoles detectados en charMap (rango U+${firstGlyph.toString(16).toUpperCase()}..U+${lastGlyph.toString(16).toUpperCase()}). Necesitarás reemplazar glifos o parchear font.pgf.`
        : `Soporte parcial al Español (${supportedCount}/${SPANISH_AUDIT_CHARS.length} caracteres verificados en charMap). Revisa los faltantes antes de insertar tildes/ñ.`
      : `Rango Unicode PGF: U+${firstGlyph.toString(16).toUpperCase()}–U+${lastGlyph.toString(16).toUpperCase()} (${charMapLength.toLocaleString('es-ES')} entradas charMap).`;

  return {
    headerSize,
    version,
    fontName,
    fontType,
    glyphCount: charPtrLength || charMapLength,
    charMapLength,
    bpp,
    firstGlyph,
    lastGlyph,
    spanishAudit,
    spanishAuditSummary,
  };
}

function decodeTim2Preview(bytes: Uint8Array): ImageDecodeInfo {
  if (bytes.length < 64 || readAscii(bytes, 0, 4) !== 'TIM2') {
    return { format: 'TIM2', width: null, height: null, bpp: null, pixelInfo: 'Cabecera TIM2 incompleta', previewUrl: null };
  }
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const picHeaderOffset = 16;
  const totalSize = dv.getUint32(picHeaderOffset, true);
  const clutSize = dv.getUint32(picHeaderOffset + 4, true);
  const imageSize = dv.getUint32(picHeaderOffset + 8, true);
  const headerSize = dv.getUint16(picHeaderOffset + 12, true) || 48;
  const imgType = bytes[picHeaderOffset + 19]; // 1=16bpp, 2=24bpp, 3=32bpp, 4=4bpp, 5=8bpp
  const width = dv.getUint16(picHeaderOffset + 20, true);
  const height = dv.getUint16(picHeaderOffset + 22, true);
  const bppMap: Record<number, number> = { 1: 16, 2: 24, 3: 32, 4: 4, 5: 8 };
  const bpp = bppMap[imgType] ?? 32;

  let previewUrl: string | null = null;
  const pixelDataStart = picHeaderOffset + headerSize;
  if (
    typeof document !== 'undefined' &&
    imgType === 3 &&
    width > 0 &&
    height > 0 &&
    width <= 1024 &&
    height <= 1024 &&
    pixelDataStart + width * height * 4 <= bytes.length
  ) {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      const imgData = ctx.createImageData(width, height);
      imgData.data.set(bytes.subarray(pixelDataStart, pixelDataStart + width * height * 4));
      ctx.putImageData(imgData, 0, 0);
      previewUrl = canvas.toDataURL('image/png');
    }
  }

  return {
    format: 'TIM2',
    width,
    height,
    bpp,
    pixelInfo: `Total ${totalSize} B · Imagen ${imageSize} B · CLUT ${clutSize} B`,
    previewUrl,
  };
}

export async function decryptOrUnpackBlob(
  item: UniversalClassifiedItem,
  maxDatScanBytes = 32 * 1024 * 1024
): Promise<UniversalDecryptResult> {
  const head = new Uint8Array(
    await item.blob.slice(0, Math.min(item.blob.size, 64 * 1024)).arrayBuffer()
  );
  const ascii4 = readAscii(head, 0, 4);
  const ascii12 = readAscii(head, 0, 12);
  const ext = getExt(item.name);
  const upperName = item.name.toUpperCase();

  // 1. ~PSP / ELF / PRX / EBOOT.BIN / BOOT.BIN
  if (
    ascii4 === '~PSP' ||
    hasSubarrayAt(head, 0, [0x7f, 0x45, 0x4c, 0x46]) ||
    ext === '.prx' ||
    upperName === 'EBOOT.BIN' ||
    upperName === 'BOOT.BIN'
  ) {
    const isElf = hasSubarrayAt(head, 0, [0x7f, 0x45, 0x4c, 0x46]);
    const pspInfo = parsePspModuleHeader(head);

    if (isElf) {
      const fullBytes =
        item.blob.size <= 32 * 1024 * 1024
          ? new Uint8Array(await item.blob.arrayBuffer())
          : head;
      return {
        fileName: item.name,
        filePath: item.path,
        fileSize: item.size,
        detectedKind: 'PSP_MODULE',
        summaryTitle: `${item.name} ya está descifrado (ELF32 MIPS)`,
        summaryStatus: 'DECRYPTED',
        details: [
          { label: 'Cabecera mágica', value: '0x7F E L F (ELF32 estándar)' },
          { label: 'Tamaño total', value: `${item.size.toLocaleString('es-ES')} bytes` },
          { label: 'Estado', value: 'Listo para editar textos/RAM/HxD sin desencriptado adicional' },
        ],
        notes: [
          'Este ejecutable ya es un ELF32 MIPS descifrado.',
          'Puedes analizar sus cadenas de texto directamente o abrirlo en el Editor HxD.',
        ],
        pspInfo,
        decompressedBytes: fullBytes,
        decompressedName: item.name.replace(/\.(bin|prx)$/i, '.elf'),
      };
    }

    // Attempt GZIP extraction if ~PSP contains embedded gzip stream
    if (pspInfo.gzipOffset !== null && item.blob.size <= 32 * 1024 * 1024) {
      try {
        const fullBuf = new Uint8Array(await item.blob.arrayBuffer());
        const gzPayload = fullBuf.subarray(pspInfo.gzipOffset);
        const elfBytes = await decompressWithStream(gzPayload, 'gzip');
        const innerIsElf = hasSubarrayAt(elfBytes, 0, [0x7f, 0x45, 0x4c, 0x46]);

        return {
          fileName: item.name,
          filePath: item.path,
          fileSize: item.size,
          detectedKind: 'PSP_MODULE',
          summaryTitle: `${item.name} descomprimido correctamente (${elfBytes.length.toLocaleString('es-ES')} bytes)`,
          summaryStatus: 'DECRYPTED',
          details: [
            { label: 'Módulo ~PSP', value: pspInfo.modName },
            { label: 'Versión SDK / Devkit', value: pspInfo.devkitVersion },
            { label: 'Offset GZIP interno', value: `0x${pspInfo.gzipOffset.toString(16).toUpperCase()}` },
            { label: 'Tamaño ELF extraído', value: `${elfBytes.length.toLocaleString('es-ES')} bytes (${innerIsElf ? 'ELF32 válido' : 'Binario'})` },
          ],
          notes: [
            'Se detectó compresión GZIP dentro de la cabecera ~PSP y se extrajo el ejecutable plano en navegador.',
            'Descarga el archivo .ELF/.PRX descifrado o envíalo al Analizador de Textos.',
          ],
          pspInfo,
          decompressedBytes: elfBytes,
          decompressedName: `${item.name.replace(/\.(bin|prx)$/i, '')}_DEC.ELF`,
        };
      } catch {
        // Fall through to Kirk locked report
      }
    }

    return {
      fileName: item.name,
      filePath: item.path,
      fileSize: item.size,
      detectedKind: 'PSP_MODULE',
      summaryTitle: `Módulo ~PSP analizado: ${pspInfo.modName}`,
      summaryStatus: pspInfo.isKirkEncrypted ? 'KIRK_HARDWARE_LOCKED' : 'PARSED',
      details: [
        { label: 'Nombre interno (~PSP)', value: pspInfo.modName },
        { label: 'Versión módulo', value: `${pspInfo.versionMajor}.${pspInfo.versionMinor}` },
        { label: 'Tamaño ELF declarado', value: `${pspInfo.elfSize.toLocaleString('es-ES')} B` },
        { label: 'Tamaño ~PSP en disco', value: `${pspInfo.pspSize.toLocaleString('es-ES')} B` },
        { label: 'Devkit SDK', value: pspInfo.devkitVersion },
        { label: 'Tag Kirk (0xD0)', value: pspInfo.tagHex || 'N/D' },
      ],
      notes: [
        'Los ejecutables EBOOT.BIN y PRX oficiales cifrados con el motor hardware Kirk (~PSP sin bloque GZIP plano) requieren las llaves internas del procesador Kirk de PSP o ejecutar "Decrypted EBOOTs" en PPSSPP (Settings > Tools > Developer tools > Dump decrypted EBOOT.BIN) para obtener el ELF plano.',
        'La cabecera ~PSP se leyó correctamente y el BOOT.BIN del mismo directorio (cuando viene sin cifrar) suele contener el ELF directo.',
      ],
      pspInfo,
    };
  }

  // 2. CRIWARE .AWB (AFS2)
  if (ascii4 === 'AFS2' || ext === '.awb') {
    const parsedAwb = await parseAwbAfs2(item.blob);
    return {
      fileName: item.name,
      filePath: item.path,
      fileSize: item.size,
      detectedKind: 'AWB_AFS2',
      summaryTitle: `Banco CRIWARE AFS2 desempaquetado: ${parsedAwb.tracks.length} pistas`,
      summaryStatus: 'UNPACKED',
      details: [
        { label: 'Formato', value: 'CRIWARE AFS2 (.AWB)' },
        { label: 'Total de pistas', value: parsedAwb.tracks.length.toLocaleString('es-ES') },
        { label: 'Tamaño de puntero', value: `${parsedAwb.offsetSize} bytes` },
        { label: 'Alineación de sectores', value: `${parsedAwb.alignment} bytes` },
        { label: 'Tamaño total', value: `${(item.size / (1024 * 1024)).toFixed(2)} MB` },
      ],
      notes: [
        'Lectura por streaming (sin cargar el archivo entero en RAM): compatible con voice.awb de 837+ MB.',
        'Puedes descargar cualquier pista individual al instante o exportar un paquete .ZIP con las pistas.',
      ],
      awbTracks: parsedAwb.tracks,
      awbOffsetSize: parsedAwb.offsetSize,
      awbAlignment: parsedAwb.alignment,
    };
  }

  // 3. .PMF (PSMF Video)
  if (ascii4 === 'PSMF' || ext === '.pmf') {
    const pmf = parsePmfVideoHeader(head);
    return {
      fileName: item.name,
      filePath: item.path,
      fileSize: item.size,
      detectedKind: 'PMF_VIDEO',
      summaryTitle: `Video PSP PSMF${pmf.version} analizado`,
      summaryStatus: 'PARSED',
      details: [
        { label: 'Cabecera', value: `PSMF${pmf.version}` },
        { label: 'Resolución estimada', value: pmf.width && pmf.height ? `${pmf.width} × ${pmf.height} px` : '480 × 272 px' },
        { label: 'Offset stream MPEG-PS', value: `0x${pmf.streamOffset.toString(16).toUpperCase()}` },
        { label: 'Tamaño stream multimedia', value: `${pmf.streamSize.toLocaleString('es-ES')} bytes` },
        { label: 'Códecs', value: pmf.codecLabel },
      ],
      notes: [
        'Usa "Extraer stream MPEG/H.264" para separar el video/audio multiplexado de la cabecera PSMF.',
      ],
      pmfInfo: pmf,
    };
  }

  // 4. .PGF Font
  if (ascii4 === 'PGF0' || readAscii(head, 4, 4) === 'PGF0' || ext === '.pgf') {
    const pgfSlice = new Uint8Array(
      await item.blob.slice(0, Math.min(item.blob.size, 2 * 1024 * 1024)).arrayBuffer()
    );
    const pgf = parsePgfFontHeader(pgfSlice);
    return {
      fileName: item.name,
      filePath: item.path,
      fileSize: item.size,
      detectedKind: 'PGF_FONT',
      summaryTitle: `Fuente PSP PGF0: ${pgf.fontName}`,
      summaryStatus: 'PARSED',
      details: [
        { label: 'Nombre de fuente', value: pgf.fontName },
        { label: 'Estilo / Familia', value: pgf.fontType },
        { label: 'Versión PGF', value: pgf.version },
        { label: 'Tamaño cabecera', value: `${pgf.headerSize} bytes` },
        { label: 'Glifos / Entradas', value: pgf.glyphCount.toLocaleString('es-ES') },
        { label: 'Profundidad (BPP)', value: `${pgf.bpp} bpp` },
      ],
      notes: [
        'Archivo de tipografía del juego (font.pgf). No contiene diálogos, pero define qué caracteres puede dibujar el motor en pantalla.',
        pgf.spanishAuditSummary,
      ],
      pgfInfo: pgf,
    };
  }

  // 5. PARAM.SFO
  if (hasSubarrayAt(head, 0, [0x00, 0x50, 0x53, 0x46]) || upperName === 'PARAM.SFO' || ext === '.sfo') {
    const fullBytes = new Uint8Array(await item.blob.slice(0, Math.min(item.blob.size, 512 * 1024)).arrayBuffer());
    const sfo = parseParamSfo(fullBytes);
    const sfoRawPairs = sfo
      ? [
          { key: 'TITLE', value: sfo.title },
          { key: 'DISC_ID', value: sfo.discId },
          { key: 'DISC_VERSION', value: sfo.discVersion },
          { key: 'PSP_SYSTEM_VER', value: sfo.pspSystemVer },
          { key: 'CATEGORY', value: sfo.categoryLabel },
          { key: 'PARENTAL_LEVEL', value: String(sfo.parentalLevel) },
        ]
      : [];
    return {
      fileName: item.name,
      filePath: item.path,
      fileSize: item.size,
      detectedKind: 'PARAM_SFO',
      summaryTitle: sfo ? `PARAM.SFO: ${sfo.title} (${sfo.discId})` : 'Tabla PARAM.SFO',
      summaryStatus: 'PARSED',
      details: sfoRawPairs.map((p) => ({ label: p.key, value: p.value })),
      notes: ['Tabla oficial de metadatos PSF/SFO decodificada correctamente.'],
      sfoInfo: sfo ?? undefined,
      sfoRawPairs,
    };
  }

  // 6. UMD_DATA.BIN
  if (upperName === 'UMD_DATA.BIN') {
    const rawText = new TextDecoder('ascii', { fatal: false }).decode(head).replace(/\0+$/, '').trim();
    const fields = rawText.split('|');
    return {
      fileName: item.name,
      filePath: item.path,
      fileSize: item.size,
      detectedKind: 'UMD_DATA',
      summaryTitle: `UMD_DATA.BIN: ${fields[0] || rawText}`,
      summaryStatus: 'PARSED',
      details: [
        { label: 'ID de Disco UMD', value: fields[0] || '—' },
        { label: 'Hash / Firma disco', value: fields[1] || '—' },
        { label: 'Versión UMD', value: fields[2] || '—' },
        { label: 'Tipo', value: fields[3] || 'G (Juego PSP)' },
      ],
      notes: ['Descriptor de volumen UMD decodificado en claro.'],
      umdDataFields: fields,
    };
  }

  // 7. Images (PNG / TIM2 / GIM)
  if (
    hasSubarrayAt(head, 0, [0x89, 0x50, 0x4e, 0x47]) ||
    ascii4 === 'TIM2' ||
    ascii12.startsWith('MIG.00.1PSP') ||
    ['.png', '.gim', '.tm2', '.tim2', '.jpg', '.jpeg', '.bmp'].includes(ext)
  ) {
    let imageInfo: ImageDecodeInfo = {
      format: 'UNKNOWN',
      width: null,
      height: null,
      bpp: null,
      pixelInfo: 'Formato gráfico',
      previewUrl: null,
    };

    if (hasSubarrayAt(head, 0, [0x89, 0x50, 0x4e, 0x47]) || ext === '.png') {
      const dv = new DataView(head.buffer, head.byteOffset, head.byteLength);
      const width = head.length >= 24 ? dv.getUint32(16, false) : null;
      const height = head.length >= 24 ? dv.getUint32(20, false) : null;
      const bitDepth = head.length >= 25 ? head[24] : null;
      const previewUrl = item.blob.size <= 16 * 1024 * 1024 ? URL.createObjectURL(item.blob) : null;
      imageInfo = {
        format: 'PNG',
        width,
        height,
        bpp: bitDepth ? bitDepth * 4 : 32,
        pixelInfo: `IHDR ${width ?? '?'}×${height ?? '?'} px · Profundidad ${bitDepth ?? '?'} bits/canal`,
        previewUrl,
      };
    } else if (ascii4 === 'TIM2' || ext === '.tm2' || ext === '.tim2') {
      const bytes = new Uint8Array(
        await item.blob.slice(0, Math.min(item.blob.size, 8 * 1024 * 1024)).arrayBuffer()
      );
      imageInfo = decodeTim2Preview(bytes);
    } else if (ascii12.startsWith('MIG.00.1PSP') || ext === '.gim') {
      imageInfo = {
        format: 'GIM',
        width: null,
        height: null,
        bpp: null,
        pixelInfo: 'Cabecera oficial Sony PSP GIM (MIG.00.1PSP)',
        previewUrl: null,
      };
    } else {
      const previewUrl = item.blob.size <= 16 * 1024 * 1024 ? URL.createObjectURL(item.blob) : null;
      imageInfo = {
        format: ext === '.bmp' ? 'BMP' : 'JPG',
        width: null,
        height: null,
        bpp: null,
        pixelInfo: `Imagen ${ext.toUpperCase()}`,
        previewUrl,
      };
    }

    return {
      fileName: item.name,
      filePath: item.path,
      fileSize: item.size,
      detectedKind: 'IMAGE_ASSET',
      summaryTitle: `Imagen ${imageInfo.format}${imageInfo.width ? ` (${imageInfo.width}×${imageInfo.height})` : ''}`,
      summaryStatus: 'PARSED',
      details: [
        { label: 'Formato', value: imageInfo.format },
        { label: 'Dimensiones', value: imageInfo.width && imageInfo.height ? `${imageInfo.width} × ${imageInfo.height} px` : 'Según contenedor' },
        { label: 'Detalle de píxeles', value: imageInfo.pixelInfo },
      ],
      notes: ['Recurso gráfico inspeccionado sin pérdidas.'],
      imageInfo,
    };
  }

  // 8. .DAT / .BIN / Containers (RES.DAT, first.dat, envpsp.dat, DATA.BIN, OPNSSMP.BIN, DUMMY.DAT)
  const scan = await scanDatContainerSignatures(item.blob, maxDatScanBytes, 5000);
  return {
    fileName: item.name,
    filePath: item.path,
    fileSize: item.size,
    detectedKind: 'DAT_CONTAINER',
    summaryTitle:
      scan.zeroRatio > 0.99
        ? `${item.name}: Archivo de relleno / padding (${(scan.zeroRatio * 100).toFixed(1)}% ceros)`
        : `${item.name}: ${scan.hits.length} firmas / subarchivos / bloques comprimidos detectados`,
    summaryStatus: scan.hits.length > 0 ? 'UNPACKED' : 'PARSED',
    details: [
      { label: 'Cabecera inicial', value: `${ascii4 || 'Binario'} (${bytesToHex(head, 8)})` },
      { label: 'Tamaño total', value: `${(item.size / (1024 * 1024)).toFixed(2)} MB (${item.size.toLocaleString('es-ES')} B)` },
      { label: 'Rango escaneado', value: `${(scan.scannedBytes / (1024 * 1024)).toFixed(2)} MB` },
      { label: 'Entradas PRES TOC', value: `${scan.presTocCount}` },
      { label: 'Densidad de ceros (0x00)', value: `${(scan.zeroRatio * 100).toFixed(1)}%` },
      { label: 'Total subarchivos / bloques', value: `${scan.hits.length}` },
    ],
    notes:
      scan.zeroRatio > 0.99
        ? [
            'Este archivo (ej. DUMMY.DAT) contiene únicamente ceros de relleno para ajustar los sectores LBA físicos del UMD.',
          ]
        : [
            'Se escanearon tablas PRES TOC, bloques BLZ4/BLZ2/zlib/gzip y activos internos (OMG modelos 3D, MIG/TIM2/PNG texturas, PSMF videos, AFS2/RIFF/HCA audios, PGF, ~PSP/ELF).',
            'Pulsa "Extraer TODO el Contenido (.ZIP)" o "Extraer TODO a Carpeta" para desencriptar/descomprimir y dividir todo el archivo sin límites.',
          ],
    datHits: scan.hits,
    datScannedBytes: scan.scannedBytes,
    datZeroRatio: scan.zeroRatio,
    datPresEntryCount: scan.presTocCount,
  };
}

export interface FullDatExtractionSummary {
  fileName: string;
  totalHitsDetected: number;
  decompressedBlocks: number;
  nestedExtracted: number;
  rawBlocksCopied: number;
  textStringsExtracted: number;
  totalOutputBytes: number;
  zipBlob?: Blob;
  folderName?: string;
}

interface WritableDirectoryLike {
  name: string;
  getDirectoryHandle(name: string, options?: { create?: boolean }): Promise<WritableDirectoryLike>;
  getFileHandle(name: string, options?: { create?: boolean }): Promise<{
    createWritable(): Promise<{
      write(data: Blob | Uint8Array | string): Promise<void>;
      close(): Promise<void>;
    }>;
  }>;
}

async function writeFileToDirTree(
  rootDir: WritableDirectoryLike,
  relativePath: string,
  data: Blob | Uint8Array | string
) {
  const parts = relativePath.split('/').filter(Boolean);
  if (parts.length === 0) return;
  let dir = rootDir;
  for (let i = 0; i < parts.length - 1; i++) {
    dir = await dir.getDirectoryHandle(parts[i], { create: true });
  }
  const fh = await dir.getFileHandle(parts[parts.length - 1], { create: true });
  const writable = await fh.createWritable();
  await writable.write(data);
  await writable.close();
}

function sanitizeArchiveName(name: string): string {
  return name.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_');
}

function extractReadableTextLinesFromBytes(bytes: Uint8Array, label: string): string[] {
  const lines: string[] = [];
  const decSj = new TextDecoder('shift_jis', { fatal: false });
  const decUtf8 = new TextDecoder('utf-8', { fatal: false });
  // Scan null-terminated / printable chunks cleanly up to first 1 MB of each block
  const limit = Math.min(bytes.length, 1024 * 1024);
  let start = -1;
  for (let i = 0; i <= limit; i++) {
    const b = i < limit ? bytes[i] : 0;
    const isByteText = b >= 32 && b <= 126 || b >= 0x80;
    if (isByteText) {
      if (start === -1) start = i;
    } else if (start !== -1) {
      const len = i - start;
      if (len >= 5) {
        const sub = bytes.subarray(start, i);
        const sUtf8 = decUtf8.decode(sub);
        const sSj = decSj.decode(sub);
        const picked = /[\u3040-\u30ff\u4e00-\u9faf]/.test(sSj) && !sSj.includes('\ufffd') ? sSj : sUtf8;
        const clean = picked.replace(/[\x00-\x1F\x7F\ufffd]/g, '').trim();
        if (clean.length >= 5 && (/[A-Za-z0-9]{3,}/.test(clean) || /[\u3040-\u30ff\u4e00-\u9faf]/.test(clean))) {
          lines.push(`[${label} +0x${start.toString(16).toUpperCase()}] ${clean}`);
        }
      }
      start = -1;
      if (lines.length >= 400) break;
    }
  }
  return lines;
}

export async function extractAllDatContents(
  items: Array<{ blob: Blob; fileName: string }>,
  options: {
    targetDirHandle?: unknown;
    includeRawContainerSlices?: boolean;
    onProgress?: (phase: string, done: number, total: number) => void;
  } = {}
): Promise<FullDatExtractionSummary> {
  const dirHandle = options.targetDirHandle as WritableDirectoryLike | undefined;
  const includeRaw = options.includeRawContainerSlices ?? true;
  const zipEntries: AsyncZipInputEntry[] = [];

  let totalHitsDetected = 0;
  let decompressedBlocks = 0;
  let nestedExtracted = 0;
  let rawBlocksCopied = 0;
  let totalOutputBytes = 0;
  const manifestLines: string[] = [
    'MANIFIESTO DE EXTRACCIÓN COMPLETA (.DAT / .BIN PSP)',
    '='.repeat(78),
  ];
  const extractedTexts: string[] = [
    'TEXTOS DETECTADOS DURANTE LA EXTRACCIÓN (Shift-JIS / UTF-8)',
    '='.repeat(78),
  ];

  const emitFile = async (relPath: string, data: Blob | Uint8Array) => {
    const sz = data instanceof Blob ? data.size : data.length;
    totalOutputBytes += sz;
    if (dirHandle) {
      await writeFileToDirTree(dirHandle, relPath, data);
    } else {
      zipEntries.push({ path: relPath, data });
    }
  };

  for (let fIdx = 0; fIdx < items.length; fIdx++) {
    const { blob, fileName } = items[fIdx];
    const baseFolder = sanitizeArchiveName(fileName.replace(/\.[^.]+$/, '') || fileName);
    options.onProgress?.(`Escaneando ${fileName} (100%)…`, 0, blob.size);

    const scan = await scanDatContainerSignatures(blob, blob.size, 100000, (scanned, total, hitsFound) => {
      options.onProgress?.(`Escaneando ${fileName} (${hitsFound} hallazgos)…`, scanned, total);
    });

    totalHitsDetected += scan.hits.length;
    manifestLines.push(
      `\nArchivo: ${fileName} (${blob.size.toLocaleString('es-ES')} B) · Hallazgos: ${scan.hits.length} · Entradas PRES TOC: ${scan.presTocCount}`
    );

    if (scan.hits.length === 0) {
      // No known signatures found — extract any readable text + raw copy
      const headScan = new Uint8Array(await blob.slice(0, Math.min(blob.size, 4 * 1024 * 1024)).arrayBuffer());
      const lines = extractReadableTextLinesFromBytes(headScan, fileName);
      extractedTexts.push(...lines);
      if (includeRaw) {
        await emitFile(`${baseFolder}/${sanitizeArchiveName(fileName)}`, blob);
        rawBlocksCopied++;
      }
      continue;
    }

    for (let i = 0; i < scan.hits.length; i++) {
      const h = scan.hits[i];
      if (i % 15 === 0 || i === scan.hits.length - 1) {
        options.onProgress?.(`Extrayendo ${fileName}: bloque ${i + 1}/${scan.hits.length}`, i + 1, scan.hits.length);
      }

      const hexOff = `0x${h.offset.toString(16).toUpperCase().padStart(8, '0')}`;
      const idxStr = String(h.index).padStart(5, '0');
      const cleanOrigName = h.suggestedName ? sanitizeArchiveName(h.suggestedName) : null;

      if (h.canDecompress) {
        try {
          const dec = await decompressEmbeddedStreamAt(blob, h.offset, h.canDecompress, 12 * 1024 * 1024);
          decompressedBlocks++;
          const outName = cleanOrigName
            ? `${baseFolder}/descomprimidos/${idxStr}_${cleanOrigName}`
            : `${baseFolder}/descomprimidos/${idxStr}_${hexOff}_${h.signature}_DEC${dec.suggestedExt}`;
          await emitFile(outName, dec.bytes);
          manifestLines.push(`  [DEC ${h.signature}] ${hexOff} -> ${outName} (${dec.bytes.length} B · ${dec.innerFormat})`);

          // Collect readable text strings from decompressed block
          const txtLines = extractReadableTextLinesFromBytes(dec.bytes, `${fileName}@${hexOff}`);
          if (txtLines.length > 0) extractedTexts.push(...txtLines);

          // Level-2 recursive extraction if decompressed block contains nested PRES/BLZ4/ZLIB
          if (dec.bytes.length >= 64) {
            for (let nOff = 16; nOff + 16 < Math.min(dec.bytes.length, 2 * 1024 * 1024); nOff += 4) {
              const isSubBlz4 =
                dec.bytes[nOff] === 0x42 && dec.bytes[nOff + 1] === 0x4c && dec.bytes[nOff + 2] === 0x5a && dec.bytes[nOff + 3] === 0x34;
              const isSubZlib =
                dec.bytes[nOff] === 0x78 && (dec.bytes[nOff + 1] === 0x9c || dec.bytes[nOff + 1] === 0xda);
              if (!isSubBlz4 && !isSubZlib) continue;
              try {
                const subDec = isSubBlz4
                  ? await tryDecompressBlz4Bytes(dec.bytes.subarray(nOff))
                  : await decompressWithStream(dec.bytes.subarray(nOff), 'deflate');
                if (subDec && subDec.length > 0) {
                  nestedExtracted++;
                  const subClass = classifyDecompressedBytes(subDec);
                  const subName = `${baseFolder}/descomprimidos/${idxStr}_${hexOff}_sub_${nestedExtracted}${subClass.suggestedExt}`;
                  await emitFile(subName, subDec);
                  const subTxt = extractReadableTextLinesFromBytes(subDec, `${fileName}@${hexOff}#${nestedExtracted}`);
                  if (subTxt.length > 0) extractedTexts.push(...subTxt);
                }
              } catch {
                // ignore invalid nested header
              }
            }
          }
          continue;
        } catch {
          // Fall through to raw block extraction
        }
      }

      if (includeRaw) {
        const sliceSize =
          h.estimatedSize !== null && h.estimatedSize > 0
            ? Math.min(h.estimatedSize, blob.size - h.offset, 32 * 1024 * 1024)
            : Math.min(512 * 1024, blob.size - h.offset);

        if (sliceSize > 0) {
          const outName = cleanOrigName
            ? `${baseFolder}/subarchivos/${idxStr}_${cleanOrigName}`
            : `${baseFolder}/subarchivos/${idxStr}_${hexOff}_${sanitizeArchiveName(h.signature)}${h.suggestedExt}`;
          const sliceBlob = blob.slice(h.offset, h.offset + sliceSize);
          await emitFile(outName, sliceBlob);
          rawBlocksCopied++;
          manifestLines.push(`  [RAW ${h.signature}] ${hexOff} -> ${outName} (${sliceSize} B)`);

          // Extract direct text lines on smaller non-media blocks
          if (h.category === 'EXECUTABLE_CONTAINER' || h.category === 'TEXT') {
            const sampleArr = new Uint8Array(await sliceBlob.slice(0, Math.min(sliceSize, 256 * 1024)).arrayBuffer());
            const txtLines = extractReadableTextLinesFromBytes(sampleArr, `${fileName}@${hexOff}`);
            if (txtLines.length > 0) extractedTexts.push(...txtLines);
          }
        }
      }
    }
  }

  const encoder = new TextEncoder();
  await emitFile('_INDICE_EXTRACCION.txt', encoder.encode(manifestLines.join('\n')));
  await emitFile('_TEXTOS_EXTRAIDOS_SHIFTJIS_UTF8.txt', encoder.encode(extractedTexts.join('\n')));

  if (dirHandle) {
    return {
      fileName: items.map((i) => i.fileName).join(' + '),
      totalHitsDetected,
      decompressedBlocks,
      nestedExtracted,
      rawBlocksCopied,
      textStringsExtracted: Math.max(0, extractedTexts.length - 2),
      totalOutputBytes,
      folderName: dirHandle.name,
    };
  }

  options.onProgress?.('Empaquetando archivo .ZIP final…', zipEntries.length, zipEntries.length);
  const zipBlob = await buildZipBlobAsync(zipEntries, (done, total, cur) => {
    options.onProgress?.(`Empaquetando ZIP: ${cur}`, done, total);
  });

  return {
    fileName: items.map((i) => i.fileName).join(' + '),
    totalHitsDetected,
    decompressedBlocks,
    nestedExtracted,
    rawBlocksCopied,
    textStringsExtracted: Math.max(0, extractedTexts.length - 2),
    totalOutputBytes,
    zipBlob,
  };
}

export async function unpackDatSubfilesToZip(
  blob: Blob,
  fileName: string,
  hits: DatSignatureHit[],
  maxEntries = 100000,
  onProgress?: (done: number, total: number, currentPath: string) => void
): Promise<Blob> {
  const subset = hits.slice(0, maxEntries);
  const baseFolder = sanitizeArchiveName(fileName.replace(/\.[^.]+$/, ''));
  const entries: AsyncZipInputEntry[] = [];

  for (let i = 0; i < subset.length; i++) {
    const h = subset[i];
    const hexOff = `0x${h.offset.toString(16).toUpperCase().padStart(8, '0')}`;
    const idxStr = String(h.index).padStart(5, '0');

    if (h.canDecompress) {
      try {
        const dec = await decompressEmbeddedStreamAt(blob, h.offset, h.canDecompress, 12 * 1024 * 1024);
        entries.push({
          path: h.suggestedName
            ? `${baseFolder}/${idxStr}_${sanitizeArchiveName(h.suggestedName)}`
            : `${baseFolder}/${idxStr}_${hexOff}_${h.signature}_DEC${dec.suggestedExt}`,
          data: dec.bytes,
        });
        onProgress?.(i + 1, subset.length, `${idxStr} (${dec.innerFormat})`);
        continue;
      } catch {
        // Fall through to raw slice
      }
    }

    const sliceSize =
      h.estimatedSize !== null && h.estimatedSize > 0
        ? Math.min(h.estimatedSize, blob.size - h.offset, 32 * 1024 * 1024)
        : Math.min(256 * 1024, blob.size - h.offset);

    if (sliceSize > 0) {
      entries.push({
        path: h.suggestedName
          ? `${baseFolder}/${idxStr}_${sanitizeArchiveName(h.suggestedName)}`
          : `${baseFolder}/${idxStr}_${hexOff}_${sanitizeArchiveName(h.signature)}${h.suggestedExt}`,
        data: blob.slice(h.offset, h.offset + sliceSize),
      });
    }
    onProgress?.(i + 1, subset.length, `${idxStr} (${h.signature})`);
  }

  return buildZipBlobAsync(entries, onProgress);
}

export function generateBandaiNamcoQuickBmsScript(fileName: string): string {
  return `# QuickBMS Script — Explorador/Descompresor Bandai Namco & Banpresto PSP (.DAT / .BIN)
# Archivo objetivo sugerido: ${fileName}
# Compatible con contenedores PRES / BLZ4 / BLZ2 / ZLIB / flujos embebidos (OMG / MIG / TIM2 / PNG / PGF)
#
# Uso en PC con QuickBMS:
#   quickbms.exe bandai_namco_psp_dat.bms "${fileName}" ./extraido_dat/

idstring "PRES"
get VER long
get ENTRY_GROUPS long
get HEADER_SIZE long

# Escaneo secuencial de firmas y bloques comprimidos dentro del .DAT
goto 0
get FILE_END asize

for
  findloc OFFSET binary "\\x42\\x4C\\x5A\\x34" 0 ""
  if OFFSET == ""
    break
  endif
  goto OFFSET
  idstring "BLZ4"
  get DEC_SIZE long
  get COMP_HINT long
  get CHUNK_FLAGS long
  string OUT_NAME p "blz4_%08X.bin" OFFSET
  savepos DATA_POS
  math NEXT_OFF = OFFSET + 0x10
  # Nota: algunos juegos usan zlib/deflate por bloques de 64 KB dentro de BLZ4
  log OUT_NAME OFFSET 0x10000
  math NEXT_POS = OFFSET + 4
  goto NEXT_POS
next

# Extractor alternativo para bloques ZLIB estándar (0x78 0x9C) dentro de ${fileName}
goto 0
comtype zlib
for
  findloc ZOFF binary "\\x78\\x9C" 0 ""
  if ZOFF == ""
    break
  endif
  string ZNAME p "zlib_%08X.bin" ZOFF
  math EST_READ = FILE_END - ZOFF
  if EST_READ > 0x100000
    math EST_READ = 0x100000
  endif
  clog ZNAME ZOFF EST_READ EST_READ
  math ZNEXT = ZOFF + 4
  goto ZNEXT
next
`;
}

export interface LegibleTextBlockForHxd {
  id: string;
  blockLabel: string;
  fileOffset: number;
  compression: 'BLZ4' | 'BLZ2' | 'ZLIB' | 'GZIP' | 'DIRECTO';
  xorKeyApplied: number | null;
  bytes: Uint8Array;
  firstTextOffset: number;
  detectedEncoding: 'shift_jis' | 'utf-8';
  legibleStringCount: number;
  previewLines: Array<{ offset: number; text: string }>;
  suggestedFileName: string;
}

export interface LegibleHxdExtractionResult {
  fileName: string;
  fileSize: number;
  xorKeyDetected: number | null;
  blocksScanned: number;
  blocksWithText: LegibleTextBlockForHxd[];
  totalLegibleStrings: number;
}

function scoreXorKeyOnHeader(sample: Uint8Array, key: number): number {
  const dec = new Uint8Array(Math.min(sample.length, 64));
  for (let i = 0; i < dec.length; i++) {
    dec[i] = sample[i] ^ key;
  }
  const a4 = readAscii(dec, 0, 4);
  if (a4 === 'PRES' || a4 === 'PCK1' || a4 === 'PACK' || a4 === 'BLZ4' || a4 === 'BLZ2' || a4 === 'AFS2') {
    return 100;
  }
  if (dec[0] === 0x7f && dec[1] === 0x45 && dec[2] === 0x4c && dec[3] === 0x46) return 100;
  if (dec[0] === 0x78 && (dec[1] === 0x9c || dec[1] === 0xda)) return 50;
  if (dec[0] === 0x1f && dec[1] === 0x8b && dec[2] === 0x08) return 50;
  return 0;
}

function scanLegibleLinesInPlainBytes(
  bytes: Uint8Array,
  maxLines = 150
): {
  lines: Array<{ offset: number; text: string }>;
  firstTextOffset: number;
  primaryEncoding: 'shift_jis' | 'utf-8';
  totalFound: number;
} {
  const sj = new TextDecoder('shift_jis', { fatal: false });
  const u8 = new TextDecoder('utf-8', { fatal: false });
  const lines: Array<{ offset: number; text: string }> = [];
  let firstTextOffset = 0;
  let totalFound = 0;
  let jaVotes = 0;
  let utfVotes = 0;

  let start = -1;
  const limit = Math.min(bytes.length, 2 * 1024 * 1024);

  for (let i = 0; i <= limit; i++) {
    const b = i < limit ? bytes[i] : 0;
    const isCandidateByte = (b >= 32 && b <= 126) || b >= 0x80;
    if (isCandidateByte) {
      if (start === -1) start = i;
    } else if (start !== -1) {
      const len = i - start;
      if (len >= 4) {
        const sub = bytes.subarray(start, i);
        const decodedSj = sj.decode(sub);
        const decodedU8 = u8.decode(sub);

        const hasJapanese =
          /[\u3040-\u309f\u30a0-\u30ff\u4e00-\u9faf]/.test(decodedSj) &&
          !decodedSj.includes('\ufffd');
        const cleanU8 = decodedU8.replace(/[\x00-\x1F\x7F\ufffd]/g, '').trim();
        const letters = (cleanU8.match(/[A-Za-z]/g) || []).length;
        const hasReadableAscii =
          cleanU8.length >= 4 &&
          letters >= Math.max(3, Math.floor(cleanU8.length * 0.55)) &&
          (/\s/.test(cleanU8) || /^[A-Za-z][A-Za-z0-9_ .:/'"!?()-]{3,}$/.test(cleanU8));

        if (hasJapanese || hasReadableAscii) {
          const text = (hasJapanese ? decodedSj : cleanU8)
            .replace(/[\x00-\x1F\x7F\ufffd]/g, '')
            .trim();
          if (text.length >= 3) {
            if (totalFound === 0) firstTextOffset = start;
            totalFound++;
            if (hasJapanese) jaVotes += 2;
            else utfVotes += 1;
            if (lines.length < maxLines) {
              lines.push({ offset: start, text });
            }
          }
        }
      }
      start = -1;
    }
  }

  return {
    lines,
    firstTextOffset,
    primaryEncoding: jaVotes >= utfVotes && jaVotes > 0 ? 'shift_jis' : 'utf-8',
    totalFound,
  };
}

/**
 * Decrypts and unpacks first.dat / RES.DAT / DATA.BIN specifically filtering for blocks
 * that contain LEGIBLE text (Shift-JIS / UTF-8) ready to inspect & edit in HxD.
 */
export async function decryptDatLegibleTextBlocksForHxd(
  blob: Blob,
  fileName: string,
  onProgress?: (phase: string, done: number, total: number) => void
): Promise<LegibleHxdExtractionResult> {
  const headProbe = new Uint8Array(await blob.slice(0, Math.min(blob.size, 4096)).arrayBuffer());
  const magic0 = readAscii(headProbe, 0, 4);
  let xorKeyDetected: number | null = null;

  // Check if file header uses single-byte XOR obfuscation when standard magic isn't present
  if (
    magic0 !== 'PRES' &&
    magic0 !== 'PCK1' &&
    magic0 !== 'PACK' &&
    magic0 !== 'BLZ4' &&
    magic0 !== 'BLZ2' &&
    magic0 !== '~PSP' &&
    !(headProbe[0] === 0x7f && headProbe[1] === 0x45) &&
    !(headProbe[0] === 0x78 && (headProbe[1] === 0x9c || headProbe[1] === 0xda))
  ) {
    let bestKey = 0;
    let bestScore = 0;
    for (let k = 1; k <= 255; k++) {
      const sc = scoreXorKeyOnHeader(headProbe, k);
      if (sc > bestScore) {
        bestScore = sc;
        bestKey = k;
      }
    }
    if (bestScore >= 100) {
      xorKeyDetected = bestKey;
    }
  }

  // If single-byte XOR obfuscated and <= 256 MB, transform stream cleanly in chunks
  let workingBlob = blob;
  if (xorKeyDetected !== null && blob.size <= 256 * 1024 * 1024) {
    onProgress?.(
      `Descifrando capa XOR (0x${xorKeyDetected.toString(16).toUpperCase().padStart(2, '0')}) en ${fileName}…`,
      0,
      blob.size
    );
    const parts: BlobPart[] = [];
    const CHUNK = 4 * 1024 * 1024;
    for (let s = 0; s < blob.size; s += CHUNK) {
      const buf = new Uint8Array(
        await blob.slice(s, Math.min(blob.size, s + CHUNK)).arrayBuffer()
      );
      for (let i = 0; i < buf.length; i++) {
        buf[i] ^= xorKeyDetected;
      }
      parts.push(buf);
      onProgress?.(`Descifrando XOR…`, Math.min(blob.size, s + CHUNK), blob.size);
    }
    workingBlob = new Blob(parts, { type: 'application/octet-stream' });
  }

  onProgress?.(`Escaneando tablas PRES y flujos BLZ4/ZLIB en ${fileName}…`, 0, workingBlob.size);
  const scan = await scanDatContainerSignatures(
    workingBlob,
    workingBlob.size,
    100000,
    (scanned, total, hitsFound) => {
      onProgress?.(`Escaneando ${fileName} (${hitsFound} bloques)…`, scanned, total);
    }
  );

  const blocksWithText: LegibleTextBlockForHxd[] = [];
  let blocksScanned = 0;
  let totalLegibleStrings = 0;
  const baseSlug = sanitizeArchiveName(fileName.replace(/\.[^.]+$/, '') || fileName);

  // 1. Decompress compressed hits and keep only blocks with legible Shift-JIS / UTF-8 text
  const compHits = scan.hits.filter((h) => h.canDecompress !== null);
  for (let i = 0; i < compHits.length; i++) {
    const h = compHits[i];
    blocksScanned++;
    if (i % 10 === 0 || i === compHits.length - 1) {
      onProgress?.(
        `Descomprimiendo y buscando textos legibles (${i + 1}/${compHits.length})…`,
        i + 1,
        compHits.length
      );
    }

    try {
      const dec = await decompressEmbeddedStreamAt(
        workingBlob,
        h.offset,
        h.canDecompress!,
        12 * 1024 * 1024
      );
      const textScan = scanLegibleLinesInPlainBytes(dec.bytes, 120);
      if (textScan.totalFound > 0) {
        const hexOff = `0x${h.offset.toString(16).toUpperCase().padStart(8, '0')}`;
        const cleanOrig = h.suggestedName ? sanitizeArchiveName(h.suggestedName) : null;
        blocksWithText.push({
          id: `${fileName}@${hexOff}`,
          blockLabel: cleanOrig
            ? `${h.canDecompress!.toUpperCase()} @ ${hexOff} · ${cleanOrig}`
            : `${h.canDecompress!.toUpperCase()} @ ${hexOff}`,
          fileOffset: h.offset,
          compression: h.canDecompress!.toUpperCase() as LegibleTextBlockForHxd['compression'],
          xorKeyApplied: xorKeyDetected,
          bytes: dec.bytes,
          firstTextOffset: textScan.firstTextOffset,
          detectedEncoding: textScan.primaryEncoding,
          legibleStringCount: textScan.totalFound,
          previewLines: textScan.lines,
          suggestedFileName: cleanOrig
            ? `${baseSlug}_${hexOff}_${cleanOrig}`
            : `${baseSlug}_${h.canDecompress}_${hexOff}_TEXTOS.bin`,
        });
        totalLegibleStrings += textScan.totalFound;
      }
    } catch {
      // Skip invalid streams
    }
  }

  // 2. Also scan direct uncompressed chunks (important if first.dat / RES.DAT stores plain Shift-JIS strings directly)
  const DIRECT_SCAN_CHUNK = 2 * 1024 * 1024;
  const directLimit = Math.min(workingBlob.size, 64 * 1024 * 1024);
  for (let start = 0; start < directLimit; start += DIRECT_SCAN_CHUNK) {
    const end = Math.min(directLimit, start + DIRECT_SCAN_CHUNK);
    const sliceBytes = new Uint8Array(await workingBlob.slice(start, end).arrayBuffer());
    const directScan = scanLegibleLinesInPlainBytes(sliceBytes, 150);
    blocksScanned++;
    if (directScan.totalFound >= 3) {
      const hexOff = `0x${start.toString(16).toUpperCase().padStart(8, '0')}`;
      blocksWithText.push({
        id: `${fileName}@DIRECT@${hexOff}`,
        blockLabel: `Texto Directo (sin comprimir) @ ${hexOff}`,
        fileOffset: start,
        compression: 'DIRECTO',
        xorKeyApplied: xorKeyDetected,
        bytes: sliceBytes,
        firstTextOffset: directScan.firstTextOffset,
        detectedEncoding: directScan.primaryEncoding,
        legibleStringCount: directScan.totalFound,
        previewLines: directScan.lines,
        suggestedFileName: `${baseSlug}_DIRECTO_${hexOff}_TEXTOS.bin`,
      });
      totalLegibleStrings += directScan.totalFound;
    }
  }

  // Sort blocks with most legible strings first so dialogue/UI scripts appear on top
  blocksWithText.sort((a, b) => b.legibleStringCount - a.legibleStringCount);

  return {
    fileName,
    fileSize: blob.size,
    xorKeyDetected,
    blocksScanned,
    blocksWithText,
    totalLegibleStrings,
  };
}

export async function exportLegibleHxdBlocksZip(
  result: LegibleHxdExtractionResult
): Promise<Blob> {
  const entries: AsyncZipInputEntry[] = [];
  const indexLines: string[] = [
    `BLOQUES DESENCRIPTADOS CON TEXTOS LEGIBLES PARA EDITAR EN HxD — ${result.fileName}`,
    `Clave XOR detectada: ${
      result.xorKeyDetected !== null
        ? `0x${result.xorKeyDetected.toString(16).toUpperCase().padStart(2, '0')}`
        : 'Ninguna (PRES/BLZ4/ZLIB estándar)'
    }`,
    `Total bloques con texto: ${result.blocksWithText.length} · Total cadenas legibles: ${result.totalLegibleStrings}`,
    '='.repeat(78),
    '',
  ];

  for (const blk of result.blocksWithText) {
    entries.push({
      path: `bloques_hxd/${blk.suggestedFileName}`,
      data: blk.bytes,
    });

    indexLines.push(
      `ARCHIVO: bloques_hxd/${blk.suggestedFileName}`,
      `  Origen en ${result.fileName}: 0x${blk.fileOffset.toString(16).toUpperCase().padStart(8, '0')} (${blk.compression})`,
      `  Codificación recomendada en HxD: ${blk.detectedEncoding === 'shift_jis' ? 'Shift-JIS' : 'UTF-8'}`,
      `  Ir al primer texto en HxD: 0x${blk.firstTextOffset.toString(16).toUpperCase().padStart(6, '0')}`,
      `  Cadenas legibles (${blk.legibleStringCount}):`
    );

    for (const line of blk.previewLines.slice(0, 20)) {
      indexLines.push(
        `    [0x${line.offset.toString(16).toUpperCase().padStart(6, '0')}] ${line.text}`
      );
    }
    indexLines.push('');
  }

  entries.push({
    path: '_INDICE_HXD_TEXTOS.txt',
    data: new TextEncoder().encode(indexLines.join('\n')),
  });

  return buildZipBlobAsync(entries);
}


