export interface KotlinTemplateFile {
  filename: string;
  path: string;
  description: string;
  code: string;
}

export const KOTLIN_PROJECT_FILES: KotlinTemplateFile[] = [
  {
    filename: 'MainActivity.kt',
    path: 'app/src/main/java/com/psplab/ebootinspector/MainActivity.kt',
    description: 'Actividad principal con Storage Access Framework (ACTION_OPEN_DOCUMENT) y exportación del informe.',
    code: `package com.psplab.ebootinspector

import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var ultimoInforme: String = ""

    private val seleccionarIsoLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { analizarArchivoSeleccionado(it) }
    }

    private val exportarInformeLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri: Uri? ->
        uri?.let { destino ->
            contentResolver.openOutputStream(destino)?.use { out ->
                out.write(ultimoInforme.toByteArray(Charsets.UTF_8))
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Conecta tu botón de carga:
        // btnCargar.setOnClickListener { seleccionarIsoLauncher.launch(arrayOf("*/*")) }
        // btnExportar.setOnClickListener { exportarInformeLauncher.launch("informe_eboot.txt") }
    }

    private fun analizarArchivoSeleccionado(uri: Uri) {
        contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
            val ebootBytes = Iso9660Reader.extraerEbootDesdePfd(pfd)
                ?: contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return

            ultimoInforme = IndexedReportGenerator.generarInformeIndexado(ebootBytes)
            // Mostrar ultimoInforme en TextView / RecyclerView o WebView
        }
    }
}`,
  },
  {
    filename: 'Iso9660Reader.kt',
    path: 'app/src/main/java/com/psplab/ebootinspector/Iso9660Reader.kt',
    description: 'Lector nativo ISO 9660 por sectores (2048 B) usando FileDescriptor para ISOs grandes sin saturar la RAM.',
    code: `package com.psplab.ebootinspector

import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

object Iso9660Reader {
    private const val SECTOR_SIZE = 2048L

    fun extraerEbootDesdePfd(pfd: ParcelFileDescriptor): ByteArray? {
        FileInputStream(pfd.fileDescriptor).channel.use { channel ->
            val pvd = leerBloque(channel, 16L * SECTOR_SIZE, SECTOR_SIZE.toInt()) ?: return null
            val stdId = String(pvd, 1, 5, Charsets.US_ASCII)
            if (pvd[0].toInt() != 1 || stdId != "CD001") return null

            val pvdBuf = ByteBuffer.wrap(pvd).order(ByteOrder.LITTLE_ENDIAN)
            val rootLba = pvdBuf.getInt(156 + 2).toLong() and 0xFFFFFFFFL
            val rootSize = pvdBuf.getInt(156 + 10)

            val pspGame = buscarEntrada(channel, rootLba, rootSize, "PSP_GAME") ?: return null
            val sysDir = buscarEntrada(channel, pspGame.first, pspGame.second, "SYSDIR") ?: return null
            val eboot = buscarEntrada(channel, sysDir.first, sysDir.second, "EBOOT.BIN") ?: return null

            return leerBloque(channel, eboot.first * SECTOR_SIZE, eboot.second)
        }
    }

    private fun buscarEntrada(
        channel: FileChannel,
        lba: Long,
        size: Int,
        nombreObjetivo: String
    ): Pair<Long, Int>? {
        val dirBytes = leerBloque(channel, lba * SECTOR_SIZE, size) ?: return null
        val buf = ByteBuffer.wrap(dirBytes).order(ByteOrder.LITTLE_ENDIAN)
        var pos = 0

        while (pos < dirBytes.size) {
            val recLen = dirBytes[pos].toInt() and 0xFF
            if (recLen == 0) {
                pos = ((pos / SECTOR_SIZE.toInt()) + 1) * SECTOR_SIZE.toInt()
                continue
            }
            val entryLba = buf.getInt(pos + 2).toLong() and 0xFFFFFFFFL
            val entrySize = buf.getInt(pos + 10)
            val idLen = dirBytes[pos + 32].toInt() and 0xFF
            val rawName = String(dirBytes, pos + 33, idLen, Charsets.US_ASCII).substringBefore(';')

            if (rawName.equals(nombreObjetivo, ignoreCase = true)) {
                return Pair(entryLba, entrySize)
            }
            pos += recLen
        }
        return null
    }

    private fun leerBloque(channel: FileChannel, offset: Long, length: Int): ByteArray? {
        if (length <= 0 || length > 32 * 1024 * 1024) return null
        val out = ByteBuffer.allocate(length)
        channel.position(offset)
        while (out.hasRemaining()) {
            if (channel.read(out) == -1) break
        }
        return out.array()
    }
}`,
  },
  {
    filename: 'IndexedReportGenerator.kt',
    path: 'app/src/main/java/com/psplab/ebootinspector/IndexedReportGenerator.kt',
    description: 'Analizador de cabeceras (~PSP y ELF32 MIPS), mapeador de direcciones RAM/Offset y generador de informe indexado.',
    code: `package com.psplab.ebootinspector

import java.nio.ByteBuffer
import java.nio.ByteOrder

data class SeccionElf(
    val nombre: String,
    val direccionVirtual: Long,
    val offsetArchivo: Int,
    val tamano: Int
)

data class DireccionIndexada(
    val indice: Int,
    val offsetArchivo: String,
    val direccionMemoria: String,
    val contenido: String
)

object IndexedReportGenerator {

    fun generarInformeIndexado(data: ByteArray): String {
        if (data.size < 52) return "Error: Archivo demasiado pequeño para ser un binario PSP válido."

        val buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val magic = buffer.getInt(0)

        if (magic == 0x5053507E) {
            val modAttr = buffer.getShort(4).toInt() and 0xFFFF
            val compAttr = buffer.getShort(6).toInt() and 0xFFFF
            val modName = String(data, 0x0A, 28, Charsets.US_ASCII).trim { it <= ' ' || it == '\\u0000' }
            return buildString {
                appendLine("=== INFORME DE CABECERA ~PSP ===")
                appendLine("• Nombre del Módulo: $modName")
                appendLine("• Atributos: 0x\${modAttr.toString(16).uppercase()}")
                appendLine("• Compresión/Formato: 0x\${compAttr.toString(16).uppercase()}")
                appendLine("• Nota: Contenedor ~PSP oficial sellado (sin tablas ELF expuestas).")
            }
        }

        if (magic != 0x464C457F) {
            return "Error: Cabecera desconocida (0x\${magic.toString(16).uppercase()})."
        }

        val entryPoint = buffer.getInt(0x18).toLong() and 0xFFFFFFFFL
        val shOff = buffer.getInt(0x20)
        val shEntSize = buffer.getShort(0x2E).toInt() and 0xFFFF
        val shNum = buffer.getShort(0x30).toInt() and 0xFFFF
        val shStrNdx = buffer.getShort(0x32).toInt() and 0xFFFF

        val secciones = mutableListOf<SeccionElf>()
        val baseVram = 0x08804000L

        if (shOff > 0 && shNum > 0 && shOff + (shNum * shEntSize) <= data.size) {
            val strTableOffset = buffer.getInt(shOff + (shStrNdx * shEntSize) + 0x10)
            for (i in 0 until shNum) {
                val entryOffset = shOff + (i * shEntSize)
                val nameIdx = buffer.getInt(entryOffset)
                val vAddr = buffer.getInt(entryOffset + 0x0C).toLong() and 0xFFFFFFFFL
                val fOffset = buffer.getInt(entryOffset + 0x10)
                val size = buffer.getInt(entryOffset + 0x14)
                val secName = leerStringNulo(data, strTableOffset + nameIdx)
                if (secName.isNotEmpty()) {
                    secciones.add(SeccionElf(secName, vAddr, fOffset, size))
                }
            }
        }

        val cadenas = mutableListOf<DireccionIndexada>()
        val sbTemp = StringBuilder()
        var inicioOffset = -1
        var contador = 1

        for (i in data.indices) {
            val b = data[i].toInt() and 0xFF
            if (b in 32..126) {
                if (sbTemp.isEmpty()) inicioOffset = i
                sbTemp.append(b.toChar())
            } else {
                if (sbTemp.length >= 5) {
                    val texto = sbTemp.toString()
                    if (texto.contains("disc0:") || texto.contains("sce") || texto.contains(".prx") || texto.length >= 8) {
                        val vram = calcularVram(inicioOffset, secciones, baseVram)
                        cadenas.add(
                            DireccionIndexada(
                                indice = contador++,
                                offsetArchivo = "0x\${inicioOffset.toString(16).uppercase().padStart(6, '0')}",
                                direccionMemoria = "0x\${vram.toString(16).uppercase().padStart(8, '0')}",
                                contenido = texto
                            )
                        )
                    }
                }
                sbTemp.clear()
            }
        }

        return buildString {
            appendLine("==========================================")
            appendLine("   INFORME INDEXADO DE EBOOT.BIN (PSP)    ")
            appendLine("==========================================")
            appendLine("• Tamaño Total: \${data.size} bytes")
            appendLine("• Entry Point: 0x\${entryPoint.toString(16).uppercase()}")
            appendLine()
            appendLine("--- [1] ÍNDICE DE SECCIONES Y DIRECCIONES ---")
            secciones.forEachIndexed { idx, sec ->
                appendLine("  [\${idx + 1}] \${sec.nombre.padEnd(14)} | Offset: 0x\${sec.offsetArchivo.toString(16).uppercase()} | RAM: 0x\${sec.direccionVirtual.toString(16).uppercase()} | Tamaño: \${sec.tamano} B")
            }
            appendLine()
            appendLine("--- [2] ÍNDICE DE RUTAS Y CADENAS (\${cadenas.size} hallazgos) ---")
            cadenas.take(150).forEach { item ->
                appendLine("  #\${item.indice.toString().padStart(3, '0')} | File: \${item.offsetArchivo} | RAM: \${item.direccionMemoria} -> \\"\${item.contenido}\\"")
            }
        }
    }

    private fun leerStringNulo(data: ByteArray, offset: Int): String {
        if (offset < 0 || offset >= data.size) return ""
        val sb = StringBuilder()
        var i = offset
        while (i < data.size && data[i] != 0.toByte()) {
            sb.append(data[i].toInt().toChar())
            i++
        }
        return sb.toString()
    }

    private fun calcularVram(fileOffset: Int, secciones: List<SeccionElf>, baseFallback: Long): Long {
        for (sec in secciones) {
            if (fileOffset >= sec.offsetArchivo && fileOffset < (sec.offsetArchivo + sec.tamano)) {
                return sec.direccionVirtual + (fileOffset - sec.offsetArchivo)
            }
        }
        return baseFallback + fileOffset
    }
}`,
  },
  {
    filename: 'DlcAndIsoVerifier.kt',
    path: 'app/src/main/java/com/psplab/ebootinspector/DlcAndIsoVerifier.kt',
    description: 'Verificador Kotlin para rutas disc0:/ (fin 0x00), alineación LBA 2048 B en Sector 16, límites sltiu en .text y auditoría de PSP_GAME/DLC/.',
    code: `package com.psplab.ebootinspector

import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

data class ResultadoRutaDisc0(
    val offsetArchivo: Int,
    val ruta: String,
    val terminadaEnNulo: Boolean
)

data class LimiteMipsDetectado(
    val offsetArchivo: Int,
    val ramVirtual: Long,
    val mnemonico: String,
    val valorInmediato: Int
)

object DlcAndIsoVerifier {
    private const val SECTOR_SIZE = 2048L

    // 1. Verificador de rutas disc0:/PSP_GAME/ y terminación en byte nulo (0x00)
    fun verificarRutasDisc0(ebootBytes: ByteArray): List<ResultadoRutaDisc0> {
        val hallazgos = mutableListOf<ResultadoRutaDisc0>()
        val patron = "disc0:/PSP_GAME/".toByteArray(Charsets.US_ASCII)
        var i = 0
        while (i <= ebootBytes.size - patron.size) {
            var coincide = true
            for (j in patron.indices) {
                if (ebootBytes[i + j] != patron[j]) {
                    coincide = false
                    break
                }
            }
            if (coincide) {
                var fin = i
                while (fin < ebootBytes.size && fin - i < 256 && (ebootBytes[fin].toInt() and 0xFF) in 32..126) {
                    fin++
                }
                val ruta = String(ebootBytes, i, fin - i, Charsets.US_ASCII)
                val nuloOk = fin < ebootBytes.size && ebootBytes[fin] == 0.toByte()
                hallazgos.add(ResultadoRutaDisc0(i, ruta, nuloOk))
                i = fin
            } else {
                i++
            }
        }
        return hallazgos
    }

    // 2. Validación de sectores LBA de la ISO (Sector 16 PVD y múltiplos de 2048 B)
    fun validarAlineacionIso(pfd: ParcelFileDescriptor): String {
        FileInputStream(pfd.fileDescriptor).channel.use { channel ->
            val tamanoReal = channel.size()
            val pvd = ByteArray(2048)
            val buf = ByteBuffer.wrap(pvd)
            channel.position(16L * SECTOR_SIZE)
            while (buf.hasRemaining()) {
                if (channel.read(buf) == -1) break
            }
            if (String(pvd, 1, 5, Charsets.US_ASCII) != "CD001") {
                return "Error: Sector 16 no contiene un Primary Volume Descriptor (CD001)."
            }
            val le = ByteBuffer.wrap(pvd).order(ByteOrder.LITTLE_ENDIAN)
            val sectoresPvd = le.getInt(80).toLong() and 0xFFFFFFFFL
            val bloqueLogico = le.getShort(128).toInt() and 0xFFFF
            val multiploOk = (tamanoReal % 2048L) == 0L
            val bytesDeclarados = sectoresPvd * bloqueLogico.toLong()

            return buildString {
                appendLine("=== VALIDACIÓN LBA ISO (SECTOR 16 PVD) ===")
                appendLine("• Bloque lógico PVD: $bloqueLogico bytes")
                appendLine("• Tamaño real archivo: $tamanoReal bytes (Múltiplo 2048 B: \${if (multiploOk) "OK" else "DESALINEADO"})")
                appendLine("• Sectores PVD: $sectoresPvd ($bytesDeclarados bytes declarados)")
            }
        }
    }

    // 3. Búsqueda de instrucciones MIPS sltiu (ej. 0x46/0x4C chars -> 0xFF, 0x10 mapas -> 0x2E)
    fun buscarLimitesIdEnText(ebootBytes: ByteArray, textOffset: Int, textSize: Int, baseVram: Long = 0x08804000L): List<LimiteMipsDetectado> {
        val out = mutableListOf<LimiteMipsDetectado>()
        val buf = ByteBuffer.wrap(ebootBytes).order(ByteOrder.LITTLE_ENDIAN)
        val objetivos = setOf(0x0A, 0x10, 0x2D, 0x2E, 0x46, 0x4C, 0xFF)
        var off = textOffset
        val limite = minOf(textOffset + textSize, ebootBytes.size - 4)
        while (off <= limite) {
            val instr = buf.getInt(off)
            val opcode = instr ushr 26
            if (opcode == 0x0B || opcode == 0x0A) { // sltiu / slti
                val imm = instr and 0xFFFF
                if (imm in objetivos) {
                    val rs = (instr ushr 21) and 0x1F
                    val rt = (instr ushr 16) and 0x1F
                    val opName = if (opcode == 0x0B) "sltiu" else "slti"
                    out.add(
                        LimiteMipsDetectado(
                            offsetArchivo = off,
                            ramVirtual = baseVram + off,
                            mnemonico = "$opName r$rt, r$rs, 0x\${imm.toString(16).uppercase()}",
                            valorInmediato = imm
                        )
                    )
                }
            }
            off += 4
        }
        return out
    }

    // 4. Auditoría básica de archivos en /PSP_GAME/DLC/ (secuencia continua CHARxxx / MAPSxx y firma DLC\\0)
    fun auditarSecuenciaDlc(nombresEnCarpetaDlc: List<String>): List<String> {
        val advertencias = mutableListOf<String>()
        val charIds = nombresEnCarpetaDlc
            .mapNotNull { Regex("^CHAR(\\\\d{3})\\\\.BIN$", RegexOption.IGNORE_CASE).matchEntire(it)?.groupValues?.get(1)?.toIntOrNull() }
            .sorted()
        if (charIds.isNotEmpty()) {
            val setChars = charIds.toSet()
            for (id in minOf(77, charIds.first())..charIds.last()) {
                if (id !in setChars) {
                    advertencias.add("Advertencia: Falta CHAR\${id.toString().padStart(3, '0')}.BIN en la secuencia continua.")
                }
            }
        }
        val mapIds = nombresEnCarpetaDlc
            .mapNotNull { Regex("^MAPS(\\\\d{2,3})\\\\.BIN$", RegexOption.IGNORE_CASE).matchEntire(it)?.groupValues?.get(1)?.toIntOrNull() }
            .sorted()
        if (mapIds.isNotEmpty()) {
            val setMaps = mapIds.toSet()
            for (id in minOf(11, mapIds.first())..mapIds.last()) {
                if (id !in setMaps) {
                    advertencias.add("Advertencia: Falta MAPS\${id.toString().padStart(2, '0')}.BIN en la secuencia continua.")
                }
            }
        }
        return advertencias
    }
}`,
  },
  {
    filename: 'build_dlc_pack.py',
    path: 'tools/build_dlc_pack.py',
    description: 'Script Python para empaquetar DLC en modo Secuencial (CHAR077-CHAR256, MAPS11-MAPS46, BGM001+) o Contenedor Indexado DLC\\0 alineado a 16 bytes (0x10).',
    code: `#!/usr/bin/env python3
"""
Empaquetador DLC PSP (Modo Secuencial Híbrido y Modo Contenedor Indexado DLC\\0)
Alineado a 16 bytes (0x10) para lectura directa por DMA/CPU MIPS de PSP.
"""
import os
import struct
from pathlib import Path

ALIGN = 16


def pad16(data: bytes) -> bytes:
    rem = len(data) % ALIGN
    return data if rem == 0 else data + (b"\\x00" * (ALIGN - rem))


def build_sequential_char(color_files: list[Path | None], out_path: Path) -> None:
    """Genera CHAR077.BIN .. CHAR256.BIN con cabecera de 64 bytes (8 colores x [offset, size])."""
    entries: list[tuple[int, int]] = []
    payload = bytearray()
    cursor = 64

    for idx in range(8):
        fpath = color_files[idx] if idx < len(color_files) else None
        if fpath and fpath.exists():
            raw = pad16(fpath.read_bytes())
            entries.append((cursor, len(raw)))
            payload.extend(raw)
            cursor += len(raw)
        else:
            entries.append((0, 0))

    header = bytearray()
    for off, sz in entries:
        header.extend(struct.pack("<II", off, sz))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(bytes(header) + bytes(payload))


def build_sequential_map(map_file: Path, minimap_file: Path | None, out_path: Path) -> None:
    """Genera MAPS11.BIN .. MAPS46.BIN con cabecera de 16 bytes ([mapOff, mapSz, miniOff, miniSz])."""
    map_raw = pad16(map_file.read_bytes()) if map_file.exists() else b""
    mini_raw = pad16(minimap_file.read_bytes()) if minimap_file and minimap_file.exists() else b""

    map_off = 16 if map_raw else 0
    mini_off = (16 + len(map_raw)) if mini_raw else 0
    header = struct.pack("<IIII", map_off, len(map_raw), mini_off, len(mini_raw))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(header + map_raw + mini_raw)


def build_indexed_dlc_container(items: list[Path | None], out_path: Path) -> None:
    """Genera contenedores CHAR77.BIN / CHAR256.BIN / MAPS11.BIN / MAPS46.BIN / BGMEXP.BIN con firma DLC\\0."""
    count = len(items)
    header_size = 8 + count * 8
    pad_header = (ALIGN - (header_size % ALIGN)) % ALIGN
    cursor = header_size + pad_header

    table = bytearray()
    payload = bytearray()
    for fpath in items:
        if fpath and fpath.exists():
            raw = pad16(fpath.read_bytes())
            table.extend(struct.pack("<II", cursor, len(raw)))
            payload.extend(raw)
            cursor += len(raw)
        else:
            table.extend(struct.pack("<II", 0, 0))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("wb") as f:
        f.write(b"DLC\\x00")
        f.write(struct.pack("<I", count))
        f.write(table)
        f.write(b"\\x00" * pad_header)
        f.write(payload)


if __name__ == "__main__":
    print("Importa build_sequential_char, build_sequential_map o build_indexed_dlc_container desde tu pipeline.")
`,
  },
];
