import { extractMultilingualStrings, type TextEncodingMode } from './codeTable';
import { decompressWithStream, tryDecompressBlz4Bytes } from './universalInspector';

export type TextStringCategory =
  | 'DIALOGUE'
  | 'UI_MENU'
  | 'SAVE_ITEM_ERROR'
  | 'PSP_PATH'
  | 'SYSTEM_DEBUG';

export interface AnalyzedTextEntry {
  id: number;
  offset: number;
  byteLength: number;
  text: string;
  encoding: TextEncodingMode;
  languageHint: 'ES' | 'EN' | 'JA' | 'ASCII/SYS';
  category: TextStringCategory;
  sourceBlock: string;
}

export interface TextAnalysisSummary {
  fileName: string;
  fileSize: number;
  scannedBytes: number;
  encodingMode: TextEncodingMode | 'AUTO_MULTI';
  detectedPrimaryEncoding: 'shift_jis' | 'utf-8' | 'utf-16le' | 'mixed';
  compressedBlocksFound: number;
  compressedBlocksDecompressed: number;
  entries: AnalyzedTextEntry[];
  categoryCounts: Record<TextStringCategory, number>;
  languageCounts: Record<'ES' | 'EN' | 'JA' | 'ASCII/SYS', number>;
}

function classifyLanguage(text: string): 'ES' | 'EN' | 'JA' | 'ASCII/SYS' {
  if (/[\u3040-\u30ff\u4e00-\u9faf]/.test(text)) return 'JA';
  if (
    /[ñÑáéíóúÁÉÍÓÚüÜ¡¿]/.test(text) ||
    /\b(misión|juego|guardar|cargar|partida|salir|continuar|enemigo|héroe|opciones|aceptar|cancelar)\b/i.test(
      text
    )
  ) {
    return 'ES';
  }
  if (/^(disc0:|ms0:|flash0:|umd0:|host0:|sce[A-Z]|\.)/i.test(text.trim())) {
    return 'ASCII/SYS';
  }
  return 'EN';
}

function classifyTextCategory(text: string): TextStringCategory {
  const t = text.trim();
  if (
    /^(disc0:|ms0:|flash0:|umd0:|host0:|\/PSP_GAME|[a-zA-Z0-9_/-]+\.(prx|pmf|awb|dat|bin|pgf|gmo|gim|tm2|png|at3))/i.test(
      t
    )
  ) {
    return 'PSP_PATH';
  }
  if (
    /(memory stick|savedata|save data|load data|overwrite|corrupt|failed|cannot save|no free space|guardar|cargar partida|sobrescribir|datos dañados|memoria insuficiente|セーブ|ロード|メモリースティック|エラー|セーブデータ|上書き|破損|アイテム|装備|スキル)/i.test(
      t
    ) ||
    /^(item|weapon|armor|shield|skill|bullet|mission|quest|error|warning)\s*[:_-]/i.test(t)
  ) {
    return 'SAVE_ITEM_ERROR';
  }
  if (
    /^sce[A-Z]|^\.(text|rodata|data|bss|shstrtab|lib\.stub|sceModuleInfo)|^(%s|%d|%x|0x[0-9a-f]+|assert|pthread|sysmem)/i.test(
      t
    ) ||
    /^[A-Z0-9_]{5,}$/.test(t)
  ) {
    return 'SYSTEM_DEBUG';
  }
  if (
    t.length >= 20 &&
    (/\s/.test(t) || /[\u3040-\u30ff\u4e00-\u9faf]/.test(t)) &&
    /[.!?,。！？…「」]/.test(t)
  ) {
    return 'DIALOGUE';
  }
  if (/\s/.test(t) && t.length >= 30) {
    return 'DIALOGUE';
  }
  return 'UI_MENU';
}

function isUsefulString(text: string): boolean {
  const t = text.trim();
  if (t.length < 3) return false;
  if (/[\u3040-\u30ff\u4e00-\u9fafñÑáéíóúÁÉÍÓÚ¡¿]/.test(t)) return true;
  const alnum = (t.match(/[A-Za-z0-9]/g) || []).length;
  return alnum >= Math.max(2, Math.floor(t.length * 0.45));
}

function hasHighReadability(text: string): boolean {
  const t = text.trim();
  if (t.length < 4) return false;
  if (/[\u3040-\u30ff\u4e00-\u9fafñÑáéíóúÁÉÍÓÚ]/.test(t)) return true;
  if (/\s/.test(t) && /[a-z]{2,}/i.test(t)) return true;
  if (/^(disc0:|ms0:|sce[A-Z])/i.test(t)) return true;
  const letters = (t.match(/[A-Za-z]/g) || []).length;
  return letters >= Math.max(3, Math.floor(t.length * 0.55));
}

export async function analyzeTextFromBlob(
  blob: Blob,
  fileName: string,
  options: {
    encoding?: TextEncodingMode | 'AUTO_MULTI';
    minLength?: number;
    maxScanBytes?: number;
    maxResults?: number;
    includeCompressedBlocks?: boolean;
    onProgress?: (scanned: number, total: number) => void;
  } = {}
): Promise<TextAnalysisSummary> {
  const mode = options.encoding ?? 'AUTO_MULTI';
  const minLength = options.minLength ?? 4;
  const maxScanBytes = options.maxScanBytes ?? 16 * 1024 * 1024;
  const maxResults = options.maxResults ?? 3500;
  const includeCompressedBlocks = options.includeCompressedBlocks ?? true;

  const totalToScan = Math.min(blob.size, maxScanBytes);
  const CHUNK_SIZE = 1024 * 1024;
  const seenKey = new Set<string>();
  const entries: AnalyzedTextEntry[] = [];

  let compressedBlocksFound = 0;
  let compressedBlocksDecompressed = 0;

  const encodingsToTry: TextEncodingMode[] =
    mode === 'AUTO_MULTI'
      ? ['shift_jis', 'utf-8', 'utf-16le']
      : [mode];

  const encVotes: Record<'shift_jis' | 'utf-8' | 'utf-16le', number> = {
    shift_jis: 0,
    'utf-8': 0,
    'utf-16le': 0,
  };

  const scanBufferForStrings = (
    buf: Uint8Array,
    baseOffset: number,
    sourceBlock: string
  ) => {
    for (const enc of encodingsToTry) {
      if (entries.length >= maxResults) break;
      const extracted = extractMultilingualStrings(buf, enc, null, false, minLength);
      for (const item of extracted) {
        if (entries.length >= maxResults) break;
        const clean = item.text.trim();
        if (!isUsefulString(clean)) continue;
        const absOffset = sourceBlock === 'Directo' ? baseOffset + item.offset : baseOffset;
        const key = `${sourceBlock}:${absOffset}:${clean}`;
        if (seenKey.has(key)) continue;
        seenKey.add(key);

        const lang = classifyLanguage(clean);
        if (enc === 'shift_jis' && lang === 'JA') encVotes.shift_jis += 3;
        else if (enc === 'utf-8' && (lang === 'ES' || hasHighReadability(clean))) encVotes['utf-8'] += 2;
        else if (enc === 'utf-16le' && hasHighReadability(clean)) encVotes['utf-16le'] += 2;

        entries.push({
          id: entries.length + 1,
          offset: absOffset,
          byteLength: item.lengthBytes,
          text: clean,
          encoding: enc,
          languageHint: lang,
          category: classifyTextCategory(clean),
          sourceBlock,
        });
      }
    }
  };

  for (let start = 0; start < totalToScan && entries.length < maxResults; start += CHUNK_SIZE) {
    const end = Math.min(totalToScan, start + CHUNK_SIZE);
    const buf = new Uint8Array(await blob.slice(start, end).arrayBuffer());

    // 1. Direct uncompressed strings
    scanBufferForStrings(buf, start, 'Directo');

    // 2. Deep scan inside ZLIB / GZIP / BLZ4 compressed chunks (critical for RES.DAT, first.dat, DATA.BIN)
    if (includeCompressedBlocks && entries.length < maxResults) {
      let blocksInChunk = 0;
      for (let i = 0; i + 8 < buf.length && blocksInChunk < 32 && entries.length < maxResults; i += 4) {
        const absOff = start + i;
        const isBlz4 =
          buf[i] === 0x42 && buf[i + 1] === 0x4c && buf[i + 2] === 0x5a && buf[i + 3] === 0x34;
        const isGzip = buf[i] === 0x1f && buf[i + 1] === 0x8b && buf[i + 2] === 0x08;
        const isZlib =
          buf[i] === 0x78 && (buf[i + 1] === 0x9c || buf[i + 1] === 0xda || buf[i + 1] === 0x01);

        if (!isBlz4 && !isGzip && !isZlib) continue;

        compressedBlocksFound++;
        blocksInChunk++;
        const hexOff = `0x${absOff.toString(16).toUpperCase().padStart(8, '0')}`;
        const sliceLen = Math.min(blob.size - absOff, 512 * 1024);
        if (sliceLen < 16) continue;

        try {
          const compBuf = new Uint8Array(await blob.slice(absOff, absOff + sliceLen).arrayBuffer());
          let dec: Uint8Array | null = null;
          let label = '';
          if (isBlz4) {
            dec = await tryDecompressBlz4Bytes(compBuf);
            label = `BLZ4 @ ${hexOff}`;
          } else if (isGzip) {
            dec = await decompressWithStream(compBuf, 'gzip');
            label = `GZIP @ ${hexOff}`;
          } else if (isZlib) {
            dec = await decompressWithStream(compBuf, 'deflate');
            label = `ZLIB @ ${hexOff}`;
          }
          if (dec && dec.length > 0) {
            compressedBlocksDecompressed++;
            scanBufferForStrings(dec, absOff, label);
          }
        } catch {
          // Ignore false-positive magic headers
        }
      }
    }

    options.onProgress?.(end, totalToScan);
  }

  entries.sort((a, b) => a.offset - b.offset);
  entries.forEach((e, i) => {
    e.id = i + 1;
  });

  const categoryCounts: Record<TextStringCategory, number> = {
    DIALOGUE: 0,
    UI_MENU: 0,
    SAVE_ITEM_ERROR: 0,
    PSP_PATH: 0,
    SYSTEM_DEBUG: 0,
  };
  const languageCounts: Record<'ES' | 'EN' | 'JA' | 'ASCII/SYS', number> = {
    ES: 0,
    EN: 0,
    JA: 0,
    'ASCII/SYS': 0,
  };

  for (const e of entries) {
    categoryCounts[e.category]++;
    languageCounts[e.languageHint]++;
  }

  let detectedPrimaryEncoding: 'shift_jis' | 'utf-8' | 'utf-16le' | 'mixed' = 'mixed';
  if (mode !== 'AUTO_MULTI') {
    detectedPrimaryEncoding =
      mode === 'shift_jis' ? 'shift_jis' : mode === 'utf-16le' ? 'utf-16le' : 'utf-8';
  } else if (encVotes.shift_jis > encVotes['utf-8'] && encVotes.shift_jis >= encVotes['utf-16le']) {
    detectedPrimaryEncoding = 'shift_jis';
  } else if (encVotes['utf-16le'] > encVotes['utf-8'] && encVotes['utf-16le'] > encVotes.shift_jis) {
    detectedPrimaryEncoding = 'utf-16le';
  } else if (encVotes['utf-8'] > 0) {
    detectedPrimaryEncoding = 'utf-8';
  }

  return {
    fileName,
    fileSize: blob.size,
    scannedBytes: totalToScan,
    encodingMode: mode,
    detectedPrimaryEncoding,
    compressedBlocksFound,
    compressedBlocksDecompressed,
    entries,
    categoryCounts,
    languageCounts,
  };
}

export function isLegibleTextEntry(entry: AnalyzedTextEntry): boolean {
  return hasHighReadability(entry.text);
}

export function exportTextAnalysis(
  summary: TextAnalysisSummary,
  format: 'TXT' | 'CSV' | 'JSON'
): string {
  if (format === 'JSON') {
    return JSON.stringify(
      {
        fileName: summary.fileName,
        fileSize: summary.fileSize,
        scannedBytes: summary.scannedBytes,
        detectedPrimaryEncoding: summary.detectedPrimaryEncoding,
        compressedBlocksFound: summary.compressedBlocksFound,
        compressedBlocksDecompressed: summary.compressedBlocksDecompressed,
        totalStrings: summary.entries.length,
        categoryCounts: summary.categoryCounts,
        languageCounts: summary.languageCounts,
        entries: summary.entries.map((e) => ({
          id: e.id,
          offsetHex: `0x${e.offset.toString(16).toUpperCase().padStart(8, '0')}`,
          sourceBlock: e.sourceBlock,
          byteLength: e.byteLength,
          encoding: e.encoding,
          language: e.languageHint,
          category: e.category,
          text: e.text,
        })),
      },
      null,
      2
    );
  }

  if (format === 'CSV') {
    const esc = (s: string) => `"${s.replace(/"/g, '""')}"`;
    const rows = ['ID,OffsetHex,Origen,Bytes,Codificacion,Idioma,Categoria,Texto'];
    for (const e of summary.entries) {
      rows.push(
        [
          e.id,
          `0x${e.offset.toString(16).toUpperCase().padStart(8, '0')}`,
          esc(e.sourceBlock),
          e.byteLength,
          e.encoding,
          e.languageHint,
          e.category,
          esc(e.text),
        ].join(',')
      );
    }
    return rows.join('\n');
  }

  const lines = [
    `ANALIZADOR DE TEXTOS UNIVERSAL — ${summary.fileName}`,
    `Tamaño total: ${summary.fileSize.toLocaleString('es-ES')} B · Escaneados: ${summary.scannedBytes.toLocaleString('es-ES')} B · Bloques descomprimidos: ${summary.compressedBlocksDecompressed}/${summary.compressedBlocksFound} · Cadenas: ${summary.entries.length}`,
    '='.repeat(80),
  ];
  for (const e of summary.entries) {
    const offHex = `0x${e.offset.toString(16).toUpperCase().padStart(8, '0')}`;
    lines.push(`[${offHex}] (${e.sourceBlock} · ${e.encoding} · ${e.languageHint} · ${e.category}) ${e.text}`);
  }
  return lines.join('\n');
}
