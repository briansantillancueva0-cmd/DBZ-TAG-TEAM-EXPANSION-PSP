import { parseParamSfo } from './sfo';
import type { IsoFileEntry, IsoInspectionResult, IsoVolumeInfo } from './types';

const SECTOR_SIZE = 2048;

async function readBlobSlice(blob: Blob, offset: number, length: number): Promise<Uint8Array> {
  const safeEnd = Math.min(blob.size, offset + length);
  if (offset >= blob.size || safeEnd <= offset) {
    return new Uint8Array(0);
  }
  const buf = await blob.slice(offset, safeEnd).arrayBuffer();
  return new Uint8Array(buf);
}

function readAscii(bytes: Uint8Array, start: number, len: number): string {
  const slice = bytes.subarray(start, Math.min(bytes.length, start + len));
  return new TextDecoder('ascii', { fatal: false }).decode(slice).replace(/\0+$/, '').trim();
}

function formatIsoDate(bytes: Uint8Array, offset: number): string {
  const raw = readAscii(bytes, offset, 16);
  if (raw.length < 14 || /^0+$/.test(raw.slice(0, 14))) return 'No especificada';
  return `${raw.slice(0, 4)}-${raw.slice(4, 6)}-${raw.slice(6, 8)} ${raw.slice(8, 10)}:${raw.slice(10, 12)}:${raw.slice(12, 14)}`;
}

interface RawDirRecord {
  name: string;
  isDirectory: boolean;
  lba: number;
  size: number;
}

function parseDirectorySectorBlock(data: Uint8Array): RawDirRecord[] {
  const results: RawDirRecord[] = [];
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  let pos = 0;

  while (pos < data.length) {
    const recLen = data[pos];
    if (recLen === 0) {
      // Skip padding until next 2048-byte sector boundary
      const nextSector = Math.floor(pos / SECTOR_SIZE) * SECTOR_SIZE + SECTOR_SIZE;
      if (nextSector <= pos) break;
      pos = nextSector;
      continue;
    }

    if (pos + recLen > data.length || recLen < 34) {
      break;
    }

    const lba = view.getUint32(pos + 2, true);
    const size = view.getUint32(pos + 10, true);
    const flags = data[pos + 25];
    const isDirectory = (flags & 0x02) !== 0;
    const idLen = data[pos + 32];

    if (pos + 33 + idLen <= data.length) {
      const rawNameBytes = data.subarray(pos + 33, pos + 33 + idLen);
      // Skip "." (0x00) and ".." (0x01)
      if (!(idLen === 1 && (rawNameBytes[0] === 0x00 || rawNameBytes[0] === 0x01))) {
        let name = new TextDecoder('ascii', { fatal: false }).decode(rawNameBytes);
        const semi = name.indexOf(';');
        if (semi !== -1) {
          name = name.slice(0, semi);
        }
        results.push({ name, isDirectory, lba, size });
      }
    }

    pos += recLen;
  }

  return results;
}

export async function inspectPspIso(file: Blob): Promise<IsoInspectionResult> {
  if (file.size < 17 * SECTOR_SIZE) {
    throw new Error('El archivo es demasiado pequeño para contener un Primary Volume Descriptor ISO 9660.');
  }

  // Check if compressed CSO ("CISO")
  const head = await readBlobSlice(file, 0, 16);
  const headMagic = readAscii(head, 0, 4);
  if (headMagic === 'CISO') {
    throw new Error(
      'El archivo está en formato CSO comprimido ("CISO"). Descomprímelo a .ISO estándar o extrae el EBOOT.BIN para analizarlo.'
    );
  }

  // Locate Primary Volume Descriptor starting at sector 16
  let pvd: Uint8Array | null = null;
  for (let sector = 16; sector < 32; sector++) {
    const secBytes = await readBlobSlice(file, sector * SECTOR_SIZE, SECTOR_SIZE);
    if (secBytes.length < SECTOR_SIZE) break;
    const volType = secBytes[0];
    const stdId = readAscii(secBytes, 1, 5);
    if (stdId !== 'CD001') break;
    if (volType === 1) {
      pvd = secBytes;
      break;
    }
    if (volType === 255) break;
  }

  if (!pvd) {
    throw new Error('No se encontró un Primary Volume Descriptor ISO 9660 ("CD001") válido.');
  }

  const pvdView = new DataView(pvd.buffer, pvd.byteOffset, pvd.byteLength);
  const volumeSpaceBlocks = pvdView.getUint32(80, true);
  const logicalBlockSize = pvdView.getUint16(128, true) || SECTOR_SIZE;

  const volume: IsoVolumeInfo = {
    systemId: readAscii(pvd, 8, 32) || 'PSP GAME',
    volumeId: readAscii(pvd, 40, 32) || 'Sin etiqueta',
    publisher: readAscii(pvd, 318, 128) || 'No especificado',
    dataPreparer: readAscii(pvd, 446, 128) || 'No especificado',
    applicationId: readAscii(pvd, 574, 128) || 'No especificado',
    volumeSpaceBlocks,
    logicalBlockSize,
    totalSizeBytes: file.size,
    creationDate: formatIsoDate(pvd, 813),
  };

  // Root Directory Record is at offset 156 (34 bytes) inside PVD
  const rootLba = pvdView.getUint32(156 + 2, true);
  const rootSize = pvdView.getUint32(156 + 10, true);

  const files: IsoFileEntry[] = [];
  let totalFiles = 0;
  let totalDirs = 0;
  const visitedLbas = new Set<number>();

  async function traverse(dirPath: string, lba: number, size: number, depth: number) {
    if (depth > 8 || visitedLbas.has(lba) || size === 0 || size > 4 * 1024 * 1024) {
      return;
    }
    visitedLbas.add(lba);

    const dirBytes = await readBlobSlice(file, lba * logicalBlockSize, size);
    const records = parseDirectorySectorBlock(dirBytes);

    for (const rec of records) {
      const fullPath = dirPath ? `${dirPath}/${rec.name}` : `/${rec.name}`;
      const entry: IsoFileEntry = {
        path: fullPath,
        name: rec.name,
        isDirectory: rec.isDirectory,
        lba: rec.lba,
        byteOffset: rec.lba * logicalBlockSize,
        size: rec.size,
      };
      files.push(entry);

      if (rec.isDirectory) {
        totalDirs++;
        await traverse(fullPath, rec.lba, rec.size, depth + 1);
      } else {
        totalFiles++;
      }
    }
  }

  await traverse('', rootLba, rootSize, 0);

  const findByPath = (target: string) =>
    files.find((f) => !f.isDirectory && f.path.toUpperCase() === target.toUpperCase()) ?? null;

  const ebootEntry =
    findByPath('/PSP_GAME/SYSDIR/EBOOT.BIN') ??
    files.find((f) => !f.isDirectory && f.name.toUpperCase() === 'EBOOT.BIN') ??
    null;

  const bootEntry =
    findByPath('/PSP_GAME/SYSDIR/BOOT.BIN') ??
    files.find((f) => !f.isDirectory && f.name.toUpperCase() === 'BOOT.BIN') ??
    null;

  const paramSfoEntry =
    findByPath('/PSP_GAME/PARAM.SFO') ??
    files.find((f) => !f.isDirectory && f.name.toUpperCase() === 'PARAM.SFO') ??
    null;

  let sfo = null;
  if (paramSfoEntry && paramSfoEntry.size > 0 && paramSfoEntry.size < 1024 * 1024) {
    const sfoBytes = await readBlobSlice(file, paramSfoEntry.byteOffset, paramSfoEntry.size);
    sfo = parseParamSfo(sfoBytes);
  }

  return {
    volume,
    files,
    totalFiles,
    totalDirs,
    ebootEntry,
    bootEntry,
    paramSfoEntry,
    sfo,
  };
}

export async function extractIsoFileBytes(file: Blob, entry: IsoFileEntry): Promise<Uint8Array> {
  return readBlobSlice(file, entry.byteOffset, entry.size);
}
