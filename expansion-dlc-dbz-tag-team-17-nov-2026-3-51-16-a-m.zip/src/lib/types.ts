export type BinaryFormatType = 'ELF32' | 'PSP_ENCRYPTED' | 'PBP' | 'UNKNOWN';

export interface SfoEntry {
  key: string;
  value: string | number;
  format: 'utf8' | 'int32' | 'utf8_special';
}

export interface SfoMetadata {
  title: string;
  discId: string;
  discVersion: string;
  pspSystemVer: string;
  appVer: string;
  category: string;
  categoryLabel: string;
  bootable: number;
  parentalLevel: number;
  region: number;
  entries: SfoEntry[];
}

export interface IsoVolumeInfo {
  systemId: string;
  volumeId: string;
  publisher: string;
  dataPreparer: string;
  applicationId: string;
  volumeSpaceBlocks: number;
  logicalBlockSize: number;
  totalSizeBytes: number;
  creationDate: string;
}

export interface IsoFileEntry {
  path: string;
  name: string;
  isDirectory: boolean;
  lba: number;
  byteOffset: number;
  size: number;
}

export interface IsoInspectionResult {
  volume: IsoVolumeInfo;
  files: IsoFileEntry[];
  totalFiles: number;
  totalDirs: number;
  ebootEntry: IsoFileEntry | null;
  bootEntry: IsoFileEntry | null;
  paramSfoEntry: IsoFileEntry | null;
  sfo: SfoMetadata | null;
}

export interface ElfHeaderInfo {
  elfClass: string;
  endianness: string;
  type: number;
  typeLabel: string;
  machine: number;
  machineLabel: string;
  entryPoint: number;
  phoff: number;
  shoff: number;
  flags: number;
  flagsLabel: string;
  phnum: number;
  shnum: number;
  shstrndx: number;
}

export interface ElfProgramSegment {
  index: number;
  type: number;
  typeLabel: string;
  offset: number;
  vaddr: number;
  paddr: number;
  filesz: number;
  memsz: number;
  flags: number;
  flagsText: string;
  align: number;
}

export interface ElfSectionInfo {
  index: number;
  name: string;
  type: number;
  typeLabel: string;
  flags: number;
  flagsText: string;
  vaddr: number;
  offset: number;
  size: number;
  align: number;
  purpose: string;
}

export interface PspHeaderInfo {
  modAttr: number;
  modAttrLabels: string[];
  compAttr: number;
  compAttrLabels: string[];
  modVerMajor: number;
  modVerMinor: number;
  modName: string;
  elfSize: number;
  pspSize: number;
  bootEntry: number;
  modInfoOffset: number;
  bssSize: number;
  devkitVersion: number;
  devkitVersionLabel: string;
  tagHex: string;
}

export interface PbpSectionEntry {
  name: string;
  offset: number;
  size: number;
  description: string;
}

export interface PbpHeaderInfo {
  version: number;
  entries: PbpSectionEntry[];
}

export interface SceModuleInfo {
  attributes: number;
  attributeLabels: string[];
  versionMajor: number;
  versionMinor: number;
  name: string;
  gpValue: number;
  entTop: number;
  entEnd: number;
  stubTop: number;
  stubEnd: number;
  fileOffset: number;
  ramAddress: number;
}

export interface ImportedLibrary {
  name: string;
  version: string;
  flags: number;
  nidCount: number;
  stubAddr: number;
  nidTableAddr: number;
  purpose: string;
}

export type AddressCategory =
  | 'ENTRY_POINT'
  | 'SECTION'
  | 'SEGMENT'
  | 'MODULE_INFO'
  | 'LIBRARY_STUB'
  | 'STRING_PATH'
  | 'STRING_SCE'
  | 'STRING_DEBUG'
  | 'MIPS_JAL'
  | 'MIPS_PTR';

export interface AddressEntry {
  index: number;
  category: AddressCategory;
  categoryLabel: string;
  label: string;
  fileOffset: number | null;
  ramAddress: number | null;
  sizeOrValue: string;
  sectionName: string;
  description: string;
}

export interface EbootAnalysis {
  sourceName: string;
  sourceKind: 'ISO' | 'STANDALONE' | 'SAMPLE';
  targetBinaryPath: string;
  fileSize: number;
  format: BinaryFormatType;
  formatLabel: string;
  isEncryptedPsp: boolean;
  isStrippedElf: boolean;
  baseRamAddress: number;
  elfHeader: ElfHeaderInfo | null;
  pspHeader: PspHeaderInfo | null;
  pbpHeader: PbpHeaderInfo | null;
  moduleInfo: SceModuleInfo | null;
  segments: ElfProgramSegment[];
  sections: ElfSectionInfo[];
  libraries: ImportedLibrary[];
  addresses: AddressEntry[];
  isoInfo: IsoInspectionResult | null;
  sfoInfo: SfoMetadata | null;
  alternativeBootBinaryPath: string | null;
  analyzedNotes: string[];
  rawBytes: Uint8Array;
}

export interface ReportSectionIndex {
  id: string;
  code: string;
  title: string;
  countLabel: string;
}

export interface IndexedReport {
  generatedAt: string;
  title: string;
  toc: ReportSectionIndex[];
  plainText: string;
  markdown: string;
  csv: string;
  json: string;
}

export type GameAssetCategory =
  | 'CHARACTERS'
  | 'MAPS'
  | 'TEXTURES'
  | 'MUSIC'
  | 'MINIMAPS';

export interface GameAssetItem {
  index: number;
  category: GameAssetCategory;
  categoryLabel: string;
  source: 'ISO_FILE' | 'EBOOT_REF' | 'EBOOT_LIB';
  name: string;
  pathOrSymbol: string;
  extension: string;
  sizeBytes: number | null;
  lba: number | null;
  fileOffset: number | null;
  ramAddress: number | null;
  isoEntryPath: string | null;
  notes: string;
}

export interface GameAssetCategorySummary {
  category: GameAssetCategory;
  label: string;
  description: string;
  count: number;
  isoFileCount: number;
  ebootRefCount: number;
  totalIsoBytes: number;
}

export interface GameAssetReport {
  items: GameAssetItem[];
  summaries: GameAssetCategorySummary[];
  totalCount: number;
  totalIsoBytes: number;
}

