export type TextEncodingMode =
  | 'windows-1252'
  | 'utf-8'
  | 'shift_jis'
  | 'utf-16le'
  | 'custom_tbl';

export interface ParsedCodeTable {
  rawText: string;
  byteToChar: Map<string, string>; // uppercase hex (2, 4, 6 hex chars) -> decoded string
  charToBytes: Array<{ token: string; bytes: number[] }>; // sorted longest token first
  maxHexBytes: number;
  entryCount: number;
}

export const PRESET_TBL_ESPANOL = `# Tabla de Códigos Español (Windows-1252 / Latin-1)
# Formato: HEX=Carácter o Token
00=<FIN>
0A=\\n
20= 
A1=¡
BF=¿
C1=Á
C9=É
CD=Í
D1=Ñ
D3=Ó
DA=Ú
DC=Ü
E1=á
E7=ç
E9=é
ED=í
F1=ñ
F3=ó
FA=ú
FC=ü`;

export const PRESET_TBL_SHIFTJIS = `# Tabla de Códigos PSP Japonés (Shift-JIS básico + Control)
00=<FIN>
0A=\\n
8140=　
8141=、
8142=。
8145=・
8148=？
8149=！
8169=（
816A=）
8175=「
8176=」
82A0=あ
82A2=い
82A4=う
82A6=え
82A8=お
82A9=か
82B3=さ
82BD=た`;

export const PRESET_TBL_CONTROL = `# Tabla de Códigos Hex -> Texto (Plantilla editable)
00=<FIN>
01=<PAUSA>
0A=\\n
20= 
41=A
42=B
43=C
E1=á
E9=é
ED=í
F1=ñ
F3=ó
FA=ú`;

// Windows-1252 0x80..0x9F special map
const WIN1252_EXTRA: Record<number, string> = {
  0x80: '€',
  0x82: '‚',
  0x83: 'ƒ',
  0x84: '„',
  0x85: '…',
  0x86: '†',
  0x87: '‡',
  0x88: 'ˆ',
  0x89: '‰',
  0x8a: 'Š',
  0x8b: '‹',
  0x8c: 'Œ',
  0x8e: 'Ž',
  0x91: '‘',
  0x92: '’',
  0x93: '“',
  0x94: '”',
  0x95: '•',
  0x96: '–',
  0x97: '—',
  0x98: '˜',
  0x99: '™',
  0x9a: 'š',
  0x9b: '›',
  0x9c: 'œ',
  0x9e: 'ž',
  0x9f: 'Ÿ',
};

const WIN1252_REVERSE: Map<string, number> = (() => {
  const m = new Map<string, number>();
  for (let b = 0x20; b <= 0x7e; b++) {
    m.set(String.fromCharCode(b), b);
  }
  for (const [byteStr, ch] of Object.entries(WIN1252_EXTRA)) {
    m.set(ch, Number(byteStr));
  }
  for (let b = 0xa0; b <= 0xff; b++) {
    m.set(String.fromCharCode(b), b);
  }
  return m;
})();

let cachedShiftJisReverse: Map<string, number[]> | null = null;

function getShiftJisReverseMap(): Map<string, number[]> {
  if (cachedShiftJisReverse) return cachedShiftJisReverse;
  const map = new Map<string, number[]>();
  const dec = new TextDecoder('shift_jis', { fatal: true });

  // ASCII
  for (let b = 0x20; b <= 0x7e; b++) {
    map.set(String.fromCharCode(b), [b]);
  }
  // Half-width katakana 0xA1..0xDF
  for (let b = 0xa1; b <= 0xdf; b++) {
    try {
      const ch = dec.decode(new Uint8Array([b]));
      if (ch && !map.has(ch)) map.set(ch, [b]);
    } catch {
      // skip invalid
    }
  }
  // 2-byte Shift-JIS
  const leadRanges = [
    [0x81, 0x9f],
    [0xe0, 0xef],
  ];
  const pair = new Uint8Array(2);
  for (const [start, end] of leadRanges) {
    for (let b1 = start; b1 <= end; b1++) {
      pair[0] = b1;
      for (let b2 = 0x40; b2 <= 0xfc; b2++) {
        if (b2 === 0x7f) continue;
        pair[1] = b2;
        try {
          const ch = dec.decode(pair);
          if (ch && ch.length === 1 && !map.has(ch)) {
            map.set(ch, [b1, b2]);
          }
        } catch {
          // skip unmapped
        }
      }
    }
  }
  cachedShiftJisReverse = map;
  return map;
}

export function parseCodeTable(rawText: string): ParsedCodeTable {
  const byteToChar = new Map<string, string>();
  const charToBytesMap = new Map<string, number[]>();
  let maxHexBytes = 1;

  const lines = rawText.split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trimEnd();
    if (!trimmed || trimmed.startsWith('#') || trimmed.startsWith('//')) continue;

    const eqIdx = trimmed.indexOf('=');
    if (eqIdx <= 0) continue;

    const hexPart = trimmed.slice(0, eqIdx).trim().replace(/^0x/i, '').toUpperCase();
    const valPart = trimmed.slice(eqIdx + 1);
    if (!/^[0-9A-F]+$/.test(hexPart) || hexPart.length % 2 !== 0) continue;

    const byteCount = hexPart.length / 2;
    if (byteCount > 4) continue;
    if (byteCount > maxHexBytes) maxHexBytes = byteCount;

    const bytes: number[] = [];
    for (let i = 0; i < hexPart.length; i += 2) {
      bytes.push(parseInt(hexPart.slice(i, i + 2), 16));
    }

    byteToChar.set(hexPart, valPart);
    if (valPart.length > 0 && !charToBytesMap.has(valPart)) {
      charToBytesMap.set(valPart, bytes);
    }
  }

  const charToBytes = Array.from(charToBytesMap.entries())
    .map(([token, bytes]) => ({ token, bytes }))
    .sort((a, b) => b.token.length - a.token.length);

  return {
    rawText,
    byteToChar,
    charToBytes,
    maxHexBytes,
    entryCount: byteToChar.size,
  };
}

function byteToHex2(b: number): string {
  return b.toString(16).toUpperCase().padStart(2, '0');
}

export function decodeByteCell(
  buffer: Uint8Array,
  offset: number,
  encoding: TextEncodingMode,
  table: ParsedCodeTable | null,
  applyTableOverlay: boolean
): { text: string; isPrintable: boolean } {
  if (offset < 0 || offset >= buffer.length) return { text: ' ', isPrintable: false };

  // Check custom TBL overlay first if enabled or mode is custom_tbl
  if ((applyTableOverlay || encoding === 'custom_tbl') && table && table.entryCount > 0) {
    for (let len = table.maxHexBytes; len >= 1; len--) {
      if (offset + len <= buffer.length) {
        let key = '';
        for (let k = 0; k < len; k++) key += byteToHex2(buffer[offset + k]);
        const mapped = table.byteToChar.get(key);
        if (mapped !== undefined) {
          // For single-cell grid width, show first visible glyph or short symbol
          const display = mapped === ' ' ? ' ' : mapped.length <= 2 ? mapped : mapped.slice(0, 2);
          return { text: display, isPrintable: true };
        }
      }
    }
    if (encoding === 'custom_tbl') {
      const b = buffer[offset];
      if (b >= 32 && b <= 126) return { text: String.fromCharCode(b), isPrintable: true };
      return { text: '.', isPrintable: false };
    }
  }

  const b = buffer[offset];

  if (encoding === 'windows-1252') {
    if (b >= 32 && b <= 126) return { text: String.fromCharCode(b), isPrintable: true };
    if (b >= 0x80 && b <= 0x9f && WIN1252_EXTRA[b]) {
      return { text: WIN1252_EXTRA[b], isPrintable: true };
    }
    if (b >= 0xa0) return { text: String.fromCharCode(b), isPrintable: true };
    return { text: '.', isPrintable: false };
  }

  if (encoding === 'utf-8') {
    if (b >= 32 && b <= 126) return { text: String.fromCharCode(b), isPrintable: true };
    if ((b & 0xc0) === 0x80) return { text: '·', isPrintable: true }; // continuation byte
    if (b >= 0xc2) {
      try {
        const dec = new TextDecoder('utf-8', { fatal: true });
        for (let l = 2; l <= 4 && offset + l <= buffer.length; l++) {
          try {
            const s = dec.decode(buffer.subarray(offset, offset + l));
            if (s) return { text: s, isPrintable: true };
          } catch {
            // try longer
          }
        }
      } catch {
        // fallback
      }
    }
    return { text: '.', isPrintable: false };
  }

  if (encoding === 'shift_jis') {
    if (b >= 32 && b <= 126) return { text: String.fromCharCode(b), isPrintable: true };
    if (b >= 0xa1 && b <= 0xdf) {
      const dec = new TextDecoder('shift_jis', { fatal: false });
      return { text: dec.decode(buffer.subarray(offset, offset + 1)), isPrintable: true };
    }
    if (((b >= 0x81 && b <= 0x9f) || (b >= 0xe0 && b <= 0xef)) && offset + 1 < buffer.length) {
      try {
        const dec = new TextDecoder('shift_jis', { fatal: true });
        const ch = dec.decode(buffer.subarray(offset, offset + 2));
        if (ch) return { text: ch, isPrintable: true };
      } catch {
        // invalid pair
      }
    }
    return { text: '.', isPrintable: false };
  }

  if (encoding === 'utf-16le') {
    if (offset % 2 === 0 && offset + 1 < buffer.length) {
      const code = buffer[offset] | (buffer[offset + 1] << 8);
      if (code >= 32 && code !== 0x7f && code < 0xd800) {
        return { text: String.fromCharCode(code), isPrintable: true };
      }
    } else if (offset % 2 === 1) {
      return { text: '·', isPrintable: false };
    }
    return { text: '.', isPrintable: false };
  }

  return { text: b >= 32 && b <= 126 ? String.fromCharCode(b) : '.', isPrintable: b >= 32 && b <= 126 };
}

export function decodeSlicePreview(
  buffer: Uint8Array,
  offset: number,
  maxBytes: number,
  encoding: TextEncodingMode,
  table: ParsedCodeTable | null,
  applyTableOverlay: boolean
): string {
  const slice = buffer.subarray(offset, Math.min(buffer.length, offset + maxBytes));
  if (slice.length === 0) return '';

  if ((applyTableOverlay || encoding === 'custom_tbl') && table && table.entryCount > 0) {
    let out = '';
    let i = 0;
    while (i < slice.length) {
      let matched = false;
      for (let len = table.maxHexBytes; len >= 1; len--) {
        if (i + len <= slice.length) {
          let key = '';
          for (let k = 0; k < len; k++) key += byteToHex2(slice[i + k]);
          const val = table.byteToChar.get(key);
          if (val !== undefined) {
            out += val;
            i += len;
            matched = true;
            if (val === '<FIN>' || slice[i - 1] === 0) return out;
            break;
          }
        }
      }
      if (!matched) {
        const b = slice[i];
        if (b === 0) break;
        out += b >= 32 && b <= 126 ? String.fromCharCode(b) : '.';
        i++;
      }
    }
    return out;
  }

  try {
    const label =
      encoding === 'windows-1252'
        ? 'windows-1252'
        : encoding === 'shift_jis'
        ? 'shift_jis'
        : encoding === 'utf-16le'
        ? 'utf-16le'
        : 'utf-8';
    const raw = new TextDecoder(label, { fatal: false }).decode(slice);
    const nullIdx = raw.indexOf('\0');
    const cut = nullIdx >= 0 ? raw.slice(0, nullIdx) : raw;
    return cut.replace(/[\x00-\x1F\x7F]/g, '.');
  } catch {
    return '';
  }
}

export function encodeTextToBytes(
  text: string,
  encoding: TextEncodingMode,
  table: ParsedCodeTable | null,
  applyTableOverlay: boolean
): { bytes: Uint8Array; unmappedChars: string[] } {
  const out: number[] = [];
  const unmappedChars: string[] = [];

  if ((applyTableOverlay || encoding === 'custom_tbl') && table && table.entryCount > 0) {
    let i = 0;
    while (i < text.length) {
      let matched = false;
      for (const entry of table.charToBytes) {
        if (text.startsWith(entry.token, i)) {
          out.push(...entry.bytes);
          i += entry.token.length;
          matched = true;
          break;
        }
      }
      if (!matched) {
        const ch = text[i];
        const code = ch.charCodeAt(0);
        if (encoding !== 'custom_tbl') {
          // Fallback to base encoding for this single character
          const single = encodeSingleChar(ch, encoding);
          if (single) {
            out.push(...single);
          } else {
            unmappedChars.push(ch);
            out.push(0x3f);
          }
        } else if (code >= 0x20 && code <= 0x7e) {
          out.push(code);
        } else {
          unmappedChars.push(ch);
          out.push(0x3f);
        }
        i++;
      }
    }
    return { bytes: new Uint8Array(out), unmappedChars };
  }

  if (encoding === 'utf-8') {
    return { bytes: new TextEncoder().encode(text), unmappedChars };
  }

  if (encoding === 'utf-16le') {
    for (let i = 0; i < text.length; i++) {
      const code = text.charCodeAt(i);
      out.push(code & 0xff, (code >>> 8) & 0xff);
    }
    return { bytes: new Uint8Array(out), unmappedChars };
  }

  for (const ch of text) {
    const encoded = encodeSingleChar(ch, encoding);
    if (encoded) {
      out.push(...encoded);
    } else {
      unmappedChars.push(ch);
      out.push(0x3f);
    }
  }
  return { bytes: new Uint8Array(out), unmappedChars };
}

function encodeSingleChar(ch: string, encoding: TextEncodingMode): number[] | null {
  if (encoding === 'windows-1252') {
    const b = WIN1252_REVERSE.get(ch);
    if (b !== undefined) return [b];
    if (ch === '\n') return [0x0a];
    return null;
  }
  if (encoding === 'shift_jis') {
    const sjisMap = getShiftJisReverseMap();
    const seq = sjisMap.get(ch);
    if (seq) return seq;
    if (ch === '\n') return [0x0a];
    return null;
  }
  const utf8 = new TextEncoder().encode(ch);
  return Array.from(utf8);
}

export interface ExtractedLanguageString {
  offset: number;
  lengthBytes: number;
  text: string;
  hasExtendedChars: boolean;
}

export function extractMultilingualStrings(
  buffer: Uint8Array,
  encoding: TextEncodingMode,
  table: ParsedCodeTable | null,
  applyTableOverlay: boolean,
  minLength = 4
): ExtractedLanguageString[] {
  const results: ExtractedLanguageString[] = [];
  const limit = Math.min(buffer.length, 4 * 1024 * 1024);

  if (encoding === 'utf-16le') {
    let cur = '';
    let start = -1;
    for (let i = 0; i + 1 < limit; i += 2) {
      const code = buffer[i] | (buffer[i + 1] << 8);
      if ((code >= 32 && code <= 126) || (code >= 0xa1 && code <= 0x2ff) || (code >= 0x3040 && code <= 0x9fff)) {
        if (start === -1) start = i;
        cur += String.fromCharCode(code);
      } else {
        if (cur.length >= minLength) {
          results.push({
            offset: start,
            lengthBytes: cur.length * 2,
            text: cur,
            hasExtendedChars: /[^\x20-\x7E]/.test(cur),
          });
        }
        cur = '';
        start = -1;
      }
    }
    return results.slice(0, 400);
  }

  let i = 0;
  let cur = '';
  let start = -1;

  const flush = (endPos: number) => {
    if (cur.length >= minLength) {
      results.push({
        offset: start,
        lengthBytes: endPos - start,
        text: cur,
        hasExtendedChars: /[^\x20-\x7E]/.test(cur),
      });
    }
    cur = '';
    start = -1;
  };

  while (i < limit && results.length < 400) {
    // Custom table check
    if ((applyTableOverlay || encoding === 'custom_tbl') && table && table.entryCount > 0) {
      let matched = false;
      for (let len = table.maxHexBytes; len >= 1; len--) {
        if (i + len <= limit) {
          let key = '';
          for (let k = 0; k < len; k++) key += byteToHex2(buffer[i + k]);
          const val = table.byteToChar.get(key);
          if (val !== undefined) {
            if (val === '<FIN>' || buffer[i] === 0) {
              flush(i);
            } else {
              if (start === -1) start = i;
              cur += val;
            }
            i += len;
            matched = true;
            break;
          }
        }
      }
      if (matched) continue;
    }

    const b = buffer[i];
    if (encoding === 'shift_jis') {
      if (b >= 32 && b <= 126) {
        if (start === -1) start = i;
        cur += String.fromCharCode(b);
        i++;
        continue;
      }
      if (b >= 0xa1 && b <= 0xdf) {
        if (start === -1) start = i;
        cur += new TextDecoder('shift_jis').decode(buffer.subarray(i, i + 1));
        i++;
        continue;
      }
      if (((b >= 0x81 && b <= 0x9f) || (b >= 0xe0 && b <= 0xef)) && i + 1 < limit) {
        try {
          const dec = new TextDecoder('shift_jis', { fatal: true });
          const ch = dec.decode(buffer.subarray(i, i + 2));
          if (start === -1) start = i;
          cur += ch;
          i += 2;
          continue;
        } catch {
          // invalid
        }
      }
      flush(i);
      i++;
      continue;
    }

    if (encoding === 'utf-8') {
      if (b >= 32 && b <= 126) {
        if (start === -1) start = i;
        cur += String.fromCharCode(b);
        i++;
        continue;
      }
      if (b >= 0xc2) {
        let decoded = false;
        const dec = new TextDecoder('utf-8', { fatal: true });
        for (let l = 2; l <= 4 && i + l <= limit; l++) {
          try {
            const ch = dec.decode(buffer.subarray(i, i + l));
            if (start === -1) start = i;
            cur += ch;
            i += l;
            decoded = true;
            break;
          } catch {
            // try longer
          }
        }
        if (decoded) continue;
      }
      flush(i);
      i++;
      continue;
    }

    // windows-1252 / custom_tbl fallback
    if ((b >= 32 && b <= 126) || (b >= 0xa1 && b !== 0xad) || (b >= 0x80 && WIN1252_EXTRA[b])) {
      if (start === -1) start = i;
      cur += b >= 0x80 && WIN1252_EXTRA[b] ? WIN1252_EXTRA[b] : String.fromCharCode(b);
    } else {
      flush(i);
    }
    i++;
  }

  flush(i);
  return results;
}
