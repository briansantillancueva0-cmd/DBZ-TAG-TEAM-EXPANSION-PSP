import { buildSampleParamSfo, buildSamplePspElf } from './sampleBuilder';
import { parseParamSfo } from './sfo';
import type { IsoInspectionResult, SfoMetadata } from './types';
import { buildZipBlobAsync, type AsyncZipInputEntry } from './zipBuilder';

const SECTOR_SIZE = 2048;
const PSP_UMD_MAX_SECTORS = 921600; // ~1.8 GB Single-Layer UMD
const FAT32_MAX_SECTORS = 2097151; // ~4.0 GB ISO32 / FAT32 limit

export type PackerEntryOrigin =
  | 'BASE_ISO'
  | 'LOCAL_FOLDER'
  | 'LOCAL_FILE'
  | 'MODIFIED_EBOOT'
  | 'GENERATED';

export interface PackerEntry {
  path: string; // Normalized ISO path, e.g. "/PSP_GAME/SYSDIR/EBOOT.BIN"
  size: number;
  source: Blob | Uint8Array;
  origin: PackerEntryOrigin;
}

export interface PackerValidationItem {
  id: string;
  title: string;
  status: 'OK' | 'WARN' | 'BLOCKED';
  detail: string;
}

export interface PackerValidationResult {
  canPack: boolean;
  hasParamSfo: boolean;
  hasBootBinary: boolean;
  hasUmdData: boolean;
  detectedSfo: SfoMetadata | null;
  maxDepth: number;
  projectedSectors: number;
  projectedBytes: number;
  items: PackerValidationItem[];
}

export interface PackPspIsoOptions {
  volumeId?: string;
  systemId?: string;
  publisher?: string;
  dataPreparer?: string;
  applicationId?: string;
  baseIsoBlob?: Blob | null;
  autoGenerateUmdData?: boolean;
  preserveCase?: boolean;
  discIdHint?: string;
  onProgress?: (phase: string, percent: number) => void;
}

export interface PackPspIsoResult {
  isoBlob: Blob;
  parts: BlobPart[];
  totalSectors: number;
  totalBytes: number;
  totalFiles: number;
  totalDirs: number;
}

function normalizeIsoSegment(raw: string, isDir: boolean, preserveCase = true): string {
  const base = raw.trim().replace(/;1$/i, '');
  const cased = preserveCase ? base : base.toUpperCase();
  const clean = cased.replace(/[^A-Za-z0-9._-]/g, '_');
  if (isDir) {
    return clean.slice(0, 31) || 'SUBDIR';
  }
  return clean.slice(0, 31) || 'FILE.BIN';
}

export function normalizeIsoPackerPath(rawPath: string, preserveCase = true): string {
  const parts = rawPath
    .replace(/\\/g, '/')
    .split('/')
    .map((p) => p.trim())
    .filter(Boolean);
  if (parts.length === 0) return '/ARCHIVO.BIN';
  const normalized = parts.map((seg, idx) =>
    normalizeIsoSegment(seg, idx < parts.length - 1, preserveCase)
  );
  return '/' + normalized.join('/');
}

export function normalizeIsoFolderPath(rawPath: string, preserveCase = true): string {
  const parts = rawPath
    .replace(/\\/g, '/')
    .split('/')
    .map((p) => p.trim())
    .filter(Boolean);
  if (parts.length === 0) return '/';
  return '/' + parts.map((seg) => normalizeIsoSegment(seg, true, preserveCase)).join('/');
}

export function buildUmdDataBin(discId = 'ULES99999'): Uint8Array {
  const clean = discId.replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 9) || 'ULES99999';
  const formatted = clean.length >= 9 ? `${clean.slice(0, 4)}-${clean.slice(4, 9)}` : clean;
  const line = `${formatted}|0000000000000000|0001|G\0`;
  const out = new Uint8Array(Math.max(32, line.length));
  out.set(new TextEncoder().encode(line), 0);
  return out;
}

export function buildMinimalPspPackerTemplate(): {
  entries: PackerEntry[];
  emptyDirs: string[];
} {
  const sfo = buildSampleParamSfo();
  const eboot = buildSamplePspElf();
  const umdData = buildUmdDataBin('ULES99999');

  return {
    entries: [
      { path: '/UMD_DATA.BIN', size: umdData.length, source: umdData, origin: 'GENERATED' },
      { path: '/PSP_GAME/PARAM.SFO', size: sfo.length, source: sfo, origin: 'GENERATED' },
      { path: '/PSP_GAME/SYSDIR/EBOOT.BIN', size: eboot.length, source: eboot, origin: 'GENERATED' },
    ],
    emptyDirs: ['/PSP_GAME/USRDIR'],
  };
}

/**
 * Normalizes a list of files coming from `<input webkitdirectory>` or recursive drag & drop.
 * Automatically strips a common outer wrapper folder (e.g. `MiJuego_Extracted/PSP_GAME/...`)
 * or wraps `SYSDIR`/`PARAM.SFO`/`USRDIR` under `/PSP_GAME/` if user selected the `PSP_GAME` folder directly.
 */
export function normalizeUploadedFolderFiles(
  files: Array<{ file: File; relativePath?: string }>,
  preserveCase = true
): { entries: PackerEntry[]; strippedWrapper: string | null } {
  if (files.length === 0) return { entries: [], strippedWrapper: null };

  const relPartsList = files.map((item) => {
    const rawRel = item.relativePath || item.file.webkitRelativePath || item.file.name;
    return rawRel
      .replace(/\\/g, '/')
      .split('/')
      .map((s) => s.trim())
      .filter(Boolean);
  });

  // Check if all files share a single top-level directory
  let strippedWrapper: string | null = null;
  const firstSegs = new Set(relPartsList.map((p) => (p.length > 1 ? p[0] : '')));
  if (firstSegs.size === 1) {
    const onlyTop = Array.from(firstSegs)[0];
    if (onlyTop && onlyTop.toUpperCase() !== 'PSP_GAME') {
      // Only strip wrapper if inside it we see PSP_GAME or UMD_DATA.BIN or SYSDIR/USRDIR/INSDIR/PARAM.SFO
      const looksLikeGameRoot = relPartsList.some(
        (p) =>
          p.length > 1 &&
          ['PSP_GAME', 'UMD_DATA.BIN', 'SYSDIR', 'USRDIR', 'INSDIR', 'PARAM.SFO'].includes(
            p[1].toUpperCase()
          )
      );
      if (looksLikeGameRoot) {
        strippedWrapper = onlyTop;
      }
    }
  }

  const trimmedPartsList = relPartsList.map((parts) =>
    strippedWrapper && parts.length > 1 ? parts.slice(1) : parts
  );

  // Check if user picked inside PSP_GAME directly (e.g. root has PARAM.SFO / SYSDIR / USRDIR / INSDIR without PSP_GAME)
  const hasPspGameTop = trimmedPartsList.some((p) => p[0]?.toUpperCase() === 'PSP_GAME');
  const hasDirectPspSubitems = trimmedPartsList.some((p) =>
    ['PARAM.SFO', 'SYSDIR', 'USRDIR', 'INSDIR', 'ICON0.PNG', 'PIC1.PNG', 'SND0.AT3'].includes(
      p[0]?.toUpperCase() || ''
    )
  );
  const prependPspGame = !hasPspGameTop && hasDirectPspSubitems;

  const entries: PackerEntry[] = [];
  for (let i = 0; i < files.length; i++) {
    const rawParts = trimmedPartsList[i];
    if (rawParts.length === 0) continue;
    const finalParts =
      prependPspGame && !['UMD_DATA.BIN', 'FONT.PGF'].includes(rawParts[0].toUpperCase())
        ? ['PSP_GAME', ...rawParts]
        : rawParts;
    const normPath = normalizeIsoPackerPath(finalParts.join('/'), preserveCase);
    const f = files[i].file;
    entries.push({
      path: normPath,
      size: f.size,
      source: f,
      origin: 'LOCAL_FOLDER',
    });
  }

  return { entries, strippedWrapper };
}

/**
 * Adds a selected folder (e.g. INSDIR, UPDATE, USRDIR, MOD, PSP_GAME) directly into `targetBaseFolder`
 * preserving the selected folder's name and all nested subfolders.
 */
export function appendFolderFilesToTarget(
  files: Array<{ file: File; relativePath?: string }>,
  targetBaseFolder: string,
  options: { preserveCase?: boolean; stripOuterFolder?: boolean } = {}
): { entries: PackerEntry[]; folderName: string | null } {
  const preserveCase = options.preserveCase ?? true;
  const cleanBase =
    targetBaseFolder.trim() === '/' || targetBaseFolder.trim() === ''
      ? ''
      : normalizeIsoFolderPath(targetBaseFolder, preserveCase);

  let folderName: string | null = null;
  const entries: PackerEntry[] = [];

  for (const item of files) {
    const rawRel = (item.relativePath || item.file.webkitRelativePath || item.file.name)
      .replace(/\\/g, '/')
      .split('/')
      .map((s) => s.trim())
      .filter(Boolean);
    if (rawRel.length === 0) continue;

    if (!folderName && rawRel.length > 1) {
      folderName = rawRel[0];
    }

    const parts = options.stripOuterFolder && rawRel.length > 1 ? rawRel.slice(1) : rawRel;
    // Avoid duplicating folder name if targetBaseFolder already ends with the same folder name (e.g. target=/PSP_GAME/INSDIR and picked folder is INSDIR)
    const baseTail = cleanBase.split('/').filter(Boolean).pop()?.toUpperCase();
    const dedupParts =
      baseTail && parts.length > 1 && parts[0].toUpperCase() === baseTail
        ? parts.slice(1)
        : parts;

    const fullPath = normalizeIsoPackerPath(
      `${cleanBase}/${dedupParts.join('/')}`,
      preserveCase
    );
    entries.push({
      path: fullPath,
      size: item.file.size,
      source: item.file,
      origin: 'LOCAL_FOLDER',
    });
  }

  return { entries, folderName };
}

export async function readDroppedItemsWithFolders(
  dataTransfer: DataTransfer
): Promise<Array<{ file: File; relativePath: string }>> {
  const results: Array<{ file: File; relativePath: string }> = [];
  const items = Array.from(dataTransfer.items || []);

  type WebkitEntry = {
    isFile: boolean;
    isDirectory: boolean;
    name: string;
    fullPath?: string;
    file?: (cb: (f: File) => void, err?: (e: unknown) => void) => void;
    createReader?: () => {
      readEntries: (cb: (entries: WebkitEntry[]) => void, err?: (e: unknown) => void) => void;
    };
  };

  const readEntry = async (entry: WebkitEntry, prefix: string): Promise<void> => {
    if (entry.isFile && entry.file) {
      await new Promise<void>((resolve) => {
        entry.file!(
          (file) => {
            results.push({
              file,
              relativePath: prefix ? `${prefix}/${file.name}` : file.name,
            });
            resolve();
          },
          () => resolve()
        );
      });
    } else if (entry.isDirectory && entry.createReader) {
      const reader = entry.createReader();
      const nextPrefix = prefix ? `${prefix}/${entry.name}` : entry.name;
      while (true) {
        const batch = await new Promise<WebkitEntry[]>((resolve) => {
          reader.readEntries(
            (entries) => resolve(entries),
            () => resolve([])
          );
        });
        if (batch.length === 0) break;
        for (const child of batch) {
          await readEntry(child, nextPrefix);
        }
      }
    }
  };

  const webkitEntries = items
    .map((it) => (it as unknown as { webkitGetAsEntry?: () => WebkitEntry | null }).webkitGetAsEntry?.())
    .filter((e): e is WebkitEntry => Boolean(e));

  if (webkitEntries.length > 0) {
    for (const entry of webkitEntries) {
      await readEntry(entry, '');
    }
    return results;
  }

  for (const file of Array.from(dataTransfer.files || [])) {
    results.push({
      file,
      relativePath: file.webkitRelativePath || file.name,
    });
  }
  return results;
}

export function importIsoToPackerEntries(
  isoBlob: Blob,
  isoInfo: IsoInspectionResult
): { entries: PackerEntry[]; emptyDirs: string[] } {
  const entries: PackerEntry[] = [];
  const dirPaths = new Set<string>();
  const nonEmptyDirs = new Set<string>();

  for (const f of isoInfo.files) {
    if (f.isDirectory) {
      dirPaths.add(normalizeIsoFolderPath(f.path));
    } else {
      const norm = normalizeIsoPackerPath(f.path);
      entries.push({
        path: norm,
        size: f.size,
        source: isoBlob.slice(f.byteOffset, f.byteOffset + f.size),
        origin: 'BASE_ISO',
      });
      const parts = norm.split('/').filter(Boolean);
      for (let i = 1; i < parts.length; i++) {
        nonEmptyDirs.add('/' + parts.slice(0, i).join('/'));
      }
    }
  }

  const emptyDirs = Array.from(dirPaths).filter((d) => !nonEmptyDirs.has(d));
  return { entries, emptyDirs };
}

export async function validatePackerProject(
  entries: PackerEntry[],
  emptyDirs: string[]
): Promise<PackerValidationResult> {
  const items: PackerValidationItem[] = [];
  const byUpper = new Map<string, PackerEntry>();
  for (const e of entries) {
    byUpper.set(e.path.toUpperCase(), e);
  }

  const paramSfoEntry = byUpper.get('/PSP_GAME/PARAM.SFO') ?? null;
  let detectedSfo: SfoMetadata | null = null;
  if (paramSfoEntry && paramSfoEntry.size > 0 && paramSfoEntry.size < 1024 * 1024) {
    try {
      const bytes =
        paramSfoEntry.source instanceof Uint8Array
          ? paramSfoEntry.source
          : new Uint8Array(await paramSfoEntry.source.arrayBuffer());
      detectedSfo = parseParamSfo(bytes);
    } catch {
      detectedSfo = null;
    }
  }

  const ebootEntry = byUpper.get('/PSP_GAME/SYSDIR/EBOOT.BIN') ?? null;
  const bootEntry = byUpper.get('/PSP_GAME/SYSDIR/BOOT.BIN') ?? null;
  const umdDataEntry = byUpper.get('/UMD_DATA.BIN') ?? null;

  const hasParamSfo = Boolean(paramSfoEntry);
  const hasBootBinary = Boolean(ebootEntry || bootEntry);
  const hasUmdData = Boolean(umdDataEntry);

  items.push({
    id: 'param_sfo',
    title: 'Identificador PSP (/PSP_GAME/PARAM.SFO)',
    status: hasParamSfo ? 'OK' : 'WARN',
    detail: hasParamSfo
      ? detectedSfo
        ? `Válido: "${detectedSfo.title}" (${detectedSfo.discId} · FW ${detectedSfo.pspSystemVer}).`
        : 'Archivo PARAM.SFO incluido en /PSP_GAME/PARAM.SFO.'
      : 'No se encontró /PSP_GAME/PARAM.SFO. PPSSPP/PSP lo necesita para reconocer el título e ID del juego.',
  });

  items.push({
    id: 'eboot',
    title: 'Ejecutable Principal (/PSP_GAME/SYSDIR/EBOOT.BIN)',
    status: hasBootBinary ? 'OK' : 'WARN',
    detail: ebootEntry
      ? `EBOOT.BIN listo (${ebootEntry.size.toLocaleString('es-ES')} B).`
      : bootEntry
      ? `BOOT.BIN listo (${bootEntry.size.toLocaleString('es-ES')} B).`
      : 'No hay EBOOT.BIN ni BOOT.BIN en /PSP_GAME/SYSDIR/. La ISO se empaquetará como volumen de datos.',
  });

  items.push({
    id: 'umd_data',
    title: 'Cabecera de Disco UMD (/UMD_DATA.BIN)',
    status: hasUmdData ? 'OK' : 'WARN',
    detail: hasUmdData
      ? `UMD_DATA.BIN presente (${umdDataEntry!.size} B).`
      : 'Falta /UMD_DATA.BIN. Puedes activar la generación automática antes de empaquetar.',
  });

  let maxDepth = 0;
  let totalPayloadSectors = 0;
  for (const e of entries) {
    const segs = e.path.split('/').filter(Boolean);
    if (segs.length > maxDepth) maxDepth = segs.length;
    totalPayloadSectors += Math.max(1, Math.ceil(e.size / SECTOR_SIZE));
  }
  for (const d of emptyDirs) {
    const segs = d.split('/').filter(Boolean);
    if (segs.length > maxDepth) maxDepth = segs.length;
  }

  const depthOk = maxDepth <= 8;
  items.push({
    id: 'ecma_depth',
    title: 'Profundidad de Rutas ECMA-119 (máx. 8 niveles)',
    status: depthOk ? 'OK' : 'BLOCKED',
    detail: depthOk
      ? `Profundidad máxima actual: ${maxDepth}/8 niveles.`
      : `Ruta excede el límite ECMA-119 (${maxDepth}/8 niveles). Acorta las subcarpetas.`,
  });

  const projectedSectors = 32 + entries.length + totalPayloadSectors;
  const projectedBytes = projectedSectors * SECTOR_SIZE;
  const sizeOk = projectedSectors <= FAT32_MAX_SECTORS;

  items.push({
    id: 'capacity',
    title: 'Tamaño Proyectado del Volumen ISO PSP',
    status:
      entries.length === 0 && emptyDirs.length === 0
        ? 'BLOCKED'
        : projectedSectors <= PSP_UMD_MAX_SECTORS
        ? 'OK'
        : sizeOk
        ? 'WARN'
        : 'BLOCKED',
    detail:
      entries.length === 0 && emptyDirs.length === 0
        ? 'Agrega al menos una carpeta o archivo para poder empaquetar la ISO.'
        : projectedSectors <= PSP_UMD_MAX_SECTORS
        ? `~${(projectedBytes / (1024 * 1024)).toFixed(2)} MB (dentro del límite UMD físico de 1.8 GB).`
        : sizeOk
        ? `~${(projectedBytes / (1024 * 1024)).toFixed(2)} MB (supera UMD 1.8 GB, válido en PPSSPP/FAT32 hasta 4 GB).`
        : 'Supera el límite máximo de 4 GB de ISO 9660 / FAT32.',
  });

  const canPack = !items.some((i) => i.status === 'BLOCKED');

  return {
    canPack,
    hasParamSfo,
    hasBootBinary,
    hasUmdData,
    detectedSfo,
    maxDepth,
    projectedSectors,
    projectedBytes,
    items,
  };
}

// =============================================================================
// STANDALONE ECMA-119 ISO 9660 PACKER
// =============================================================================

interface DirNode {
  name: string;
  fullPath: string;
  childrenDirs: Map<string, DirNode>;
  childrenFiles: Map<string, { name: string; size: number; sliceSource: Blob | Uint8Array; lba?: number }>;
  parent: DirNode | null;
  pathTableIndex: number;
  lba: number;
  dirByteSize: number;
  dirSectorCount: number;
  sectorBuffer: Uint8Array;
}

function writeIsoDate7(buf: Uint8Array, off: number, now: Date) {
  buf[off] = Math.max(0, now.getFullYear() - 1900) & 0xff;
  buf[off + 1] = (now.getMonth() + 1) & 0xff;
  buf[off + 2] = now.getDate() & 0xff;
  buf[off + 3] = now.getHours() & 0xff;
  buf[off + 4] = now.getMinutes() & 0xff;
  buf[off + 5] = now.getSeconds() & 0xff;
  buf[off + 6] = 0;
}

function buildDirRecordBytes(
  nameBytes: Uint8Array,
  lba: number,
  size: number,
  isDir: boolean,
  now: Date
): Uint8Array {
  const baseLen = 33 + nameBytes.length;
  const recLen = baseLen % 2 === 1 ? baseLen + 1 : baseLen;
  const rec = new Uint8Array(recLen);
  const dv = new DataView(rec.buffer);

  rec[0] = recLen;
  rec[1] = 0;
  dv.setUint32(2, lba, true);
  dv.setUint32(6, lba, false);
  dv.setUint32(10, size, true);
  dv.setUint32(14, size, false);
  writeIsoDate7(rec, 18, now);
  rec[25] = isDir ? 0x02 : 0x00;
  rec[26] = 0;
  rec[27] = 0;
  dv.setUint16(28, 1, true);
  dv.setUint16(30, 1, false);
  rec[32] = nameBytes.length;
  rec.set(nameBytes, 33);
  return rec;
}

function estimateDirectorySectors(node: DirNode): number {
  const encoder = new TextEncoder();
  const lengths: number[] = [34, 34];
  for (const d of node.childrenDirs.values()) {
    const len = 33 + encoder.encode(d.name).length;
    lengths.push(len % 2 === 1 ? len + 1 : len);
  }
  for (const f of node.childrenFiles.values()) {
    const isoName = f.name.endsWith(';1') ? f.name : `${f.name};1`;
    const len = 33 + encoder.encode(isoName).length;
    lengths.push(len % 2 === 1 ? len + 1 : len);
  }
  let cursor = 0;
  for (const l of lengths) {
    const inSec = cursor % SECTOR_SIZE;
    if (inSec + l > SECTOR_SIZE) cursor += SECTOR_SIZE - inSec;
    cursor += l;
  }
  return Math.max(1, Math.ceil(cursor / SECTOR_SIZE));
}

function encodeDirectoryTable(node: DirNode, now: Date): Uint8Array {
  const encoder = new TextEncoder();
  const entries: Array<{ nameBytes: Uint8Array; lba: number; size: number; isDir: boolean }> = [
    {
      nameBytes: new Uint8Array([0x00]),
      lba: node.lba,
      size: node.dirByteSize,
      isDir: true,
    },
    {
      nameBytes: new Uint8Array([0x01]),
      lba: node.parent ? node.parent.lba : node.lba,
      size: node.parent ? node.parent.dirByteSize : node.dirByteSize,
      isDir: true,
    },
  ];

  for (const dName of Array.from(node.childrenDirs.keys()).sort()) {
    const child = node.childrenDirs.get(dName)!;
    entries.push({
      nameBytes: encoder.encode(child.name),
      lba: child.lba,
      size: child.dirByteSize,
      isDir: true,
    });
  }

  for (const fName of Array.from(node.childrenFiles.keys()).sort()) {
    const f = node.childrenFiles.get(fName)!;
    const isoName = f.name.endsWith(';1') ? f.name : `${f.name};1`;
    entries.push({
      nameBytes: encoder.encode(isoName),
      lba: f.lba ?? 0,
      size: f.size,
      isDir: false,
    });
  }

  let cursor = 0;
  const serialized = entries.map((e) => buildDirRecordBytes(e.nameBytes, e.lba, e.size, e.isDir, now));
  for (const rec of serialized) {
    const inSec = cursor % SECTOR_SIZE;
    if (inSec + rec.length > SECTOR_SIZE) cursor += SECTOR_SIZE - inSec;
    cursor += rec.length;
  }

  const totalBytes = Math.max(SECTOR_SIZE, Math.ceil(cursor / SECTOR_SIZE) * SECTOR_SIZE);
  const out = new Uint8Array(totalBytes);
  let writePos = 0;
  for (const rec of serialized) {
    const inSec = writePos % SECTOR_SIZE;
    if (inSec + rec.length > SECTOR_SIZE) writePos += SECTOR_SIZE - inSec;
    out.set(rec, writePos);
    writePos += rec.length;
  }
  return out;
}

function buildPathTable(orderedDirs: DirNode[], littleEndian: boolean): Uint8Array {
  const encoder = new TextEncoder();
  const chunks: Uint8Array[] = [];
  let totalLen = 0;

  for (const dir of orderedDirs) {
    const idBytes = dir.parent === null ? new Uint8Array([0x00]) : encoder.encode(dir.name);
    const recLen = 8 + idBytes.length + (idBytes.length % 2);
    const rec = new Uint8Array(recLen);
    const dv = new DataView(rec.buffer);
    rec[0] = idBytes.length;
    rec[1] = 0;
    dv.setUint32(2, dir.lba, littleEndian);
    dv.setUint16(6, dir.parent ? dir.parent.pathTableIndex : 1, littleEndian);
    rec.set(idBytes, 8);
    chunks.push(rec);
    totalLen += recLen;
  }

  const out = new Uint8Array(totalLen);
  let pos = 0;
  for (const c of chunks) {
    out.set(c, pos);
    pos += c.length;
  }
  return out;
}

export async function packPspIsoBlob(
  entries: PackerEntry[],
  emptyDirs: string[],
  options: PackPspIsoOptions = {}
): Promise<PackPspIsoResult> {
  const onProgress = options.onProgress;
  onProgress?.('Construyendo árbol de directorios ECMA-119...', 10);

  const now = new Date();
  const root: DirNode = {
    name: '',
    fullPath: '',
    childrenDirs: new Map(),
    childrenFiles: new Map(),
    parent: null,
    pathTableIndex: 1,
    lba: 0,
    dirByteSize: SECTOR_SIZE,
    dirSectorCount: 1,
    sectorBuffer: new Uint8Array(SECTOR_SIZE),
  };

  const preserveCase = options.preserveCase ?? true;

  const ensureDir = (dirParts: string[]): DirNode => {
    let cur = root;
    let curPath = '';
    for (const rawSeg of dirParts) {
      const seg = normalizeIsoSegment(rawSeg, true, preserveCase);
      curPath += '/' + seg;
      let next = cur.childrenDirs.get(seg);
      if (!next) {
        next = {
          name: seg,
          fullPath: curPath,
          childrenDirs: new Map(),
          childrenFiles: new Map(),
          parent: cur,
          pathTableIndex: 0,
          lba: 0,
          dirByteSize: SECTOR_SIZE,
          dirSectorCount: 1,
          sectorBuffer: new Uint8Array(SECTOR_SIZE),
        };
        cur.childrenDirs.set(seg, next);
      }
      cur = next;
    }
    return cur;
  };

  for (const dirPath of emptyDirs) {
    const parts = normalizeIsoFolderPath(dirPath, preserveCase).split('/').filter(Boolean);
    if (parts.length > 0) ensureDir(parts);
  }

  const workingEntries = [...entries];
  if (
    options.autoGenerateUmdData &&
    !workingEntries.some((e) => e.path.toUpperCase() === '/UMD_DATA.BIN')
  ) {
    const umdBytes = buildUmdDataBin(options.discIdHint || options.volumeId || 'ULES99999');
    workingEntries.push({
      path: '/UMD_DATA.BIN',
      size: umdBytes.length,
      source: umdBytes,
      origin: 'GENERATED',
    });
  }

  for (const item of workingEntries) {
    const norm = normalizeIsoPackerPath(item.path, preserveCase);
    const parts = norm.split('/').filter(Boolean);
    if (parts.length === 0) continue;
    const dirNode = ensureDir(parts.slice(0, -1));
    const fileName = normalizeIsoSegment(parts[parts.length - 1], false, preserveCase);
    dirNode.childrenFiles.set(fileName, {
      name: fileName,
      size: item.size,
      sliceSource: item.source,
    });
  }

  onProgress?.('Calculando Path Tables L/M y asignando sectores LBA...', 35);

  const orderedDirs: DirNode[] = [];
  const queue: DirNode[] = [root];
  while (queue.length > 0) {
    const cur = queue.shift()!;
    cur.pathTableIndex = orderedDirs.length + 1;
    cur.dirSectorCount = estimateDirectorySectors(cur);
    cur.dirByteSize = cur.dirSectorCount * SECTOR_SIZE;
    orderedDirs.push(cur);

    for (const cName of Array.from(cur.childrenDirs.keys()).sort()) {
      queue.push(cur.childrenDirs.get(cName)!);
    }
  }

  const prelimLTable = buildPathTable(orderedDirs, true);
  const pathTableByteLen = prelimLTable.length;
  const pathTableSectors = Math.max(1, Math.ceil(pathTableByteLen / SECTOR_SIZE));

  let lbaCursor = 18;
  const lPathTableLba = lbaCursor;
  lbaCursor += pathTableSectors;
  const mPathTableLba = lbaCursor;
  lbaCursor += pathTableSectors;

  for (const dir of orderedDirs) {
    dir.lba = lbaCursor;
    lbaCursor += dir.dirSectorCount;
  }

  let totalFiles = 0;
  const filePayloadsOrdered: Array<{ size: number; source: Blob | Uint8Array }> = [];
  for (const dir of orderedDirs) {
    for (const fName of Array.from(dir.childrenFiles.keys()).sort()) {
      const f = dir.childrenFiles.get(fName)!;
      f.lba = lbaCursor;
      filePayloadsOrdered.push({ size: f.size, source: f.sliceSource });
      lbaCursor += Math.max(1, Math.ceil(f.size / SECTOR_SIZE));
      totalFiles++;
    }
  }

  const totalSectors = lbaCursor;

  onProgress?.('Codificando Primary Volume Descriptor y directorios...', 65);

  const lPathRaw = buildPathTable(orderedDirs, true);
  const mPathRaw = buildPathTable(orderedDirs, false);
  const lPathPadded = new Uint8Array(pathTableSectors * SECTOR_SIZE);
  const mPathPadded = new Uint8Array(pathTableSectors * SECTOR_SIZE);
  lPathPadded.set(lPathRaw);
  mPathPadded.set(mPathRaw);

  for (const dir of orderedDirs) {
    dir.sectorBuffer = encodeDirectoryTable(dir, now);
  }

  const sysAreaBytes = new Uint8Array(16 * SECTOR_SIZE);
  if (options.baseIsoBlob && options.baseIsoBlob.size >= 16 * SECTOR_SIZE) {
    const origSys = new Uint8Array(
      await options.baseIsoBlob.slice(0, 16 * SECTOR_SIZE).arrayBuffer()
    );
    sysAreaBytes.set(origSys);
  }

  const pvd = new Uint8Array(SECTOR_SIZE);
  pvd.fill(0x20, 8, 72);
  pvd.fill(0x20, 190, 813);
  const pvdView = new DataView(pvd.buffer);
  const enc = new TextEncoder();
  const writePaddedAscii = (off: number, len: number, str: string) => {
    const bytes = enc.encode(str.slice(0, len));
    pvd.fill(0x20, off, off + len);
    pvd.set(bytes, off);
  };

  pvd[0] = 1;
  pvd.set(enc.encode('CD001'), 1);
  pvd[6] = 1;
  writePaddedAscii(8, 32, (options.systemId || 'PSP GAME').toUpperCase());
  writePaddedAscii(40, 32, (options.volumeId || 'PSP_CUSTOM_ISO').toUpperCase());
  pvdView.setUint32(80, totalSectors, true);
  pvdView.setUint32(84, totalSectors, false);
  pvdView.setUint16(120, 1, true);
  pvdView.setUint16(122, 1, false);
  pvdView.setUint16(124, 1, true);
  pvdView.setUint16(126, 1, false);
  pvdView.setUint16(128, SECTOR_SIZE, true);
  pvdView.setUint16(130, SECTOR_SIZE, false);
  pvdView.setUint32(132, pathTableByteLen, true);
  pvdView.setUint32(136, pathTableByteLen, false);
  pvdView.setUint32(140, lPathTableLba, true);
  pvdView.setUint32(148, mPathTableLba, false);

  const rootRecord = buildDirRecordBytes(new Uint8Array([0x00]), root.lba, root.dirByteSize, true, now);
  pvd.set(rootRecord, 156);

  writePaddedAscii(318, 128, options.publisher || 'PSP EBOOT INSPECTOR');
  writePaddedAscii(446, 128, options.dataPreparer || 'ECMA-119 PSP ISO PACKER');
  writePaddedAscii(574, 128, options.applicationId || 'PSP ISO 9660');

  const pad2 = (n: number) => String(n).padStart(2, '0');
  const dec16 = `${now.getFullYear()}${pad2(now.getMonth() + 1)}${pad2(now.getDate())}${pad2(now.getHours())}${pad2(now.getMinutes())}${pad2(now.getSeconds())}00`;
  pvd.set(enc.encode(dec16), 813);
  pvd[829] = 0;
  pvd.set(enc.encode(dec16), 830);
  pvd[846] = 0;
  pvd[881] = 1;

  const term = new Uint8Array(SECTOR_SIZE);
  term[0] = 255;
  term.set(enc.encode('CD001'), 1);
  term[6] = 1;

  onProgress?.('Ensamblando imagen .ISO alineada a 2048 bytes...', 88);

  const parts: BlobPart[] = [
    sysAreaBytes as unknown as BlobPart,
    pvd as unknown as BlobPart,
    term as unknown as BlobPart,
    lPathPadded as unknown as BlobPart,
    mPathPadded as unknown as BlobPart,
  ];

  for (const dir of orderedDirs) {
    parts.push(dir.sectorBuffer as unknown as BlobPart);
  }

  for (const fp of filePayloadsOrdered) {
    if (fp.size === 0) {
      parts.push(new Uint8Array(SECTOR_SIZE) as unknown as BlobPart);
      continue;
    }
    parts.push(fp.source instanceof Blob ? fp.source : (fp.source as unknown as BlobPart));
    const rem = fp.size % SECTOR_SIZE;
    if (rem !== 0) {
      parts.push(new Uint8Array(SECTOR_SIZE - rem) as unknown as BlobPart);
    }
  }

  onProgress?.('Empaquetado ISO completado.', 100);

  return {
    isoBlob: new Blob(parts, { type: 'application/octet-stream' }),
    parts,
    totalSectors,
    totalBytes: totalSectors * SECTOR_SIZE,
    totalFiles,
    totalDirs: orderedDirs.length - 1,
  };
}

export async function writeIsoPartsToWritableStream(
  parts: BlobPart[],
  totalBytes: number,
  writable: {
    write: (data: Uint8Array | Blob) => Promise<void>;
    close: () => Promise<void>;
  },
  onProgress?: (writtenBytes: number, totalBytes: number) => void
): Promise<void> {
  const CHUNK_SIZE = 4 * 1024 * 1024;
  let written = 0;

  for (const part of parts) {
    if (part instanceof Blob) {
      let off = 0;
      while (off < part.size) {
        const end = Math.min(part.size, off + CHUNK_SIZE);
        const slice = part.slice(off, end);
        await writable.write(slice);
        written += end - off;
        off = end;
        onProgress?.(written, totalBytes);
      }
    } else if (part instanceof Uint8Array) {
      await writable.write(part);
      written += part.byteLength;
      onProgress?.(written, totalBytes);
    }
  }
  await writable.close();
}

export function buildFolderPackerPythonScript(): string {
  return `#!/usr/bin/env python3
"""
Empaquetador de Carpeta PSP a Imagen .ISO (ISO 9660 / ECMA-119) por Streaming
Ideal para juegos PSP grandes (1 GB - 4 GB) con carpetas como:
  PSP_GAME/ (SYSDIR, USRDIR, INSDIR, PARAM.SFO, ICON0.PNG, PIC1.PNG)
  UMD_DATA.BIN
  font.pgf
"""

import argparse
import datetime
import struct
from pathlib import Path

SECTOR = 2048


def pad2048(n: int) -> int:
    return ((n + SECTOR - 1) // SECTOR) * SECTOR


def iso_date7(now: datetime.datetime) -> bytes:
    return bytes([
        max(0, now.year - 1900) & 0xFF,
        now.month & 0xFF,
        now.day & 0xFF,
        now.hour & 0xFF,
        now.minute & 0xFF,
        now.second & 0xFF,
        0,
    ])


class IsoNode:
    def __init__(self, name: str, parent=None):
        self.name = name
        self.parent = parent
        self.dirs: dict[str, "IsoNode"] = {}
        self.files: dict[str, tuple[str, Path, int]] = {}
        self.pt_index = 1
        self.lba = 0
        self.dir_size = SECTOR
        self.dir_sectors = 1


def make_dir_rec(name_bytes: bytes, lba: int, size: int, is_dir: bool, now: datetime.datetime) -> bytes:
    base_len = 33 + len(name_bytes)
    rec_len = base_len + (base_len % 2)
    rec = bytearray(rec_len)
    rec[0] = rec_len
    struct.pack_into("<I", rec, 2, lba)
    struct.pack_into(">I", rec, 6, lba)
    struct.pack_into("<I", rec, 10, size)
    struct.pack_into(">I", rec, 14, size)
    rec[18:25] = iso_date7(now)
    rec[25] = 0x02 if is_dir else 0x00
    struct.pack_into("<H", rec, 28, 1)
    struct.pack_into(">H", rec, 30, 1)
    rec[32] = len(name_bytes)
    rec[33 : 33 + len(name_bytes)] = name_bytes
    return bytes(rec)


def pack_folder_to_iso(src_dir: Path, out_iso: Path, volume_id: str = "PSP_CUSTOM_ISO") -> None:
    now = datetime.datetime.now()
    root = IsoNode("")

    def ensure_dir(parts: list[str]) -> IsoNode:
        cur = root
        for p in parts:
            seg = p[:31]
            if seg not in cur.dirs:
                cur.dirs[seg] = IsoNode(seg, cur)
            cur = cur.dirs[seg]
        return cur

    for item in sorted(src_dir.rglob("*")):
        rel = item.relative_to(src_dir)
        parts = [p[:31] for p in rel.parts]
        if item.is_dir():
            ensure_dir(parts)
        else:
            parent = ensure_dir(parts[:-1])
            fname = parts[-1]
            parent.files[fname] = (fname, item, item.stat().st_size)

    ordered: list[IsoNode] = []
    q = [root]
    while q:
        cur = q.pop(0)
        cur.pt_index = len(ordered) + 1
        ordered.append(cur)
        for k in sorted(cur.dirs):
            q.append(cur.dirs[k])

    for d in ordered:
        lens = [34, 34]
        for k in sorted(d.dirs):
            n = 33 + len(k.encode("ascii", errors="ignore"))
            lens.append(n + (n % 2))
        for k in sorted(d.files):
            n = 33 + len((k + ";1").encode("ascii", errors="ignore"))
            lens.append(n + (n % 2))
        cursor = 0
        for ln in lens:
            if (cursor % SECTOR) + ln > SECTOR:
                cursor += SECTOR - (cursor % SECTOR)
            cursor += ln
        d.dir_sectors = max(1, pad2048(cursor) // SECTOR)
        d.dir_size = d.dir_sectors * SECTOR

    def build_pt(le: bool) -> bytes:
        chunks = []
        fmt_u32 = "<I" if le else ">I"
        fmt_u16 = "<H" if le else ">H"
        for d in ordered:
            ident = b"\\x00" if d.parent is None else d.name.encode("ascii", errors="ignore")
            rec_len = 8 + len(ident) + (len(ident) % 2)
            rec = bytearray(rec_len)
            rec[0] = len(ident)
            struct.pack_into(fmt_u32, rec, 2, d.lba)
            struct.pack_into(fmt_u16, rec, 6, d.parent.pt_index if d.parent else 1)
            rec[8 : 8 + len(ident)] = ident
            chunks.append(bytes(rec))
        return b"".join(chunks)

    pt_raw_len = len(build_pt(True))
    pt_sectors = max(1, pad2048(pt_raw_len) // SECTOR)

    cursor = 18
    l_pt_lba = cursor
    cursor += pt_sectors
    m_pt_lba = cursor
    cursor += pt_sectors

    for d in ordered:
        d.lba = cursor
        cursor += d.dir_sectors

    file_queue = []
    for d in ordered:
        for k in sorted(d.files):
            fname, fpath, fsize = d.files[k]
            file_queue.append((d, fname, cursor, fpath, fsize))
            cursor += max(1, pad2048(fsize) // SECTOR)

    total_sectors = cursor
    l_pt = build_pt(True).ljust(pt_sectors * SECTOR, b"\\x00")
    m_pt = build_pt(False).ljust(pt_sectors * SECTOR, b"\\x00")
    file_lba_map = {(id(d), fname): flba for (d, fname, flba, _, _) in file_queue}

    pvd = bytearray(SECTOR)
    pvd[0] = 1
    pvd[1:6] = b"CD001"
    pvd[6] = 1
    pvd[8:40] = b"PSP GAME".ljust(32, b" ")
    pvd[40:72] = volume_id.upper()[:32].encode("ascii", errors="ignore").ljust(32, b" ")
    struct.pack_into("<I", pvd, 80, total_sectors)
    struct.pack_into(">I", pvd, 84, total_sectors)
    struct.pack_into("<H", pvd, 120, 1)
    struct.pack_into(">H", pvd, 122, 1)
    struct.pack_into("<H", pvd, 124, 1)
    struct.pack_into(">H", pvd, 126, 1)
    struct.pack_into("<H", pvd, 128, SECTOR)
    struct.pack_into(">H", pvd, 130, SECTOR)
    struct.pack_into("<I", pvd, 132, pt_raw_len)
    struct.pack_into(">I", pvd, 136, pt_raw_len)
    struct.pack_into("<I", pvd, 140, l_pt_lba)
    struct.pack_into(">I", pvd, 148, m_pt_lba)
    pvd[156:190] = make_dir_rec(b"\\x00", root.lba, root.dir_size, True, now)
    pvd[881] = 1

    term = bytearray(SECTOR)
    term[0] = 255
    term[1:6] = b"CD001"
    term[6] = 1

    with out_iso.open("wb") as f_out:
        f_out.write(b"\\x00" * (16 * SECTOR))
        f_out.write(pvd)
        f_out.write(term)
        f_out.write(l_pt)
        f_out.write(m_pt)

        for d in ordered:
            recs = [
                make_dir_rec(b"\\x00", d.lba, d.dir_size, True, now),
                make_dir_rec(b"\\x01", d.parent.lba if d.parent else d.lba, d.parent.dir_size if d.parent else d.dir_size, True, now),
            ]
            for k in sorted(d.dirs):
                ch = d.dirs[k]
                recs.append(make_dir_rec(ch.name.encode("ascii", errors="ignore"), ch.lba, ch.dir_size, True, now))
            for k in sorted(d.files):
                fname, _, fsize = d.files[k]
                flba = file_lba_map[(id(d), fname)]
                recs.append(make_dir_rec((fname + ";1").encode("ascii", errors="ignore"), flba, fsize, False, now))
            dir_buf = bytearray(d.dir_size)
            pos = 0
            for r in recs:
                if (pos % SECTOR) + len(r) > SECTOR:
                    pos += SECTOR - (pos % SECTOR)
                dir_buf[pos : pos + len(r)] = r
                pos += len(r)
            f_out.write(dir_buf)

        for _, _, _, fpath, fsize in file_queue:
            if fsize == 0:
                f_out.write(b"\\x00" * SECTOR)
                continue
            with fpath.open("rb") as sf:
                while True:
                    chunk = sf.read(4 * 1024 * 1024)
                    if not chunk:
                        break
                    f_out.write(chunk)
            tail = fsize % SECTOR
            if tail:
                f_out.write(b"\\x00" * (SECTOR - tail))

    print(f"ISO PSP generada: {out_iso} ({total_sectors} sectores / {total_sectors * SECTOR:,} bytes)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Empaqueta una carpeta PSP extraida en una imagen .ISO ECMA-119.")
    ap.add_argument("carpeta_psp", type=Path, help="Carpeta raiz con PSP_GAME/ y UMD_DATA.BIN")
    ap.add_argument("--out", type=Path, default=Path("./PSP_EMPAQUETADA.ISO"), help="Archivo .ISO de salida")
    ap.add_argument("--vol", type=str, default="PSP_CUSTOM_ISO", help="Etiqueta de volumen PVD")
    args = ap.parse_args()
    pack_folder_to_iso(args.carpeta_psp, args.out, args.vol)
`;
}

export async function extractIsoSelectionToZip(
  isoBlob: Blob,
  isoInfo: IsoInspectionResult,
  folderPrefix: string | null,
  onProgress?: (done: number, total: number, currentPath: string) => void
): Promise<{ zipBlob: Blob; fileCount: number; totalBytes: number }> {
  const normPrefix =
    folderPrefix && folderPrefix !== '/'
      ? folderPrefix.replace(/\/+$/, '').toUpperCase()
      : null;

  const matchingFiles = isoInfo.files.filter((f) => {
    if (f.isDirectory) return false;
    if (!normPrefix) return true;
    const upper = f.path.toUpperCase();
    return upper.startsWith(`${normPrefix}/`) || upper === normPrefix;
  });

  const zipEntries: AsyncZipInputEntry[] = matchingFiles.map((f) => ({
    path: f.path.replace(/^\/+/, ''),
    data: isoBlob.slice(f.byteOffset, f.byteOffset + f.size),
  }));

  const totalBytes = matchingFiles.reduce((acc, f) => acc + f.size, 0);
  const zipBlob = await buildZipBlobAsync(zipEntries, onProgress);

  return {
    zipBlob,
    fileCount: matchingFiles.length,
    totalBytes,
  };
}
