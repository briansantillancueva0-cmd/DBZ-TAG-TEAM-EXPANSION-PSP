import {
  encodeTextToBytes,
  extractMultilingualStrings,
  type ParsedCodeTable,
  type TextEncodingMode,
} from './codeTable';
import type { EbootAnalysis } from './types';

export type TargetLangCode = 'es' | 'en' | 'pt' | 'fr' | 'it' | 'ja';

export interface TranslatableTextSlot {
  id: number;
  offset: number;
  ramAddress: number;
  originalText: string;
  translatedText: string;
  rawByteLength: number;
  maxByteCapacity: number; // max payload bytes before needing pointer relocation (leaves >=1 null byte)
  detectedLang: 'es' | 'ja' | 'en';
  isSystemToken: boolean; // disc0:/, ms0:/, sce..., ELF section names
}

interface GlossaryItem {
  keys: string[];
  es: string;
  en: string;
  pt: string;
  fr: string;
  it: string;
  ja: string;
}

const PSP_GAME_GLOSSARY: GlossaryItem[] = [
  { keys: ['new game', 'ニューゲーム', 'nuevo juego', 'nueva partida'], es: 'Nueva Partida', en: 'New Game', pt: 'Novo Jogo', fr: 'Nouvelle Partie', it: 'Nuova Partita', ja: 'ニューゲーム' },
  { keys: ['continue', 'コンティニュー', 'continuar'], es: 'Continuar', en: 'Continue', pt: 'Continuar', fr: 'Continuer', it: 'Continua', ja: 'コンティニュー' },
  { keys: ['load game', 'load', 'ロード', 'cargar', 'cargar partida'], es: 'Cargar Partida', en: 'Load Game', pt: 'Carregar', fr: 'Charger', it: 'Carica', ja: 'ロード' },
  { keys: ['save game', 'save', 'セーブ', 'guardar', 'guardar partida'], es: 'Guardar', en: 'Save', pt: 'Salvar', fr: 'Sauvegarder', it: 'Salva', ja: 'セーブ' },
  { keys: ['press start', 'press start button', 'スタートボタン'], es: 'Pulsa START', en: 'Press START', pt: 'Pressione START', fr: 'Appuyez START', it: 'Premi START', ja: 'スタートを押す' },
  { keys: ['start', 'スタート', 'iniciar'], es: 'Iniciar', en: 'Start', pt: 'Iniciar', fr: 'Démarrer', it: 'Avvia', ja: 'スタート' },
  { keys: ['options', 'option', 'オプション', 'opciones'], es: 'Opciones', en: 'Options', pt: 'Opções', fr: 'Options', it: 'Opzioni', ja: 'オプション' },
  { keys: ['story mode', 'historia', 'modo historia', 'ストーリー'], es: 'Modo Historia', en: 'Story Mode', pt: 'Modo História', fr: 'Mode Histoire', it: 'Modalità Storia', ja: 'ストーリー' },
  { keys: ['free battle', 'versus', 'combate libre', 'フリーバトル'], es: 'Combate Libre', en: 'Free Battle', pt: 'Batalha Livre', fr: 'Combat Libre', it: 'Battaglia Libera', ja: 'フリーバトル' },
  { keys: ['training', 'practice', 'トレーニング', 'entrenamiento'], es: 'Entrenamiento', en: 'Training', pt: 'Treino', fr: 'Entraînement', it: 'Allenamento', ja: 'トレーニング' },
  { keys: ['character select', 'select character', 'キャラクター'], es: 'Elegir Luchador', en: 'Character Select', pt: 'Escolher Lutador', fr: 'Choix Personnage', it: 'Scelta Personaggio', ja: 'キャラ選択' },
  { keys: ['stage select', 'select stage', 'ステージ'], es: 'Elegir Escenario', en: 'Stage Select', pt: 'Escolher Cenário', fr: 'Choix Terrain', it: 'Scelta Scenario', ja: 'ステージ' },
  { keys: ['health', 'hp', 'vida', 'barra de vida', '体力'], es: 'Salud', en: 'Health', pt: 'Vida', fr: 'Santé', it: 'Salute', ja: '体力' },
  { keys: ['energy', 'ki', 'chakra', 'mp', '気力'], es: 'Energía', en: 'Energy', pt: 'Energia', fr: 'Énergie', it: 'Energia', ja: '気力' },
  { keys: ['guard', 'defense', 'defensa', 'ガード'], es: 'Defensa', en: 'Guard', pt: 'Defesa', fr: 'Garde', it: 'Difesa', ja: 'ガード' },
  { keys: ['pause', 'pausa', 'ポーズ'], es: 'Pausa', en: 'Pause', pt: 'Pausa', fr: 'Pause', it: 'Pausa', ja: 'ポーズ' },
  { keys: ['retry', 'reintentar', 'リトライ'], es: 'Reintentar', en: 'Retry', pt: 'Tentar de novo', fr: 'Réessayer', it: 'Riprova', ja: 'リトライ' },
  { keys: ['victory', 'you win', 'win', 'victoria'], es: 'Victoria', en: 'Victory', pt: 'Vitória', fr: 'Victoire', it: 'Vittoria', ja: '勝利' },
  { keys: ['defeat', 'you lose', 'game over', 'derrota'], es: 'Derrota', en: 'Defeat', pt: 'Derrota', fr: 'Défaite', it: 'Sconfitta', ja: '敗北' },
  { keys: ['mission', 'misión', 'mision', 'ミッション'], es: 'Misión', en: 'Mission', pt: 'Missão', fr: 'Mission', it: 'Missione', ja: 'ミッション' },
  { keys: ['loading', 'now loading', 'cargando', 'ロード中'], es: 'Cargando...', en: 'Loading...', pt: 'Carregando...', fr: 'Chargement...', it: 'Caricamento...', ja: 'ロード中' },
  { keys: ['lobby', 'sala', 'vestibulo', 'ロビー'], es: 'Sala / Lobby', en: 'Lobby', pt: 'Lobby', fr: 'Salon', it: 'Lobby', ja: 'ロビー' },
  { keys: ['back', 'return', 'volver', 'atrás', '戻る'], es: 'Volver', en: 'Back', pt: 'Voltar', fr: 'Retour', it: 'Indietro', ja: '戻る' },
  { keys: ['exit', 'quit', 'salir', '終了'], es: 'Salir', en: 'Exit', pt: 'Sair', fr: 'Quitter', it: 'Esci', ja: '終了' },
  { keys: ['yes', 'sí', 'si', 'はい'], es: 'Sí', en: 'Yes', pt: 'Sim', fr: 'Oui', it: 'Sì', ja: 'はい' },
  { keys: ['no', 'いいえ'], es: 'No', en: 'No', pt: 'Não', fr: 'Non', it: 'No', ja: 'いいえ' },
  { keys: ['sound', 'audio', 'music', 'bgm', 'música', 'サウンド'], es: 'Música / Audio', en: 'Music / Audio', pt: 'Música / Áudio', fr: 'Musique / Audio', it: 'Musica / Audio', ja: 'サウンド' },
  { keys: ['player 1', '1p'], es: 'Jugador 1', en: 'Player 1', pt: 'Jogador 1', fr: 'Joueur 1', it: 'Giocatore 1', ja: 'プレイヤー1' },
  { keys: ['player 2', '2p'], es: 'Jugador 2', en: 'Player 2', pt: 'Jogador 2', fr: 'Joueur 2', it: 'Giocatore 2', ja: 'プレイヤー2' },
];

export function suggestOfflineTranslation(
  original: string,
  targetLang: TargetLangCode
): string | null {
  const clean = original.trim().toLowerCase().replace(/[.!:]+$/g, '');
  if (!clean) return null;

  for (const item of PSP_GAME_GLOSSARY) {
    for (const k of item.keys) {
      if (clean === k) {
        return item[targetLang];
      }
    }
  }

  // Partial word-level replacements inside longer debug/menu phrases
  let result = original;
  let changed = false;
  for (const item of PSP_GAME_GLOSSARY) {
    for (const k of item.keys) {
      if (k.length < 4) continue;
      const escaped = k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const re = new RegExp(`\\b${escaped}\\b`, 'gi');
      if (re.test(result)) {
        result = result.replace(re, item[targetLang]);
        changed = true;
      }
    }
  }

  return changed ? result : null;
}

export function stripAccentsToAscii(text: string): string {
  const map: Record<string, string> = {
    á: 'a', é: 'e', í: 'i', ó: 'o', ú: 'u', ü: 'u',
    Á: 'A', É: 'E', Í: 'I', Ó: 'O', Ú: 'U', Ü: 'U',
    ñ: 'n', Ñ: 'N', '¡': '!', '¿': '?',
    ã: 'a', õ: 'o', ç: 'c', Ç: 'C',
    à: 'a', è: 'e', ì: 'i', ò: 'o', ù: 'u',
    ê: 'e', ô: 'o', â: 'a',
  };
  return text.replace(/[^\x00-\x7F]/g, (ch) => map[ch] ?? ch);
}

function mapOffsetToRam(offset: number, analysis: EbootAnalysis): number {
  for (const sec of analysis.sections) {
    if (sec.size > 0 && sec.offset > 0 && offset >= sec.offset && offset < sec.offset + sec.size) {
      const base = sec.vaddr > 0 ? sec.vaddr : analysis.baseRamAddress + sec.offset;
      return base + (offset - sec.offset);
    }
  }
  for (const seg of analysis.segments) {
    if (seg.filesz > 0 && offset >= seg.offset && offset < seg.offset + seg.filesz) {
      return seg.vaddr + (offset - seg.offset);
    }
  }
  return analysis.baseRamAddress + offset;
}

function detectStringLanguage(text: string): 'es' | 'ja' | 'en' {
  if (/[\u3040-\u30ff\u4e00-\u9faf]/.test(text)) return 'ja';
  if (/[ñÑáéíóúÁÉÍÓÚüÜ¡¿]/.test(text) || /(misión|héroe|españa|partida|cargar|guardar)/i.test(text)) {
    return 'es';
  }
  return 'en';
}

function isSystemString(text: string): boolean {
  const t = text.trim();
  if (/^(disc0:|ms0:|flash0:|umd0:|host0:)/i.test(t)) return true;
  if (/^sce[A-Z]/.test(t)) return true;
  if (/^\.(text|rodata|data|bss|shstrtab|lib\.stub|sceModuleInfo)/.test(t)) return true;
  return false;
}

export function extractTranslatableSlots(
  buffer: Uint8Array,
  encoding: TextEncodingMode,
  table: ParsedCodeTable | null,
  applyTableOverlay: boolean,
  analysis: EbootAnalysis,
  minLength = 3
): TranslatableTextSlot[] {
  const extracted = extractMultilingualStrings(
    buffer,
    encoding,
    table,
    applyTableOverlay,
    minLength
  );

  return extracted.map((item, idx) => {
    // Count trailing 0x00 bytes after the string to know exact safe in-place capacity
    let trailingZeros = 0;
    let p = item.offset + item.lengthBytes;
    while (p < buffer.length && buffer[p] === 0x00 && trailingZeros < 256) {
      trailingZeros++;
      p++;
    }
    // Keep at least 1 byte for null terminator (unless original had 0 trailing zeros, still preserve length)
    const maxCap =
      trailingZeros >= 1
        ? item.lengthBytes + trailingZeros - 1
        : item.lengthBytes;

    return {
      id: idx + 1,
      offset: item.offset,
      ramAddress: mapOffsetToRam(item.offset, analysis),
      originalText: item.text,
      translatedText: item.text,
      rawByteLength: item.lengthBytes,
      maxByteCapacity: maxCap,
      detectedLang: detectStringLanguage(item.text),
      isSystemToken: isSystemString(item.text),
    };
  });
}

export function applyTranslationsToBinary(
  rawBytes: Uint8Array,
  slots: TranslatableTextSlot[],
  targetEncoding: TextEncodingMode,
  table: ParsedCodeTable | null,
  applyTableOverlay: boolean,
  autoFitToBudget: boolean
): {
  patchedBytes: Uint8Array;
  appliedCount: number;
  truncatedCount: number;
  unmappedWarnings: number;
} {
  const out = new Uint8Array(rawBytes);
  let appliedCount = 0;
  let truncatedCount = 0;
  let unmappedWarnings = 0;

  for (const slot of slots) {
    if (slot.translatedText === slot.originalText) continue;
    if (slot.offset < 0 || slot.offset >= out.length) continue;

    let candidateText = slot.translatedText;
    let encoded = encodeTextToBytes(candidateText, targetEncoding, table, applyTableOverlay);

    if (encoded.bytes.length > slot.maxByteCapacity && autoFitToBudget) {
      candidateText = stripAccentsToAscii(candidateText);
      encoded = encodeTextToBytes(candidateText, targetEncoding, table, applyTableOverlay);
    }

    if (encoded.unmappedChars.length > 0) {
      unmappedWarnings += encoded.unmappedChars.length;
    }

    let payload = encoded.bytes;
    if (payload.length > slot.maxByteCapacity) {
      payload = payload.subarray(0, slot.maxByteCapacity);
      truncatedCount++;
    }

    // Write translated bytes in-place and zero-pad remainder up to maxByteCapacity + 1 null byte
    const wipeEnd = Math.min(out.length, slot.offset + slot.maxByteCapacity + 1);
    for (let k = slot.offset; k < wipeEnd; k++) {
      out[k] = 0x00;
    }
    out.set(payload, slot.offset);
    appliedCount++;
  }

  return { patchedBytes: out, appliedCount, truncatedCount, unmappedWarnings };
}

export function exportTranslationScriptCsv(slots: TranslatableTextSlot[]): string {
  const esc = (s: string) => `"${s.replace(/"/g, '""')}"`;
  const lines = ['ID,OffsetHex,RamHex,MaxBytes,Idioma,Original,Traduccion'];
  for (const s of slots) {
    lines.push(
      [
        s.id,
        `0x${(s.offset >>> 0).toString(16).toUpperCase().padStart(6, '0')}`,
        `0x${(s.ramAddress >>> 0).toString(16).toUpperCase().padStart(8, '0')}`,
        s.maxByteCapacity,
        s.detectedLang.toUpperCase(),
        esc(s.originalText),
        esc(s.translatedText),
      ].join(',')
    );
  }
  return lines.join('\n');
}

export function parseTranslationScriptCsv(
  csvText: string
): Map<number, string> {
  const out = new Map<number, string>();
  const rows = csvText.split(/\r?\n/);

  const parseCsvLine = (line: string): string[] => {
    const cols: string[] = [];
    let cur = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (inQuotes && line[i + 1] === '"') {
          cur += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (ch === ',' && !inQuotes) {
        cols.push(cur);
        cur = '';
      } else {
        cur += ch;
      }
    }
    cols.push(cur);
    return cols;
  };

  for (let i = 0; i < rows.length; i++) {
    const line = rows[i].trim();
    if (!line || line.startsWith('ID,')) continue;
    const cols = parseCsvLine(line);
    if (cols.length < 7) continue;
    const offHex = cols[1].trim().replace(/^0x/i, '');
    const off = parseInt(offHex, 16);
    if (!Number.isNaN(off)) {
      out.set(off, cols[6]);
    }
  }
  return out;
}
