import {
  encodeTextToBytes,
  extractMultilingualStrings,
  type TextEncodingMode,
} from './codeTable';
import { analyzeTextFromBlob, type TextStringCategory } from './textAnalyzer';
import { stripAccentsToAscii, suggestOfflineTranslation } from './textTranslator';
import type { IsoInspectionResult } from './types';
import {
  decryptOrUnpackBlob,
  decompressWithStream,
  tryDecompressBlz4Bytes,
  tryParsePresTocEntries,
  type UniversalClassifiedItem,
} from './universalInspector';
import { buildZipBlobAsync, type AsyncZipInputEntry } from './zipBuilder';

export type OreimoTargetRole =
  | 'FIRST_DAT'
  | 'RES_DAT'
  | 'DATA_BIN'
  | 'BOOT_BIN'
  | 'EBOOT_BIN'
  | 'PARAM_SFO'
  | 'FONT_PGF';

export interface OreimoTargetAuditRow {
  role: OreimoTargetRole;
  expectedName: string;
  purpose: string;
  item: UniversalClassifiedItem | null;
  status: 'READY' | 'KIRK_LOCKED' | 'GLYPH_WARN' | 'MISSING';
  detail: string;
}

export interface OreimoWorkspaceAudit {
  targets: OreimoTargetAuditRow[];
  discId: string | null;
  gameTitle: string | null;
  fontSupportsSpanish: boolean | null;
  fontAuditDetail: string;
  readyCount: number;
}

export interface OreimoPatchSlot {
  id: string;
  fileKey: string;
  fileName: string;
  isoPath: string;
  offset: number;
  sourceBlock: string;
  encoding: TextEncodingMode;
  originalText: string;
  translatedText: string;
  rawByteLength: number;
  maxByteCapacity: number;
  category: TextStringCategory;
  patchableInPlace: boolean;
  presEntryOffset?: number;
  presEntryCompressedSize?: number;
  innerOffset?: number;
}

export interface OreimoPatchChunk {
  offset: number;
  data: Uint8Array;
}

export interface OreimoPatchedFileOutput {
  fileName: string;
  isoPath: string;
  originalSize: number;
  chunks: OreimoPatchChunk[];
  patchedBlob: Blob;
  ppfBlob: Blob;
  ipsBlob: Blob | null;
  appliedStrings: number;
  truncatedStrings: number;
  recompressedBlocks: number;
  bytesModified: number;
}

export interface OreimoPatchBundleOutput {
  patchTitle: string;
  discId: string;
  patchedFiles: OreimoPatchedFileOutput[];
  isoPpfBlob: Blob | null;
  zipBlob: Blob;
  totalStringsPatched: number;
  totalBytesModified: number;
  notes: string[];
}

interface OreimoGlossaryRule {
  patterns: string[];
  es: string;
}

const OREIMO_SPANISH_GLOSSARY: OreimoGlossaryRule[] = [
  { patterns: ['俺の妹がこんなに可愛いわけがない', '俺の妹'], es: 'Oreimo Portable' },
  { patterns: ['高坂 京介', '高坂京介', '京介'], es: 'Kyousuke' },
  { patterns: ['高坂 桐乃', '高坂桐乃', '桐乃'], es: 'Kirino' },
  { patterns: ['五更 瑠璃', '五更瑠璃', '黒猫'], es: 'Kuroneko' },
  { patterns: ['新垣 あやせ', '新垣あやせ', 'あやせ'], es: 'Ayase' },
  { patterns: ['田村 麻奈実', '田村麻奈実', '麻奈実'], es: 'Manami' },
  { patterns: ['沙織・バジーナ', '槇島 沙織', '沙織'], es: 'Saori' },
  { patterns: ['来栖 加奈子', '来栖加奈子', '加奈子'], es: 'Kanako' },
  { patterns: ['星くず☆うぃっちメルル', 'メルル'], es: 'Meruru' },
  { patterns: ['赤城 瀬菜', '瀬菜'], es: 'Sena' },
  { patterns: ['ブリジット'], es: 'Bridget' },
  { patterns: ['はじめから', '最初から', 'new game'], es: 'Nueva Partida' },
  { patterns: ['つづきから', '続きから', 'continue'], es: 'Continuar' },
  { patterns: ['ロード', 'load', 'load game'], es: 'Cargar' },
  { patterns: ['セーブ', 'save', 'save game'], es: 'Guardar' },
  { patterns: ['コンフィグ', 'オプション', 'config', 'options'], es: 'Opciones' },
  { patterns: ['ギャラリー', 'gallery'], es: 'Galería' },
  { patterns: ['バックログ', 'ログ', 'backlog'], es: 'Historial' },
  { patterns: ['スキップ', 'skip'], es: 'Saltar' },
  { patterns: ['オート', 'auto'], es: 'Auto' },
  { patterns: ['タイトルへ戻る', 'タイトルに戻る'], es: 'Volver al título' },
  { patterns: ['タイトル', 'title'], es: 'Título' },
  { patterns: ['データインストール', 'data install'], es: 'Instalar datos' },
  { patterns: ['セーブデータ', 'save data', 'savedata'], es: 'Datos guardados' },
  { patterns: ['メモリースティック', 'memory stick'], es: 'Memory Stick' },
  { patterns: ['空き容量が不足しています'], es: 'Espacio libre insuficiente' },
  { patterns: ['上書きしますか', 'overwrite'], es: '¿Sobrescribir?' },
  { patterns: ['セーブしました'], es: 'Partida guardada' },
  { patterns: ['ロードしました'], es: 'Partida cargada' },
  { patterns: ['決定', 'ok'], es: 'Aceptar' },
  { patterns: ['キャンセル', 'cancel'], es: 'Cancelar' },
  { patterns: ['戻る', 'back'], es: 'Volver' },
  { patterns: ['終了', 'exit'], es: 'Salir' },
  { patterns: ['はい', 'yes'], es: 'Sí' },
  { patterns: ['いいえ', 'no'], es: 'No' },
  { patterns: ['エンディング', 'ending'], es: 'Final' },
  { patterns: ['プロローグ', 'prologue'], es: 'Prólogo' },
  { patterns: ['ルート', 'route'], es: 'Ruta' },
  { patterns: ['イベント', 'event'], es: 'Evento' },
  { patterns: ['シナリオ', 'scenario'], es: 'Escenario' },
  { patterns: ['ボイス', 'voice'], es: 'Voces' },
  { patterns: ['ボリューム', 'volume'], es: 'Volumen' },
  { patterns: ['メッセージ速度'], es: 'Velocidad de texto' },
  { patterns: ['キャラクター'], es: 'Personajes' },
  { patterns: ['妹'], es: 'Hermana' },
];

export function suggestOreimoSpanishTranslation(original: string): string | null {
  const trimmed = original.trim();
  if (!trimmed) return null;

  const lower = trimmed.toLowerCase().replace(/[.!?:]+$/g, '');
  for (const rule of OREIMO_SPANISH_GLOSSARY) {
    for (const pat of rule.patterns) {
      if (lower === pat.toLowerCase() || trimmed === pat) {
        return rule.es;
      }
    }
  }

  // Fallback to general PSP offline glossary
  const general = suggestOfflineTranslation(trimmed, 'es');
  if (general && general !== trimmed) {
    return general;
  }

  // Partial character/UI replacements inside longer Japanese/English lines
  let result = trimmed;
  let changed = false;
  for (const rule of OREIMO_SPANISH_GLOSSARY) {
    for (const pat of rule.patterns) {
      if (pat.length < 2) continue;
      if (/^[\x20-\x7e]+$/.test(pat)) {
        const escaped = pat.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const re = new RegExp(`\\b${escaped}\\b`, 'gi');
        if (re.test(result)) {
          result = result.replace(re, rule.es);
          changed = true;
        }
      } else if (result.includes(pat)) {
        result = result.split(pat).join(rule.es);
        changed = true;
      }
    }
  }

  return changed ? result : null;
}

export function normalizeTargetIsoPath(item: { name: string; path: string }): string {
  const p = item.path.replace(/\\/g, '/');
  if (/\/PSP_GAME\//i.test(p)) {
    return p.startsWith('/') ? p : `/${p}`;
  }
  const upper = item.name.toUpperCase();
  if (upper === 'PARAM.SFO') return '/PSP_GAME/PARAM.SFO';
  if (upper === 'EBOOT.BIN' || upper === 'BOOT.BIN') return `/PSP_GAME/SYSDIR/${upper}`;
  if (upper === 'DATA.BIN') return '/PSP_GAME/INSDIR/DATA.BIN';
  if (upper === 'UMD_DATA.BIN') return '/UMD_DATA.BIN';
  return `/PSP_GAME/USRDIR/${item.name}`;
}

export async function auditOreimoWorkspace(
  items: UniversalClassifiedItem[],
  isoInfo?: IsoInspectionResult | null
): Promise<OreimoWorkspaceAudit> {
  const findByName = (targetUpper: string, pathHint?: string) => {
    const matches = items.filter((i) => i.name.toUpperCase() === targetUpper);
    if (matches.length === 0) return null;
    if (pathHint) {
      const preferred = matches.find((m) => m.path.toUpperCase().includes(pathHint));
      if (preferred) return preferred;
    }
    return matches[0];
  };

  const firstDat = findByName('FIRST.DAT');
  const resDat = findByName('RES.DAT');
  const dataBin = findByName('DATA.BIN', 'INSDIR');
  const bootBin = findByName('BOOT.BIN', 'SYSDIR');
  const ebootBin = findByName('EBOOT.BIN', 'SYSDIR') ?? findByName('EBOOT.BIN');
  const paramSfo = findByName('PARAM.SFO', 'PSP_GAME/PARAM.SFO') ?? findByName('PARAM.SFO');
  const fontPgf = findByName('FONT.PGF');

  let discId: string | null = isoInfo?.sfo?.discId ?? null;
  let gameTitle: string | null = isoInfo?.sfo?.title ?? null;

  if (paramSfo && (!discId || !gameTitle)) {
    try {
      const dec = await decryptOrUnpackBlob(paramSfo, 512 * 1024);
      discId = dec.sfoInfo?.discId ?? discId;
      gameTitle = dec.sfoInfo?.title ?? gameTitle;
    } catch {
      // ignore
    }
  }

  let fontSupportsSpanish: boolean | null = null;
  let fontAuditDetail = 'No se cargó font.pgf; por seguridad se recomienda activar normalización ASCII para ñ/tildes.';
  if (fontPgf) {
    try {
      const dec = await decryptOrUnpackBlob(fontPgf, 2 * 1024 * 1024);
      if (dec.pgfInfo) {
        const missing = dec.pgfInfo.spanishAudit.filter((g) => g.supported === false).length;
        const present = dec.pgfInfo.spanishAudit.filter((g) => g.supported === true).length;
        fontSupportsSpanish = missing === 0 && present > 0;
        fontAuditDetail = dec.pgfInfo.spanishAuditSummary;
      }
    } catch {
      fontAuditDetail = 'font.pgf detectada, sin auditoría extendida de rango.';
    }
  }

  const checkPspLock = (item: UniversalClassifiedItem | null): 'READY' | 'KIRK_LOCKED' | 'MISSING' => {
    if (!item) return 'MISSING';
    if (item.compressionOrEncryption.toLowerCase().includes('kirk')) return 'KIRK_LOCKED';
    return 'READY';
  };

  const targets: OreimoTargetAuditRow[] = [
    {
      role: 'FIRST_DAT',
      expectedName: 'first.dat',
      purpose: 'Textos iniciales, interfaz de arranque y menús principales',
      item: firstDat,
      status: firstDat ? 'READY' : 'MISSING',
      detail: firstDat ? `${(firstDat.size / 1024).toFixed(1)} KB · ${firstDat.formatLabel}` : 'No cargado',
    },
    {
      role: 'RES_DAT',
      expectedName: 'RES.DAT',
      purpose: 'Guiones, diálogos, gráficos comprimidos y tablas de texto',
      item: resDat,
      status: resDat ? 'READY' : 'MISSING',
      detail: resDat ? `${(resDat.size / (1024 * 1024)).toFixed(2)} MB · ${resDat.formatLabel}` : 'No cargado',
    },
    {
      role: 'DATA_BIN',
      expectedName: 'DATA.BIN',
      purpose: 'Paquete INSDIR con recursos adicionales y descripciones',
      item: dataBin,
      status: dataBin ? 'READY' : 'MISSING',
      detail: dataBin ? `${(dataBin.size / (1024 * 1024)).toFixed(2)} MB · ${dataBin.formatLabel}` : 'No cargado',
    },
    {
      role: 'BOOT_BIN',
      expectedName: 'BOOT.BIN',
      purpose: 'Ejecutable ELF plano de SYSDIR (objetos, guardado y errores)',
      item: bootBin,
      status: checkPspLock(bootBin),
      detail: bootBin ? `${(bootBin.size / 1024).toFixed(1)} KB · ${bootBin.compressionOrEncryption}` : 'No cargado',
    },
    {
      role: 'EBOOT_BIN',
      expectedName: 'EBOOT.BIN',
      purpose: 'Ejecutable principal PSP (~PSP o ELF descifrado)',
      item: ebootBin,
      status: checkPspLock(ebootBin),
      detail: ebootBin ? `${(ebootBin.size / 1024).toFixed(1)} KB · ${ebootBin.compressionOrEncryption}` : 'No cargado',
    },
    {
      role: 'PARAM_SFO',
      expectedName: 'PARAM.SFO',
      purpose: 'Metadatos XMB (permite traducir el título del juego en PPSSPP/PSP)',
      item: paramSfo,
      status: paramSfo ? 'READY' : 'MISSING',
      detail: paramSfo ? (gameTitle ? `Título actual: ${gameTitle}` : 'Tabla SFO lista') : 'No cargado',
    },
    {
      role: 'FONT_PGF',
      expectedName: 'font.pgf',
      purpose: 'Tipografía PSP (verifica soporte de ñ y tildes á, é, í, ó, ú)',
      item: fontPgf,
      status: !fontPgf ? 'MISSING' : fontSupportsSpanish === false ? 'GLYPH_WARN' : 'READY',
      detail: fontAuditDetail,
    },
  ];

  const readyCount = targets.filter((t) => t.status === 'READY' || t.status === 'GLYPH_WARN').length;

  return {
    targets,
    discId,
    gameTitle,
    fontSupportsSpanish,
    fontAuditDetail,
    readyCount,
  };
}

export async function extractOreimoPatchSlots(
  items: UniversalClassifiedItem[],
  options: {
    maxDirectScanMb?: number;
    maxSlotsPerFile?: number;
    includePresZlibBlocks?: boolean;
  } = {}
): Promise<OreimoPatchSlot[]> {
  const maxDirectScanBytes = (options.maxDirectScanMb ?? 16) * 1024 * 1024;
  const maxSlotsPerFile = options.maxSlotsPerFile ?? 1200;
  const includePresZlib = options.includePresZlibBlocks ?? true;

  const slots: OreimoPatchSlot[] = [];

  for (const item of items) {
    const upper = item.name.toUpperCase();
    // Skip audio, video, images, padding, and SFO/PGF
    if (
      item.translationRole === 'IGNORE_NO_TEXT' ||
      upper === 'PARAM.SFO' ||
      upper.endsWith('.PGF')
    ) {
      continue;
    }

    const isoPath = normalizeTargetIsoPath(item);
    const fileKey = item.path || item.name;

    // 1. Direct strings scan with exact trailing-zero capacity measurement
    const directLimit = Math.min(item.blob.size, maxDirectScanBytes);
    const rawBuf = new Uint8Array(await item.blob.slice(0, directLimit).arrayBuffer());

    // Try Shift-JIS + UTF-8 cleanly
    const seenDirect = new Set<number>();
    for (const enc of ['shift_jis', 'utf-8'] as const) {
      const found = extractMultilingualStrings(rawBuf, enc, null, false, 3);
      for (const s of found) {
        if (slots.filter((x) => x.fileKey === fileKey).length >= maxSlotsPerFile) break;
        if (seenDirect.has(s.offset)) continue;
        const clean = s.text.trim();
        if (clean.length < 3) continue;
        const isJaOrUseful =
          /[\u3040-\u30ff\u4e00-\u9faf]/.test(clean) ||
          (/[A-Za-z]{3,}/.test(clean) && !/^[A-Z0-9_]{6,}$/.test(clean));
        if (!isJaOrUseful) continue;

        let trailingZeros = 0;
        let p = s.offset + s.lengthBytes;
        while (p < rawBuf.length && rawBuf[p] === 0x00 && trailingZeros < 128) {
          trailingZeros++;
          p++;
        }
        const maxCap = trailingZeros >= 1 ? s.lengthBytes + trailingZeros - 1 : s.lengthBytes;

        seenDirect.add(s.offset);
        slots.push({
          id: `${fileKey}@0x${s.offset.toString(16)}`,
          fileKey,
          fileName: item.name,
          isoPath,
          offset: s.offset,
          sourceBlock: 'Directo',
          encoding: enc,
          originalText: clean,
          translatedText: clean,
          rawByteLength: s.lengthBytes,
          maxByteCapacity: maxCap,
          category: /[\u3040-\u30ff\u4e00-\u9faf]/.test(clean) ? 'DIALOGUE' : 'UI_MENU',
          patchableInPlace: true,
        });
      }
    }

    // 2. If it's a PRES container (RES.DAT / first.dat / DATA.BIN), inspect compressed TOC entries
    if (includePresZlib && (upper.endsWith('.DAT') || upper === 'DATA.BIN')) {
      const presHits = await tryParsePresTocEntries(item.blob);
      let processedBlocks = 0;
      for (const ph of presHits) {
        if (processedBlocks >= 80) break;
        if (slots.filter((x) => x.fileKey === fileKey).length >= maxSlotsPerFile) break;
        if (!ph.canDecompress || !ph.estimatedSize || ph.estimatedSize <= 16) continue;
        if (ph.offset + ph.estimatedSize > item.blob.size) continue;

        try {
          const compBuf = new Uint8Array(
            await item.blob.slice(ph.offset, ph.offset + Math.min(ph.estimatedSize, 1024 * 1024)).arrayBuffer()
          );
          let dec: Uint8Array | null = null;
          if (ph.canDecompress === 'zlib') {
            dec = await decompressWithStream(compBuf, 'deflate');
          } else if (ph.canDecompress === 'gzip') {
            dec = await decompressWithStream(compBuf, 'gzip');
          } else if (ph.canDecompress === 'blz4') {
            dec = await tryDecompressBlz4Bytes(compBuf);
          }
          if (!dec || dec.length < 8) continue;
          processedBlocks++;

          const extracted = extractMultilingualStrings(dec, 'shift_jis', null, false, 3);
          for (const s of extracted) {
            if (slots.filter((x) => x.fileKey === fileKey).length >= maxSlotsPerFile) break;
            const clean = s.text.trim();
            if (!/[\u3040-\u30ff\u4e00-\u9faf]/.test(clean) && !/\s/.test(clean)) continue;

            let trailingZeros = 0;
            let p = s.offset + s.lengthBytes;
            while (p < dec.length && dec[p] === 0x00 && trailingZeros < 128) {
              trailingZeros++;
              p++;
            }
            const maxCap = trailingZeros >= 1 ? s.lengthBytes + trailingZeros - 1 : s.lengthBytes;

            slots.push({
              id: `${fileKey}@0x${ph.offset.toString(16)}+0x${s.offset.toString(16)}`,
              fileKey,
              fileName: item.name,
              isoPath,
              offset: ph.offset,
              sourceBlock: `${ph.canDecompress.toUpperCase()} @ 0x${ph.offset.toString(16).toUpperCase()}`,
              encoding: 'shift_jis',
              originalText: clean,
              translatedText: clean,
              rawByteLength: s.lengthBytes,
              maxByteCapacity: maxCap,
              category: 'DIALOGUE',
              patchableInPlace: ph.canDecompress === 'zlib',
              presEntryOffset: ph.offset,
              presEntryCompressedSize: ph.estimatedSize,
              innerOffset: s.offset,
            });
          }
        } catch {
          // ignore non-standard block
        }
      }
    }

    // 3. Fallback deep scan if no PRES TOC entries produced hits (e.g. DATA.BIN without PRES TOC)
    if (
      slots.filter((x) => x.fileKey === fileKey).length < 25 &&
      (upper.endsWith('.DAT') || upper === 'DATA.BIN')
    ) {
      const summary = await analyzeTextFromBlob(item.blob, item.name, {
        encoding: 'AUTO_MULTI',
        minLength: 3,
        maxScanBytes: Math.min(item.blob.size, 8 * 1024 * 1024),
        maxResults: 300,
        includeCompressedBlocks: true,
      });
      const existingOffsets = new Set(slots.filter((x) => x.fileKey === fileKey).map((x) => `${x.offset}:${x.originalText}`));
      for (const e of summary.entries) {
        if (slots.filter((x) => x.fileKey === fileKey).length >= maxSlotsPerFile) break;
        if (existingOffsets.has(`${e.offset}:${e.text}`)) continue;
        if (e.languageHint === 'ASCII/SYS') continue;
        slots.push({
          id: `${fileKey}@${e.sourceBlock}@0x${e.offset.toString(16)}#${e.id}`,
          fileKey,
          fileName: item.name,
          isoPath,
          offset: e.offset,
          sourceBlock: e.sourceBlock,
          encoding: e.encoding,
          originalText: e.text,
          translatedText: e.text,
          rawByteLength: e.byteLength,
          maxByteCapacity: e.byteLength,
          category: e.category,
          patchableInPlace: e.sourceBlock === 'Directo',
        });
      }
    }
  }

  return slots;
}

async function compressDeflateZlib(bytes: Uint8Array): Promise<Uint8Array> {
  const cs = new CompressionStream('deflate');
  const writer = cs.writable.getWriter();
  await writer.write(new Uint8Array(bytes));
  await writer.close();
  const outBuf = await new Response(cs.readable).arrayBuffer();
  return new Uint8Array(outBuf);
}

/**
 * Generates an official PPF 3.0 (PlayStation Patch Format v3.0) binary patch.
 * Supports 64-bit offsets (>4 GB) so it works on single files or full PSP ISOs.
 */
export function buildPpf3Patch(
  chunks: OreimoPatchChunk[],
  description = 'Oreimo Portable ESP Patch - PSP EBOOT Inspector'
): Blob {
  // Sort and split into chunks of max 255 bytes (PPF3.0 length field is uint8)
  const sorted = [...chunks].sort((a, b) => a.offset - b.offset);
  const ppfRecords: Array<{ offset: number; slice: Uint8Array }> = [];

  for (const ch of sorted) {
    let pos = 0;
    while (pos < ch.data.length) {
      const len = Math.min(255, ch.data.length - pos);
      ppfRecords.push({
        offset: ch.offset + pos,
        slice: ch.data.subarray(pos, pos + len),
      });
      pos += len;
    }
  }

  const headerSize = 60;
  let bodySize = 0;
  for (const r of ppfRecords) {
    bodySize += 9 + r.slice.length;
  }

  const out = new Uint8Array(headerSize + bodySize);
  const dv = new DataView(out.buffer);
  const enc = new TextEncoder();

  // "PPF30" + encoding 0x02
  out.set(enc.encode('PPF30'), 0);
  out[5] = 0x02;

  // 50-byte space-padded description
  out.fill(0x20, 6, 56);
  const descBytes = enc.encode(description.slice(0, 50));
  out.set(descBytes, 6);

  // imagetype=0 (BIN/ISO), blockcheck=0, undo=0, dummy=0
  out[56] = 0x00;
  out[57] = 0x00;
  out[58] = 0x00;
  out[59] = 0x00;

  let cursor = headerSize;
  for (const rec of ppfRecords) {
    const low = rec.offset >>> 0;
    const high = Math.floor(rec.offset / 0x100000000) >>> 0;
    dv.setUint32(cursor, low, true);
    dv.setUint32(cursor + 4, high, true);
    out[cursor + 8] = rec.slice.length;
    out.set(rec.slice, cursor + 9);
    cursor += 9 + rec.slice.length;
  }

  return new Blob([out.buffer as ArrayBuffer], { type: 'application/octet-stream' });
}

/**
 * Generates a standard IPS binary patch ("PATCH ... EOF") for files < 16 MB.
 */
export function buildIpsPatch(chunks: OreimoPatchChunk[]): Blob | null {
  const sorted = [...chunks].sort((a, b) => a.offset - b.offset);
  const ipsRecords: Array<{ offset: number; slice: Uint8Array }> = [];

  for (const ch of sorted) {
    if (ch.offset + ch.data.length >= 0xffffff) {
      return null; // IPS limit is 16 MB
    }
    let pos = 0;
    while (pos < ch.data.length) {
      const len = Math.min(65535, ch.data.length - pos);
      const off = ch.offset + pos;
      // Guard against IPS magic sentinel 0x454F46 ("EOF")
      if (off === 0x454f46) {
        return null;
      }
      ipsRecords.push({ offset: off, slice: ch.data.subarray(pos, pos + len) });
      pos += len;
    }
  }

  let bodySize = 0;
  for (const r of ipsRecords) {
    bodySize += 5 + r.slice.length;
  }

  const out = new Uint8Array(5 + bodySize + 3);
  const enc = new TextEncoder();
  out.set(enc.encode('PATCH'), 0);

  let cursor = 5;
  for (const r of ipsRecords) {
    out[cursor] = (r.offset >>> 16) & 0xff;
    out[cursor + 1] = (r.offset >>> 8) & 0xff;
    out[cursor + 2] = r.offset & 0xff;
    out[cursor + 3] = (r.slice.length >>> 8) & 0xff;
    out[cursor + 4] = r.slice.length & 0xff;
    out.set(r.slice, cursor + 5);
    cursor += 5 + r.slice.length;
  }

  out.set(enc.encode('EOF'), cursor);
  return new Blob([out.buffer as ArrayBuffer], { type: 'application/octet-stream' });
}

/**
 * Computes sparse OreimoPatchChunks comparing two arbitrary Blobs (Original vs Modified).
 */
export async function diffBlobsToChunks(
  originalBlob: Blob,
  modifiedBlob: Blob,
  onProgress?: (scanned: number, total: number) => void
): Promise<OreimoPatchChunk[]> {
  const len = Math.min(originalBlob.size, modifiedBlob.size);
  const CHUNK = 2 * 1024 * 1024;
  const chunks: OreimoPatchChunk[] = [];

  let runStart = -1;
  let runBytes: number[] = [];

  for (let start = 0; start < len; start += CHUNK) {
    const end = Math.min(len, start + CHUNK);
    const [aBuf, bBuf] = await Promise.all([
      originalBlob.slice(start, end).arrayBuffer(),
      modifiedBlob.slice(start, end).arrayBuffer(),
    ]);
    const a = new Uint8Array(aBuf);
    const b = new Uint8Array(bBuf);

    for (let i = 0; i < a.length; i++) {
      if (a[i] !== b[i]) {
        if (runStart === -1) {
          runStart = start + i;
          runBytes = [b[i]];
        } else {
          runBytes.push(b[i]);
        }
      } else if (runStart !== -1) {
        chunks.push({ offset: runStart, data: new Uint8Array(runBytes) });
        runStart = -1;
        runBytes = [];
      }
    }
    onProgress?.(end, len);
  }

  if (runStart !== -1) {
    chunks.push({ offset: runStart, data: new Uint8Array(runBytes) });
  }

  if (modifiedBlob.size > originalBlob.size) {
    const tail = new Uint8Array(
      await modifiedBlob.slice(originalBlob.size, modifiedBlob.size).arrayBuffer()
    );
    if (tail.length > 0) {
      chunks.push({ offset: originalBlob.size, data: tail });
    }
  }

  return chunks;
}

/**
 * Splices sparse byte chunks onto a Blob without copying massive unchanged regions in JS arrays.
 */
export function spliceBlobWithChunks(baseBlob: Blob, chunks: OreimoPatchChunk[]): Blob {
  if (chunks.length === 0) return baseBlob;
  const sorted = [...chunks].sort((a, b) => a.offset - b.offset);
  const parts: BlobPart[] = [];
  let cursor = 0;

  for (const ch of sorted) {
    if (ch.offset > cursor) {
      parts.push(baseBlob.slice(cursor, Math.min(baseBlob.size, ch.offset)));
    }
    parts.push(new Uint8Array(ch.data));
    cursor = ch.offset + ch.data.length;
  }

  if (cursor < baseBlob.size) {
    parts.push(baseBlob.slice(cursor, baseBlob.size));
  }

  return new Blob(parts, { type: 'application/octet-stream' });
}

/**
 * Updates PARAM.SFO TITLE string safely in-place without shifting any table offsets.
 */
export function patchParamSfoTitle(
  sfoBytes: Uint8Array,
  newTitle: string
): { patchedBytes: Uint8Array; chunk: OreimoPatchChunk | null } {
  if (sfoBytes.length < 20) return { patchedBytes: sfoBytes, chunk: null };
  const dv = new DataView(sfoBytes.buffer, sfoBytes.byteOffset, sfoBytes.byteLength);
  if (dv.getUint32(0, true) !== 0x46535000) {
    return { patchedBytes: sfoBytes, chunk: null };
  }

  const keyTableStart = dv.getUint32(0x08, true);
  const dataTableStart = dv.getUint32(0x0c, true);
  const entryCount = dv.getUint32(0x10, true);
  const dec = new TextDecoder('ascii', { fatal: false });

  for (let i = 0; i < entryCount; i++) {
    const base = 0x14 + i * 16;
    if (base + 16 > sfoBytes.length) break;
    const keyOffset = dv.getUint16(base, true);
    const dataMaxLen = dv.getUint32(base + 8, true);
    const dataOffset = dv.getUint32(base + 12, true);

    const kStart = keyTableStart + keyOffset;
    let kEnd = kStart;
    while (kEnd < dataTableStart && sfoBytes[kEnd] !== 0) kEnd++;
    const keyName = dec.decode(sfoBytes.subarray(kStart, kEnd));

    if (keyName === 'TITLE') {
      const absData = dataTableStart + dataOffset;
      if (absData + dataMaxLen > sfoBytes.length || dataMaxLen < 2) break;

      const out = new Uint8Array(sfoBytes);
      const outDv = new DataView(out.buffer);
      const titleBytes = new TextEncoder().encode(newTitle).subarray(0, dataMaxLen - 1);
      out.fill(0x00, absData, absData + dataMaxLen);
      out.set(titleBytes, absData);
      outDv.setUint32(base + 4, titleBytes.length + 1, true);

      return {
        patchedBytes: out,
        chunk: { offset: 0, data: out },
      };
    }
  }

  return { patchedBytes: sfoBytes, chunk: null };
}

function buildPythonPatcherScript(
  manifest: Array<{
    fileName: string;
    isoPath: string;
    chunks: Array<{ offset: number; hex: string }>;
  }>,
  patchTitle: string,
  discId: string
): string {
  const payloadJson = JSON.stringify(manifest, null, 2);
  return `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Instalador de Parche de Traducción Español — ${patchTitle} (${discId})
Generado por PSP EBOOT Inspector

Uso 1 — Parchear carpeta extraída (PSP_GAME/):
    python aplicar_parche_oreimo.py ./MI_CARPETA_OREIMO/

Uso 2 — Parchear archivo suelto (ej. first.dat, BOOT.BIN, PARAM.SFO):
    python aplicar_parche_oreimo.py ./first.dat
"""

import json
import os
import sys

PATCH_MANIFEST = json.loads(r'''${payloadJson}''')


def apply_chunks_to_file(target_path: str, chunks: list) -> int:
    changed = 0
    with open(target_path, "r+b") as f:
        for ch in chunks:
            f.seek(ch["offset"])
            raw = bytes.fromhex(ch["hex"])
            f.write(raw)
            changed += len(raw)
    return changed


def find_matching_file(root: str, file_name: str, iso_path: str):
    direct = os.path.join(root, iso_path.lstrip("/").replace("/", os.sep))
    if os.path.isfile(direct):
        return direct
    for dirpath, _, filenames in os.walk(root):
        for fn in filenames:
            if fn.upper() == file_name.upper():
                return os.path.join(dirpath, fn)
    return None


def main():
    if len(sys.argv) < 2:
        print("Uso: python aplicar_parche_oreimo.py <carpeta_juego_o_archivo>")
        sys.exit(1)

    target = sys.argv[1]
    total_bytes = 0

    if os.path.isfile(target):
        base = os.path.basename(target).upper()
        matched = [m for m in PATCH_MANIFEST if m["fileName"].upper() == base]
        if not matched:
            print(f"No hay parches registrados para {base}.")
            sys.exit(1)
        for m in matched:
            total_bytes += apply_chunks_to_file(target, m["chunks"])
        print(f"Parche aplicado sobre {target} ({total_bytes} bytes escritos).")
        return

    if os.path.isdir(target):
        for m in PATCH_MANIFEST:
            found = find_matching_file(target, m["fileName"], m["isoPath"])
            if found:
                written = apply_chunks_to_file(found, m["chunks"])
                total_bytes += written
                print(f"[OK] {found} -> {written} bytes parcheados")
            else:
                print(f"[OMITIDO] No se encontró {m['fileName']} en {target}")
        print(f"Finalizado. Total modificado: {total_bytes} bytes.")
        return

    print(f"Ruta no válida: {target}")
    sys.exit(1)


if __name__ == "__main__":
    main()
`;
}

export function exportOreimoSlotsCsv(slots: OreimoPatchSlot[]): string {
  const esc = (s: string) => `"${s.replace(/"/g, '""')}"`;
  const lines = [
    'Archivo,IsoPath,OffsetHex,Bloque,Codificacion,MaxBytes,Original,Traduccion',
  ];
  for (const s of slots) {
    lines.push(
      [
        esc(s.fileName),
        esc(s.isoPath),
        `0x${(s.offset >>> 0).toString(16).toUpperCase().padStart(8, '0')}`,
        esc(s.sourceBlock),
        s.encoding,
        s.maxByteCapacity,
        esc(s.originalText),
        esc(s.translatedText),
      ].join(',')
    );
  }
  return lines.join('\n');
}

export function parseOreimoSlotsCsv(
  csvText: string
): Array<{ fileName: string; offset: number; sourceBlock: string; translatedText: string }> {
  const rows = csvText.split(/\r?\n/);
  const out: Array<{
    fileName: string;
    offset: number;
    sourceBlock: string;
    translatedText: string;
  }> = [];

  const splitCsv = (line: string): string[] => {
    const cols: string[] = [];
    let cur = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (c === '"') {
        if (inQuotes && line[i + 1] === '"') {
          cur += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (c === ',' && !inQuotes) {
        cols.push(cur);
        cur = '';
      } else {
        cur += c;
      }
    }
    cols.push(cur);
    return cols;
  };

  for (const line of rows) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('Archivo,')) continue;
    const cols = splitCsv(trimmed);
    if (cols.length < 8) continue;
    const off = parseInt(cols[2].trim().replace(/^0x/i, ''), 16);
    if (Number.isNaN(off)) continue;
    out.push({
      fileName: cols[0].trim(),
      offset: off,
      sourceBlock: cols[3].trim(),
      translatedText: cols[7],
    });
  }
  return out;
}

export async function buildOreimoTranslationPatchBundle(params: {
  items: UniversalClassifiedItem[];
  slots: OreimoPatchSlot[];
  patchTitle: string;
  discId: string;
  newSfoTitle?: string;
  autoAsciiAccents: boolean;
  isoInfo?: IsoInspectionResult | null;
  onProgress?: (phase: string) => void;
}): Promise<OreimoPatchBundleOutput> {
  const {
    items,
    slots,
    patchTitle,
    discId,
    newSfoTitle,
    autoAsciiAccents,
    isoInfo,
    onProgress,
  } = params;

  const patchedFiles: OreimoPatchedFileOutput[] = [];
  const isoWideChunks: OreimoPatchChunk[] = [];
  const pythonManifest: Array<{
    fileName: string;
    isoPath: string;
    chunks: Array<{ offset: number; hex: string }>;
  }> = [];
  const notes: string[] = [];

  let totalStringsPatched = 0;
  let totalBytesModified = 0;

  // Group edited slots by fileKey
  const editedByFile = new Map<string, OreimoPatchSlot[]>();
  for (const s of slots) {
    if (s.translatedText === s.originalText) continue;
    const arr = editedByFile.get(s.fileKey) ?? [];
    arr.push(s);
    editedByFile.set(s.fileKey, arr);
  }

  // Also check PARAM.SFO title override
  const sfoItem = items.find((i) => i.name.toUpperCase() === 'PARAM.SFO') ?? null;

  for (const item of items) {
    const fileKey = item.path || item.name;
    const fileSlots = editedByFile.get(fileKey) ?? [];
    const isSfoEdit =
      item.name.toUpperCase() === 'PARAM.SFO' &&
      Boolean(newSfoTitle && newSfoTitle.trim().length > 0);

    if (fileSlots.length === 0 && !isSfoEdit) continue;

    onProgress?.(`Generando parche binario para ${item.name}…`);
    const isoPath = normalizeTargetIsoPath(item);
    const chunks: OreimoPatchChunk[] = [];
    let appliedStrings = 0;
    let truncatedStrings = 0;
    let recompressedBlocks = 0;

    if (isSfoEdit && sfoItem && item === sfoItem && newSfoTitle) {
      const sfoBytes = new Uint8Array(await item.blob.arrayBuffer());
      const res = patchParamSfoTitle(sfoBytes, newSfoTitle.trim());
      if (res.chunk) {
        chunks.push(res.chunk);
        appliedStrings++;
      }
    }

    // Direct in-place edits
    const directSlots = fileSlots.filter((s) => s.sourceBlock === 'Directo');
    for (const slot of directSlots) {
      let candidate = slot.translatedText;
      let encoded = encodeTextToBytes(candidate, slot.encoding, null, false);

      if ((encoded.bytes.length > slot.maxByteCapacity || autoAsciiAccents) && autoAsciiAccents) {
        candidate = stripAccentsToAscii(candidate);
        encoded = encodeTextToBytes(candidate, slot.encoding, null, false);
      }

      let payload = encoded.bytes;
      if (payload.length > slot.maxByteCapacity) {
        payload = payload.subarray(0, slot.maxByteCapacity);
        truncatedStrings++;
      }

      // Preserve exact original slot footprint with 0x00 trailing padding
      const wipeLen = Math.max(1, slot.maxByteCapacity + 1);
      const outChunk = new Uint8Array(wipeLen);
      outChunk.set(payload, 0);
      chunks.push({ offset: slot.offset, data: outChunk });
      appliedStrings++;
    }

    // ZLIB PRES TOC block recompression when inner text edited
    const compressedSlots = fileSlots.filter(
      (s) => s.sourceBlock !== 'Directo' && s.presEntryOffset !== undefined && s.innerOffset !== undefined
    );
    const byPresBlock = new Map<number, OreimoPatchSlot[]>();
    for (const cs of compressedSlots) {
      const list = byPresBlock.get(cs.presEntryOffset!) ?? [];
      list.push(cs);
      byPresBlock.set(cs.presEntryOffset!, list);
    }

    for (const [blockOff, blockSlots] of byPresBlock.entries()) {
      const compSize = blockSlots[0].presEntryCompressedSize ?? 0;
      if (compSize <= 16 || !blockSlots[0].patchableInPlace) continue;
      try {
        const compBytes = new Uint8Array(
          await item.blob.slice(blockOff, blockOff + compSize).arrayBuffer()
        );
        const dec = await decompressWithStream(compBytes, 'deflate');
        const patchedDec = new Uint8Array(dec);
        let blockChanged = 0;

        for (const s of blockSlots) {
          const innerOff = s.innerOffset!;
          if (innerOff < 0 || innerOff >= patchedDec.length) continue;
          let candidate = autoAsciiAccents ? stripAccentsToAscii(s.translatedText) : s.translatedText;
          let encoded = encodeTextToBytes(candidate, s.encoding, null, false).bytes;
          if (encoded.length > s.maxByteCapacity) {
            encoded = encoded.subarray(0, s.maxByteCapacity);
            truncatedStrings++;
          }
          const wipeEnd = Math.min(patchedDec.length, innerOff + s.maxByteCapacity + 1);
          patchedDec.fill(0x00, innerOff, wipeEnd);
          patchedDec.set(encoded, innerOff);
          blockChanged++;
        }

        if (blockChanged > 0) {
          const recompressed = await compressDeflateZlib(patchedDec);
          if (recompressed.length <= compSize) {
            const paddedBlock = new Uint8Array(compSize);
            paddedBlock.set(recompressed, 0);
            chunks.push({ offset: blockOff, data: paddedBlock });
            recompressedBlocks++;
            appliedStrings += blockChanged;
          } else {
            notes.push(
              `Bloque ZLIB en ${item.name} @ 0x${blockOff.toString(16).toUpperCase()} creció de ${compSize} B a ${recompressed.length} B; exportado en el guion CSV para reimportación QuickBMS.`
            );
          }
        }
      } catch {
        // Ignore incompatible block
      }
    }

    if (chunks.length === 0) continue;

    const patchedBlob = spliceBlobWithChunks(item.blob, chunks);
    const ppfBlob = buildPpf3Patch(chunks, `${patchTitle} (${item.name})`);
    const ipsBlob = item.size < 16 * 1024 * 1024 ? buildIpsPatch(chunks) : null;

    let fileBytesModified = 0;
    const pyChunks: Array<{ offset: number; hex: string }> = [];
    for (const ch of chunks) {
      fileBytesModified += ch.data.length;
      pyChunks.push({
        offset: ch.offset,
        hex: Array.from(ch.data)
          .map((b) => b.toString(16).padStart(2, '0'))
          .join(''),
      });
    }

    // Map into loaded ISO LBA offset if available
    if (isoInfo) {
      const isoEntry = isoInfo.files.find(
        (f) => !f.isDirectory && f.name.toUpperCase() === item.name.toUpperCase()
      );
      if (isoEntry) {
        for (const ch of chunks) {
          if (ch.offset + ch.data.length <= isoEntry.size) {
            isoWideChunks.push({
              offset: isoEntry.byteOffset + ch.offset,
              data: ch.data,
            });
          }
        }
      }
    }

    pythonManifest.push({
      fileName: item.name,
      isoPath,
      chunks: pyChunks,
    });

    patchedFiles.push({
      fileName: item.name,
      isoPath,
      originalSize: item.size,
      chunks,
      patchedBlob,
      ppfBlob,
      ipsBlob,
      appliedStrings,
      truncatedStrings,
      recompressedBlocks,
      bytesModified: fileBytesModified,
    });

    totalStringsPatched += appliedStrings;
    totalBytesModified += fileBytesModified;
  }

  const isoPpfBlob =
    isoWideChunks.length > 0
      ? buildPpf3Patch(isoWideChunks, `${patchTitle} [ISO Completa ${discId}]`)
      : null;

  onProgress?.('Empaquetando archivos, parches PPF/IPS y guion en .ZIP…');

  const zipEntries: AsyncZipInputEntry[] = [];
  const enc = new TextEncoder();

  for (const pf of patchedFiles) {
    const cleanSlug = pf.fileName.replace(/\.[^.]+$/, '');
    zipEntries.push({
      path: `parches_ppf/${cleanSlug}.ppf`,
      data: pf.ppfBlob,
    });
    if (pf.ipsBlob) {
      zipEntries.push({
        path: `parches_ips/${cleanSlug}.ips`,
        data: pf.ipsBlob,
      });
    }
    // Include ready-to-replace patched files <= 64 MB inside ZIP directly
    if (pf.originalSize <= 64 * 1024 * 1024) {
      const cleanRel = pf.isoPath.replace(/^\/+/, '');
      zipEntries.push({
        path: `archivos_parcheados/${cleanRel}`,
        data: pf.patchedBlob,
      });
    } else {
      notes.push(
        `${pf.fileName} (${(pf.originalSize / (1024 * 1024)).toFixed(1)} MB) se distribuye mediante su parche binario .ppf y aplicar_parche_oreimo.py para no duplicar >200 MB en el .ZIP.`
      );
    }
  }

  if (isoPpfBlob) {
    zipEntries.push({
      path: `parches_ppf/OREIMO_ISO_COMPLETA_${discId}.ppf`,
      data: isoPpfBlob,
    });
  }

  zipEntries.push({
    path: 'guion/GUION_OREIMO_ES.csv',
    data: enc.encode(exportOreimoSlotsCsv(slots)),
  });

  zipEntries.push({
    path: 'aplicar_parche_oreimo.py',
    data: enc.encode(buildPythonPatcherScript(pythonManifest, patchTitle, discId)),
  });

  const readme = [
    `PARCHE DE TRADUCCIÓN AL ESPAÑOL — ${patchTitle}`,
    `Disc ID: ${discId}`,
    `Cadenas traducidas aplicadas: ${totalStringsPatched}`,
    `Bytes binarios parcheados: ${totalBytesModified}`,
    '='.repeat(72),
    '',
    'OPCIONES DE INSTALACIÓN EN PPSSPP O PSP:',
    '',
    '1) Reemplazo directo / Reempaquetado de ISO:',
    '   - Copia la carpeta "archivos_parcheados/PSP_GAME/..." sobre tu carpeta extraída del juego',
    '     y vuelve a generar el .ISO desde la pestaña "Extraer / Empaquetar ISO".',
    '',
    isoPpfBlob
      ? '2) Parche directo a tu archivo .ISO con PPF-O-Matic / UniPatcher:\n   - Usa "parches_ppf/OREIMO_ISO_COMPLETA_' +
        discId +
        '.ppf" directamente sobre tu ISO original.'
      : '2) Parches PPF 3.0 / IPS por archivo individual:\n   - Aplica los archivos .ppf (PPF-O-Matic / UniPatcher) o .ips sobre first.dat, BOOT.BIN, DATA.BIN o RES.DAT.',
    '',
    '3) Instalador automático Python (Windows / Linux / macOS):',
    '   python aplicar_parche_oreimo.py "./CARPETA_DEL_JUEGO_OREIMO/"',
    '',
    '4) Continuar traduciendo diálogos de RES.DAT / first.dat:',
    '   - Edita "guion/GUION_OREIMO_ES.csv" en Excel / LibreOffice Calc e impórtalo en el Generador de Parches.',
    '',
    ...notes.map((n) => `NOTA: ${n}`),
  ].join('\n');

  zipEntries.push({
    path: 'LEEME_INSTALAR_PARCHE_OREIMO.txt',
    data: enc.encode(readme),
  });

  const zipBlob = await buildZipBlobAsync(zipEntries);

  return {
    patchTitle,
    discId,
    patchedFiles,
    isoPpfBlob,
    zipBlob,
    totalStringsPatched,
    totalBytesModified,
    notes,
  };
}
