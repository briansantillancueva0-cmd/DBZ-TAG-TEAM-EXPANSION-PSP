import type { SfoEntry, SfoMetadata } from './types';

const CATEGORY_MAP: Record<string, string> = {
  UG: 'Juego UMD (UMD Game)',
  MG: 'Juego Memory Stick / Homebrew (PBP)',
  MS: 'Datos / Savegame Memory Stick',
  EG: 'Emulador / Juego PS1 (POPS)',
  ME: 'Datos Multimedia / Video',
  AP: 'Aplicación / Homebrew PSP',
  WG: 'Actualización de Red / Firmware',
};

function readNullTerminatedUtf8(bytes: Uint8Array, start: number, maxLen: number): string {
  let end = start;
  const limit = Math.min(bytes.length, start + maxLen);
  while (end < limit && bytes[end] !== 0) {
    end++;
  }
  return new TextDecoder('utf-8', { fatal: false }).decode(bytes.subarray(start, end)).trim();
}

export function parseParamSfo(bytes: Uint8Array): SfoMetadata | null {
  if (bytes.length < 20) return null;
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const magic = view.getUint32(0, true);
  // "\0PSF" -> 0x46535000 little-endian
  if (magic !== 0x46535000) return null;

  const keyTableOffset = view.getUint32(8, true);
  const dataTableOffset = view.getUint32(12, true);
  const entryCount = view.getUint32(16, true);

  if (entryCount > 512 || keyTableOffset >= bytes.length || dataTableOffset >= bytes.length) {
    return null;
  }

  const entries: SfoEntry[] = [];
  const map: Record<string, string | number> = {};

  for (let i = 0; i < entryCount; i++) {
    const idxOff = 20 + i * 16;
    if (idxOff + 16 > bytes.length) break;

    const keyRelOff = view.getUint16(idxOff, true);
    const dataFmt = view.getUint16(idxOff + 2, true);
    const dataLen = view.getUint32(idxOff + 4, true);
    const dataMaxLen = view.getUint32(idxOff + 8, true);
    const dataRelOff = view.getUint32(idxOff + 12, true);

    const keyAbsOff = keyTableOffset + keyRelOff;
    const dataAbsOff = dataTableOffset + dataRelOff;
    if (keyAbsOff >= bytes.length || dataAbsOff >= bytes.length) continue;

    const key = readNullTerminatedUtf8(bytes, keyAbsOff, 128);
    let value: string | number = '';
    let format: SfoEntry['format'] = 'utf8';

    if (dataFmt === 0x0404 && dataAbsOff + 4 <= bytes.length) {
      value = view.getUint32(dataAbsOff, true);
      format = 'int32';
    } else if (dataFmt === 0x0004) {
      format = 'utf8_special';
      value = readNullTerminatedUtf8(bytes, dataAbsOff, Math.max(dataLen, dataMaxLen));
    } else {
      format = 'utf8';
      value = readNullTerminatedUtf8(bytes, dataAbsOff, Math.max(dataLen, dataMaxLen));
    }

    entries.push({ key, value, format });
    map[key] = value;
  }

  const category = String(map['CATEGORY'] ?? '');
  return {
    title: String(map['TITLE'] ?? 'Sin título'),
    discId: String(map['DISC_ID'] ?? 'N/A'),
    discVersion: String(map['DISC_VERSION'] ?? 'N/A'),
    pspSystemVer: String(map['PSP_SYSTEM_VER'] ?? 'N/A'),
    appVer: String(map['APP_VER'] ?? 'N/A'),
    category: category || 'N/A',
    categoryLabel: CATEGORY_MAP[category] ?? (category ? `Categoría ${category}` : 'Desconocida'),
    bootable: Number(map['BOOTABLE'] ?? 0),
    parentalLevel: Number(map['PARENTAL_LEVEL'] ?? 0),
    region: Number(map['REGION'] ?? 0),
    entries,
  };
}
