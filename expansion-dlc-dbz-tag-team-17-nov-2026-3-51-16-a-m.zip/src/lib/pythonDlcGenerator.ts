export interface PythonDlcScriptConfig {
  charStart: number;
  charEnd: number;
  mapStart: number;
  mapEnd: number;
  alignFileTo2048: boolean;
  alignSubBlocksTo2048: boolean;
  createMissingStubs: boolean;
}

export function buildSequentialDlcPythonScript(cfg: PythonDlcScriptConfig): string {
  const charStart = Math.max(0, Math.min(255, Math.floor(cfg.charStart)));
  const charEnd = Math.max(charStart, Math.min(256, Math.floor(cfg.charEnd)));
  const mapStart = Math.max(0, Math.min(99, Math.floor(cfg.mapStart)));
  const mapEnd = Math.max(mapStart, Math.min(99, Math.floor(cfg.mapEnd)));

  const alignSubBlocksPy = cfg.alignSubBlocksTo2048 ? 'True' : 'False';
  const alignFilePy = cfg.alignFileTo2048 ? 'True' : 'False';
  const createStubsPy = cfg.createMissingStubs ? 'True' : 'False';

  return `#!/usr/bin/env python3
"""
Generador Automatizado de DLC Secuencial PSP (CHARxxx.BIN y MAPSxx.BIN)
con alineacion a sectores ISO 9660 de 2048 bytes (0x800) y 16 bytes (0x10) para CPU MIPS.

Estructura de entrada esperada:
  ./dlc_source/
    chars/
      077/  (color_0.bin ... color_7.bin, o .amo/.mdl/.tm2)
      078/
      ...
    maps/
      11/   (map.bin/.mdl + minimap.tm2)
      12/
      ...

Salida generada lista para copiar a PSP_GAME/DLC/ dentro de la ISO:
  ./PSP_GAME/DLC/CHAR077.BIN ... CHAR256.BIN
  ./PSP_GAME/DLC/MAPS11.BIN  ... MAPS46.BIN
  ./PSP_GAME/DLC/dlc_sector_report.json
"""

import argparse
import json
import struct
from pathlib import Path

ISO_SECTOR_SIZE = 2048  # 0x800 bytes por sector logico en ISO 9660 / UMD
MIPS_DMA_ALIGN = 16     # 0x10 bytes para punteros y transferencias sceIoRead/GE en PSP

CHAR_RANGE = (${charStart}, ${charEnd})
MAP_RANGE = (${mapStart}, ${mapEnd})
ALIGN_SUBBLOCKS_TO_2048 = ${alignSubBlocksPy}
ALIGN_FINAL_FILE_TO_2048 = ${alignFilePy}
CREATE_EMPTY_STUBS = ${createStubsPy}


def align_up(value: int, alignment: int) -> int:
    """Redondea hacia arriba al multiplo exacto de alignment bytes."""
    if alignment <= 1:
        return value
    return ((value + alignment - 1) // alignment) * alignment


def pad_bytes(data: bytes, alignment: int) -> bytes:
    """Rellena con bytes nulos (0x00) hasta completar el multiplo de alignment."""
    target_len = align_up(len(data), alignment)
    if target_len == len(data):
        return data
    return data + (b"\\x00" * (target_len - len(data)))


def find_color_asset(char_dir: Path, color_idx: int) -> Path | None:
    """Busca archivos color_0..color_7 o 0..7 con cualquier extension (.bin, .amo, .mdl, .tm2)."""
    if not char_dir.exists():
        return None
    prefixes = (f"color_{color_idx}", f"color{color_idx}", f"col_{color_idx}", f"{color_idx}")
    for candidate in sorted(char_dir.iterdir()):
        if candidate.is_file() and candidate.stem.lower() in prefixes:
            return candidate
    return None


def find_map_assets(map_dir: Path) -> tuple[Path | None, Path | None]:
    """Localiza el paquete 3D del escenario y su minimapa .tm2/.gim dentro de la carpeta del mapa."""
    if not map_dir.exists():
        return None, None
    map_file = None
    minimap_file = None
    for candidate in sorted(map_dir.iterdir()):
        if not candidate.is_file():
            continue
        stem = candidate.stem.lower()
        ext = candidate.suffix.lower()
        if minimap_file is None and ("minimap" in stem or "radar" in stem or ext in (".tm2", ".gim")):
            minimap_file = candidate
        elif map_file is None:
            map_file = candidate
    return map_file, minimap_file


def build_char_bin(char_id: int, char_dir: Path, out_file: Path) -> dict | None:
    """
    Construye CHARxxx.BIN con cabecera de 64 bytes (8 entradas x [offset: uint32, size: uint32]).
    Si ALIGN_SUBBLOCKS_TO_2048 es True, la cabecera se rellena a 2048 B y cada traje inicia en sector LBA.
    Si ALIGN_FINAL_FILE_TO_2048 es True, el archivo final se alinea a multiplo exacto de 2048 B.
    """
    slot_files = [find_color_asset(char_dir, c) for c in range(8)]
    has_any = any(f is not None for f in slot_files)

    if not has_any and not CREATE_EMPTY_STUBS:
        return None

    block_align = ISO_SECTOR_SIZE if ALIGN_SUBBLOCKS_TO_2048 else MIPS_DMA_ALIGN
    header_size = 2048 if ALIGN_SUBBLOCKS_TO_2048 else 64

    entries: list[tuple[int, int]] = []
    payload = bytearray()
    cursor = header_size

    for fpath in slot_files:
        if fpath is not None:
            raw = pad_bytes(fpath.read_bytes(), block_align)
            entries.append((cursor, len(raw)))
            payload.extend(raw)
            cursor += len(raw)
        else:
            entries.append((0, 0))

    header = bytearray()
    for off, sz in entries:
        header.extend(struct.pack("<II", off, sz))
    header = bytearray(pad_bytes(bytes(header), header_size))

    final_bytes = bytes(header) + bytes(payload)
    if ALIGN_FINAL_FILE_TO_2048:
        final_bytes = pad_bytes(final_bytes, ISO_SECTOR_SIZE)

    out_file.parent.mkdir(parents=True, exist_ok=True)
    out_file.write_bytes(final_bytes)

    return {
        "file": out_file.name,
        "id": char_id,
        "colors_populated": sum(1 for _, sz in entries if sz > 0),
        "bytes": len(final_bytes),
        "sectors_2048": len(final_bytes) // ISO_SECTOR_SIZE if len(final_bytes) % ISO_SECTOR_SIZE == 0 else None,
        "aligned_2048": (len(final_bytes) % ISO_SECTOR_SIZE == 0),
    }


def build_map_bin(map_id: int, map_dir: Path, out_file: Path) -> dict | None:
    """
    Construye MAPSxx.BIN con cabecera de 16 bytes:
      [map_offset: uint32, map_size: uint32, minimap_offset: uint32, minimap_size: uint32]
    Alineado internamente a 16 B / 2048 B y con tamano total multiplo de 2048 B para ISO 9660.
    """
    map_file, minimap_file = find_map_assets(map_dir)
    if map_file is None and minimap_file is None and not CREATE_EMPTY_STUBS:
        return None

    block_align = ISO_SECTOR_SIZE if ALIGN_SUBBLOCKS_TO_2048 else MIPS_DMA_ALIGN
    header_size = 2048 if ALIGN_SUBBLOCKS_TO_2048 else 16

    map_raw = pad_bytes(map_file.read_bytes(), block_align) if map_file else b""
    mini_raw = pad_bytes(minimap_file.read_bytes(), block_align) if minimap_file else b""

    map_off = header_size if map_raw else 0
    mini_off = (header_size + len(map_raw)) if mini_raw else 0

    header = struct.pack("<IIII", map_off, len(map_raw), mini_off, len(mini_raw))
    header = pad_bytes(header, header_size)

    final_bytes = header + map_raw + mini_raw
    if ALIGN_FINAL_FILE_TO_2048:
        final_bytes = pad_bytes(final_bytes, ISO_SECTOR_SIZE)

    out_file.parent.mkdir(parents=True, exist_ok=True)
    out_file.write_bytes(final_bytes)

    return {
        "file": out_file.name,
        "id": map_id,
        "has_map_3d": len(map_raw) > 0,
        "has_minimap": len(mini_raw) > 0,
        "bytes": len(final_bytes),
        "sectors_2048": len(final_bytes) // ISO_SECTOR_SIZE if len(final_bytes) % ISO_SECTOR_SIZE == 0 else None,
        "aligned_2048": (len(final_bytes) % ISO_SECTOR_SIZE == 0),
    }


def generate_dlc_pack(source_root: Path, output_dlc_dir: Path) -> None:
    chars_src = source_root / "chars"
    maps_src = source_root / "maps"
    output_dlc_dir.mkdir(parents=True, exist_ok=True)

    report = {
        "sector_size_bytes": ISO_SECTOR_SIZE,
        "subblocks_aligned_2048": ALIGN_SUBBLOCKS_TO_2048,
        "files_aligned_2048": ALIGN_FINAL_FILE_TO_2048,
        "characters": [],
        "maps": [],
        "warnings": [],
    }

    for cid in range(CHAR_RANGE[0], CHAR_RANGE[1] + 1):
        char_dir = chars_src / f"{cid:03d}"
        if not char_dir.exists():
            char_dir = chars_src / str(cid)
        out_path = output_dlc_dir / f"CHAR{cid:03d}.BIN"
        meta = build_char_bin(cid, char_dir, out_path)
        if meta is not None:
            report["characters"].append(meta)
        else:
            report["warnings"].append(f"Falta carpeta o datos para CHAR{cid:03d}.BIN")

    for mid in range(MAP_RANGE[0], MAP_RANGE[1] + 1):
        map_dir = maps_src / f"{mid:02d}"
        if not map_dir.exists():
            map_dir = maps_src / str(mid)
        out_path = output_dlc_dir / f"MAPS{mid:02d}.BIN"
        meta = build_map_bin(mid, map_dir, out_path)
        if meta is not None:
            report["maps"].append(meta)
        else:
            report["warnings"].append(f"Falta carpeta o datos para MAPS{mid:02d}.BIN")

    manifest_path = output_dlc_dir / "dlc_sector_report.json"
    manifest_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"Generados {len(report['characters'])} CHARxxx.BIN y {len(report['maps'])} MAPSxx.BIN en {output_dlc_dir}")
    print(f"Manifiesto de sectores guardado en: {manifest_path}")
    if report["warnings"]:
        print(f"Advertencias de secuencia ({len(report['warnings'])}): revisa dlc_sector_report.json")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Genera CHARxxx.BIN y MAPSxx.BIN secuenciales alineados a sectores de 2048 bytes."
    )
    parser.add_argument("--src", type=Path, default=Path("./dlc_source"), help="Carpeta fuente (chars/ y maps/)")
    parser.add_argument("--out", type=Path, default=Path("./PSP_GAME/DLC"), help="Carpeta destino PSP_GAME/DLC/")
    args = parser.parse_args()
    generate_dlc_pack(args.src, args.out)
`;
}
