import { scanDatContainerSignatures } from './universalInspector';

export type QuickBmsTemplateId =
  | 'AUTO'
  | 'PRES_BANDAI'
  | 'PCK1_CONTAINER'
  | 'TOC_OFFSET_SIZE'
  | 'AFS2_AWB'
  | 'AFS_ARCHIVE'
  | 'CPK_CRIWARE'
  | 'PSP_GZIP_MODULE'
  | 'ZLIB_GZIP_CARVER';

export type QuickBmsDetectedTemplate = Exclude<QuickBmsTemplateId, 'AUTO'>;

export interface QuickBmsTocGuess {
  found: boolean;
  countOffset: number | null;
  tableStart: number;
  estimatedCount: number;
  entryStride: 8 | 12 | 16;
  endian: 'little' | 'big';
  layoutDescription: string;
}

export interface QuickBmsHeaderProfile {
  fileName: string;
  fileSize: number;
  ext: string;
  magicHex: string;
  magicAscii4: string;
  headerDumpLines: string[];
  detectedTemplate: QuickBmsDetectedTemplate;
  detectedFormatLabel: string;
  confidence: 'ALTA' | 'MEDIA' | 'HEURÍSTICA';
  recommendedEndian: 'little' | 'big';
  recommendedCompression: 'none' | 'zlib' | 'deflate' | 'gzip';
  detectedToc: QuickBmsTocGuess | null;
  detectedSignatures: Array<{
    signature: string;
    count: number;
    canDecompress: boolean;
  }>;
  pspGzipOffset: number | null;
  isKirkLocked: boolean;
  zeroRatioSample: number;
  notes: string[];
}

export interface QuickBmsGenOptions {
  template: QuickBmsTemplateId;
  endian: 'little' | 'big';
  compression: 'auto' | 'none' | 'zlib' | 'deflate' | 'gzip';
  tocStartHex: string;
  countOffsetHex: string;
  entryStride: 8 | 12 | 16;
  includeSignatureCarver: boolean;
  xorKeyHex: string;
  outputPrefix: string;
}

export const QUICKBMS_TEMPLATE_LABELS: Record<QuickBmsTemplateId, string> = {
  AUTO: 'Detección automática según cabecera',
  PRES_BANDAI: 'Bandai Namco / Banpresto PRES (.DAT / RES.DAT / first.dat / DATA.BIN)',
  PCK1_CONTAINER: 'Contenedor PCK1 / PACK (.PCK / .BIN)',
  TOC_OFFSET_SIZE: 'Tabla de punteros genérica TOC [Offset + Tamaño] (.DAT / .BIN / .PCK)',
  AFS2_AWB: 'CRIWARE AFS2 (.AWB audio)',
  AFS_ARCHIVE: 'CRI Legacy AFS (.AFS)',
  CPK_CRIWARE: 'CRIWARE CPK (.CPK)',
  PSP_GZIP_MODULE: 'Módulo ~PSP (GZIP interno / diagnóstico Kirk)',
  ZLIB_GZIP_CARVER: 'Escáner de firmas embebidas (ZLIB / GZIP / BLZ4 / OMG / MIG / TIM2)',
};

function getExtLower(name: string): string {
  const idx = name.lastIndexOf('.');
  return idx >= 0 ? name.slice(idx).toLowerCase() : '';
}

function readAscii(bytes: Uint8Array, start: number, len: number): string {
  const end = Math.min(bytes.length, start + len);
  let out = '';
  for (let i = start; i < end; i++) {
    const b = bytes[i];
    out += b >= 32 && b <= 126 ? String.fromCharCode(b) : '.';
  }
  return out;
}

function bytesToHexSpaced(bytes: Uint8Array, count: number): string {
  const slice = bytes.subarray(0, Math.min(bytes.length, count));
  return Array.from(slice)
    .map((b) => b.toString(16).toUpperCase().padStart(2, '0'))
    .join(' ');
}

function formatHexDumpLines(bytes: Uint8Array, maxBytes = 64): string[] {
  const limit = Math.min(bytes.length, maxBytes);
  const lines: string[] = [];
  for (let off = 0; off < limit; off += 16) {
    const chunk = bytes.subarray(off, Math.min(limit, off + 16));
    const hexParts: string[] = [];
    let ascii = '';
    for (let i = 0; i < 16; i++) {
      if (i < chunk.length) {
        const b = chunk[i];
        hexParts.push(b.toString(16).toUpperCase().padStart(2, '0'));
        ascii += b >= 32 && b <= 126 ? String.fromCharCode(b) : '.';
      } else {
        hexParts.push('  ');
        ascii += ' ';
      }
    }
    const addr = off.toString(16).toUpperCase().padStart(4, '0');
    lines.push(`${addr}  ${hexParts.slice(0, 8).join(' ')}  ${hexParts.slice(8).join(' ')}  |${ascii}|`);
  }
  return lines;
}

function hasBytesAt(buf: Uint8Array, offset: number, sig: number[]): boolean {
  if (offset < 0 || offset + sig.length > buf.length) return false;
  for (let i = 0; i < sig.length; i++) {
    if (buf[offset + i] !== sig[i]) return false;
  }
  return true;
}

function sanitizeOutputPrefix(name: string): string {
  const base = name.replace(/\.[^.]+$/, '').replace(/[^a-zA-Z0-9_-]+/g, '_').replace(/^_+|_+$/g, '');
  return base || 'extraido';
}

function parseHexOrDecimal(raw: string, fallback: number): number {
  const trimmed = raw.trim();
  if (!trimmed) return fallback;
  const parsed = /^0x/i.test(trimmed) ? parseInt(trimmed, 16) : parseInt(trimmed, 16);
  if (!Number.isFinite(parsed) || parsed < 0) return fallback;
  return parsed;
}

function formatHexAddr(value: number): string {
  return `0x${(value >>> 0).toString(16).toUpperCase().padStart(2, '0')}`;
}

function probeGenericToc(head: Uint8Array, fileSize: number): QuickBmsTocGuess | null {
  if (head.length < 32 || fileSize < 64) return null;
  const dv = new DataView(head.buffer, head.byteOffset, head.byteLength);

  let best: { score: number; guess: QuickBmsTocGuess } | null = null;
  const candidateCountOffsets = [0x00, 0x04, 0x08, 0x0c, 0x10];
  const candidateStrides: Array<8 | 12 | 16> = [8, 12, 16];

  for (const littleEndian of [true, false]) {
    for (const countOffset of candidateCountOffsets) {
      if (countOffset + 4 > head.length) continue;
      const count = dv.getUint32(countOffset, littleEndian);
      if (count < 2 || count > 25000) continue;

      const candidateStarts = Array.from(
        new Set([countOffset + 4, 0x10, 0x20].filter((s) => s > countOffset && s < head.length - 16))
      );

      for (const tableStart of candidateStarts) {
        for (const stride of candidateStrides) {
          const tableEnd = tableStart + count * stride;
          if (tableEnd >= fileSize) continue;

          const sampleCount = Math.min(count, 12, Math.floor((head.length - tableStart) / stride));
          if (sampleCount < 2) continue;

          // Test layouts inside stride:
          // stride 8 -> [offset, size] (field0, field1)
          // stride 12 -> [offset, size, unk] OR [id, offset, size]
          // stride 16 -> [offset, size, unk1, unk2] OR [id, offset, size, zsize]
          const fieldPairs: Array<{ offIdx: number; sizeIdx: number; label: string }> =
            stride === 8
              ? [{ offIdx: 0, sizeIdx: 4, label: '[Offset(u32), Tamaño(u32)]' }]
              : stride === 12
              ? [
                  { offIdx: 0, sizeIdx: 4, label: '[Offset(u32), Tamaño(u32), Extra(u32)]' },
                  { offIdx: 4, sizeIdx: 8, label: '[ID/Hash(u32), Offset(u32), Tamaño(u32)]' },
                ]
              : [
                  { offIdx: 0, sizeIdx: 4, label: '[Offset(u32), Tamaño(u32), Extra1(u32), Extra2(u32)]' },
                  { offIdx: 4, sizeIdx: 8, label: '[ID/Flags(u32), Offset(u32), Tamaño(u32), ZSize/Extra(u32)]' },
                ];

          for (const fp of fieldPairs) {
            let validCount = 0;
            let ascendingCount = 0;
            let prevOff = -1;

            for (let i = 0; i < sampleCount; i++) {
              const base = tableStart + i * stride;
              const off = dv.getUint32(base + fp.offIdx, littleEndian);
              const sz = dv.getUint32(base + fp.sizeIdx, littleEndian);

              if (off >= tableEnd && off < fileSize && sz > 0 && off + sz <= fileSize) {
                validCount++;
                if (prevOff !== -1 && off >= prevOff) {
                  ascendingCount++;
                }
                prevOff = off;
              } else {
                break;
              }
            }

            if (validCount === sampleCount && ascendingCount >= sampleCount - 1) {
              const score =
                validCount * 10 +
                ascendingCount * 5 +
                (littleEndian ? 2 : 0) +
                (countOffset === 0 || countOffset === 4 ? 2 : 0);

              if (!best || score > best.score) {
                best = {
                  score,
                  guess: {
                    found: true,
                    countOffset,
                    tableStart,
                    estimatedCount: count,
                    entryStride: stride,
                    endian: littleEndian ? 'little' : 'big',
                    layoutDescription: `${count} entradas × ${stride} B ${fp.label}`,
                  },
                };
              }
            }
          }
        }
      }
    }
  }

  return best?.guess ?? null;
}

export async function analyzeHeaderForQuickBms(
  blob: Blob,
  fileName: string
): Promise<QuickBmsHeaderProfile> {
  const headLen = Math.min(blob.size, 65536);
  const head = new Uint8Array(await blob.slice(0, headLen).arrayBuffer());
  const dv = head.length >= 16 ? new DataView(head.buffer, head.byteOffset, head.byteLength) : null;
  const ext = getExtLower(fileName);
  const magicHex = bytesToHexSpaced(head, 16);
  const magicAscii4 = readAscii(head, 0, 4);
  const headerDumpLines = formatHexDumpLines(head, 64);

  let zeroCount = 0;
  const sampleCheckLen = Math.min(head.length, 4096);
  for (let i = 0; i < sampleCheckLen; i++) {
    if (head[i] === 0) zeroCount++;
  }
  const zeroRatioSample = sampleCheckLen > 0 ? zeroCount / sampleCheckLen : 0;

  // Lightweight signature probe on up to first 4 MB (plus PRES TOC when magic === PRES)
  const probeLimit = Math.min(blob.size, 4 * 1024 * 1024);
  const scan = await scanDatContainerSignatures(blob, probeLimit, 400);

  const sigCounts = new Map<string, { count: number; canDecompress: boolean }>();
  for (const hit of scan.hits) {
    const existing = sigCounts.get(hit.signature);
    if (existing) {
      existing.count++;
    } else {
      sigCounts.set(hit.signature, {
        count: 1,
        canDecompress: hit.canDecompress !== null,
      });
    }
  }
  const detectedSignatures = Array.from(sigCounts.entries())
    .map(([signature, meta]) => ({
      signature,
      count: meta.count,
      canDecompress: meta.canDecompress,
    }))
    .sort((a, b) => b.count - a.count);

  const notes: string[] = [];
  let detectedTemplate: QuickBmsDetectedTemplate = 'TOC_OFFSET_SIZE';
  let detectedFormatLabel = 'Archivo binario PSP (.DAT / .BIN / .PCK)';
  let confidence: 'ALTA' | 'MEDIA' | 'HEURÍSTICA' = 'HEURÍSTICA';
  let recommendedEndian: 'little' | 'big' = 'little';
  let recommendedCompression: 'none' | 'zlib' | 'deflate' | 'gzip' = 'none';
  let detectedToc: QuickBmsTocGuess | null = null;
  let pspGzipOffset: number | null = null;
  let isKirkLocked = false;

  // 1. Bandai Namco / Banpresto PRES container
  if (magicAscii4 === 'PRES') {
    detectedTemplate = 'PRES_BANDAI';
    detectedFormatLabel = 'Bandai Namco / Banpresto PRES (.DAT / .BIN)';
    confidence = 'ALTA';
    recommendedCompression = sigCounts.has('ZLIB') ? 'zlib' : 'deflate';
    detectedToc = {
      found: true,
      countOffset: 0x08,
      tableStart: 0x10,
      estimatedCount: scan.presTocCount,
      entryStride: 16,
      endian: 'little',
      layoutDescription: `Tabla PRES TOC (${scan.presTocCount} entradas detectadas en grupos de directorio)`,
    };
    notes.push(
      `Cabecera PRES detectada con ${scan.presTocCount} entradas TOC indexadas y flujos internos (${
        detectedSignatures.map((s) => `${s.signature}×${s.count}`).join(', ') || 'listos para escaneo'
      }).`
    );
  }
  // 2. PCK1 / PACK PSP Archive
  else if (magicAscii4 === 'PCK1' || magicAscii4 === 'PACK') {
    detectedTemplate = 'PCK1_CONTAINER';
    detectedFormatLabel =
      magicAscii4 === 'PCK1' ? 'Archivo contenedor PSP PCK1 (.PCK)' : 'Contenedor estándar PACK';
    confidence = 'ALTA';
    const guessedToc = probeGenericToc(head, blob.size);
    detectedToc = guessedToc ?? {
      found: true,
      countOffset: 0x04,
      tableStart: 0x08,
      estimatedCount: dv ? Math.min(50000, dv.getUint32(4, true)) : 0,
      entryStride: 8,
      endian: 'little',
      layoutDescription: 'Cabecera PCK1/PACK con tabla de punteros [Offset, Tamaño]',
    };
    if (sigCounts.has('ZLIB')) recommendedCompression = 'zlib';
    else if (sigCounts.has('GZIP')) recommendedCompression = 'gzip';
    notes.push(`Cabecera mágica ${magicAscii4} confirmada en 0x00.`);
  }
  // 3. CRIWARE AFS2 (.AWB)
  else if (magicAscii4 === 'AFS2' || ext === '.awb') {
    detectedTemplate = 'AFS2_AWB';
    detectedFormatLabel = 'Banco de audio CRIWARE AFS2 (.AWB)';
    confidence = 'ALTA';
    const entryCount = dv && head.length >= 16 ? dv.getUint32(8, true) : 0;
    const align = dv && head.length >= 16 ? dv.getUint32(12, true) : 32;
    detectedToc = {
      found: entryCount > 0,
      countOffset: 0x08,
      tableStart: 0x10,
      estimatedCount: entryCount,
      entryStride: 8,
      endian: 'little',
      layoutDescription: `Tabla AFS2 de ${entryCount} pistas (alineación ${align} bytes)`,
    };
    notes.push('Tabla de pistas CRIWARE AFS2 detectada; QuickBMS extraerá todas las pistas HCA/ADX/AT3.');
  }
  // 4. CRI Legacy AFS\0
  else if (hasBytesAt(head, 0, [0x41, 0x46, 0x53, 0x00]) || ext === '.afs') {
    detectedTemplate = 'AFS_ARCHIVE';
    detectedFormatLabel = 'Contenedor clásico CRI AFS (.AFS)';
    confidence = 'ALTA';
    const count = dv ? dv.getUint32(4, true) : 0;
    detectedToc = {
      found: count > 0 && count < 100000,
      countOffset: 0x04,
      tableStart: 0x08,
      estimatedCount: count,
      entryStride: 8,
      endian: 'little',
      layoutDescription: `${count} entradas [Offset(u32), Tamaño(u32)] desde 0x08`,
    };
    notes.push('Formato CRI AFS clásico detectado.');
  }
  // 5. CRIWARE CPK
  else if (magicAscii4 === 'CPK ' || ext === '.cpk') {
    detectedTemplate = 'CPK_CRIWARE';
    detectedFormatLabel = 'Paquete CRIWARE CPK (.CPK)';
    confidence = 'ALTA';
    notes.push('Cabecera CPK detectada con metadatos @UTF.');
  }
  // 6. ~PSP Encrypted / GZIP Module
  else if (magicAscii4 === '~PSP') {
    detectedTemplate = 'PSP_GZIP_MODULE';
    detectedFormatLabel = 'Módulo ejecutable Sony PSP (~PSP)';
    confidence = 'ALTA';
    for (let i = 0x40; i + 3 < Math.min(head.length, 0x800); i++) {
      if (head[i] === 0x1f && head[i + 1] === 0x8b && head[i + 2] === 0x08) {
        pspGzipOffset = i;
        break;
      }
    }
    if (pspGzipOffset !== null) {
      recommendedCompression = 'gzip';
      notes.push(
        `Bloque GZIP sin cifrado Kirk detectado en 0x${pspGzipOffset.toString(16).toUpperCase()}. El script puede descomprimir el ELF plano directamente.`
      );
    } else {
      isKirkLocked = true;
      notes.push(
        'Módulo cifrado por hardware Kirk (tag 0xD0). QuickBMS no posee llaves privadas Kirk: usa PPSSPP ("Dump decrypted EBOOT.BIN") o extrae primero el ELF plano en la pestaña 2.'
      );
    }
  }
  // 7. Raw ZLIB / GZIP / BLZ4 / BLZ2 at offset 0x00
  else if (
    hasBytesAt(head, 0, [0x78, 0x9c]) ||
    hasBytesAt(head, 0, [0x78, 0xda]) ||
    hasBytesAt(head, 0, [0x78, 0x01]) ||
    hasBytesAt(head, 0, [0x78, 0x5e]) ||
    hasBytesAt(head, 0, [0x1f, 0x8b, 0x08]) ||
    magicAscii4 === 'BLZ4' ||
    magicAscii4 === 'BLZ2'
  ) {
    detectedTemplate = 'ZLIB_GZIP_CARVER';
    detectedFormatLabel = `Flujo comprimido directo (${magicAscii4.startsWith('BLZ') ? magicAscii4 : hasBytesAt(head, 0, [0x1f, 0x8b, 0x08]) ? 'GZIP' : 'ZLIB'})`;
    confidence = 'ALTA';
    recommendedCompression = hasBytesAt(head, 0, [0x1f, 0x8b, 0x08]) ? 'gzip' : 'zlib';
    notes.push('El archivo inicia directamente con una cabecera de compresión estándar.');
  }
  // 8. Generic .DAT / .BIN / .PCK heuristic analysis
  else {
    const guessedToc = probeGenericToc(head, blob.size);
    if (guessedToc) {
      detectedTemplate = ext === '.pck' ? 'PCK1_CONTAINER' : 'TOC_OFFSET_SIZE';
      detectedFormatLabel =
        ext === '.pck'
          ? 'Contenedor .PCK con tabla TOC heurística'
          : 'Contenedor .DAT/.BIN con tabla de punteros detectada';
      confidence = 'MEDIA';
      recommendedEndian = guessedToc.endian;
      detectedToc = guessedToc;
      notes.push(`Tabla TOC probable en 0x${guessedToc.tableStart.toString(16).toUpperCase()}: ${guessedToc.layoutDescription}.`);
    } else if (detectedSignatures.some((s) => s.canDecompress || s.signature === 'BLZ4' || s.signature === 'ZLIB')) {
      detectedTemplate = 'ZLIB_GZIP_CARVER';
      detectedFormatLabel = 'Contenedor .DAT/.BIN con flujos comprimidos embebidos';
      confidence = 'MEDIA';
      recommendedCompression = sigCounts.has('ZLIB') ? 'zlib' : sigCounts.has('GZIP') ? 'gzip' : 'deflate';
      notes.push(
        `No se detectó tabla TOC fija en 0x00..0x20, pero sí ${scan.hits.length} firmas embebidas (${detectedSignatures
          .slice(0, 4)
          .map((s) => `${s.signature}×${s.count}`)
          .join(', ')}). Se recomienda escaneo por firmas (findloc).`
      );
    } else {
      detectedTemplate = ext === '.pck' ? 'PCK1_CONTAINER' : 'TOC_OFFSET_SIZE';
      detectedFormatLabel =
        zeroRatioSample > 0.99
          ? 'Archivo de relleno / padding (0x00)'
          : `Archivo binario ${ext ? ext.toUpperCase() : '.DAT/.BIN'} (plantilla TOC editable)`;
      confidence = 'HEURÍSTICA';
      if (zeroRatioSample > 0.99) {
        notes.push(
          'Los primeros 4 KB son >99% ceros (ej. DUMMY.DAT). No requiere extracción ni traducción.'
        );
      } else {
        notes.push(
          'Sin firma mágica estándar al inicio. Ajusta el offset TOC, stride o clave XOR si este binario utiliza cabecera personalizada.'
        );
      }
    }
  }

  return {
    fileName,
    fileSize: blob.size,
    ext,
    magicHex,
    magicAscii4,
    headerDumpLines,
    detectedTemplate,
    detectedFormatLabel,
    confidence,
    recommendedEndian,
    recommendedCompression,
    detectedToc,
    detectedSignatures,
    pspGzipOffset,
    isKirkLocked,
    zeroRatioSample,
    notes,
  };
}

function normalizeXorDirective(xorKeyHex: string): string[] {
  const clean = xorKeyHex.trim().replace(/^0x/i, '').replace(/\s+/g, '');
  if (!clean || !/^[0-9a-fA-F]+$/.test(clean)) return [];
  if (clean.length <= 2) {
    return [
      `# Clave XOR de 1 byte aplicada al leer o extraer`,
      `filexor 0x${clean.toUpperCase().padStart(2, '0')}`,
      '',
    ];
  }
  const padded = clean.length % 2 === 1 ? `0${clean}` : clean;
  const escaped = padded.match(/.{2}/g)?.map((pair) => `\\x${pair.toUpperCase()}`).join('') ?? '';
  return [
    `# Clave XOR multibyte para bloques extraídos`,
    `encryption xor "${escaped}"`,
    '',
  ];
}

function buildCarverSection(profile: QuickBmsHeaderProfile | null, prefix: string): string[] {
  const lines: string[] = [
    '# --- Escáner por firmas embebidas (findloc) para subarchivos y bloques comprimidos ---',
    'goto 0',
    'get FILE_END asize',
    '',
  ];

  const sigSet = new Set((profile?.detectedSignatures ?? []).map((s) => s.signature));
  const includeAllDefaults = sigSet.size === 0;

  if (includeAllDefaults || sigSet.has('ZLIB')) {
    lines.push(
      '# Flujos ZLIB (0x78 0x9C y 0x78 0xDA)',
      'comtype zlib_noerror',
      'goto 0',
      'for',
      '  findloc ZOFF binary "\\x78\\x9C" 0 ""',
      '  if ZOFF == ""',
      '    break',
      '  endif',
      `  string ZNAME p "${prefix}_zlib_%08X.bin" ZOFF`,
      '  math MAX_IN = FILE_END - ZOFF',
      '  if MAX_IN > 0x200000',
      '    math MAX_IN = 0x200000',
      '  endif',
      '  math MAX_OUT = MAX_IN * 4',
      '  clog ZNAME ZOFF MAX_IN MAX_OUT',
      '  math ZNEXT = ZOFF + 4',
      '  goto ZNEXT',
      'next',
      ''
    );
  }

  if (includeAllDefaults || sigSet.has('GZIP')) {
    lines.push(
      '# Flujos GZIP (0x1F 0x8B 0x08)',
      'comtype gzip',
      'goto 0',
      'for',
      '  findloc GOFF binary "\\x1F\\x8B\\x08" 0 ""',
      '  if GOFF == ""',
      '    break',
      '  endif',
      `  string GNAME p "${prefix}_gzip_%08X.bin" GOFF`,
      '  math MAX_IN = FILE_END - GOFF',
      '  if MAX_IN > 0x200000',
      '    math MAX_IN = 0x200000',
      '  endif',
      '  math MAX_OUT = MAX_IN * 4',
      '  clog GNAME GOFF MAX_IN MAX_OUT',
      '  math GNEXT = GOFF + 4',
      '  goto GNEXT',
      'next',
      ''
    );
  }

  if (includeAllDefaults || sigSet.has('BLZ4')) {
    lines.push(
      '# Bloques BLZ4 (Bandai Namco / God Eater / Tag Team)',
      'goto 0',
      'for',
      '  findloc BOFF binary "\\x42\\x4C\\x5A\\x34" 0 ""',
      '  if BOFF == ""',
      '    break',
      '  endif',
      '  goto BOFF',
      '  idstring "BLZ4"',
      '  get BLZ_DEC_SIZE long',
      '  get BLZ_UNK1 long',
      '  get BLZ_UNK2 long',
      `  string BNAME p "${prefix}_blz4_%08X.bin" BOFF`,
      '  math SLICE_SZ = FILE_END - BOFF',
      '  if SLICE_SZ > 0x40000',
      '    math SLICE_SZ = 0x40000',
      '  endif',
      '  log BNAME BOFF SLICE_SZ',
      '  math BNEXT = BOFF + 4',
      '  goto BNEXT',
      'next',
      ''
    );
  }

  const assetSignatures: Array<{ sig: string; bin: string; ext: string; label: string }> = [
    { sig: 'OMG.00.1PSP', bin: '\\x4F\\x4D\\x47\\x2E\\x30\\x30\\x2E\\x31\\x50\\x53\\x50', ext: 'gmo', label: 'Modelos 3D GMO PSP' },
    { sig: 'MIG.00.1PSP', bin: '\\x4D\\x49\\x47\\x2E\\x30\\x30\\x2E\\x31\\x50\\x53\\x50', ext: 'gim', label: 'Texturas GIM PSP' },
    { sig: 'TIM2', bin: '\\x54\\x49\\x4D\\x32', ext: 'tm2', label: 'Texturas TIM2' },
    { sig: 'PNG', bin: '\\x89\\x50\\x4E\\x47\\x0D\\x0A\\x1A\\x0A', ext: 'png', label: 'Imágenes PNG' },
    { sig: 'PSMF', bin: '\\x50\\x53\\x4D\\x46', ext: 'pmf', label: 'Videos PSMF' },
  ];

  const matchedAssets = assetSignatures.filter((a) => sigSet.has(a.sig));
  for (const asset of matchedAssets) {
    lines.push(
      `# ${asset.label}`,
      'goto 0',
      'for',
      `  findloc AOFF binary "${asset.bin}" 0 ""`,
      '  if AOFF == ""',
      '    break',
      '  endif',
      `  string ANAME p "${prefix}_%08X.${asset.ext}" AOFF`,
      '  math REM = FILE_END - AOFF',
      '  if REM > 0x40000',
      '    math REM = 0x40000',
      '  endif',
      '  log ANAME AOFF REM',
      '  math ANEXT = AOFF + 4',
      '  goto ANEXT',
      'next',
      ''
    );
  }

  return lines;
}

export function buildQuickBmsScript(
  profile: QuickBmsHeaderProfile | null,
  options: QuickBmsGenOptions
): string {
  const fileName = profile?.fileName || 'ARCHIVO.DAT';
  const resolvedTemplate: QuickBmsDetectedTemplate =
    options.template === 'AUTO'
      ? profile?.detectedTemplate ?? 'TOC_OFFSET_SIZE'
      : options.template;

  const resolvedCompression: 'none' | 'zlib' | 'deflate' | 'gzip' =
    options.compression === 'auto'
      ? profile?.recommendedCompression ?? 'none'
      : options.compression;

  const prefix = sanitizeOutputPrefix(options.outputPrefix || fileName);
  const bmsFileSuggestion = `${prefix}_extract.bms`;

  const lines: string[] = [
    `# ==============================================================================`,
    `# Script QuickBMS generado automáticamente para: ${fileName}`,
    `# Motor / Plantilla: ${QUICKBMS_TEMPLATE_LABELS[resolvedTemplate]}`,
    profile
      ? `# Cabecera detectada: ${profile.magicHex || '(vacía)'} ("${profile.magicAscii4}") · ${(profile.fileSize / 1024).toFixed(1)} KB`
      : `# Cabecera: personalizada por el usuario`,
    `# Uso en PC: quickbms.exe ${bmsFileSuggestion} "${fileName}" ./extraido_${prefix}/`,
    `# ==============================================================================`,
    '',
  ];

  if (options.endian === 'big') {
    lines.push('endian big', '');
  } else {
    lines.push('endian little', '');
  }

  lines.push(...normalizeXorDirective(options.xorKeyHex));

  if (resolvedTemplate === 'PRES_BANDAI') {
    lines.push(
      '# Verifica cabecera PRES (si tu archivo no la trae al principio, comenta idstring)',
      'getDstring MAGIC 4',
      'if MAGIC == "PRES"',
      '  get PRES_VER long',
      '  get DIR_COUNT long',
      '  get DATA_BASE long',
      'endif',
      '',
      '# Escaneo completo de bloques comprimidos y subarchivos en Bandai Namco PSP',
      ...buildCarverSection(profile, prefix)
    );
    return lines.join('\n');
  }

  if (resolvedTemplate === 'PCK1_CONTAINER') {
    const countOff = formatHexAddr(
      parseHexOrDecimal(options.countOffsetHex, profile?.detectedToc?.countOffset ?? 0x04)
    );
    const tocStart = formatHexAddr(
      parseHexOrDecimal(options.tocStartHex, profile?.detectedToc?.tableStart ?? 0x08)
    );

    lines.push(
      '# Lector PCK1 / PACK (.PCK)',
      'getDstring MAGIC 4',
      'if MAGIC == "PCK1" || MAGIC == "PACK"',
      `  goto ${countOff}`,
      'else',
      `  goto ${countOff}`,
      'endif',
      'get FILES long',
      `goto ${tocStart}`,
      ''
    );

    if (resolvedCompression !== 'none') {
      const compType = resolvedCompression === 'zlib' ? 'zlib_noerror' : resolvedCompression;
      lines.push(`comtype ${compType}`, '');
    }

    lines.push('for i = 0 < FILES');
    if (options.entryStride === 16) {
      lines.push('  get ENTRY_ID long', '  get OFFSET long', '  get SIZE long', '  get ZSIZE long');
    } else if (options.entryStride === 12) {
      lines.push('  get ENTRY_ID long', '  get OFFSET long', '  get SIZE long');
    } else {
      lines.push('  get OFFSET long', '  get SIZE long');
    }
    lines.push(
      `  string OUT_NAME p "${prefix}_%04d.bin" i`,
      '  if SIZE > 0'
    );
    if (resolvedCompression !== 'none') {
      lines.push(
        options.entryStride === 16
          ? '    if ZSIZE > SIZE\n      clog OUT_NAME OFFSET SIZE ZSIZE\n    else\n      clog OUT_NAME OFFSET SIZE SIZE\n    endif'
          : '    math EST_OUT = SIZE * 4\n    clog OUT_NAME OFFSET SIZE EST_OUT'
      );
    } else {
      lines.push('    log OUT_NAME OFFSET SIZE');
    }
    lines.push('  endif', 'next i', '');

    if (options.includeSignatureCarver) {
      lines.push(...buildCarverSection(profile, prefix));
    }
    return lines.join('\n');
  }

  if (resolvedTemplate === 'TOC_OFFSET_SIZE') {
    const countOff = formatHexAddr(
      parseHexOrDecimal(options.countOffsetHex, profile?.detectedToc?.countOffset ?? 0x00)
    );
    const tocStart = formatHexAddr(
      parseHexOrDecimal(options.tocStartHex, profile?.detectedToc?.tableStart ?? 0x04)
    );

    lines.push(
      `# Tabla TOC genérica (${options.entryStride} bytes por entrada)`,
      `goto ${countOff}`,
      'get FILES long',
      'if FILES > 100000',
      '  print "Advertencia: FILES=%FILES% parece inválido; ajusta Count Offset o Endian."',
      '  cleanexit',
      'endif',
      `goto ${tocStart}`,
      ''
    );

    if (resolvedCompression !== 'none') {
      const compType = resolvedCompression === 'zlib' ? 'zlib_noerror' : resolvedCompression;
      lines.push(`comtype ${compType}`, '');
    }

    lines.push('for i = 0 < FILES');
    if (options.entryStride === 16) {
      lines.push('  get ENTRY_FLAGS long', '  get OFFSET long', '  get SIZE long', '  get UNCOMP_SIZE long');
    } else if (options.entryStride === 12) {
      lines.push('  get ENTRY_ID long', '  get OFFSET long', '  get SIZE long');
    } else {
      lines.push('  get OFFSET long', '  get SIZE long');
    }
    lines.push(
      `  string OUT_NAME p "${prefix}_%04d.bin" i`,
      '  if SIZE > 0 && OFFSET > 0'
    );
    if (resolvedCompression !== 'none') {
      lines.push(
        options.entryStride === 16
          ? '    if UNCOMP_SIZE > SIZE\n      clog OUT_NAME OFFSET SIZE UNCOMP_SIZE\n    else\n      clog OUT_NAME OFFSET SIZE SIZE\n    endif'
          : '    math EST_OUT = SIZE * 4\n    clog OUT_NAME OFFSET SIZE EST_OUT'
      );
    } else {
      lines.push('    log OUT_NAME OFFSET SIZE');
    }
    lines.push('  endif', 'next i', '');

    if (options.includeSignatureCarver) {
      lines.push(...buildCarverSection(profile, prefix));
    }
    return lines.join('\n');
  }

  if (resolvedTemplate === 'AFS2_AWB') {
    lines.push(
      '# Extractor oficial de pistas de audio CRIWARE AFS2 (.AWB)',
      'idstring "AFS2"',
      'get AFS2_VER byte',
      'get OFFSET_SIZE byte',
      'get ID_SIZE short',
      'get FILES long',
      'get ALIGN long',
      '',
      'for i = 0 < FILES',
      '  if ID_SIZE == 2',
      '    get CUE_ID short',
      '  else',
      '    get CUE_ID long',
      '  endif',
      '  putarray 0 i CUE_ID',
      'next i',
      '',
      'math TOTAL_OFFS = FILES + 1',
      'for i = 0 < TOTAL_OFFS',
      '  if OFFSET_SIZE == 2',
      '    get TRACK_OFF short',
      '  else',
      '    get TRACK_OFF long',
      '  endif',
      '  math MOD = TRACK_OFF % ALIGN',
      '  if MOD != 0',
      '    math TRACK_OFF += ALIGN',
      '    math TRACK_OFF -= MOD',
      '  endif',
      '  putarray 1 i TRACK_OFF',
      'next i',
      '',
      'for i = 0 < FILES',
      '  getarray CUE_ID 0 i',
      '  getarray START_OFF 1 i',
      '  math NEXT_IDX = i + 1',
      '  getarray END_OFF 1 NEXT_IDX',
      '  math TRACK_SIZE = END_OFF - START_OFF',
      `  string TRACK_NAME p "${prefix}_%04d_cue_%d.bin" i CUE_ID`,
      '  if TRACK_SIZE > 0',
      '    log TRACK_NAME START_OFF TRACK_SIZE',
      '  endif',
      'next i',
      ''
    );
    return lines.join('\n');
  }

  if (resolvedTemplate === 'AFS_ARCHIVE') {
    lines.push(
      '# Extractor de contenedor CRI AFS clásico',
      'idstring "AFS\\x00"',
      'get FILES long',
      'for i = 0 < FILES',
      '  get OFFSET long',
      '  get SIZE long',
      `  string OUT_NAME p "${prefix}_%04d.bin" i`,
      '  if SIZE > 0',
      '    log OUT_NAME OFFSET SIZE',
      '  endif',
      'next i',
      ''
    );
    return lines.join('\n');
  }

  if (resolvedTemplate === 'CPK_CRIWARE') {
    lines.push(
      '# Inspector CRIWARE CPK (.CPK)',
      'idstring "CPK "',
      'get UNK1 long',
      'get UTF_SIZE longlong',
      'print "Cabecera CPK validada. Tamaño tabla @UTF: %UTF_SIZE% bytes."',
      'print "Si los archivos están sin comprimir o en ZLIB, el escáner inferior los extraerá."',
      '',
      ...(options.includeSignatureCarver
        ? buildCarverSection(profile, prefix)
        : ['# Activa "Incluir escáner de firmas embebidas" si deseas extraer streams ZLIB/media sueltos.'])
    );
    return lines.join('\n');
  }

  if (resolvedTemplate === 'PSP_GZIP_MODULE') {
    const gzOff = profile?.pspGzipOffset;
    if (gzOff !== null && gzOff !== undefined) {
      const hexOff = formatHexAddr(gzOff);
      lines.push(
        `# Descompresor directo ~PSP con payload GZIP plano en ${hexOff}`,
        'idstring "~PSP"',
        'get FILE_SIZE asize',
        'comtype gzip',
        `math ZSIZE = FILE_SIZE - ${hexOff}`,
        'math EST_ELF_SIZE = ZSIZE * 4',
        `log "${prefix}_HEADER_PSP.bin" 0 ${hexOff}`,
        `clog "${prefix}_DECOMPRESSED.ELF" ${hexOff} ZSIZE EST_ELF_SIZE`,
        ''
      );
    } else {
      lines.push(
        '# ATENCIÓN: Módulo ~PSP cifrado por hardware Kirk (sin GZIP plano en 0x40..0x800)',
        '# QuickBMS estándar no contiene llaves AES/ECDSA privadas del chip Kirk de Sony PSP.',
        '# Solución recomendada:',
        '#   1) En PPSSPP: Ajustes > Herramientas > Herramientas de desarrollo > Volcar EBOOT.BIN descifrado',
        '#   2) O abre el archivo equivalente BOOT.BIN del directorio SYSDIR (suele ser ELF plano).',
        'idstring "~PSP"',
        'print "Módulo protegido con cifrado hardware Kirk. Buscando bloques planos ELF/GZIP residuales..."',
        '',
        ...buildCarverSection(profile, prefix)
      );
    }
    return lines.join('\n');
  }

  // ZLIB_GZIP_CARVER default
  lines.push(...buildCarverSection(profile, prefix));
  return lines.join('\n');
}
