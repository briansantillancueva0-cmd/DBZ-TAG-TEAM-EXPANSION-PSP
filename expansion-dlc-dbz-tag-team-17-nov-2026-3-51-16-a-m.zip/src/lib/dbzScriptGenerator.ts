import type { DbzRoster256JsonManifest } from './dbzTagTeamExpander';

export type RosterScriptTarget = 'PYTHON' | 'C_HEADER' | 'MIPS_ARMIPS' | 'CWCHEAT_INI';

export interface RosterScriptGeneratorOptions {
  target: RosterScriptTarget;
  baseIndexMode: '0x00_BASED' | '0x01_BASED';
  dlcBasePath: string;
  includeCanonicalNamesOnly: boolean;
  customSlotPrefix: string;
}

export interface GameEngineRosterJsonSlot {
  slotIndex: number;
  hexId: string;
  internalCode: string;
  displayName: string;
  isBaseCanonical: boolean;
  assets: {
    modelBin: string;
    chibiGim: string;
    specialPmf: string;
  };
  ramBudgetKb: number;
  loadPriority: string;
  costumeVariants: number;
}

export interface GameEngineRosterJson {
  schema: 'DBZ_TT_ENGINE_ROSTER_V2';
  gameId: string;
  engineTarget: 'PSP_TAG_TEAM_256';
  indexMode: '0x00_BASED' | '0x01_BASED';
  totalSlots: number;
  ramPolicy: {
    targetRamMb: number;
    loadStrategy: string;
    maxActiveFightersInRam: number;
    fighterRamCapMb: number;
    chibiGimCacheMb: number;
    pmfStreamBufferKb: number;
    vramTextureBudgetMb: number;
    unloadUnusedCostumes: boolean;
  };
  slots: GameEngineRosterJsonSlot[];
}

export function buildGameEngineCompatibleJson(
  manifest: DbzRoster256JsonManifest,
  options: Pick<RosterScriptGeneratorOptions, 'baseIndexMode' | 'dlcBasePath' | 'customSlotPrefix'>
): GameEngineRosterJson {
  const cleanDlcBase = options.dlcBasePath.replace(/\/+$/, '');
  const slots: GameEngineRosterJsonSlot[] = manifest.characters.slice(0, 256).map((ch, idx) => {
    const numId = options.baseIndexMode === '0x00_BASED' ? idx : idx + 1;
    const hexId = `0x${numId.toString(16).toUpperCase().padStart(2, '0')}`;
    const padded = String(numId).padStart(3, '0');
    const code = `${options.customSlotPrefix || 'CHAR'}${padded}`;

    return {
      slotIndex: numId,
      hexId,
      internalCode: ch.codeName || code,
      displayName: ch.displayName,
      isBaseCanonical: idx <= 0x46,
      assets: {
        modelBin: ch.modelBinPath || `${cleanDlcBase}/PERSONAJES/${code}.BIN`,
        chibiGim: ch.gimPortraitPath || `${cleanDlcBase}/CHIBIS/CHIBI${padded}.GIM`,
        specialPmf: ch.pmfSpecialPath || `${cleanDlcBase}/VIDEOS/ULT_${padded}.PMF`,
      },
      ramBudgetKb: Math.round((ch.ramWeightMb || 6.0) * 1024),
      loadPriority: ch.priority,
      costumeVariants: ch.costumes,
    };
  });

  return {
    schema: 'DBZ_TT_ENGINE_ROSTER_V2',
    gameId: manifest.gameId,
    engineTarget: 'PSP_TAG_TEAM_256',
    indexMode: options.baseIndexMode,
    totalSlots: slots.length,
    ramPolicy: {
      targetRamMb: manifest.ramBalance.targetRamMb,
      loadStrategy: manifest.ramBalance.loadStrategy,
      maxActiveFightersInRam: manifest.ramBalance.maxActiveFightersInRam,
      fighterRamCapMb: manifest.ramBalance.fighterRamCapMb,
      chibiGimCacheMb: manifest.ramBalance.chibiGimCacheMb,
      pmfStreamBufferKb: manifest.ramBalance.pmfStreamBufferKb,
      vramTextureBudgetMb: manifest.ramBalance.vramTextureBudgetMb,
      unloadUnusedCostumes: manifest.ramBalance.unloadUnusedCostumes,
    },
    slots,
  };
}

export function generateRosterMappingScript(
  manifest: DbzRoster256JsonManifest,
  options: RosterScriptGeneratorOptions
): { filename: string; content: string } {
  const engineJson = buildGameEngineCompatibleJson(manifest, options);
  const previewLimit = options.includeCanonicalNamesOnly ? 71 : engineJson.slots.length;
  const activeSlots = engineJson.slots.slice(0, previewLimit);

  if (options.target === 'PYTHON') {
    const rows = activeSlots
      .map(
        (s) =>
          `    (${s.hexId}, ${JSON.stringify(s.internalCode)}, ${JSON.stringify(s.displayName)}, ${JSON.stringify(s.assets.modelBin)}, ${JSON.stringify(s.assets.chibiGim)}, ${JSON.stringify(s.assets.specialPmf)}, ${s.ramBudgetKb}),`
      )
      .join('\n');

    return {
      filename: `${manifest.gameId}_map_256_roster.py`,
      content: `#!/usr/bin/env python3
"""
Generador y Parcheador de Mapeo de 256 IDs - DBZ Tenkaichi Tag Team (${manifest.gameId})
Base RAM Objetivo: ${engineJson.ramPolicy.targetRamMb} MB | Estrategia: ${engineJson.ramPolicy.loadStrategy}
"""
import json
from pathlib import Path

GAME_ID = ${JSON.stringify(manifest.gameId)}
DLC_BASE_PATH = ${JSON.stringify(options.dlcBasePath)}
RAM_TARGET_MB = ${engineJson.ramPolicy.targetRamMb}

# (slot_id, codigo, nombre, model_bin, chibi_gim, special_pmf, ram_kb)
ROSTER_SLOTS = [
${rows}
]

def export_engine_json(out_path: Path) -> None:
    payload = {
        "schema": "DBZ_TT_ENGINE_ROSTER_V2",
        "gameId": GAME_ID,
        "indexMode": ${JSON.stringify(options.baseIndexMode)},
        "totalSlots": len(ROSTER_SLOTS),
        "ramPolicy": {
            "targetRamMb": RAM_TARGET_MB,
            "loadStrategy": ${JSON.stringify(engineJson.ramPolicy.loadStrategy)},
            "maxActiveFightersInRam": ${engineJson.ramPolicy.maxActiveFightersInRam},
        },
        "slots": [
            {
                "slotIndex": sid,
                "hexId": f"0x{sid:02X}",
                "internalCode": code,
                "displayName": name,
                "assets": {
                    "modelBin": mpath,
                    "chibiGim": gpath,
                    "specialPmf": ppath,
                },
                "ramBudgetKb": rkb,
            }
            for (sid, code, name, mpath, gpath, ppath, rkb) in ROSTER_SLOTS
        ],
    }
    out_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[OK] Exportado {out_path} con {len(ROSTER_SLOTS)} IDs.")

if __name__ == "__main__":
    export_engine_json(Path(f"{GAME_ID}_ENGINE_256_MAP.json"))
`,
    };
  }

  if (options.target === 'C_HEADER') {
    const structs = activeSlots
      .map(
        (s) =>
          `  { ${s.hexId}, ${JSON.stringify(s.internalCode)}, ${JSON.stringify(s.displayName)}, ${JSON.stringify(s.assets.modelBin)}, ${JSON.stringify(s.assets.chibiGim)}, ${JSON.stringify(s.assets.specialPmf)}, ${s.ramBudgetKb}, ${s.costumeVariants} },`
      )
      .join('\n');

    return {
      filename: `${manifest.gameId.toLowerCase()}_roster_256.h`,
      content: `/* Auto-generado para PSP SDK / PPSSPP PRX Hook - ${manifest.gameId} */
#pragma once
#include <stdint.h>

#define DBZ_TT_MAX_ROSTER_SLOTS ${activeSlots.length}
#define DBZ_TT_TARGET_RAM_MB    ${engineJson.ramPolicy.targetRamMb}

typedef struct {
  uint16_t slotId;
  const char* internalCode;
  const char* displayName;
  const char* modelBinPath;
  const char* chibiGimPath;
  const char* specialPmfPath;
  uint32_t ramBudgetKb;
  uint8_t costumeVariants;
} DbzCharacterSlotEntry;

static const DbzCharacterSlotEntry g_dbzRoster256Table[DBZ_TT_MAX_ROSTER_SLOTS] = {
${structs}
};
`,
    };
  }

  if (options.target === 'MIPS_ARMIPS') {
    const ptrLines = activeSlots
      .map((s) => `  .word str_char_${s.slotIndex.toString(16).toUpperCase().padStart(2, '0')} ; ${s.hexId} ${s.displayName}`)
      .join('\n');
    const strLines = activeSlots
      .map((s) => `str_char_${s.slotIndex.toString(16).toUpperCase().padStart(2, '0')}: .asciiz ${JSON.stringify(s.assets.modelBin)}`)
      .join('\n');

    return {
      filename: `${manifest.gameId}_roster_256_armips.asm`,
      content: `; ============================================================================
; Script MIPS Assembly (armips) - Tabla Extendida ${activeSlots.length} IDs (${manifest.gameId})
; RAM Objetivo: ${engineJson.ramPolicy.targetRamMb} MB
; ============================================================================
.psp
.open "EBOOT.BIN", "EBOOT_256.BIN", 0x08804000

; Ampliar comprobacion de limite de personajes a 256 (0x0100)
.org 0x08812040
  sltiu $v0, $a0, 0x0100
  nop

; Tabla de punteros a rutas DLC para los ${activeSlots.length} slots
.align 16
g_roster_256_path_table:
${ptrLines}

; Cadenas null-terminated en DLC/PERSONAJES/
${strLines}

.close
`,
    };
  }

  // CWCHEAT_INI
  const unlockLines = activeSlots
    .slice(0, 64)
    .map((s) => `_L 0x005A12${s.slotIndex.toString(16).toUpperCase().padStart(2, '0')} 0x000000FF ; ${s.hexId} ${s.displayName}`)
    .join('\n');

  return {
    filename: `${manifest.gameId}_MAPPER_256.ini`,
    content: `; CWCheat Script Generado - Mapeo de ${activeSlots.length} IDs (${manifest.gameId})
_S ${manifest.gameId}
_G Dragon Ball Z Tenkaichi Tag Team [Roster 256 Script]

_C1 [MAPPER 256] Habilitar Tabla Extendida y RAM ${engineJson.ramPolicy.targetRamMb}MB
_L 0x205A4000 0x00000100
_L 0x20010000 0x${(engineJson.ramPolicy.targetRamMb === 64 ? 0x0c000000 : engineJson.ramPolicy.targetRamMb === 128 ? 0x10000000 : 0x18000000).toString(16).toUpperCase().padStart(8, '0')}
${unlockLines}
`,
  };
}
