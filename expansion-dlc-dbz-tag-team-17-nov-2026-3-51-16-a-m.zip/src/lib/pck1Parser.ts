import { buildZipBlob, type ZipInputEntry } from './zipBuilder';

export type Pck1AssetCategory =
  | 'PERSONAJES'
  | 'MAPAS'
  | 'MINIMAPAS'
  | 'OBJ_3D'
  | 'MUSICA_AT3'
  | 'IMAGENES'
  | 'OTROS';

export interface Pck1CategorySummary {
  category: Pck1AssetCategory;
  folderName: string;
  label: string;
  count: number;
  totalBytes: number;
}

export interface Pck1ExtractedEntry {
  id: number;
  name: string;
  subfolder: string;
  category: Pck1AssetCategory;
  categoryLabel: string;
  signature: string;
  extension: string;
  compressed: 'NONE' | 'ZLIB';
  /** Byte offset in the root blob if directly sliceable, or offset within decompressed parent */
  offset: number;
  rawSize: number;
  uncompressedSize: number;
  depth: number;
  /** Path of parent slices/decompression steps needed to extract exact bytes */
  extractionChain: Array<{ offset: number; size: number; isZlib: boolean }>;
  notes: string;
}

export interface Pck1AnalysisResult {
  packName: string;
  totalBytes: number;
  pck1BlocksFound: number;
  entries: Pck1ExtractedEntry[];
  summaries: Pck1CategorySummary[];
  notes: string[];
}

const CATEGORY_INFO: Record<
  Pck1AssetCategory,
  { folderName: string; label: string }
> = {
  PERSONAJES: { folderName: 'Personajes', label: 'Personajes 3D (.GMO/.AMO)' },
  MAPAS: { folderName: 'Mapas', label: 'Mapas y Escenarios (.MAP/.STG)' },
  MINIMAPAS: { folderName: 'Minimapas', label: 'Minimapas y Radar HUD' },
  OBJ_3D: { folderName: 'Modelos_OBJ', label: 'Modelos 3D / Wavefront .OBJ' },
  MUSICA_AT3: { folderName: 'Musica_AT3', label: 'Música ATRAC3+ (.AT3) y Audio' },
  IMAGENES: { folderName: 'Imagenes', label: 'Imágenes y Texturas (.GIM/.TM2/.PNG)' },
  OTROS: { folderName: 'Otros_Binarios', label: 'Otros Bloques / Sub-PCK1' },
};

function isZlibHeader(bytes: Uint8Array, off = 0): boolean {
  if (off + 2 >= bytes.length) return false;
  const cmf = bytes[off];
  const flg = bytes[off + 1];
  if ((cmf & 0x0f) !== 8) return false;
  return ((cmf << 8) + flg) % 31 === 0;
}

export async function tryDecompressZlib(bytes: Uint8Array): Promise<Uint8Array | null> {
  if (typeof DecompressionStream === 'undefined') return null;
  if (!isZlibHeader(bytes, 0)) return null;
  try {
    const ds = new DecompressionStream('deflate');
    const copy = new Uint8Array(bytes.byteLength);
    copy.set(bytes);
    const stream = new Blob([copy.buffer]).stream().pipeThrough(ds);
    const buf = await new Response(stream).arrayBuffer();
    return new Uint8Array(buf);
  } catch {
    // Fallback for raw deflate without zlib header or corrupt tail
    try {
      const dsRaw = new DecompressionStream('deflate-raw');
      const sliced = new Uint8Array(bytes.byteLength - 2);
      sliced.set(bytes.subarray(2));
      const stream = new Blob([sliced.buffer]).stream().pipeThrough(dsRaw);
      const buf = await new Response(stream).arrayBuffer();
      return new Uint8Array(buf);
    } catch {
      return null;
    }
  }
}

function asciiAt(bytes: Uint8Array, off: number, len: number): string {
  if (off + len > bytes.length) return '';
  let s = '';
  for (let i = 0; i < len; i++) {
    s += String.fromCharCode(bytes[off + i]);
  }
  return s;
}

function classifySignatureAndPayload(
  head: Uint8Array,
  hintName?: string
): {
  category: Pck1AssetCategory;
  signature: string;
  extension: string;
  notes: string;
} {
  const s4 = asciiAt(head, 0, 4);
  const s8 = asciiAt(head, 0, 8);
  const s12 = asciiAt(head, 0, Math.min(128, head.length));
  const lowerPeek = `${hintName ?? ''} ${s12}`.toLowerCase();

  // 1. Wavefront ASCII .OBJ detection (lines starting with # / mtllib / o / v  / vn / vt / f )
  if (
    /(^|\n)\s*v\s+-?\d+\.\d+/.test(s12) ||
    /(^|\n)\s*(mtllib|usemtl|o\s+\w+)/.test(s12) ||
    (hintName && /\.obj$/i.test(hintName))
  ) {
    return {
      category: 'OBJ_3D',
      signature: 'Wavefront OBJ',
      extension: 'obj',
      notes: 'Geometría 3D en formato Wavefront .OBJ.',
    };
  }

  // 2. Audio / Música .AT3 (RIFF WAVE/AT3, VAGp, PSMF)
  if (s4 === 'RIFF') {
    return {
      category: 'MUSICA_AT3',
      signature: 'RIFF ATRAC3+',
      extension: 'at3',
      notes: 'Pista de audio PSP RIFF/ATRAC3+ (.AT3).',
    };
  }
  if (s4 === 'VAGp') {
    return {
      category: 'MUSICA_AT3',
      signature: 'Sony VAGp',
      extension: 'vag',
      notes: 'Efecto o voz ADPCM Sony VAG.',
    };
  }
  if (s4 === 'PSMF') {
    return {
      category: 'MUSICA_AT3',
      signature: 'PSMF Video/Audio',
      extension: 'pmf',
      notes: 'Cinemática PSP con flujo de audio.',
    };
  }

  // 3. Minimapas (MIG/TIM2/PNG/GIM con pistas de minimapa/radar)
  if (/(minimap|mini_map|mmap|radar|compass)/.test(lowerPeek)) {
    const ext =
      s8.startsWith('MIG.00.1') ? 'gim' : s4 === 'TIM2' ? 'tm2' : head[0] === 0x89 ? 'png' : 'tm2';
    const sig =
      s8.startsWith('MIG.00.1')
        ? 'MIG.00.1PSP'
        : s4 === 'TIM2'
        ? 'TIM2'
        : head[0] === 0x89
        ? 'PNG'
        : 'MINIMAP';
    return {
      category: 'MINIMAPAS',
      signature: sig,
      extension: ext,
      notes: 'Textura o radar de minimapa HUD.',
    };
  }

  // 4. Imágenes / Texturas nativas Sony GIM / TIM2 / PNG (prioritario sobre coincidencia de texto 'stage'/'map')
  if (s8.startsWith('MIG.00.1')) {
    return {
      category: 'IMAGENES',
      signature: 'MIG.00.1PSP',
      extension: 'gim',
      notes: 'Imagen/Textura nativa Sony GIM.',
    };
  }
  if (s4 === 'TIM2') {
    return {
      category: 'IMAGENES',
      signature: 'TIM2',
      extension: 'tm2',
      notes: 'Imagen/Textura PlayStation TIM2.',
    };
  }

  // 5. Mapas y Escenarios
  if (
    s4.startsWith('MAP') ||
    s4.startsWith('STG') ||
    /(map_|stage|arena|field|lvl|escenario)/.test(lowerPeek)
  ) {
    return {
      category: 'MAPAS',
      signature: s4.replace(/[^\x20-\x7E]/g, '.') || 'MAP',
      extension: 'map',
      notes: 'Escenario, geometría de mapa o zona jugable.',
    };
  }

  // 6. Personajes 3D (OMG.00.1PSP, AMO, MDL)
  if (s8.startsWith('OMG.00.1')) {
    return {
      category: 'PERSONAJES',
      signature: 'OMG.00.1PSP',
      extension: 'gmo',
      notes: 'Modelo 3D esquelético Sony PSP (.GMO) de personaje.',
    };
  }
  if (s4 === '#AMO' || s4 === 'AMO\0' || /(chara|char_|hero|boss|fighter|player)/.test(lowerPeek)) {
    return {
      category: 'PERSONAJES',
      signature: s4.replace(/[^\x20-\x7E]/g, '.') || 'CHAR',
      extension: s4.includes('AMO') ? 'amo' : 'gmo',
      notes: 'Recurso 3D o esqueleto de personaje.',
    };
  }
  if (head.length >= 4 && head[0] === 0x89 && asciiAt(head, 1, 3) === 'PNG') {
    return {
      category: 'IMAGENES',
      signature: 'PNG',
      extension: 'png',
      notes: 'Imagen PNG estándar.',
    };
  }
  if (s4.startsWith('BM')) {
    return {
      category: 'IMAGENES',
      signature: 'BMP',
      extension: 'bmp',
      notes: 'Mapa de bits BMP.',
    };
  }

  return {
    category: 'OTROS',
    signature: s4.replace(/[^\x20-\x7E]/g, '.') || 'BIN',
    extension: 'bin',
    notes: 'Bloque binario o datos de juego dentro de PCK1.',
  };
}

interface ParsedPck1Toc {
  headerVariant: string;
  entries: Array<{ offset: number; size: number; name?: string }>;
}

function tryParsePck1Header(buf: Uint8Array, containerSize: number): ParsedPck1Toc | null {
  if (buf.length < 16) return null;
  if (asciiAt(buf, 0, 4) !== 'PCK1') return null;

  const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);

  // Try common PCK1 header layouts:
  // Layout A: [PCK1][count @ 0x04][offset,size @ 0x08..] (stride 8)
  // Layout B: [PCK1][count @ 0x04][unk/hdrSz][unk][offset,size @ 0x10..] (stride 8)
  // Layout C: [PCK1][count @ 0x04][offset0, offset1.. @ 0x08..] (stride 4)
  // Layout D: [PCK1][count @ 0x04][offset0, offset1.. @ 0x10..] (stride 4)
  // Layout E: [PCK1][count @ 0x04][16B entries: off, sz, unk, unk @ 0x10..] (stride 16)
  // Layout F: [PCK1][unk @ 0x04][count @ 0x08][entries @ 0x10..]
  const layouts: Array<{ countOff: number; tableOff: number; stride: 4 | 8 | 16; label: string }> = [
    { countOff: 4, tableOff: 16, stride: 8, label: 'PCK1 (TOC 16B+8B [off,size])' },
    { countOff: 4, tableOff: 8, stride: 8, label: 'PCK1 (TOC 8B+8B [off,size])' },
    { countOff: 4, tableOff: 16, stride: 16, label: 'PCK1 (TOC 16B [off,size,meta])' },
    { countOff: 4, tableOff: 8, stride: 4, label: 'PCK1 (Tabla punteros 4B @ 0x08)' },
    { countOff: 4, tableOff: 16, stride: 4, label: 'PCK1 (Tabla punteros 4B @ 0x10)' },
    { countOff: 8, tableOff: 16, stride: 8, label: 'PCK1 (count @ 0x08, [off,size])' },
    { countOff: 8, tableOff: 16, stride: 4, label: 'PCK1 (count @ 0x08, ptrs 4B)' },
  ];

  for (const layout of layouts) {
    if (layout.countOff + 4 > buf.length) continue;
    const count = dv.getUint32(layout.countOff, true);
    if (count < 1 || count > 16384) continue;

    const needed = layout.tableOff + count * layout.stride;
    if (needed > buf.length || needed > containerSize) continue;

    const items: Array<{ offset: number; size: number }> = [];
    let valid = true;
    let prevOff = -1;

    for (let i = 0; i < count; i++) {
      const p = layout.tableOff + i * layout.stride;
      const off = dv.getUint32(p, true);
      const sz = layout.stride >= 8 ? dv.getUint32(p + 4, true) : 0;

      if (off === 0 && sz === 0) {
        // Empty slot allowed in some PCK1 packs
        items.push({ offset: 0, size: 0 });
        continue;
      }
      if (off < needed || off >= containerSize || off < prevOff) {
        valid = false;
        break;
      }
      if (layout.stride >= 8 && (sz === 0 || off + sz > containerSize)) {
        valid = false;
        break;
      }
      prevOff = off;
      items.push({ offset: off, size: sz });
    }

    if (!valid || items.every((x) => x.offset === 0)) continue;

    if (layout.stride === 4) {
      for (let i = 0; i < items.length; i++) {
        if (items[i].offset === 0) continue;
        let nextOff = containerSize;
        for (let j = i + 1; j < items.length; j++) {
          if (items[j].offset > items[i].offset) {
            nextOff = items[j].offset;
            break;
          }
        }
        items[i].size = Math.max(4, nextOff - items[i].offset);
      }
    }

    return { headerVariant: layout.label, entries: items.filter((it) => it.size > 0) };
  }

  return null;
}

export async function parseAndScanPck1Blob(
  blob: Blob,
  packName: string,
  onProgress?: (pct: number) => void
): Promise<Pck1AnalysisResult> {
  const entries: Pck1ExtractedEntry[] = [];
  const notes: string[] = [];
  let pck1BlocksFound = 0;
  let nextId = 1;

  const inspectSlice = async (
    currentBytes: Uint8Array | null,
    rootOffset: number,
    sliceSize: number,
    chain: Array<{ offset: number; size: number; isZlib: boolean }>,
    depth: number,
    prefixName: string
  ) => {
    if (depth > 3 || entries.length >= 2500) return;

    const headLen = Math.min(sliceSize, 128 * 1024);
    const headBytes =
      currentBytes !== null
        ? currentBytes.subarray(0, headLen)
        : new Uint8Array(await blob.slice(rootOffset, rootOffset + headLen).arrayBuffer());

    const toc = tryParsePck1Header(headBytes, sliceSize);
    if (toc) {
      pck1BlocksFound++;
      if (depth === 0) {
        notes.push(`Cabecera raíz detectada: ${toc.headerVariant} con ${toc.entries.length} entradas.`);
      }

      for (let i = 0; i < toc.entries.length; i++) {
        if (entries.length >= 2500) break;
        const item = toc.entries[i];
        const itemHeaderLen = Math.min(item.size, 256);
        const itemBytes =
          currentBytes !== null
            ? currentBytes.subarray(item.offset, Math.min(currentBytes.length, item.offset + item.size))
            : null;
        const itemHead =
          itemBytes !== null
            ? itemBytes.subarray(0, itemHeaderLen)
            : new Uint8Array(
                await blob.slice(rootOffset + item.offset, rootOffset + item.offset + itemHeaderLen).arrayBuffer()
              );

        const itemChain = [...chain, { offset: item.offset, size: item.size, isZlib: false }];
        const zlib = isZlibHeader(itemHead, 0) && item.size <= 16 * 1024 * 1024;

        let workingHead = itemHead;
        let workingFull: Uint8Array | null = itemBytes;
        let uncompSize = item.size;
        let compressed: 'NONE' | 'ZLIB' = 'NONE';
        let activeChain = itemChain;

        if (zlib) {
          const compBuf =
            itemBytes !== null
              ? itemBytes
              : new Uint8Array(
                  await blob.slice(rootOffset + item.offset, rootOffset + item.offset + item.size).arrayBuffer()
                );
          const decomp = await tryDecompressZlib(compBuf);
          if (decomp && decomp.length > 0) {
            compressed = 'ZLIB';
            workingFull = decomp;
            workingHead = decomp.subarray(0, Math.min(decomp.length, 256));
            uncompSize = decomp.length;
            activeChain = [...chain, { offset: item.offset, size: item.size, isZlib: true }];
          }
        }

        // Check if nested PCK1
        if (asciiAt(workingHead, 0, 4) === 'PCK1' && depth < 3) {
          const subName = `${prefixName}SUB_${String(i + 1).padStart(3, '0')}_`;
          await inspectSlice(
            workingFull,
            workingFull ? 0 : rootOffset + item.offset,
            uncompSize,
            activeChain,
            depth + 1,
            subName
          );
          continue;
        }

        const cls = classifySignatureAndPayload(workingHead, item.name);
        const catMeta = CATEGORY_INFO[cls.category];
        const baseName = `${prefixName}${cls.category}_${String(nextId).padStart(4, '0')}.${cls.extension}`;

        entries.push({
          id: nextId++,
          name: baseName,
          subfolder: catMeta.folderName,
          category: cls.category,
          categoryLabel: catMeta.label,
          signature: cls.signature,
          extension: cls.extension,
          compressed,
          offset: rootOffset + item.offset,
          rawSize: item.size,
          uncompressedSize: uncompSize,
          depth,
          extractionChain: activeChain,
          notes: compressed === 'ZLIB' ? `${cls.notes} (Descomprimido Zlib)` : cls.notes,
        });
      }
      return;
    }

    // Fallback when top-level file is PACKFILE.BIN containing embedded PCK1 blocks or raw assets
    if (depth === 0) {
      const CHUNK = 2 * 1024 * 1024;
      const OVERLAP = 16;
      const foundPckOffsets: number[] = [];

      for (let start = 0; start < blob.size; start += CHUNK) {
        const end = Math.min(blob.size, start + CHUNK + OVERLAP);
        const chunk = new Uint8Array(await blob.slice(start, end).arrayBuffer());
        const scanEnd = Math.min(chunk.length - 4, CHUNK);

        for (let i = 0; i < scanEnd; i += 4) {
          if (
            chunk[i] === 0x50 &&
            chunk[i + 1] === 0x43 &&
            chunk[i + 2] === 0x4b &&
            chunk[i + 3] === 0x31
          ) {
            foundPckOffsets.push(start + i);
          }
        }
        if (onProgress) {
          onProgress(Math.min(95, Math.round(((start + CHUNK) / blob.size) * 100)));
        }
      }

      if (foundPckOffsets.length > 0) {
        notes.push(
          `Se encontraron ${foundPckOffsets.length} sub-contenedores PCK1 incrustados dentro de ${packName}.`
        );
        for (let k = 0; k < foundPckOffsets.length; k++) {
          const pckOff = foundPckOffsets[k];
          const maxSlice = Math.min(
            (k + 1 < foundPckOffsets.length ? foundPckOffsets[k + 1] : blob.size) - pckOff,
            64 * 1024 * 1024
          );
          await inspectSlice(
            null,
            pckOff,
            maxSlice,
            [{ offset: pckOff, size: maxSlice, isZlib: false }],
            1,
            `PCK${String(k + 1).padStart(2, '0')}_`
          );
        }
      } else {
        // Scan raw signatures (OMG, MIG, TIM2, RIFF AT3, VAGp, PSMF, PNG, OBJ, Zlib)
        notes.push(
          `No se detectó tabla PCK1 directa; se ejecutó extracción por firmas reales (OMG, MIG, TIM2, RIFF/AT3, Zlib) en ${packName}.`
        );
        const carved: Array<{ off: number; sz: number; head: Uint8Array; isZlib: boolean }> = [];
        for (let start = 0; start < blob.size; start += CHUNK) {
          const end = Math.min(blob.size, start + CHUNK + 64);
          const chunk = new Uint8Array(await blob.slice(start, end).arrayBuffer());
          const scanEnd = Math.min(chunk.length - 12, CHUNK);

          for (let i = 0; i < scanEnd; i += 4) {
            const b0 = chunk[i];
            const isSig =
              (b0 === 0x4f && asciiAt(chunk, i, 8) === 'OMG.00.1') ||
              (b0 === 0x4d && asciiAt(chunk, i, 8) === 'MIG.00.1') ||
              (b0 === 0x54 && asciiAt(chunk, i, 4) === 'TIM2') ||
              (b0 === 0x52 && asciiAt(chunk, i, 4) === 'RIFF') ||
              (b0 === 0x56 && asciiAt(chunk, i, 4) === 'VAGp') ||
              (b0 === 0x50 && asciiAt(chunk, i, 4) === 'PSMF') ||
              (b0 === 0x89 && asciiAt(chunk, i + 1, 3) === 'PNG');

            if (isSig) {
              let sz = 0;
              if (asciiAt(chunk, i, 4) === 'RIFF') {
                const dv = new DataView(chunk.buffer, chunk.byteOffset, chunk.byteLength);
                const rsz = dv.getUint32(i + 4, true) + 8;
                if (rsz > 16 && start + i + rsz <= blob.size) sz = rsz;
              }
              carved.push({
                off: start + i,
                sz,
                head: chunk.slice(i, Math.min(chunk.length, i + 128)),
                isZlib: false,
              });
              if (carved.length >= 1200) break;
            }
          }
          if (carved.length >= 1200) break;
        }

        for (let i = 0; i < carved.length; i++) {
          const cur = carved[i];
          const nextOff = i + 1 < carved.length ? carved[i + 1].off : blob.size;
          const estSize = cur.sz > 0 ? cur.sz : Math.max(64, Math.min(nextOff - cur.off, 16 * 1024 * 1024));
          const cls = classifySignatureAndPayload(cur.head);
          const catMeta = CATEGORY_INFO[cls.category];
          entries.push({
            id: nextId++,
            name: `${cls.category}_${String(nextId - 1).padStart(4, '0')}.${cls.extension}`,
            subfolder: catMeta.folderName,
            category: cls.category,
            categoryLabel: catMeta.label,
            signature: cls.signature,
            extension: cls.extension,
            compressed: 'NONE',
            offset: cur.off,
            rawSize: estSize,
            uncompressedSize: estSize,
            depth: 0,
            extractionChain: [{ offset: cur.off, size: estSize, isZlib: false }],
            notes: cls.notes,
          });
        }
      }
    }
  };

  await inspectSlice(null, 0, blob.size, [], 0, '');
  if (onProgress) onProgress(100);

  const order: Pck1AssetCategory[] = [
    'PERSONAJES',
    'MAPAS',
    'MINIMAPAS',
    'OBJ_3D',
    'MUSICA_AT3',
    'IMAGENES',
    'OTROS',
  ];

  const summaries: Pck1CategorySummary[] = order.map((cat) => {
    const items = entries.filter((e) => e.category === cat);
    return {
      category: cat,
      folderName: CATEGORY_INFO[cat].folderName,
      label: CATEGORY_INFO[cat].label,
      count: items.length,
      totalBytes: items.reduce((acc, cur) => acc + cur.uncompressedSize, 0),
    };
  });

  return {
    packName,
    totalBytes: blob.size,
    pck1BlocksFound,
    entries,
    summaries,
    notes,
  };
}

export async function extractPck1EntryData(
  rootBlob: Blob,
  entry: Pck1ExtractedEntry
): Promise<Uint8Array> {
  if (entry.extractionChain.length === 0) {
    return new Uint8Array(
      await rootBlob.slice(entry.offset, Math.min(rootBlob.size, entry.offset + entry.rawSize)).arrayBuffer()
    );
  }

  let currentBytes: Uint8Array | null = null;
  for (const step of entry.extractionChain) {
    if (currentBytes === null) {
      currentBytes = new Uint8Array(
        await rootBlob.slice(step.offset, Math.min(rootBlob.size, step.offset + step.size)).arrayBuffer()
      );
    } else {
      currentBytes = currentBytes.subarray(
        step.offset,
        Math.min(currentBytes.length, step.offset + step.size)
      );
    }
    if (step.isZlib) {
      const dec = await tryDecompressZlib(currentBytes);
      if (dec) currentBytes = dec;
    }
  }

  return currentBytes ?? new Uint8Array(0);
}

export async function exportPck1SubfoldersZip(
  rootBlob: Blob,
  result: Pck1AnalysisResult,
  categoryFilter?: Pck1AssetCategory
): Promise<Blob> {
  const targets = categoryFilter
    ? result.entries.filter((e) => e.category === categoryFilter)
    : result.entries;

  const zipEntries: ZipInputEntry[] = [];
  const indexLines: string[] = [
    `DESCOMPRESIÓN PCK1 EN SUBCARPETAS - ${result.packName}`,
    `Total extraído: ${targets.length} archivos`,
    '',
  ];

  for (const entry of targets.slice(0, 600)) {
    const data = await extractPck1EntryData(rootBlob, entry);
    const fullZipPath = `${entry.subfolder}/${entry.name}`;
    zipEntries.push({ path: fullZipPath, data });
    indexLines.push(
      `#${String(entry.id).padStart(4, '0')} | ${fullZipPath.padEnd(38)} | ${entry.signature.padEnd(14)} | ${data.length} B`
    );
  }

  zipEntries.push({
    path: 'INDICE_PCK1.txt',
    data: new TextEncoder().encode(indexLines.join('\n')),
  });

  return buildZipBlob(zipEntries);
}

export function buildPck1PythonUnpackerScript(): string {
  return `#!/usr/bin/env python3
"""
Descomprimidor Recursivo de PCK1 / PACKFILE.BIN en Subcarpetas (PSP)
Analiza y separa automaticamente:
  - Personajes/     (.gmo, .amo, OMG.00.1PSP)
  - Mapas/          (.map, .stg)
  - Minimapas/      (radar / minimap .gim/.tm2)
  - Modelos_OBJ/    (geometria Wavefront .obj)
  - Musica_AT3/     (audio RIFF ATRAC3+ .at3, VAGp, PSMF)
  - Imagenes/       (texturas MIG .gim, TIM2 .tm2, .png)
  - Otros_Binarios/ (bloques restantes)
"""

import argparse
import struct
import zlib
from pathlib import Path


def is_zlib(data: bytes) -> bool:
    if len(data) < 3:
        return False
    cmf, flg = data[0], data[1]
    return (cmf & 0x0F) == 8 and (((cmf << 8) + flg) % 31 == 0)


def try_decompress(data: bytes) -> tuple[bytes, bool]:
    if not is_zlib(data):
        return data, False
    try:
        return zlib.decompress(data), True
    except Exception:
        return data, False


def classify_payload(data: bytes) -> tuple[str, str]:
    head = data[:128]
    peek_low = head.decode("ascii", errors="ignore").lower()

    if head.startswith(b"RIFF"):
        return "Musica_AT3", "at3"
    if head.startswith(b"VAGp"):
        return "Musica_AT3", "vag"
    if head.startswith(b"PSMF"):
        return "Musica_AT3", "pmf"
    if any(k in peek_low for k in ("minimap", "mini_map", "radar", "mmap")):
        ext = "gim" if head.startswith(b"MIG.00.1") else ("png" if head.startswith(b"\\x89PNG") else "tm2")
        return "Minimapas", ext
    if "\\nv " in "\\n" + peek_low or peek_low.startswith(("mtllib", "o ", "v ")):
        return "Modelos_OBJ", "obj"
    if head.startswith(b"OMG.00.1") or any(k in peek_low for k in ("chara", "hero", "boss", "amo")):
        return "Personajes", "gmo"
    if head.startswith((b"MAP", b"STG")) or any(k in peek_low for k in ("map_", "stage", "arena", "field")):
        return "Mapas", "map"
    if head.startswith(b"MIG.00.1"):
        return "Imagenes", "gim"
    if head.startswith(b"TIM2"):
        return "Imagenes", "tm2"
    if head.startswith(b"\\x89PNG"):
        return "Imagenes", "png"
    return "Otros_Binarios", "bin"


def parse_pck1_toc(buf: bytes) -> list[tuple[int, int]] | None:
    if len(buf) < 16 or not buf.startswith(b"PCK1"):
        return None
    for count_off, table_off, stride in (
        (4, 16, 8), (4, 8, 8), (4, 16, 16), (4, 8, 4), (4, 16, 4), (8, 16, 8)
    ):
        if count_off + 4 > len(buf):
            continue
        count = struct.unpack_from("<I", buf, count_off)[0]
        if not (1 <= count <= 16384):
            continue
        needed = table_off + count * stride
        if needed > len(buf):
            continue
        entries: list[tuple[int, int]] = []
        prev_off = -1
        ok = True
        for i in range(count):
            pos = table_off + i * stride
            off = struct.unpack_from("<I", buf, pos)[0]
            sz = struct.unpack_from("<I", buf, pos + 4)[0] if stride >= 8 else 0
            if off == 0 and sz == 0:
                continue
            if off < needed or off >= len(buf) or off < prev_off:
                ok = False
                break
            if stride >= 8 and (sz == 0 or off + sz > len(buf)):
                ok = False
                break
            prev_off = off
            entries.append((off, sz))
        if ok and entries:
            if stride == 4:
                resolved = []
                for idx, (off, _) in enumerate(entries):
                    nxt = entries[idx + 1][0] if idx + 1 < len(entries) else len(buf)
                    resolved.append((off, max(4, nxt - off)))
                return resolved
            return entries
    return None


def unpack_recursive(buf: bytes, out_dir: Path, prefix: str = "", depth: int = 0, stats: dict | None = None) -> dict:
    if stats is None:
        stats = {}
    if depth > 4:
        return stats

    toc = parse_pck1_toc(buf)
    if toc:
        for i, (off, sz) in enumerate(toc):
            raw_chunk = buf[off : off + sz]
            chunk, _ = try_decompress(raw_chunk)
            if chunk.startswith(b"PCK1") and depth < 4:
                unpack_recursive(chunk, out_dir, f"{prefix}SUB{i+1:03d}_", depth + 1, stats)
                continue
            folder, ext = classify_payload(chunk)
            target_dir = out_dir / folder
            target_dir.mkdir(parents=True, exist_ok=True)
            out_path = target_dir / f"{prefix}{folder}_{i+1:04d}.{ext}"
            out_path.write_bytes(chunk)
            stats[folder] = stats.get(folder, 0) + 1
        return stats

    # Fallback: buscar sub-bloques PCK1 incrustados dentro de PACKFILE.BIN
    cursor = 0
    found = 0
    while True:
        idx = buf.find(b"PCK1", cursor)
        if idx == -1:
            break
        nxt = buf.find(b"PCK1", idx + 4)
        sub_buf = buf[idx : (nxt if nxt != -1 else len(buf))]
        if parse_pck1_toc(sub_buf):
            found += 1
            unpack_recursive(sub_buf, out_dir, f"PCK{found:03d}_", 1, stats)
        cursor = idx + 4
    return stats


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Descomprime PCK1 / PACKFILE.BIN en subcarpetas por categoria.")
    parser.add_argument("input", type=Path, help="Ruta a PACKFILE.BIN o archivo .PCK")
    parser.add_argument("--out", type=Path, default=Path("./PCK1_EXTRAIDO"), help="Carpeta de salida")
    args = parser.parse_args()

    raw = args.input.read_bytes()
    res = unpack_recursive(raw, args.out)
    print(f"Descompresion completada en {args.out}:")
    for k, v in sorted(res.items()):
        print(f"  - {k}: {v} archivos")
`;
}

export interface Pck1PackInputEntry {
  name: string;
  data: Uint8Array;
  category?: Pck1AssetCategory;
}

/**
 * Construye un contenedor binario PCK1 real (cabecera 'PCK1' + tabla [offset,size] de 8 bytes desde 0x10
 * y bloques alineados a 16 bytes). Compatible con tryParsePck1Header y extractores PSP/Tenkaichi Tag Team.
 */
export function buildPck1Container(entries: Pck1PackInputEntry[]): Uint8Array {
  const safeEntries = entries.slice(0, 4096);
  const count = safeEntries.length;
  const headerAndTocBytes = 16 + count * 8;
  const firstDataOffset = Math.ceil(headerAndTocBytes / 16) * 16;

  let cursor = firstDataOffset;
  const offsets: number[] = [];
  for (const entry of safeEntries) {
    offsets.push(cursor);
    const alignedLen = Math.ceil(Math.max(4, entry.data.length) / 16) * 16;
    cursor += alignedLen;
  }

  const out = new Uint8Array(cursor);
  const dv = new DataView(out.buffer);
  // Magic 'PCK1'
  out[0] = 0x50;
  out[1] = 0x43;
  out[2] = 0x4b;
  out[3] = 0x31;
  dv.setUint32(4, count, true);
  dv.setUint32(8, firstDataOffset, true);
  dv.setUint32(12, cursor, true);

  for (let i = 0; i < count; i++) {
    const tocPos = 16 + i * 8;
    dv.setUint32(tocPos, offsets[i], true);
    dv.setUint32(tocPos + 4, safeEntries[i].data.length, true);
    out.set(safeEntries[i].data, offsets[i]);
  }

  return out;
}

/**
 * Genera una textura Sony PSP GIM mínima válida ('MIG.00.1PSP') con píxeles RGBA8888 8x8
 * para que las herramientas de PCK1 la reconozcan como Imagen / Minimapa / Chibi auténtico.
 */
export function buildMinimalPspGimTexture(
  label: string,
  rgb: [number, number, number] = [249, 115, 22]
): Uint8Array {
  const width = 8;
  const height = 8;
  const pixelBytes = width * height * 4;
  const labelBytes = new TextEncoder().encode(label.slice(0, 32));
  const totalSize = 64 + pixelBytes + 32;
  const buf = new Uint8Array(totalSize);
  const dv = new DataView(buf.buffer);

  // MIG.00.1PSP magic (16 bytes)
  const magic = 'MIG.00.1PSP\0\0\0\0\0';
  for (let i = 0; i < 16; i++) buf[i] = magic.charCodeAt(i);
  // Root chunk 0x02
  dv.setUint16(16, 0x02, true);
  dv.setUint16(18, 0, true);
  dv.setUint32(20, totalSize - 16, true);
  dv.setUint32(24, 16, true);
  // Image header tag at 32
  dv.setUint16(32, 0x04, true);
  dv.setUint16(34, 0, true);
  dv.setUint32(36, 32 + pixelBytes, true);
  dv.setUint16(48, width, true);
  dv.setUint16(50, height, true);
  dv.setUint16(52, 3, true); // RGBA8888

  for (let p = 0; p < width * height; p++) {
    const base = 64 + p * 4;
    buf[base] = rgb[0];
    buf[base + 1] = rgb[1];
    buf[base + 2] = rgb[2];
    buf[base + 3] = 0xff;
  }

  // Metadata / slot label tail (helps PCK1 classifier identify MINIMAP / CHIBI / PORTRAIT)
  buf.set(labelBytes, 64 + pixelBytes);
  return buf;
}

/**
 * Genera un flujo RIFF PCM / contenedor ATRAC3+ ligero reproducible y clasificable por PCK1 como Musica_AT3.
 */
export function buildMinimalRiffAt3Blob(trackNumber: number, title: string): Uint8Array {
  const sampleRate = 11025;
  const samples = Math.floor(sampleRate * 0.25); // 250ms chime for compact PCK1 packing
  const dataBytes = samples * 2;
  const buf = new Uint8Array(44 + dataBytes + 32);
  const dv = new DataView(buf.buffer);
  const writeStr = (off: number, s: string) => {
    for (let i = 0; i < s.length; i++) buf[off + i] = s.charCodeAt(i);
  };

  writeStr(0, 'RIFF');
  dv.setUint32(4, 36 + dataBytes, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  dv.setUint32(16, 16, true);
  dv.setUint16(20, 1, true); // PCM
  dv.setUint16(22, 1, true); // mono
  dv.setUint32(24, sampleRate, true);
  dv.setUint32(28, sampleRate * 2, true);
  dv.setUint16(32, 2, true);
  dv.setUint16(34, 16, true);
  writeStr(36, 'data');
  dv.setUint32(40, dataBytes, true);

  const baseFreq = 220 + (trackNumber % 16) * 28;
  for (let i = 0; i < samples; i++) {
    const env = Math.max(0, 1 - i / samples);
    const val = Math.sin((2 * Math.PI * baseFreq * i) / sampleRate) * 9000 * env;
    dv.setInt16(44 + i * 2, Math.round(val), true);
  }

  writeStr(44 + dataBytes, `AT3_${String(trackNumber).padStart(3, '0')}:${title.slice(0, 20)}`);
  return buf;
}

export type ProceduralGimVariant = 'PORTRAIT' | 'MAP' | 'MINIMAP' | 'UI';

export interface ProceduralGimPalette {
  primary: [number, number, number];
  secondary: [number, number, number];
  hair?: [number, number, number];
}

function clampByte(n: number): number {
  return Math.max(0, Math.min(255, Math.round(n)));
}

/**
 * Genera una textura Sony PSP GIM ('MIG.00.1PSP') de 32×32 RGBA8888 con pixel-art real:
 * - PORTRAIT: retrato estilizado DBZ (aura, gi, rostro y cabello)
 * - MAP: miniatura atmosférica de escenario (cielo, horizonte, terreno/anillos)
 * - MINIMAP: radar táctico con cuadrícula y puntos de equipo
 * - UI: marco HUD / cursor
 */
export function buildProceduralPspGimTexture(
  label: string,
  palette: ProceduralGimPalette,
  variant: ProceduralGimVariant = 'PORTRAIT',
  seed = 0
): Uint8Array {
  const width = 32;
  const height = 32;
  const pixelBytes = width * height * 4;
  const labelBytes = new TextEncoder().encode(label.slice(0, 48));
  const totalSize = 64 + pixelBytes + 48;
  const buf = new Uint8Array(totalSize);
  const dv = new DataView(buf.buffer);

  const magic = 'MIG.00.1PSP\0\0\0\0\0';
  for (let i = 0; i < 16; i++) buf[i] = magic.charCodeAt(i);
  dv.setUint16(16, 0x02, true);
  dv.setUint16(18, 0, true);
  dv.setUint32(20, totalSize - 16, true);
  dv.setUint32(24, 16, true);
  dv.setUint16(32, 0x04, true);
  dv.setUint16(34, 0, true);
  dv.setUint32(36, 32 + pixelBytes, true);
  dv.setUint16(48, width, true);
  dv.setUint16(50, height, true);
  dv.setUint16(52, 3, true); // RGBA8888

  // 10-byte inline tag inside header padding (read inside first 128 bytes by PCK1 scanner)
  const tag =
    variant === 'MINIMAP'
      ? 'MINIMAP\0\0\0'
      : variant === 'MAP'
      ? 'MAPIMG\0\0\0\0'
      : variant === 'UI'
      ? 'UIHUD\0\0\0\0\0'
      : 'CHARIMG\0\0\0';
  for (let i = 0; i < 10; i++) buf[54 + i] = tag.charCodeAt(i);

  const [pR, pG, pB] = palette.primary;
  const [sR, sG, sB] = palette.secondary;
  const [hR, hG, hB] = palette.hair ?? [250, 204, 21];

  const putPx = (x: number, y: number, r: number, g: number, b: number, a = 255) => {
    if (x < 0 || x >= width || y < 0 || y >= height) return;
    const base = 64 + (y * width + x) * 4;
    buf[base] = clampByte(r);
    buf[base + 1] = clampByte(g);
    buf[base + 2] = clampByte(b);
    buf[base + 3] = clampByte(a);
  };

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const t = y / (height - 1);
      if (variant === 'PORTRAIT') {
        const dx = x - 15.5;
        const dy = y - 15.5;
        const dist = Math.hypot(dx, dy);
        // Aura radial backdrop
        const glow = Math.max(0, 1 - dist / 18);
        let r = sR * (0.45 + 0.35 * (1 - t)) + glow * 85;
        let g = sG * (0.45 + 0.35 * (1 - t)) + glow * 70;
        let b = sB * (0.45 + 0.35 * (1 - t)) + glow * 30;

        // Torso / Gi (lower third)
        if (y >= 20 && Math.abs(dx) <= 9 + (y - 20) * 0.45) {
          r = Math.abs(dx) <= 2.5 && y <= 25 ? sR : pR;
          g = Math.abs(dx) <= 2.5 && y <= 25 ? sG : pG;
          b = Math.abs(dx) <= 2.5 && y <= 25 ? sB : pB;
        }
        // Face oval
        if (Math.hypot(dx / 6.2, (y - 14.5) / 6.5) <= 1.0) {
          r = 253;
          g = 210;
          b = 168;
        }
        // Eyes
        if (y === 14 && (x === 13 || x === 14 || x === 18 || x === 19)) {
          r = 15;
          g = 23;
          b = 42;
        }
        // Spiky DBZ hair crest
        const spikeWave = Math.sin(((x + (seed % 5)) / 32) * Math.PI * 5) * 2.5;
        if (
          y >= 3 &&
          y <= 11 + (Math.abs(dx) > 4 ? 2 : 0) + spikeWave * 0.4 &&
          Math.abs(dx) <= 8.5 + (11 - y) * 0.35
        ) {
          r = hR;
          g = hG;
          b = hB;
        }
        // Subtle 1px frame
        if (x === 0 || y === 0 || x === width - 1 || y === height - 1) {
          r = 250;
          g = 204;
          b = 21;
        }
        putPx(x, y, r, g, b, 255);
      } else if (variant === 'MAP') {
        const horizon = 18 + Math.round(Math.sin((x + seed * 3) * 0.28) * 3);
        let r = sR * (1 - t) + pR * t;
        let g = sG * (1 - t) + pG * t;
        let b = sB * (1 - t) + pB * t;
        if (y >= horizon) {
          const gt = (y - horizon) / Math.max(1, height - horizon);
          r = pR * (0.85 - gt * 0.35);
          g = pG * (0.85 - gt * 0.35);
          b = pB * (0.85 - gt * 0.35);
          if ((x + y) % 8 === 0) {
            r += 18;
            g += 18;
            b += 18;
          }
        } else if (Math.hypot(x - 23, y - 8) <= 4.2) {
          // Sun / Moon / Namek orb
          r = hR;
          g = hG;
          b = hB;
        }
        if (x === 0 || y === 0 || x === width - 1 || y === height - 1) {
          r = 56;
          g = 189;
          b = 248;
        }
        putPx(x, y, r, g, b, 255);
      } else if (variant === 'MINIMAP') {
        const dx = x - 15.5;
        const dy = y - 15.5;
        const dist = Math.hypot(dx, dy);
        if (dist > 15) {
          putPx(x, y, 2, 6, 23, 210);
          continue;
        }
        let r = 6;
        let g = 55;
        let b = 42;
        if (Math.abs(dist - 14.2) < 0.9 || Math.abs(dist - 8) < 0.65) {
          r = 52;
          g = 211;
          b = 153;
        } else if (Math.round(dx) === 0 || Math.round(dy) === 0) {
          r = 16;
          g = 120;
          b = 90;
        }
        const px1 = 9 + (seed % 7);
        const py1 = 11 + (seed % 5);
        const px2 = 22 - (seed % 6);
        const py2 = 20 - (seed % 5);
        if (Math.hypot(x - px1, y - py1) <= 1.8) {
          r = 250;
          g = 204;
          b = 21;
        } else if (Math.hypot(x - px2, y - py2) <= 1.8) {
          r = 239;
          g = 68;
          b = 68;
        }
        putPx(x, y, r, g, b, 255);
      } else {
        const border = x < 2 || y < 2 || x >= width - 2 || y >= height - 2;
        putPx(
          x,
          y,
          border ? pR : sR,
          border ? pG : sG,
          border ? pB : sB,
          border ? 255 : 200
        );
      }
    }
  }

  buf.set(labelBytes, 64 + pixelBytes);
  return buf;
}

/**
 * Decodifica una textura PSP .GIM ('MIG.00.1PSP') o TIM2 básica a píxeles RGBA8888 listos para <canvas>.
 */
export function decodeGimTextureToRgba(
  bytes: Uint8Array
): { width: number; height: number; rgba: Uint8ClampedArray } | null {
  if (bytes.length < 64) return null;
  const sig = asciiAt(bytes, 0, 8);
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);

  if (sig.startsWith('MIG.00.1')) {
    // Buscar sub-chunk imagen 0x0004 (por defecto en 32 o escanear cabecera)
    let imgChunkOff = -1;
    for (const candidate of [32, 48, 64, 16]) {
      if (candidate + 24 <= bytes.length && dv.getUint16(candidate, true) === 0x0004) {
        imgChunkOff = candidate;
        break;
      }
    }
    const w = imgChunkOff >= 0 ? dv.getUint16(imgChunkOff + 16, true) : dv.getUint16(48, true);
    const h = imgChunkOff >= 0 ? dv.getUint16(imgChunkOff + 18, true) : dv.getUint16(50, true);
    const fmt = imgChunkOff >= 0 ? dv.getUint16(imgChunkOff + 20, true) : dv.getUint16(52, true);
    const pixStart = imgChunkOff >= 0 ? imgChunkOff + 32 : 64;

    if (w < 1 || h < 1 || w > 1024 || h > 1024) return null;
    const count = w * h;
    const rgba = new Uint8ClampedArray(count * 4);

    if (fmt === 3 && pixStart + count * 4 <= bytes.length) {
      rgba.set(bytes.subarray(pixStart, pixStart + count * 4));
      return { width: w, height: h, rgba };
    }
    if (fmt === 0 && pixStart + count * 2 <= bytes.length) {
      // RGB565
      for (let i = 0; i < count; i++) {
        const v = dv.getUint16(pixStart + i * 2, true);
        rgba[i * 4] = ((v & 0x1f) * 255) / 31;
        rgba[i * 4 + 1] = (((v >> 5) & 0x3f) * 255) / 63;
        rgba[i * 4 + 2] = (((v >> 11) & 0x1f) * 255) / 31;
        rgba[i * 4 + 3] = 255;
      }
      return { width: w, height: h, rgba };
    }
    if (fmt === 2 && pixStart + count * 2 <= bytes.length) {
      // RGBA4444
      for (let i = 0; i < count; i++) {
        const v = dv.getUint16(pixStart + i * 2, true);
        rgba[i * 4] = (v & 0x0f) * 17;
        rgba[i * 4 + 1] = ((v >> 4) & 0x0f) * 17;
        rgba[i * 4 + 2] = ((v >> 8) & 0x0f) * 17;
        rgba[i * 4 + 3] = ((v >> 12) & 0x0f) * 17;
      }
      return { width: w, height: h, rgba };
    }
    if (pixStart + count * 4 <= bytes.length) {
      rgba.set(bytes.subarray(pixStart, pixStart + count * 4));
      return { width: w, height: h, rgba };
    }
    return null;
  }

  if (asciiAt(bytes, 0, 4) === 'TIM2' && bytes.length >= 64) {
    const w = dv.getUint16(36, true);
    const h = dv.getUint16(38, true);
    const pixStart = 64;
    if (w >= 1 && h >= 1 && w <= 512 && h <= 512 && pixStart + w * h * 4 <= bytes.length) {
      const rgba = new Uint8ClampedArray(w * h * 4);
      rgba.set(bytes.subarray(pixStart, pixStart + w * h * 4));
      return { width: w, height: h, rgba };
    }
  }

  return null;
}

/**
 * Convierte bytes de textura PSP (.GIM/.TM2) o PNG estándar en una DataURL visualizable en <img>.
 */
export function renderPspImageBytesToDataUrl(bytes: Uint8Array): string | null {
  if (bytes.length < 16) return null;
  if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) {
    let bin = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
    }
    return `data:image/png;base64,${btoa(bin)}`;
  }

  const decoded = decodeGimTextureToRgba(bytes);
  if (!decoded || typeof document === 'undefined') return null;

  const canvas = document.createElement('canvas');
  canvas.width = decoded.width;
  canvas.height = decoded.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;
  const imgData = new ImageData(new Uint8ClampedArray(decoded.rgba), decoded.width, decoded.height);
  ctx.putImageData(imgData, 0, 0);
  return canvas.toDataURL('image/png');
}

export interface MasterPackfileCharacterInput {
  slotId: number;
  hexId: string;
  name: string;
  modelBinPath: string;
  gimPortraitPath: string;
  modes?: string[];
  customPortraitBytes?: Uint8Array;
}

export interface MasterPackfileMapInput {
  slotId: number;
  name: string;
  stagePath: string;
  minimapPath: string;
  linkedMusicTrackId: number;
  customMapBytes?: Uint8Array;
  customMinimapBytes?: Uint8Array;
}

export interface MasterPackfileMusicInput {
  trackId: number;
  title: string;
  dlcPath: string;
  customAudioBytes?: Uint8Array;
}

export interface MasterPackfileBuildOptions {
  gameId: string;
  freeBattleHeaderBin: Uint8Array;
  freeBattleLayoutJson: string;
  characters: MasterPackfileCharacterInput[];
  maps: MasterPackfileMapInput[];
  music: MasterPackfileMusicInput[];
  preservedEntries?: Pck1PackInputEntry[];
  extraEntries?: Pck1PackInputEntry[];
}

function hexPaletteSeed(seed: number): ProceduralGimPalette {
  const presets: ProceduralGimPalette[] = [
    { primary: [249, 115, 22], secondary: [29, 78, 216], hair: [15, 23, 42] },
    { primary: [30, 58, 138], secondary: [248, 250, 252], hair: [250, 204, 21] },
    { primary: [126, 34, 206], secondary: [250, 204, 21], hair: [250, 204, 21] },
    { primary: [21, 128, 61], secondary: [147, 51, 234], hair: [22, 163, 74] },
    { primary: [226, 232, 240], secondary: [109, 40, 217], hair: [248, 250, 252] },
    { primary: [22, 101, 52], secondary: [15, 23, 42], hair: [34, 197, 94] },
    { primary: [244, 114, 182], secondary: [248, 250, 252], hair: [249, 168, 212] },
    { primary: [34, 197, 94], secondary: [220, 38, 38], hair: [250, 204, 21] },
  ];
  return presets[seed % presets.length];
}

function mapPaletteSeed(seed: number): ProceduralGimPalette {
  const presets: ProceduralGimPalette[] = [
    { primary: [146, 64, 14], secondary: [194, 65, 12], hair: [251, 146, 60] },
    { primary: [22, 163, 74], secondary: [2, 132, 199], hair: [250, 204, 21] },
    { primary: [63, 63, 70], secondary: [127, 29, 29], hair: [248, 113, 113] },
    { primary: [4, 120, 87], secondary: [52, 211, 153], hair: [167, 243, 208] },
    { primary: [203, 213, 225], secondary: [29, 78, 216], hair: [245, 158, 11] },
    { primary: [88, 28, 135], secondary: [192, 132, 252], hair: [240, 171, 252] },
  ];
  return presets[seed % presets.length];
}

/**
 * Construye el archivo maestro /PSP_GAME/USRDIR/PACKFILE.BIN (formato PCK1 anidado)
 * integrando:
 * 1) UI de Batalla Libre
 * 2) Roster Expandida (Batalla Libre + Historia Dragon Walker + Supervivencia + Entrenamiento + Ad-Hoc) con sus imágenes .GIM
 * 3) Seleccionador de Mapas DLC (46+ escenarios + minimapas radar .GIM)
 * 4) Tabla de Música AT3 y recursos originales preservados.
 */
export function buildMasterPackfileBin(opts: MasterPackfileBuildOptions): Uint8Array {
  const enc = new TextEncoder();

  // Sub-PCK 1: UI Batalla Libre
  const uiEntries: Pck1PackInputEntry[] = [
    { name: 'FREE_BATTLE_HDR.bin', data: opts.freeBattleHeaderBin },
    { name: 'FREE_BATTLE_LAYOUT.json', data: enc.encode(opts.freeBattleLayoutJson) },
    {
      name: 'HUD_FRAME.gim',
      data: buildProceduralPspGimTexture(
        'HUD_FRAME_PACKFILE',
        { primary: [34, 211, 238], secondary: [15, 23, 42] },
        'UI',
        1
      ),
    },
    {
      name: 'HUD_CURSOR.gim',
      data: buildProceduralPspGimTexture(
        'HUD_CURSOR_PACKFILE',
        { primary: [250, 204, 21], secondary: [180, 83, 9] },
        'UI',
        2
      ),
    },
  ];
  const sub1Ui = buildPck1Container(uiEntries);

  // Sub-PCK 2: Roster Expandida Batalla Libre y Otros Modos + 256 Retratos .GIM
  const rosterJsonBatallaLibre = {
    schema: 'DBZ_TT_PACKFILE_ROSTER_V1',
    gameId: opts.gameId,
    mode: 'BATALLA_LIBRE',
    totalSlots: opts.characters.length,
    slots: opts.characters.map((c) => ({
      slotId: c.slotId,
      hexId: c.hexId,
      name: c.name,
      modelBinPath: c.modelBinPath,
      gimPortraitPath: c.gimPortraitPath,
    })),
  };

  const rosterJsonOtrosModos = {
    schema: 'DBZ_TT_PACKFILE_OTHER_MODES_V1',
    gameId: opts.gameId,
    modesEnabled: [
      'BATALLA_LIBRE',
      'DRAGON_WALKER_HISTORIA',
      'SUPERVIVENCIA',
      'ENTRENAMIENTO',
      'MULTIJUGADOR_ADHOC',
      'PERSONALIZAR',
    ],
    totalSlots: opts.characters.length,
    sharedRosterTable: opts.characters.map((c) => ({
      slotId: c.slotId,
      hexId: c.hexId,
      name: c.name,
      unlockedInAllModes: true,
      modes: c.modes ?? [
        'BATALLA_LIBRE',
        'HISTORIA',
        'SUPERVIVENCIA',
        'ENTRENAMIENTO',
        'AD_HOC',
      ],
    })),
  };

  const rosterEntries: Pck1PackInputEntry[] = [
    {
      name: 'ROSTER_BATALLA_LIBRE.json',
      data: enc.encode(JSON.stringify(rosterJsonBatallaLibre, null, 2)),
    },
    {
      name: 'ROSTER_OTROS_MODOS.json',
      data: enc.encode(JSON.stringify(rosterJsonOtrosModos, null, 2)),
    },
  ];
  for (const ch of opts.characters.slice(0, 256)) {
    const img =
      ch.customPortraitBytes ??
      buildProceduralPspGimTexture(
        `CHAR_${ch.hexId}_${ch.name}`,
        hexPaletteSeed(ch.slotId),
        'PORTRAIT',
        ch.slotId
      );
    rosterEntries.push({
      name: `CHAR_PORTRAIT_${String(ch.slotId).padStart(3, '0')}.gim`,
      data: img,
      category: 'IMAGENES',
    });
  }
  const sub2Roster = buildPck1Container(rosterEntries);

  // Sub-PCK 3: Seleccionador de Mapas DLC + Imágenes Escenario & Minimapas .GIM
  const mapsManifest = {
    schema: 'DBZ_TT_PACKFILE_MAP_SELECTOR_DLC_V1',
    gameId: opts.gameId,
    totalMaps: opts.maps.length,
    maps: opts.maps.map((m) => ({
      slotId: m.slotId,
      name: m.name,
      stagePath: m.stagePath,
      minimapPath: m.minimapPath,
      linkedMusicTrackId: m.linkedMusicTrackId,
    })),
  };
  const mapEntries: Pck1PackInputEntry[] = [
    {
      name: 'MAP_SELECTOR_DLC.json',
      data: enc.encode(JSON.stringify(mapsManifest, null, 2)),
    },
  ];
  for (const m of opts.maps.slice(0, 99)) {
    const mStr = String(m.slotId).padStart(2, '0');
    const stagePreviewImg =
      m.customMapBytes && m.customMapBytes.length > 64 && asciiAt(m.customMapBytes, 0, 4) === 'MIG.'
        ? m.customMapBytes
        : buildProceduralPspGimTexture(
            `MAP_${mStr}_${m.name}`,
            mapPaletteSeed(m.slotId),
            'MAP',
            m.slotId
          );
    const minimapImg =
      m.customMinimapBytes ??
      buildProceduralPspGimTexture(
        `MINIMAP_${mStr}_${m.name}`,
        mapPaletteSeed(m.slotId),
        'MINIMAP',
        m.slotId
      );
    mapEntries.push({
      name: `MAP_STAGE_IMG_${mStr}.gim`,
      data: stagePreviewImg,
      category: 'IMAGENES',
    });
    mapEntries.push({
      name: `MINIMAP_${mStr}.gim`,
      data: minimapImg,
      category: 'MINIMAPAS',
    });
  }
  const sub3Maps = buildPck1Container(mapEntries);

  // Sub-PCK 4: Índice y Pistas BGM .AT3
  const musicIndex = {
    schema: 'DBZ_TT_PACKFILE_BGM_V1',
    gameId: opts.gameId,
    totalTracks: opts.music.length,
    tracks: opts.music.map((t) => ({
      trackId: t.trackId,
      title: t.title,
      dlcPath: t.dlcPath,
    })),
  };
  const musicEntries: Pck1PackInputEntry[] = [
    { name: 'BGM_SELECTOR_DLC.json', data: enc.encode(JSON.stringify(musicIndex, null, 2)) },
  ];
  for (const t of opts.music.slice(0, 64)) {
    musicEntries.push({
      name: `BGM_${String(t.trackId).padStart(2, '0')}.at3`,
      data: t.customAudioBytes ?? buildMinimalRiffAt3Blob(t.trackId, t.title),
      category: 'MUSICA_AT3',
    });
  }
  const sub4Music = buildPck1Container(musicEntries);

  const rootEntries: Pck1PackInputEntry[] = [
    { name: 'SUB_01_UI_BATALLA_LIBRE.pck', data: sub1Ui },
    { name: 'SUB_02_ROSTER_BATALLA_LIBRE_OTROS.pck', data: sub2Roster },
    { name: 'SUB_03_MAPAS_DLC_SELECTOR.pck', data: sub3Maps },
    { name: 'SUB_04_MUSICA_AT3_DLC.pck', data: sub4Music },
  ];

  if (opts.preservedEntries && opts.preservedEntries.length > 0) {
    rootEntries.push({
      name: 'SUB_05_BASE_PACKFILE_PRESERVADO.pck',
      data: buildPck1Container(opts.preservedEntries.slice(0, 200)),
    });
  }
  if (opts.extraEntries && opts.extraEntries.length > 0) {
    rootEntries.push(...opts.extraEntries.slice(0, 64));
  }

  return buildPck1Container(rootEntries);
}


