import type {
  EbootAnalysis,
  GameAssetCategory,
  GameAssetCategorySummary,
  GameAssetItem,
  GameAssetReport,
} from './types';

const CATEGORY_META: Record<
  GameAssetCategory,
  { label: string; description: string }
> = {
  CHARACTERS: {
    label: 'Personajes y Modelos 3D',
    description: 'Modelos esqueléticos (.GMO, .PMO, .P3D), animaciones, NPCs, jefes y skins de personajes.',
  },
  MAPS: {
    label: 'Mapas y Escenarios',
    description: 'Geometría de niveles, escenarios (.MAP, .STG, .FLD), colisiones y zonas del mundo.',
  },
  TEXTURES: {
    label: 'Texturas y Sprites',
    description: 'Texturas nativas PSP (.GIM, .TM2, .TIM, .TXD, .PNG), atlas HUD, fuentes y efectos.',
  },
  MUSIC: {
    label: 'Música, Voces y Audio',
    description: 'Pistas ATRAC3+ (.AT3), audio ADPCM (.VAG, .ADX), cinemáticas (.PMF) y librerías de sonido.',
  },
  MINIMAPS: {
    label: 'Minimapas y Radar HUD',
    description: 'Capas de minimapa, radar, brújula, iconos de navegación y mapas de área en pantalla.',
  },
};

function getExtension(pathStr: string): string {
  const clean = pathStr.split('?')[0].trim();
  const base = clean.split('/').pop() || clean;
  const dot = base.lastIndexOf('.');
  if (dot <= 0 || dot === base.length - 1) return '';
  return base.slice(dot + 1).toUpperCase();
}

function classifyByPathAndName(
  fullPath: string
): { category: GameAssetCategory; notes: string } | null {
  const lower = fullPath.toLowerCase();
  const ext = getExtension(fullPath).toLowerCase();

  // Ignore core system boot files
  if (
    lower.endsWith('/eboot.bin') ||
    lower.endsWith('/boot.bin') ||
    lower.endsWith('/param.sfo') ||
    lower.endsWith('/umd_data.bin')
  ) {
    return null;
  }

  // 1. Minimaps first (more specific than general maps or textures)
  if (
    /(minimap|mini_map|mmap|radar|automap|navi_map|areamap|area_map|compass|hud_map|worldmap_ui|map_icon)/.test(
      lower
    )
  ) {
    return {
      category: 'MINIMAPS',
      notes: 'Recurso identificado como minimapa, radar de navegación o mapa HUD.',
    };
  }

  // 2. Music, Voices & Audio
  if (
    ['at3', 'at9', 'oma', 'vag', 'adx', 'awb', 'acb', 'bgm', 'snd', 'wav', 'mp3', 'ogg', 'aac', 'sdat', 'phd', 'pbd', 'pmf', 'mps'].includes(
      ext
    ) ||
    /(\/|^|_)(bgm|music|sound|audio|voice|vo|sfx|se|track|song|stream|movie)(\/|_|\.|$)/.test(lower)
  ) {
    return {
      category: 'MUSIC',
      notes:
        ext === 'pmf'
          ? 'Video cinemático PSP (PMF) con pista de audio multiplexada.'
          : 'Archivo o referencia de música, pista ATRAC3+, voz o efecto de sonido.',
    };
  }

  // 3. Characters & 3D Models
  if (
    ['gmo', 'gmd', 'pmo', 'p3d', 'pmd', 'mdl', 'chr', 'bone', 'mot', 'anm', 'skl', 'bmd'].includes(
      ext
    ) ||
    /(\/|^|_)(chara|char|character|player|hero|enemy|npc|boss|unit|fighter|actor|model|skin|avatar)(\/|_|\.|$)/.test(
      lower
    )
  ) {
    return {
      category: 'CHARACTERS',
      notes: 'Modelo 3D, esqueleto de personaje, animación o entidad jugable/enemiga.',
    };
  }

  // 4. Maps & Stages
  if (
    ['map', 'stg', 'fld', 'bsp', 'scn', 'lvl', 'wld', 'col', 'nav', 'area', 'zone'].includes(ext) ||
    /(\/|^|_)(map|stage|field|level|world|dungeon|arena|town|room|zone|terrain|skybox)(\/|_|\.|$)/.test(
      lower
    )
  ) {
    return {
      category: 'MAPS',
      notes: 'Escenario, geometría de nivel, malla de colisión o datos de zona.',
    };
  }

  // 5. Textures & Sprites
  if (
    ['gim', 'tm2', 'tim', 'tex', 'txd', 'dds', 'png', 'bmp', 'tga', 'mig', 'ptx', 'ctex', 'pgf'].includes(
      ext
    ) ||
    /(\/|^|_)(tex|texture|sprite|font|ui|hud|icon|eff|effect|pal|atlas|img)(\/|_|\.|$)/.test(lower)
  ) {
    // Special case: PSP XMB ICON0/PIC1 are textures
    return {
      category: 'TEXTURES',
      notes: 'Textura gráfica PSP (GIM/TIM2/PNG), sprite, atlas de interfaz o fuente.',
    };
  }

  return null;
}

export function detectAssetMagicSignature(bytes: Uint8Array): string {
  if (bytes.length < 4) return 'Archivo vacío o muy corto';
  const ascii4 = new TextDecoder('ascii', { fatal: false }).decode(bytes.subarray(0, 4));
  const ascii8 =
    bytes.length >= 8
      ? new TextDecoder('ascii', { fatal: false }).decode(bytes.subarray(0, 8))
      : ascii4;

  if (ascii8.startsWith('MIG.00.1')) return 'Sony PSP GIM Texture (MIG.00.1PSP)';
  if (ascii8.startsWith('OMG.00.1')) return 'Sony PSP GMO 3D Model (OMG.00.1PSP)';
  if (ascii4 === 'TIM2') return 'PlayStation TIM2 Texture';
  if (ascii4 === 'RIFF') return 'RIFF Audio / Sony ATRAC3 (.AT3 / .WAV)';
  if (ascii4 === 'PSMF') return 'PSP Streamed Movie (PSMF / .PMF)';
  if (ascii4 === 'VAGp') return 'Sony VAG ADPCM Audio';
  if (ascii4 === 'CRID' || ascii4 === '@UTF') return 'CRI Middleware Container / Audio';
  if (ascii4 === 'AFS\0') return 'CRI AFS Archive (Contenedor de recursos)';
  if (ascii4 === 'CPK ') return 'CRI CPK Archive (Paquete de modelos/texturas/audio)';
  if (bytes[0] === 0x89 && ascii4.slice(1) === 'PNG') return 'Imagen PNG Estándar';
  if (bytes[0] === 0x80 && bytes[1] === 0x00) return 'Posible flujo CRI ADX Audio';
  return `Firma binaria 0x${Array.from(bytes.subarray(0, 4))
    .map((b) => b.toString(16).toUpperCase().padStart(2, '0'))
    .join(' ')}`;
}

export function buildGameAssetReport(analysis: EbootAnalysis): GameAssetReport {
  const items: GameAssetItem[] = [];
  const seenKeys = new Set<string>();
  let idx = 1;

  // 1. Scan ISO 9660 files
  if (analysis.isoInfo) {
    for (const entry of analysis.isoInfo.files) {
      if (entry.isDirectory) continue;
      const cls = classifyByPathAndName(entry.path);
      if (!cls) continue;

      const key = `ISO:${entry.path.toLowerCase()}`;
      if (seenKeys.has(key)) continue;
      seenKeys.add(key);

      items.push({
        index: idx++,
        category: cls.category,
        categoryLabel: CATEGORY_META[cls.category].label,
        source: 'ISO_FILE',
        name: entry.name,
        pathOrSymbol: entry.path,
        extension: getExtension(entry.path) || 'BIN',
        sizeBytes: entry.size,
        lba: entry.lba,
        fileOffset: entry.byteOffset,
        ramAddress: null,
        isoEntryPath: entry.path,
        notes: cls.notes,
      });
    }
  }

  // 2. Scan EBOOT.BIN strings / disc0: paths / symbols
  for (const addr of analysis.addresses) {
    if (
      addr.category !== 'STRING_PATH' &&
      addr.category !== 'STRING_DEBUG' &&
      addr.category !== 'STRING_SCE'
    ) {
      continue;
    }

    const cls = classifyByPathAndName(addr.label);
    if (!cls) continue;

    const cleanName = addr.label.split('/').pop() || addr.label;
    const key = `EBOOT:${addr.label.toLowerCase()}`;
    if (seenKeys.has(key)) continue;
    seenKeys.add(key);

    items.push({
      index: idx++,
      category: cls.category,
      categoryLabel: CATEGORY_META[cls.category].label,
      source: 'EBOOT_REF',
      name: cleanName,
      pathOrSymbol: addr.label,
      extension: getExtension(addr.label) || 'STR',
      sizeBytes: null,
      lba: null,
      fileOffset: addr.fileOffset,
      ramAddress: addr.ramAddress,
      isoEntryPath: null,
      notes: `${cls.notes} Referenciado en ${addr.sectionName}.`,
    });
  }

  // 3. Scan imported PSP SDK libraries that handle Audio/Music or 3D Models/Textures
  for (const lib of analysis.libraries) {
    const lname = lib.name.toLowerCase();
    let cat: GameAssetCategory | null = null;
    if (/audio|atrac|sas|mpeg/.test(lname)) {
      cat = 'MUSIC';
    } else if (/ge_user|scegu|display/.test(lname)) {
      cat = 'TEXTURES';
    }
    if (!cat) continue;

    items.push({
      index: idx++,
      category: cat,
      categoryLabel: CATEGORY_META[cat].label,
      source: 'EBOOT_LIB',
      name: lib.name,
      pathOrSymbol: `${lib.name} (${lib.nidCount} NIDs)`,
      extension: 'NID',
      sizeBytes: null,
      lba: null,
      fileOffset: null,
      ramAddress: lib.stubAddr,
      isoEntryPath: null,
      notes: lib.purpose,
    });
  }

  const order: GameAssetCategory[] = ['CHARACTERS', 'MAPS', 'TEXTURES', 'MUSIC', 'MINIMAPS'];
  const summaries: GameAssetCategorySummary[] = order.map((cat) => {
    const catItems = items.filter((i) => i.category === cat);
    return {
      category: cat,
      label: CATEGORY_META[cat].label,
      description: CATEGORY_META[cat].description,
      count: catItems.length,
      isoFileCount: catItems.filter((i) => i.source === 'ISO_FILE').length,
      ebootRefCount: catItems.filter((i) => i.source !== 'ISO_FILE').length,
      totalIsoBytes: catItems.reduce((acc, cur) => acc + (cur.sizeBytes ?? 0), 0),
    };
  });

  const totalIsoBytes = summaries.reduce((acc, s) => acc + s.totalIsoBytes, 0);

  return {
    items,
    summaries,
    totalCount: items.length,
    totalIsoBytes,
  };
}

export function formatAssetReportText(report: GameAssetReport, sourceName: string): string {
  const lines: string[] = [];
  lines.push('========================================================================');
  lines.push('   INFORME INDEXADO DE PERSONAJES, MAPAS, TEXTURAS, MÚSICA Y MINIMAPAS  ');
  lines.push('========================================================================');
  lines.push(`Origen analizado : ${sourceName}`);
  lines.push(`Total de activos : ${report.totalCount}`);
  lines.push('');
  lines.push('--- RESUMEN POR CATEGORÍA ---');
  report.summaries.forEach((s, i) => {
    lines.push(
      `  [${i + 1}] ${s.label.padEnd(28)} | Total: ${String(s.count).padStart(4)} (ISO: ${s.isoFileCount}, EBOOT: ${s.ebootRefCount}) | Tamaño ISO: ${s.totalIsoBytes.toLocaleString('es-ES')} B`
    );
  });
  lines.push('');

  report.summaries.forEach((s, sIdx) => {
    lines.push(`--- [${sIdx + 1}] ${s.label.toUpperCase()} (${s.count}) ---`);
    const catItems = report.items.filter((i) => i.category === s.category);
    if (catItems.length === 0) {
      lines.push('  (Sin activos clasificados en esta categoría)');
    } else {
      catItems.forEach((item) => {
        const off =
          item.fileOffset !== null
            ? `0x${(item.fileOffset >>> 0).toString(16).toUpperCase().padStart(6, '0')}`
            : 'N/A';
        const ram =
          item.ramAddress !== null
            ? `0x${(item.ramAddress >>> 0).toString(16).toUpperCase().padStart(8, '0')}`
            : 'N/A';
        const sizeStr =
          item.sizeBytes !== null ? `${item.sizeBytes.toLocaleString('es-ES')} B` : 'Ref';
        lines.push(
          `  #${String(item.index).padStart(3, '0')} [${item.source.padEnd(9)}] | Off: ${off} | RAM: ${ram} | ${sizeStr.padStart(11)} | ${item.pathOrSymbol}`
        );
      });
    }
    lines.push('');
  });

  return lines.join('\n');
}

export function formatAssetReportMarkdown(report: GameAssetReport, sourceName: string): string {
  const md: string[] = [];
  md.push(`# Informe de Activos PSP: ${sourceName}`);
  md.push('');
  md.push('## Resumen de Personajes, Mapas, Texturas, Música y Minimapas');
  md.push('| Categoría | Total | Archivos ISO | Referencias EBOOT | Tamaño ISO |');
  md.push('| --- | ---: | ---: | ---: | ---: |');
  report.summaries.forEach((s) => {
    md.push(
      `| ${s.label} | ${s.count} | ${s.isoFileCount} | ${s.ebootRefCount} | ${s.totalIsoBytes.toLocaleString('es-ES')} B |`
    );
  });
  md.push('');

  report.summaries.forEach((s) => {
    md.push(`## ${s.label} (${s.count})`);
    const catItems = report.items.filter((i) => i.category === s.category);
    if (catItems.length === 0) {
      md.push('No se detectaron activos en esta categoría.');
    } else {
      md.push('| # | Origen | Nombre / Ruta | Formato | Offset | RAM | Tamaño |');
      md.push('| --- | --- | --- | --- | --- | --- | ---: |');
      catItems.forEach((item) => {
        const off =
          item.fileOffset !== null
            ? `\`0x${(item.fileOffset >>> 0).toString(16).toUpperCase().padStart(6, '0')}\``
            : '—';
        const ram =
          item.ramAddress !== null
            ? `\`0x${(item.ramAddress >>> 0).toString(16).toUpperCase().padStart(8, '0')}\``
            : '—';
        const sizeStr =
          item.sizeBytes !== null ? `${item.sizeBytes.toLocaleString('es-ES')} B` : '—';
        md.push(
          `| ${item.index} | ${item.source} | \`${item.pathOrSymbol.replace(/\|/g, '\\|')}\` | ${item.extension} | ${off} | ${ram} | ${sizeStr} |`
        );
      });
    }
    md.push('');
  });

  return md.join('\n');
}

export function formatAssetReportCsv(report: GameAssetReport): string {
  const rows = [
    'Indice,Categoria,Origen,Nombre,RutaOSimbolo,Extension,Offset,DireccionRAM,TamanoBytes,Notas',
  ];
  const esc = (s: string) => `"${s.replace(/"/g, '""')}"`;
  for (const item of report.items) {
    const off =
      item.fileOffset !== null
        ? `0x${(item.fileOffset >>> 0).toString(16).toUpperCase().padStart(6, '0')}`
        : '';
    const ram =
      item.ramAddress !== null
        ? `0x${(item.ramAddress >>> 0).toString(16).toUpperCase().padStart(8, '0')}`
        : '';
    rows.push(
      [
        item.index,
        esc(item.categoryLabel),
        item.source,
        esc(item.name),
        esc(item.pathOrSymbol),
        item.extension,
        off,
        ram,
        item.sizeBytes ?? '',
        esc(item.notes),
      ].join(',')
    );
  }
  return rows.join('\n');
}
