import { extractIsoFileBytes } from './iso9660';
import type { EbootAnalysis, IsoInspectionResult } from './types';

const MIPS_REGS = [
  '$zero', '$at', '$v0', '$v1', '$a0', '$a1', '$a2', '$a3',
  '$t0', '$t1', '$t2', '$t3', '$t4', '$t5', '$t6', '$t7',
  '$s0', '$s1', '$s2', '$s3', '$s4', '$s5', '$s6', '$s7',
  '$t8', '$t9', '$k0', '$k1', '$gp', '$sp', '$fp', '$ra',
];

export interface Disc0PathCheck {
  index: number;
  path: string;
  fileOffset: number;
  ramAddress: number;
  nullTerminated: boolean;
  kind: 'DLC' | 'USRDIR' | 'SYSDIR' | 'MS0' | 'OTHER';
}

export interface IsoAlignmentCheck {
  logicalBlockSize: number;
  isBlockSize2048: boolean;
  totalSizeBytes: number;
  isSizeMultipleOf2048: boolean;
  pvdDeclaredBytes: number;
  pvdMatchesFileSize: boolean;
  unalignedFilesCount: number;
  notes: string[];
}

export interface MipsLimitCandidate {
  index: number;
  fileOffset: number;
  ramAddress: number;
  mnemonic: string;
  immediate: number;
  immediateHex: string;
  likelyRole: 'PERSONAJES' | 'MAPAS' | 'OTRO_LIMITE';
  suggestion: string;
}

export interface SequentialSlotAudit {
  fileName: string;
  path: string;
  idNumber: number;
  sizeBytes: number;
  status: 'OK' | 'MISSING' | 'EMPTY_STUB';
  subSlotsPopulated?: number;
  subSlotsTotal?: number;
  detail: string;
}

export interface DlcContainerAudit {
  fileName: string;
  path: string;
  sizeBytes: number;
  hasDlcMagic: boolean;
  declaredEntries: number;
  populatedEntries: number;
  emptyStubEntries: number;
  detail: string;
}

export interface DlcAuditResult {
  hasDlcFolder: boolean;
  totalDlcFiles: number;
  totalDlcBytes: number;
  sequentialChars: SequentialSlotAudit[];
  missingCharWarnings: string[];
  sequentialMaps: SequentialSlotAudit[];
  missingMapWarnings: string[];
  sequentialBgm: SequentialSlotAudit[];
  containers: DlcContainerAudit[];
}

export interface ModVerificationSuite {
  disc0Paths: Disc0PathCheck[];
  isoAlignment: IsoAlignmentCheck | null;
  mipsLimits: MipsLimitCandidate[];
  dlcAudit: DlcAuditResult | null;
}

function mapFileOffsetToRam(offset: number, analysis: EbootAnalysis): number {
  for (const sec of analysis.sections) {
    if (sec.size > 0 && sec.offset > 0 && offset >= sec.offset && offset < sec.offset + sec.size) {
      const base = sec.vaddr > 0 ? sec.vaddr : analysis.baseRamAddress + sec.offset;
      return base + (offset - sec.offset);
    }
  }
  for (const seg of analysis.segments) {
    if (seg.filesz > 0 && offset >= seg.offset && offset < seg.offset + seg.filesz) {
      return seg.vaddr + (offset - seg.offset);
    }
  }
  return analysis.baseRamAddress + offset;
}

export function verifyDisc0Paths(analysis: EbootAnalysis): Disc0PathCheck[] {
  const bytes = analysis.rawBytes;
  const results: Disc0PathCheck[] = [];
  const limit = Math.min(bytes.length, 8 * 1024 * 1024);
  let idx = 1;

  for (let i = 0; i < limit - 6; i++) {
    // Match "disc0:" or "ms0:/"
    const isDisc0 =
      bytes[i] === 0x64 &&
      bytes[i + 1] === 0x69 &&
      bytes[i + 2] === 0x73 &&
      bytes[i + 3] === 0x63 &&
      bytes[i + 4] === 0x30 &&
      bytes[i + 5] === 0x3a;
    const isMs0 =
      bytes[i] === 0x6d &&
      bytes[i + 1] === 0x73 &&
      bytes[i + 2] === 0x30 &&
      bytes[i + 3] === 0x3a &&
      bytes[i + 4] === 0x2f;

    if (!isDisc0 && !isMs0) continue;

    // Only capture start of path (avoid sub-matches)
    if (i > 0 && bytes[i - 1] >= 33 && bytes[i - 1] <= 126 && bytes[i - 1] !== 0x22 && bytes[i - 1] !== 0x3d) {
      continue;
    }

    let end = i;
    while (end < limit && end - i < 256 && bytes[end] >= 32 && bytes[end] <= 126) {
      end++;
    }
    const pathStr = new TextDecoder('ascii', { fatal: false }).decode(bytes.subarray(i, end));
    const nullTerminated = end < bytes.length && bytes[end] === 0x00;

    let kind: Disc0PathCheck['kind'] = 'OTHER';
    const upper = pathStr.toUpperCase();
    if (upper.startsWith('MS0:/')) kind = 'MS0';
    else if (upper.includes('/DLC/')) kind = 'DLC';
    else if (upper.includes('/USRDIR/')) kind = 'USRDIR';
    else if (upper.includes('/SYSDIR/')) kind = 'SYSDIR';

    results.push({
      index: idx++,
      path: pathStr,
      fileOffset: i,
      ramAddress: mapFileOffsetToRam(i, analysis),
      nullTerminated,
      kind,
    });

    i = end;
  }

  return results;
}

export function validateIsoLbaAlignment(isoInfo: IsoInspectionResult): IsoAlignmentCheck {
  const { volume, files } = isoInfo;
  const isBlockSize2048 = volume.logicalBlockSize === 2048;
  const isSizeMultipleOf2048 = volume.totalSizeBytes % 2048 === 0;
  const pvdDeclaredBytes = volume.volumeSpaceBlocks * volume.logicalBlockSize;
  const pvdMatchesFileSize = Math.abs(pvdDeclaredBytes - volume.totalSizeBytes) <= 2048;

  let unalignedFilesCount = 0;
  for (const f of files) {
    if (!f.isDirectory && f.byteOffset % 2048 !== 0) {
      unalignedFilesCount++;
    }
  }

  const notes: string[] = [];
  if (isBlockSize2048) notes.push('Sector lógico PVD correcto: 2048 bytes.');
  else notes.push(`Advertencia: tamaño de bloque lógico inusual (${volume.logicalBlockSize} B).`);

  if (isSizeMultipleOf2048) notes.push('Tamaño total del archivo ISO alineado a múltiplos de 2048 bytes.');
  else notes.push('Advertencia: el archivo .ISO no es múltiplo exacto de 2048 bytes.');

  if (pvdMatchesFileSize) notes.push('Los sectores declarados en el PVD coinciden con el tamaño real de la ISO.');
  else {
    notes.push(
      `Diferencia entre sectores PVD (${pvdDeclaredBytes.toLocaleString('es-ES')} B) y tamaño real (${volume.totalSizeBytes.toLocaleString('es-ES')} B).`
    );
  }

  return {
    logicalBlockSize: volume.logicalBlockSize,
    isBlockSize2048,
    totalSizeBytes: volume.totalSizeBytes,
    isSizeMultipleOf2048,
    pvdDeclaredBytes,
    pvdMatchesFileSize,
    unalignedFilesCount,
    notes,
  };
}

const TARGET_LIMIT_IMMS = new Set([0x0a, 0x0b, 0x10, 0x2d, 0x2e, 0x46, 0x4c, 0x4d, 0xff, 0x100]);

export function scanMipsIdLimits(analysis: EbootAnalysis): MipsLimitCandidate[] {
  if (analysis.format !== 'ELF32' && analysis.format !== 'PBP') return [];
  const bytes = analysis.rawBytes;
  const textSec = analysis.sections.find((s) => s.name === '.text') ?? null;
  const codeStart = textSec ? textSec.offset : analysis.segments[0]?.offset ?? 0;
  const codeSize = textSec ? textSec.size : Math.min(bytes.length - codeStart, 1024 * 1024);
  const codeVaddr = textSec ? textSec.vaddr : analysis.segments[0]?.vaddr ?? analysis.baseRamAddress;

  if (codeSize < 4 || codeStart + codeSize > bytes.length) return [];

  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const out: MipsLimitCandidate[] = [];
  let idx = 1;

  const limit = Math.min(codeStart + codeSize, bytes.length - 4);
  for (let off = codeStart; off <= limit; off += 4) {
    const instr = view.getUint32(off, true);
    const opcode = instr >>> 26;
    if (opcode !== 0x0b && opcode !== 0x0a) continue; // sltiu (0x0B) / slti (0x0A)

    const rs = (instr >>> 21) & 0x1f;
    const rt = (instr >>> 16) & 0x1f;
    const imm = instr & 0xffff;
    if (!TARGET_LIMIT_IMMS.has(imm)) continue;

    const opName = opcode === 0x0b ? 'sltiu' : 'slti';
    const mnemonic = `${opName} ${MIPS_REGS[rt]}, ${MIPS_REGS[rs]}, 0x${imm.toString(16).toUpperCase()}`;
    const vaddr = codeVaddr + (off - codeStart);

    let likelyRole: MipsLimitCandidate['likelyRole'] = 'OTRO_LIMITE';
    let suggestion = 'Comparación de rango en .text; verifica el contexto antes de modificar.';

    if (imm === 0x46 || imm === 0x4c || imm === 0x4d) {
      likelyRole = 'PERSONAJES';
      suggestion = `Posible tope de personajes base (${imm}). Cambiar byte inmediato a 0xFF habilita hasta 256 slots.`;
    } else if (imm === 0xff || imm === 0x100) {
      likelyRole = 'PERSONAJES';
      suggestion = `Límite ampliado detectado (0x${imm.toString(16).toUpperCase()} = ${imm} slots).`;
    } else if (imm === 0x0a || imm === 0x10) {
      likelyRole = 'MAPAS';
      suggestion = `Posible tope de mapas base (${imm}). Cambiar a 0x2E (46) o 0x2D (45) habilita los 46 escenarios.`;
    } else if (imm === 0x2d || imm === 0x2e) {
      likelyRole = 'MAPAS';
      suggestion = `Límite ampliado de mapas detectado (0x${imm.toString(16).toUpperCase()} = ${imm}).`;
    }

    out.push({
      index: idx++,
      fileOffset: off,
      ramAddress: vaddr,
      mnemonic,
      immediate: imm,
      immediateHex: `0x${imm.toString(16).toUpperCase().padStart(2, '0')}`,
      likelyRole,
      suggestion,
    });

    if (out.length >= 200) break;
  }

  return out;
}

export async function auditDlcFolder(
  isoInfo: IsoInspectionResult,
  isoBlob: Blob | null
): Promise<DlcAuditResult> {
  const dlcFiles = isoInfo.files.filter(
    (f) => !f.isDirectory && f.path.toUpperCase().startsWith('/PSP_GAME/DLC/')
  );

  const totalDlcBytes = dlcFiles.reduce((acc, f) => acc + f.size, 0);
  const sequentialChars: SequentialSlotAudit[] = [];
  const sequentialMaps: SequentialSlotAudit[] = [];
  const sequentialBgm: SequentialSlotAudit[] = [];
  const containers: DlcContainerAudit[] = [];

  for (const f of dlcFiles) {
    const upper = f.name.toUpperCase();

    // 1. Indexed Containers (CHAR256.BIN, CHAR77.BIN, MAPS46.BIN, MAPS11.BIN, BGMEXP.BIN)
    if (/^(CHAR(256|77)|MAPS(46|11)|BGMEXP)\.BIN$/.test(upper)) {
      let hasDlcMagic = false;
      let declaredEntries = 0;
      let populatedEntries = 0;
      let emptyStubEntries = 0;

      if (isoBlob && f.size >= 8) {
        const hdr = await extractIsoFileBytes(isoBlob, { ...f, size: Math.min(f.size, 65536) });
        const dv = new DataView(hdr.buffer, hdr.byteOffset, hdr.byteLength);
        if (hdr[0] === 0x44 && hdr[1] === 0x4c && hdr[2] === 0x43 && hdr[3] === 0x00) {
          hasDlcMagic = true;
          declaredEntries = dv.getUint32(4, true);
          const maxCheck = Math.min(declaredEntries, Math.floor((hdr.length - 8) / 8));
          for (let i = 0; i < maxCheck; i++) {
            const sz = dv.getUint32(8 + i * 8 + 4, true);
            if (sz > 16) populatedEntries++;
            else emptyStubEntries++;
          }
        }
      }

      containers.push({
        fileName: f.name,
        path: f.path,
        sizeBytes: f.size,
        hasDlcMagic,
        declaredEntries,
        populatedEntries,
        emptyStubEntries,
        detail: hasDlcMagic
          ? `Cabecera DLC\\0 válida · ${declaredEntries} entradas (${populatedEntries} con datos, ${emptyStubEntries} stubs vacíos).`
          : 'Sin firma DLC\\0 en los primeros 4 bytes.',
      });
      continue;
    }

    // 2. Sequential Characters: CHAR077.BIN .. CHAR256.BIN
    const charMatch = upper.match(/^CHAR(\d{2,3})\.BIN$/);
    if (charMatch) {
      const idNumber = parseInt(charMatch[1], 10);
      let subPopulated = 0;
      if (isoBlob && f.size >= 64) {
        const hdr = await extractIsoFileBytes(isoBlob, { ...f, size: 64 });
        const dv = new DataView(hdr.buffer, hdr.byteOffset, hdr.byteLength);
        for (let c = 0; c < 8; c++) {
          const sz = dv.getUint32(c * 8 + 4, true);
          if (sz > 16) subPopulated++;
        }
      }
      sequentialChars.push({
        fileName: f.name,
        path: f.path,
        idNumber,
        sizeBytes: f.size,
        status: f.size <= 64 ? 'EMPTY_STUB' : 'OK',
        subSlotsPopulated: subPopulated,
        subSlotsTotal: 8,
        detail:
          f.size <= 64
            ? 'Slot sin datos de colores.'
            : `${subPopulated}/8 colores con datos en cabecera de 64 B.`,
      });
      continue;
    }

    // 3. Sequential Maps: MAPS11.BIN .. MAPS46.BIN
    const mapMatch = upper.match(/^MAPS(\d{2,3})\.BIN$/);
    if (mapMatch) {
      const idNumber = parseInt(mapMatch[1], 10);
      let hasBoth = false;
      if (isoBlob && f.size >= 16) {
        const hdr = await extractIsoFileBytes(isoBlob, { ...f, size: 16 });
        const dv = new DataView(hdr.buffer, hdr.byteOffset, hdr.byteLength);
        const mapSz = dv.getUint32(4, true);
        const miniSz = dv.getUint32(12, true);
        hasBoth = mapSz > 16 && miniSz > 16;
      }
      sequentialMaps.push({
        fileName: f.name,
        path: f.path,
        idNumber,
        sizeBytes: f.size,
        status: f.size <= 16 ? 'EMPTY_STUB' : 'OK',
        subSlotsPopulated: hasBoth ? 2 : 1,
        subSlotsTotal: 2,
        detail: hasBoth
          ? 'Cabecera 16 B válida (Mapa 3D + Minimapa .TM2 presentes).'
          : 'Revisar cabecera 16 B (Mapa 3D / Minimapa).',
      });
      continue;
    }

    // 4. Sequential BGM: BGM001.AT3+
    const bgmMatch = upper.match(/^BGM(\d{2,4})\.(AT3|OMA|WAV)$/);
    if (bgmMatch) {
      const idNumber = parseInt(bgmMatch[1], 10);
      sequentialBgm.push({
        fileName: f.name,
        path: f.path,
        idNumber,
        sizeBytes: f.size,
        status: f.size > 0 ? 'OK' : 'EMPTY_STUB',
        detail: `Pista de audio streaming (${(f.size / 1024).toFixed(1)} KB).`,
      });
    }
  }

  // Detect missing sequence gaps for Characters & Maps
  sequentialChars.sort((a, b) => a.idNumber - b.idNumber);
  const missingCharWarnings: string[] = [];
  if (sequentialChars.length > 0) {
    const presentSet = new Set(sequentialChars.map((c) => c.idNumber));
    const minId = Math.min(77, sequentialChars[0].idNumber);
    const maxId = sequentialChars[sequentialChars.length - 1].idNumber;
    for (let id = minId; id <= maxId; id++) {
      if (!presentSet.has(id)) {
        const name = `CHAR${String(id).padStart(3, '0')}.BIN`;
        missingCharWarnings.push(
          `Advertencia: Falta ${name}; seleccionar el slot ${id} provocará pantalla negra si el EBOOT apunta a la secuencia continua.`
        );
        sequentialChars.push({
          fileName: name,
          path: `/PSP_GAME/DLC/${name}`,
          idNumber: id,
          sizeBytes: 0,
          status: 'MISSING',
          detail: 'Archivo faltante en la secuencia.',
        });
      }
    }
    sequentialChars.sort((a, b) => a.idNumber - b.idNumber);
  }

  sequentialMaps.sort((a, b) => a.idNumber - b.idNumber);
  const missingMapWarnings: string[] = [];
  if (sequentialMaps.length > 0) {
    const presentSet = new Set(sequentialMaps.map((m) => m.idNumber));
    const minId = Math.min(11, sequentialMaps[0].idNumber);
    const maxId = sequentialMaps[sequentialMaps.length - 1].idNumber;
    for (let id = minId; id <= maxId; id++) {
      if (!presentSet.has(id)) {
        const name = `MAPS${String(id).padStart(2, '0')}.BIN`;
        missingMapWarnings.push(
          `Advertencia: Falta ${name}; seleccionar el mapa ${id} causará fallo de carga.`
        );
        sequentialMaps.push({
          fileName: name,
          path: `/PSP_GAME/DLC/${name}`,
          idNumber: id,
          sizeBytes: 0,
          status: 'MISSING',
          detail: 'Archivo faltante en la secuencia.',
        });
      }
    }
    sequentialMaps.sort((a, b) => a.idNumber - b.idNumber);
  }

  sequentialBgm.sort((a, b) => a.idNumber - b.idNumber);

  return {
    hasDlcFolder: dlcFiles.length > 0,
    totalDlcFiles: dlcFiles.length,
    totalDlcBytes,
    sequentialChars,
    missingCharWarnings,
    sequentialMaps,
    missingMapWarnings,
    sequentialBgm,
    containers,
  };
}

export async function runModVerificationSuite(
  analysis: EbootAnalysis,
  isoBlob: Blob | null
): Promise<ModVerificationSuite> {
  const disc0Paths = verifyDisc0Paths(analysis);
  const isoAlignment = analysis.isoInfo ? validateIsoLbaAlignment(analysis.isoInfo) : null;
  const mipsLimits = scanMipsIdLimits(analysis);
  const dlcAudit = analysis.isoInfo ? await auditDlcFolder(analysis.isoInfo, isoBlob) : null;

  return {
    disc0Paths,
    isoAlignment,
    mipsLimits,
    dlcAudit,
  };
}
