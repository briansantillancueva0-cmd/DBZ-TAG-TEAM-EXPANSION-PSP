import type { GameAssetCategory } from './types';

export interface PackEmbeddedEntry {
  index: number;
  offset: number;
  estimatedSize: number;
  signature: string;
  extension: string;
  category: GameAssetCategory | 'ARCHIVE' | 'EXECUTABLE' | 'TEXT_DATA';
  categoryLabel: string;
  label: string;
  sourceMethod: 'TOC_AFS' | 'TOC_PTR' | 'MAGIC_SCAN' | 'NAME_TABLE';
}

export interface PackScanResult {
  packName: string;
  totalBytes: number;
  containerType: string;
  entries: PackEmbeddedEntry[];
  categoryCounts: Record<GameAssetCategory, number>;
  textHintsCount: number;
}

interface MagicRule {
  bytes: number[];
  signature: string;
  extension: string;
  category: PackEmbeddedEntry['category'];
  categoryLabel: string;
  defaultLabel: string;
}

const MAGIC_RULES: MagicRule[] = [
  {
    bytes: [0x4f, 0x4d, 0x47, 0x2e, 0x30, 0x30, 0x2e, 0x31], // OMG.00.1
    signature: 'OMG.00.1PSP',
    extension: 'GMO',
    category: 'CHARACTERS',
    categoryLabel: 'Personajes y Modelos 3D',
    defaultLabel: 'Modelo 3D Sony GMO',
  },
  {
    bytes: [0x4d, 0x49, 0x47, 0x2e, 0x30, 0x30, 0x2e, 0x31], // MIG.00.1
    signature: 'MIG.00.1PSP',
    extension: 'GIM',
    category: 'TEXTURES',
    categoryLabel: 'Texturas y Sprites',
    defaultLabel: 'Textura Sony GIM',
  },
  {
    bytes: [0x54, 0x49, 0x4d, 0x32], // TIM2
    signature: 'TIM2',
    extension: 'TM2',
    category: 'TEXTURES',
    categoryLabel: 'Texturas y Sprites',
    defaultLabel: 'Textura PlayStation TIM2',
  },
  {
    bytes: [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a], // PNG
    signature: 'PNG',
    extension: 'PNG',
    category: 'TEXTURES',
    categoryLabel: 'Texturas y Sprites',
    defaultLabel: 'Imagen / Atlas PNG',
  },
  {
    bytes: [0x52, 0x49, 0x46, 0x46], // RIFF
    signature: 'RIFF (AT3/WAV)',
    extension: 'AT3',
    category: 'MUSIC',
    categoryLabel: 'Música, Voces y Audio',
    defaultLabel: 'Audio RIFF / ATRAC3+',
  },
  {
    bytes: [0x56, 0x41, 0x47, 0x70], // VAGp
    signature: 'VAGp',
    extension: 'VAG',
    category: 'MUSIC',
    categoryLabel: 'Música, Voces y Audio',
    defaultLabel: 'Audio ADPCM Sony VAG',
  },
  {
    bytes: [0x50, 0x53, 0x4d, 0x46], // PSMF
    signature: 'PSMF',
    extension: 'PMF',
    category: 'MUSIC',
    categoryLabel: 'Música, Voces y Audio',
    defaultLabel: 'Cinemática PSP PMF',
  },
  {
    bytes: [0x41, 0x46, 0x53, 0x00], // AFS\0
    signature: 'AFS\\0',
    extension: 'AFS',
    category: 'ARCHIVE',
    categoryLabel: 'Sub-contenedor',
    defaultLabel: 'Archivo CRI AFS incrustado',
  },
  {
    bytes: [0x7e, 0x50, 0x53, 0x50], // ~PSP
    signature: '~PSP',
    extension: 'PRX',
    category: 'EXECUTABLE',
    categoryLabel: 'Módulo / Ejecutable',
    defaultLabel: 'Módulo PRX firmado',
  },
  {
    bytes: [0x7f, 0x45, 0x4c, 0x46], // \x7FELF
    signature: 'ELF32',
    extension: 'ELF',
    category: 'EXECUTABLE',
    categoryLabel: 'Módulo / Ejecutable',
    defaultLabel: 'Binario ELF incrustado',
  },
  {
    bytes: [0x43, 0x50, 0x4b, 0x20], // CPK 
    signature: 'CPK',
    extension: 'CPK',
    category: 'ARCHIVE',
    categoryLabel: 'Sub-contenedor',
    defaultLabel: 'Contenedor CRI CPK',
  },
  {
    bytes: [0x44, 0x4c, 0x43, 0x00], // DLC\0
    signature: 'DLC\\0',
    extension: 'BIN',
    category: 'ARCHIVE',
    categoryLabel: 'Sub-contenedor',
    defaultLabel: 'Paquete DLC indexado',
  },
  {
    bytes: [0x50, 0x43, 0x4b, 0x31], // PCK1
    signature: 'PCK1',
    extension: 'PCK',
    category: 'ARCHIVE',
    categoryLabel: 'Sub-contenedor PCK1',
    defaultLabel: 'Paquete PCK1 (descomprimible en subcarpetas)',
  },
];

function classifyNameHint(name: string): { category: PackEmbeddedEntry['category']; label: string } {
  const l = name.toLowerCase();
  if (/(minimap|mini_map|mmap|radar|compass|automap)/.test(l)) {
    return { category: 'MINIMAPS', label: 'Minimapas y Radar HUD' };
  }
  if (/\.(at3|vag|adx|pmf|bgm|wav|mp3|ogg)/.test(l) || /(bgm|music|voice|sound|audio|sfx)/.test(l)) {
    return { category: 'MUSIC', label: 'Música, Voces y Audio' };
  }
  if (/\.(gmo|pmo|p3d|mot|anm|mdl)/.test(l) || /(chara|char|hero|enemy|boss|player|model)/.test(l)) {
    return { category: 'CHARACTERS', label: 'Personajes y Modelos 3D' };
  }
  if (/\.(map|stg|fld|col|nav|lvl)/.test(l) || /(map|stage|field|dungeon|arena|zone)/.test(l)) {
    return { category: 'MAPS', label: 'Mapas y Escenarios' };
  }
  if (/\.(gim|tm2|tim|png|tex|txd|pgf)/.test(l) || /(tex|ui|hud|font|sprite|atlas)/.test(l)) {
    return { category: 'TEXTURES', label: 'Texturas y Sprites' };
  }
  return { category: 'TEXT_DATA', label: 'Referencia / Recurso' };
}

function matchMagicAt(buf: Uint8Array, pos: number): MagicRule | null {
  for (const rule of MAGIC_RULES) {
    if (pos + rule.bytes.length > buf.length) continue;
    let ok = true;
    for (let j = 0; j < rule.bytes.length; j++) {
      if (buf[pos + j] !== rule.bytes[j]) {
        ok = false;
        break;
      }
    }
    if (ok) {
      // Extra validation for RIFF: bytes 8..11 should be WAVE or Atrac
      if (rule.signature.startsWith('RIFF') && pos + 12 <= buf.length) {
        const sub = String.fromCharCode(buf[pos + 8], buf[pos + 9], buf[pos + 10], buf[pos + 11]);
        if (!/^[A-Z0-9 ]{4}$/.test(sub)) return null;
      }
      return rule;
    }
  }
  return null;
}

export async function scanPackfileBlob(
  blob: Blob,
  packName: string,
  onProgress?: (pct: number) => void
): Promise<PackScanResult> {
  const totalBytes = blob.size;
  const entries: PackEmbeddedEntry[] = [];
  let containerType = 'PACKFILE Genérico (Escaneo por firmas + tabla de nombres)';
  let idx = 1;

  // 1. Inspect header (first 256 KB) for AFS\0 TOC or embedded path tables
  const headerSliceLen = Math.min(totalBytes, 256 * 1024);
  const headBytes = new Uint8Array(await blob.slice(0, headerSliceLen).arrayBuffer());
  const headView = new DataView(headBytes.buffer, headBytes.byteOffset, headBytes.byteLength);

  if (
    headBytes.length >= 16 &&
    headBytes[0] === 0x41 &&
    headBytes[1] === 0x46 &&
    headBytes[2] === 0x53 &&
    headBytes[3] === 0x00
  ) {
    const fileCount = headView.getUint32(4, true);
    if (fileCount > 0 && fileCount < 20000 && 8 + fileCount * 8 <= headBytes.length) {
      containerType = `Contenedor CRI AFS (${fileCount} entradas en TOC)`;
      for (let i = 0; i < fileCount; i++) {
        const off = headView.getUint32(8 + i * 8, true);
        const sz = headView.getUint32(8 + i * 8 + 4, true);
        if (off > 0 && sz > 0 && off < totalBytes) {
          // Read 8 bytes at entry offset to identify format
          const probe = new Uint8Array(
            await blob.slice(off, Math.min(totalBytes, off + 12)).arrayBuffer()
          );
          const rule = matchMagicAt(probe, 0);
          entries.push({
            index: idx++,
            offset: off,
            estimatedSize: sz,
            signature: rule?.signature ?? 'BIN',
            extension: rule?.extension ?? 'BIN',
            category: rule?.category ?? 'TEXT_DATA',
            categoryLabel: rule?.categoryLabel ?? 'Entrada AFS',
            label: `${rule?.defaultLabel ?? 'Archivo AFS'} #${i + 1}`,
            sourceMethod: 'TOC_AFS',
          });
        }
      }
    }
  } else {
    // 1b. Try detecting generic PSP PACKFILE 32-bit pointer tables:
    // Case A: [count @ 0x00] followed by N increasing offsets (or [offset, size] pairs)
    // Case B: [magic @ 0x00, count @ 0x04] followed by increasing offsets or [offset, size] pairs
    const candidates: Array<{ countOff: number; tableOff: number; stride: 4 | 8 }> = [
      { countOff: 0, tableOff: 4, stride: 4 },
      { countOff: 0, tableOff: 4, stride: 8 },
      { countOff: 4, tableOff: 8, stride: 4 },
      { countOff: 4, tableOff: 8, stride: 8 },
      { countOff: 8, tableOff: 16, stride: 8 },
    ];

    for (const cand of candidates) {
      if (cand.countOff + 4 > headBytes.length) continue;
      const count = headView.getUint32(cand.countOff, true);
      if (count < 4 || count > 8192) continue;
      const needed = cand.tableOff + count * cand.stride;
      if (needed > headBytes.length) continue;

      let prevOff = -1;
      let valid = true;
      const parsedPairs: Array<{ off: number; sz: number }> = [];
      for (let i = 0; i < count; i++) {
        const pos = cand.tableOff + i * cand.stride;
        const off = headView.getUint32(pos, true);
        const sz = cand.stride === 8 ? headView.getUint32(pos + 4, true) : 0;
        if (off < needed || off >= totalBytes || off <= prevOff) {
          valid = false;
          break;
        }
        if (cand.stride === 8 && (sz === 0 || off + sz > totalBytes)) {
          valid = false;
          break;
        }
        prevOff = off;
        parsedPairs.push({ off, sz });
      }

      if (valid && parsedPairs.length >= 4) {
        containerType = `Tabla de Punteros PACKFILE (${parsedPairs.length} bloques indexados)`;
        for (let i = 0; i < parsedPairs.length; i++) {
          const cur = parsedPairs[i];
          const nextOff = i + 1 < parsedPairs.length ? parsedPairs[i + 1].off : totalBytes;
          const sz = cur.sz > 0 ? cur.sz : Math.max(16, nextOff - cur.off);
          const probe = new Uint8Array(
            await blob.slice(cur.off, Math.min(totalBytes, cur.off + 16)).arrayBuffer()
          );
          const rule = matchMagicAt(probe, 0);
          const isZlib = probe.length >= 2 && probe[0] === 0x78 && (probe[1] === 0x9c || probe[1] === 0xda || probe[1] === 0x01);

          entries.push({
            index: idx++,
            offset: cur.off,
            estimatedSize: sz,
            signature: rule?.signature ?? (isZlib ? 'ZLIB' : 'BIN'),
            extension: rule?.extension ?? (isZlib ? 'ZLIB' : 'BIN'),
            category: rule?.category ?? 'TEXT_DATA',
            categoryLabel: rule?.categoryLabel ?? (isZlib ? 'Bloque Comprimido Zlib' : 'Entrada PACKFILE'),
            label: `${rule?.defaultLabel ?? (isZlib ? 'Bloque Zlib (0x789C)' : 'Bloque indexado')} #${i + 1}`,
            sourceMethod: 'TOC_PTR',
          });
        }
        break;
      }
    }
  }

  // Scan header area for internal filename hints (e.g. hero_01.gmo, stage_01.map, minimap.gim)
  const nameMatches = new Set<string>();
  let curStr = '';
  let strStart = -1;
  for (let i = 0; i < headBytes.length; i++) {
    const b = headBytes[i];
    if (b >= 32 && b <= 126) {
      if (strStart === -1) strStart = i;
      curStr += String.fromCharCode(b);
    } else {
      if (
        curStr.length >= 5 &&
        /\.(gmo|gim|tm2|tim|at3|vag|adx|pmf|map|stg|fld|png|pac|bin)$/i.test(curStr) &&
        !nameMatches.has(curStr)
      ) {
        nameMatches.add(curStr);
        const cls = classifyNameHint(curStr);
        entries.push({
          index: idx++,
          offset: strStart,
          estimatedSize: curStr.length,
          signature: 'PATH_HDR',
          extension: curStr.split('.').pop()?.toUpperCase() || 'STR',
          category: cls.category,
          categoryLabel: cls.label,
          label: curStr,
          sourceMethod: 'NAME_TABLE',
        });
      }
      curStr = '';
      strStart = -1;
    }
  }

  // 2. Streaming Chunk Magic Carving across the entire PACKFILE.BIN (up to 1 GB safely)
  const CHUNK_SIZE = 2 * 1024 * 1024;
  const OVERLAP = 16;
  const seenOffsets = new Set<number>();
  const carvedRaw: PackEmbeddedEntry[] = [];
  let textHintsCount = 0;

  // Check if Pack has a custom header magic
  if (headBytes.length >= 8 && containerType.startsWith('PACKFILE Genérico')) {
    const sig4 = String.fromCharCode(headBytes[0], headBytes[1], headBytes[2], headBytes[3]).replace(
      /[^\x20-\x7E]/g,
      '.'
    );
    containerType = `Contenedor PACKFILE (${sig4} · ${(totalBytes / 1024).toFixed(1)} KB)`;
  }

  for (let chunkStart = 0; chunkStart < totalBytes; chunkStart += CHUNK_SIZE) {
    const sliceEnd = Math.min(totalBytes, chunkStart + CHUNK_SIZE + OVERLAP);
    const chunk = new Uint8Array(await blob.slice(chunkStart, sliceEnd).arrayBuffer());
    const scanLimit = Math.min(chunk.length, CHUNK_SIZE);

    for (let i = 0; i < scanLimit; i += 4) {
      // Quick first-byte filter for performance (O, M, T, 0x89, R, V, P, A, ~, 0x7F)
      const b0 = chunk[i];
      if (
        b0 !== 0x4f &&
        b0 !== 0x4d &&
        b0 !== 0x54 &&
        b0 !== 0x89 &&
        b0 !== 0x52 &&
        b0 !== 0x56 &&
        b0 !== 0x50 &&
        b0 !== 0x41 &&
        b0 !== 0x7e &&
        b0 !== 0x7f
      ) {
        continue;
      }

      const absOffset = chunkStart + i;
      if (seenOffsets.has(absOffset)) continue;

      const rule = matchMagicAt(chunk, i);
      if (rule) {
        seenOffsets.add(absOffset);

        // Peek nearby strings (up to 48 bytes around header) to check if it's a Minimap or Map
        let cat = rule.category;
        let catLabel = rule.categoryLabel;
        let label = rule.defaultLabel;

        if (i + 32 < chunk.length) {
          const peek = new TextDecoder('ascii', { fatal: false })
            .decode(chunk.subarray(i, Math.min(chunk.length, i + 64)))
            .toLowerCase();
          if (/(minimap|radar|mmap|compass)/.test(peek)) {
            cat = 'MINIMAPS';
            catLabel = 'Minimapas y Radar HUD';
            label = `${rule.defaultLabel} (Minimap/Radar)`;
          } else if (/(map|stage|field|level|arena)/.test(peek)) {
            cat = 'MAPS';
            catLabel = 'Mapas y Escenarios';
            label = `${rule.defaultLabel} (Mapa/Escenario)`;
          }
        }

        // Read RIFF exact chunk size if RIFF
        let estSize = 0;
        if (rule.signature.startsWith('RIFF') && i + 8 <= chunk.length) {
          const dv = new DataView(chunk.buffer, chunk.byteOffset, chunk.byteLength);
          const riffSize = dv.getUint32(i + 4, true) + 8;
          if (riffSize > 16 && absOffset + riffSize <= totalBytes) {
            estSize = riffSize;
          }
        }

        carvedRaw.push({
          index: 0,
          offset: absOffset,
          estimatedSize: estSize,
          signature: rule.signature,
          extension: rule.extension,
          category: cat,
          categoryLabel: catLabel,
          label,
          sourceMethod: 'MAGIC_SCAN',
        });

        if (carvedRaw.length >= 1500) break;
      }
    }

    // Count non-ASCII UTF-8/Shift-JIS/Spanish text runs in chunk for quick diagnostics
    let run = 0;
    for (let k = 0; k < Math.min(scanLimit, 65536); k++) {
      const b = chunk[k];
      if ((b >= 32 && b <= 126) || b >= 0xa1) run++;
      else {
        if (run >= 12) textHintsCount++;
        run = 0;
      }
    }

    if (onProgress) {
      onProgress(Math.min(100, Math.round(((chunkStart + CHUNK_SIZE) / totalBytes) * 100)));
    }
    if (carvedRaw.length >= 1500) break;
  }

  // Estimate sizes between consecutive carved entries if not already known
  carvedRaw.sort((a, b) => a.offset - b.offset);
  for (let i = 0; i < carvedRaw.length; i++) {
    const cur = carvedRaw[i];
    if (cur.estimatedSize <= 0) {
      const nextOff = i + 1 < carvedRaw.length ? carvedRaw[i + 1].offset : totalBytes;
      cur.estimatedSize = Math.max(64, Math.min(nextOff - cur.offset, 16 * 1024 * 1024));
    }
    cur.index = idx++;
    entries.push(cur);
  }

  const categoryCounts: Record<GameAssetCategory, number> = {
    CHARACTERS: 0,
    MAPS: 0,
    TEXTURES: 0,
    MUSIC: 0,
    MINIMAPS: 0,
  };
  for (const e of entries) {
    if (
      e.category === 'CHARACTERS' ||
      e.category === 'MAPS' ||
      e.category === 'TEXTURES' ||
      e.category === 'MUSIC' ||
      e.category === 'MINIMAPS'
    ) {
      categoryCounts[e.category]++;
    }
  }

  return {
    packName,
    totalBytes,
    containerType,
    entries,
    categoryCounts,
    textHintsCount,
  };
}

export function formatPackScanText(scan: PackScanResult): string {
  const lines: string[] = [];
  lines.push('========================================================================');
  lines.push('              ÍNDICE DE CONTENIDOS DE PACKFILE.BIN (PSP)                ');
  lines.push('========================================================================');
  lines.push(`Contenedor      : ${scan.packName}`);
  lines.push(`Tipo detectado  : ${scan.containerType}`);
  lines.push(`Tamaño total    : ${scan.totalBytes.toLocaleString('es-ES')} bytes`);
  lines.push(`Entradas totales: ${scan.entries.length}`);
  lines.push(
    `Resumen         : Personajes ${scan.categoryCounts.CHARACTERS} | Mapas ${scan.categoryCounts.MAPS} | Texturas ${scan.categoryCounts.TEXTURES} | Música ${scan.categoryCounts.MUSIC} | Minimapas ${scan.categoryCounts.MINIMAPS}`
  );
  lines.push('');
  scan.entries.forEach((e) => {
    const offHex = `0x${(e.offset >>> 0).toString(16).toUpperCase().padStart(8, '0')}`;
    lines.push(
      `#${String(e.index).padStart(4, '0')} | ${e.sourceMethod.padEnd(10)} | ${e.signature.padEnd(14)} | Off: ${offHex} | ${String(e.estimatedSize).padStart(10)} B | ${e.categoryLabel.padEnd(24)} | ${e.label}`
    );
  });
  return lines.join('\n');
}

export function formatPackScanCsv(scan: PackScanResult): string {
  const rows = ['Indice,Metodo,Firma,Extension,Offset,TamanoBytes,Categoria,Detalle'];
  const esc = (s: string) => `"${s.replace(/"/g, '""')}"`;
  for (const e of scan.entries) {
    const offHex = `0x${(e.offset >>> 0).toString(16).toUpperCase().padStart(8, '0')}`;
    rows.push(
      [
        e.index,
        e.sourceMethod,
        esc(e.signature),
        e.extension,
        offHex,
        e.estimatedSize,
        esc(e.categoryLabel),
        esc(e.label),
      ].join(',')
    );
  }
  return rows.join('\n');
}

