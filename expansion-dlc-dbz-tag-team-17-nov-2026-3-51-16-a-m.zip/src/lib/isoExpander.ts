import type { IsoFileEntry, IsoInspectionResult } from './types';
import { buildZipBlob, type ZipInputEntry } from './zipBuilder';

export const STANDARD_MOD_DLC_SUBFOLDERS = [
  '/PSP_GAME/MOD',
  '/PSP_GAME/MOD/DLC',
  '/PSP_GAME/MOD/DLC/PERSONAJES',
  '/PSP_GAME/MOD/DLC/MAPAS',
  '/PSP_GAME/MOD/DLC/MINIMAPAS',
  '/PSP_GAME/MOD/DLC/MUSICA_AT3',
  '/PSP_GAME/MOD/DLC/OBJ',
  '/PSP_GAME/MOD/DLC/LOBBY',
  '/PSP_GAME/MOD/DLC/CASILLAS_ROSTER',
  '/PSP_GAME/MOD/DLC/BARRA_DE_VIDA',
  '/PSP_GAME/MOD/DLC/VIDEOS_PMF',
] as const;

export const PMF_FFMPEG_COMMAND =
  'ffmpeg -i intro_dlc.mp4 -vf "scale=480:272,fps=30000/1001" -c:v libx264 -profile:v main -level 2.1 -pix_fmt yuv420p -b:v 1500k -an intro_video.264 && ffmpeg -i intro_dlc.mp4 -vn -c:a pcm_s16le -ar 48000 -ac 2 intro_audio.wav';

export function validatePmfVideoBytes(
  data: Uint8Array,
  fileName: string
): { isPmf: boolean; version?: string; warning?: string } {
  const lower = fileName.toLowerCase();
  if (data.length >= 8) {
    const magic =
      String.fromCharCode(data[0], data[1], data[2], data[3]);
    if (magic === 'PSMF') {
      const ver = String.fromCharCode(data[4], data[5], data[6], data[7]).replace(/[^\x20-\x7E]/g, '');
      return { isPmf: true, version: ver || '0014' };
    }
  }
  if (/\.(mp4|avi|mkv|mov|webm)$/i.test(lower)) {
    return {
      isPmf: false,
      warning:
        'Archivo en formato PC (.mp4/.avi/.mkv). El chip sceMpeg de PSP solo reproduce .PMF (PSMF0014, 480×272 H.264 Main L2.1 @ 29.97fps + ATRAC3+). Convierte con FFmpeg + UmdStreamComposer para streaming sin saturar la RAM.',
    };
  }
  if (lower.endsWith('.pmf')) {
    return {
      isPmf: false,
      warning:
        'Extensión .pmf sin cabecera PSMF válida en los primeros 4 bytes; verifica que haya sido empaquetado con UmdStreamComposer / MPS to PMF.',
    };
  }
  return { isPmf: false };
}

const SECTOR_SIZE = 2048;
const PSP_UMD_MAX_SECTORS = 921600; // ~1.8 GB Single-Layer UMD (1,887,436,800 B)
const FAT32_MAX_SECTORS = 2097151; // ~4.0 GB ISO32 / Memory Stick FAT32 limit

export interface IsoPermissionCheckItem {
  id: string;
  title: string;
  status: 'OK' | 'WARN' | 'BLOCKED';
  detail: string;
}

export interface IsoExpansionCheckResult {
  canExpand: boolean;
  needsTableRebuild: boolean;
  verdictTitle: string;
  verdictSummary: string;
  currentSectors: number;
  currentSizeBytes: number;
  umdRemainingBytes: number;
  currentMaxDepth: number;
  pspGameDirFreeBytes: number;
  hasDlcDir: boolean;
  browserRebuildRecommended: boolean;
  checks: IsoPermissionCheckItem[];
}

export interface InjectedIsoFileInput {
  path: string; // e.g. "/PSP_GAME/DLC/MUSICA_AT3/THEME_01.AT3"
  data: Uint8Array;
}

export interface ExpandedIsoBuildResult {
  isoBlob: Blob;
  totalSectors: number;
  totalBytes: number;
  totalFiles: number;
  totalDirs: number;
  createdSubfolders: string[];
}

function normalizeIsoSegment(raw: string, isDir: boolean): string {
  const clean = raw
    .trim()
    .toUpperCase()
    .replace(/;1$/i, '')
    .replace(/[^A-Z0-9._-]/g, '_');
  if (isDir) {
    return clean.slice(0, 31) || 'SUBDIR';
  }
  return clean.slice(0, 31) || 'FILE.BIN';
}

export function normalizeIsoTargetPath(rawPath: string): string {
  const parts = rawPath
    .replace(/\\/g, '/')
    .split('/')
    .map((p) => p.trim())
    .filter(Boolean);
  if (parts.length === 0) return '/PSP_GAME/DLC/ARCHIVO.BIN';
  const normalized = parts.map((seg, idx) => normalizeIsoSegment(seg, idx < parts.length - 1));
  return '/' + normalized.join('/');
}

async function computeDirectorySectorFreeBytes(
  isoBlob: Blob | null,
  dirEntry: IsoFileEntry | undefined
): Promise<number> {
  if (!isoBlob || !dirEntry || dirEntry.size === 0) return 0;
  try {
    const readSize = Math.min(dirEntry.size, 64 * 1024);
    const bytes = new Uint8Array(
      await isoBlob.slice(dirEntry.byteOffset, dirEntry.byteOffset + readSize).arrayBuffer()
    );
    let pos = 0;
    let lastUsed = 0;
    while (pos < bytes.length) {
      const recLen = bytes[pos];
      if (recLen === 0) {
        const nextSec = Math.floor(pos / SECTOR_SIZE) * SECTOR_SIZE + SECTOR_SIZE;
        if (nextSec >= bytes.length) break;
        pos = nextSec;
        continue;
      }
      pos += recLen;
      lastUsed = pos;
    }
    const allocatedSectors = Math.max(1, Math.ceil(dirEntry.size / SECTOR_SIZE)) * SECTOR_SIZE;
    return Math.max(0, allocatedSectors - lastUsed);
  } catch {
    return 0;
  }
}

export async function checkIsoExpansionPermissions(
  isoInfo: IsoInspectionResult,
  isoBlob: Blob | null,
  plannedPaths: string[] = [...STANDARD_MOD_DLC_SUBFOLDERS],
  extraPayloadBytes = 0
): Promise<IsoExpansionCheckResult> {
  const checks: IsoPermissionCheckItem[] = [];
  const { volume, files } = isoInfo;

  const isBlock2048 = volume.logicalBlockSize === 2048;
  const currentSectors = Math.max(
    volume.volumeSpaceBlocks,
    Math.ceil(volume.totalSizeBytes / SECTOR_SIZE)
  );
  const currentSizeBytes = volume.totalSizeBytes;

  // 1. PVD & Logical Block check
  checks.push({
    id: 'pvd',
    title: 'Cabecera ISO 9660 (Sector 16 CD001 / Bloque 2048 B)',
    status: isBlock2048 ? 'OK' : 'BLOCKED',
    detail: isBlock2048
      ? `PVD válido detectado (${volume.volumeSpaceBlocks.toLocaleString('es-ES')} sectores de 2048 B).`
      : `Tamaño de bloque no estándar (${volume.logicalBlockSize} B); se esperan 2048 B.`,
  });

  // 2. ECMA-119 Directory depth check (max 8 levels)
  let currentMaxDepth = 0;
  for (const f of files) {
    const depth = f.path.split('/').filter(Boolean).length;
    if (depth > currentMaxDepth) currentMaxDepth = depth;
  }
  let plannedMaxDepth = currentMaxDepth;
  for (const p of plannedPaths) {
    const d = p.split('/').filter(Boolean).length;
    if (d > plannedMaxDepth) plannedMaxDepth = d;
  }
  const depthOk = plannedMaxDepth <= 8;
  checks.push({
    id: 'depth',
    title: 'Permiso de profundidad de subcarpetas ECMA-119 (máx. 8 niveles)',
    status: depthOk ? 'OK' : 'BLOCKED',
    detail: depthOk
      ? `Profundidad actual: ${currentMaxDepth}/8 · Con las nuevas subcarpetas: ${plannedMaxDepth}/8 niveles permitidos.`
      : `La ruta supera el máximo de 8 niveles ISO 9660 (${plannedMaxDepth}/8). Acorta la jerarquía.`,
  });

  // 3. Physical UMD / FAT32 capacity check
  const addedSectors = Math.ceil((extraPayloadBytes + plannedPaths.length * 4096) / SECTOR_SIZE);
  const projectedSectors = currentSectors + addedSectors;
  const umdRemainingBytes = Math.max(0, (PSP_UMD_MAX_SECTORS - projectedSectors) * SECTOR_SIZE);

  if (projectedSectors <= PSP_UMD_MAX_SECTORS) {
    checks.push({
      id: 'capacity',
      title: 'Capacidad física UMD PSP (límite 1.8 GB / 921,600 sectores)',
      status: 'OK',
      detail: `Espacio disponible dentro del estándar UMD: ${(umdRemainingBytes / (1024 * 1024)).toFixed(1)} MB libres tras expandir.`,
    });
  } else if (projectedSectors <= FAT32_MAX_SECTORS) {
    checks.push({
      id: 'capacity',
      title: 'Capacidad física UMD PSP (supera 1.8 GB, válido hasta 4 GB)',
      status: 'WARN',
      detail: `Supera el UMD físico de 1.8 GB (${(projectedSectors * 2048 / (1024 * 1024)).toFixed(1)} MB), pero sigue siendo válido en emulador PPSSPP o CFW en Memory Stick.`,
    });
  } else {
    checks.push({
      id: 'capacity',
      title: 'Límite máximo ISO 9660 / FAT32 (4 GB)',
      status: 'BLOCKED',
      detail: 'El tamaño proyectado supera el límite de 4 GB del formato ISO32 / FAT32 de PSP.',
    });
  }

  // 4. Directory sector room + Read-Only ISO permission model
  const pspGameDir = files.find((f) => f.isDirectory && f.path.toUpperCase() === '/PSP_GAME');
  const dlcDir = files.find((f) => f.isDirectory && f.path.toUpperCase() === '/PSP_GAME/DLC');
  const pspGameDirFreeBytes = await computeDirectorySectorFreeBytes(isoBlob, pspGameDir);

  checks.push({
    id: 'dir_table',
    title: 'Permisos de directorio ISO 9660 (Bandera 0x02 + Tabla L/M + PVD)',
    status: 'OK',
    detail: `La ISO es un volumen óptico de solo lectura: al agregar subcarpetas se asigna permiso estándar ISO (0x02 directorio / 0x00 archivo;1) y se reconstruyen los sectores LBA (${pspGameDirFreeBytes} B libres en el sector actual de PSP_GAME).`,
  });

  // 5. EBOOT / disc0:/ compatibility hint
  const modDir = files.find((f) => f.isDirectory && f.path.toUpperCase() === '/PSP_GAME/MOD');
  const hasDlcDir = Boolean(dlcDir || modDir);
  checks.push({
    id: 'psp_layout',
    title: 'Compatibilidad de rutas PSP (disc0:/PSP_GAME/MOD/DLC/...)',
    status: isoInfo.ebootEntry ? 'OK' : 'WARN',
    detail: isoInfo.ebootEntry
      ? `EBOOT.BIN presente en ${isoInfo.ebootEntry.path}. Las subcarpetas dentro de /PSP_GAME/MOD/DLC/ (Roster, Barra de Vida, Lobby, Personajes, Mapas, AT3) son accesibles vía disc0:/PSP_GAME/MOD/DLC/ y sustituyen los recursos originales.`
      : 'No se encontró EBOOT.BIN; la ISO seguirá siendo válida como volumen de datos.',
  });

  const hasBlocked = checks.some((c) => c.status === 'BLOCKED');
  const browserRebuildRecommended = Boolean(isoBlob && currentSizeBytes <= 450 * 1024 * 1024);

  return {
    canExpand: !hasBlocked,
    needsTableRebuild: true,
    verdictTitle: !hasBlocked
      ? 'ISO apta para expansión y creación de subcarpetas'
      : 'Expansión bloqueada por restricciones ISO 9660',
    verdictSummary: !hasBlocked
      ? browserRebuildRecommended
        ? 'Cumple las reglas ECMA-119 (profundidad, sector 2048 B y permisos 0x02/0x00). Puedes agregar subcarpetas y generar la nueva .ISO directamente aquí.'
        : 'La ISO es válida para expandir con subcarpetas, aunque por su gran tamaño (>450 MB) se recomienda generar la .ISO reconstruida mediante el script Python incluido o UMDGen para evitar límites de memoria del navegador.'
      : 'Corrige los elementos bloqueados (profundidad > 8 niveles o tamaño > 4 GB) antes de generar la nueva ISO.',
    currentSectors,
    currentSizeBytes,
    umdRemainingBytes,
    currentMaxDepth,
    pspGameDirFreeBytes,
    hasDlcDir,
    browserRebuildRecommended,
    checks,
  };
}

// =============================================================================
// ECMA-119 ISO 9660 WRITER (Browser Streaming BlobPart[] Builder)
// =============================================================================

interface DirNode {
  name: string;
  fullPath: string;
  childrenDirs: Map<string, DirNode>;
  childrenFiles: Map<string, { name: string; size: number; sliceSource: Blob | Uint8Array }>;
  parent: DirNode | null;
  pathTableIndex: number;
  lba: number;
  dirByteSize: number;
  dirSectorCount: number;
  sectorBuffer: Uint8Array;
}

function writeIsoDate7(buf: Uint8Array, off: number, now: Date) {
  buf[off] = Math.max(0, now.getFullYear() - 1900) & 0xff;
  buf[off + 1] = (now.getMonth() + 1) & 0xff;
  buf[off + 2] = now.getDate() & 0xff;
  buf[off + 3] = now.getHours() & 0xff;
  buf[off + 4] = now.getMinutes() & 0xff;
  buf[off + 5] = now.getSeconds() & 0xff;
  buf[off + 6] = 0; // GMT offset
}

function buildDirRecordBytes(
  nameBytes: Uint8Array,
  lba: number,
  size: number,
  isDir: boolean,
  now: Date
): Uint8Array {
  const baseLen = 33 + nameBytes.length;
  const recLen = baseLen % 2 === 1 ? baseLen + 1 : baseLen;
  const rec = new Uint8Array(recLen);
  const dv = new DataView(rec.buffer);

  rec[0] = recLen;
  rec[1] = 0; // Extended attribute length
  dv.setUint32(2, lba, true);
  dv.setUint32(6, lba, false);
  dv.setUint32(10, size, true);
  dv.setUint32(14, size, false);
  writeIsoDate7(rec, 18, now);
  rec[25] = isDir ? 0x02 : 0x00; // ISO 9660 File Flags (Directory bit 0x02 / Standard Read 0x00)
  rec[26] = 0;
  rec[27] = 0;
  dv.setUint16(28, 1, true); // Volume Sequence Number LE
  dv.setUint16(30, 1, false); // Volume Sequence Number BE
  rec[32] = nameBytes.length;
  rec.set(nameBytes, 33);
  return rec;
}

function encodeDirectoryTable(node: DirNode, now: Date): Uint8Array {
  const encoder = new TextEncoder();
  const entries: Array<{ nameBytes: Uint8Array; lba: number; size: number; isDir: boolean }> = [];

  // "." and ".." mandatory ISO 9660 entries
  entries.push({
    nameBytes: new Uint8Array([0x00]),
    lba: node.lba,
    size: node.dirByteSize,
    isDir: true,
  });
  entries.push({
    nameBytes: new Uint8Array([0x01]),
    lba: node.parent ? node.parent.lba : node.lba,
    size: node.parent ? node.parent.dirByteSize : node.dirByteSize,
    isDir: true,
  });

  const dirNames = Array.from(node.childrenDirs.keys()).sort();
  for (const dName of dirNames) {
    const child = node.childrenDirs.get(dName)!;
    entries.push({
      nameBytes: encoder.encode(child.name),
      lba: child.lba,
      size: child.dirByteSize,
      isDir: true,
    });
  }

  const fileNames = Array.from(node.childrenFiles.keys()).sort();
  for (const fName of fileNames) {
    const f = node.childrenFiles.get(fName)!;
    const isoName = f.name.endsWith(';1') ? f.name : `${f.name};1`;
    entries.push({
      nameBytes: encoder.encode(isoName),
      lba: (f as { lba?: number }).lba ?? 0,
      size: f.size,
      isDir: false,
    });
  }

  // First pass to know exact padded size
  let cursor = 0;
  const serialized = entries.map((e) => buildDirRecordBytes(e.nameBytes, e.lba, e.size, e.isDir, now));
  for (const rec of serialized) {
    const inSector = cursor % SECTOR_SIZE;
    if (inSector + rec.length > SECTOR_SIZE) {
      cursor += SECTOR_SIZE - inSector;
    }
    cursor += rec.length;
  }

  const totalBytes = Math.max(SECTOR_SIZE, Math.ceil(cursor / SECTOR_SIZE) * SECTOR_SIZE);
  const out = new Uint8Array(totalBytes);
  let writePos = 0;
  for (const rec of serialized) {
    const inSector = writePos % SECTOR_SIZE;
    if (inSector + rec.length > SECTOR_SIZE) {
      writePos += SECTOR_SIZE - inSector;
    }
    out.set(rec, writePos);
    writePos += rec.length;
  }
  return out;
}

function estimateDirectorySectors(node: DirNode): number {
  const encoder = new TextEncoder();
  const lengths: number[] = [34, 34]; // "." and ".."
  for (const d of node.childrenDirs.values()) {
    const len = 33 + encoder.encode(d.name).length;
    lengths.push(len % 2 === 1 ? len + 1 : len);
  }
  for (const f of node.childrenFiles.values()) {
    const isoName = f.name.endsWith(';1') ? f.name : `${f.name};1`;
    const len = 33 + encoder.encode(isoName).length;
    lengths.push(len % 2 === 1 ? len + 1 : len);
  }
  let cursor = 0;
  for (const l of lengths) {
    const inSec = cursor % SECTOR_SIZE;
    if (inSec + l > SECTOR_SIZE) cursor += SECTOR_SIZE - inSec;
    cursor += l;
  }
  return Math.max(1, Math.ceil(cursor / SECTOR_SIZE));
}

function buildPathTable(orderedDirs: DirNode[], littleEndian: boolean): Uint8Array {
  const encoder = new TextEncoder();
  const chunks: Uint8Array[] = [];
  let totalLen = 0;

  for (const dir of orderedDirs) {
    const idBytes = dir.parent === null ? new Uint8Array([0x00]) : encoder.encode(dir.name);
    const recLen = 8 + idBytes.length + (idBytes.length % 2);
    const rec = new Uint8Array(recLen);
    const dv = new DataView(rec.buffer);
    rec[0] = idBytes.length;
    rec[1] = 0;
    dv.setUint32(2, dir.lba, littleEndian);
    dv.setUint16(6, dir.parent ? dir.parent.pathTableIndex : 1, littleEndian);
    rec.set(idBytes, 8);
    chunks.push(rec);
    totalLen += recLen;
  }

  const out = new Uint8Array(totalLen);
  let pos = 0;
  for (const c of chunks) {
    out.set(c, pos);
    pos += c.length;
  }
  return out;
}

export async function buildExpandedPspIsoBlob(
  baseIsoBlob: Blob,
  existingIso: IsoInspectionResult,
  injectedFiles: InjectedIsoFileInput[],
  options?: { volumeId?: string; explicitSubfolders?: string[] }
): Promise<ExpandedIsoBuildResult> {
  const now = new Date();
  const root: DirNode = {
    name: '',
    fullPath: '',
    childrenDirs: new Map(),
    childrenFiles: new Map(),
    parent: null,
    pathTableIndex: 1,
    lba: 0,
    dirByteSize: SECTOR_SIZE,
    dirSectorCount: 1,
    sectorBuffer: new Uint8Array(SECTOR_SIZE),
  };

  const createdSubfoldersSet = new Set<string>();

  const ensureDir = (dirParts: string[], trackNew: boolean): DirNode => {
    let cur = root;
    let curPath = '';
    for (const rawSeg of dirParts) {
      const seg = normalizeIsoSegment(rawSeg, true);
      curPath += '/' + seg;
      let next = cur.childrenDirs.get(seg);
      if (!next) {
        next = {
          name: seg,
          fullPath: curPath,
          childrenDirs: new Map(),
          childrenFiles: new Map(),
          parent: cur,
          pathTableIndex: 0,
          lba: 0,
          dirByteSize: SECTOR_SIZE,
          dirSectorCount: 1,
          sectorBuffer: new Uint8Array(SECTOR_SIZE),
        };
        cur.childrenDirs.set(seg, next);
        if (trackNew) createdSubfoldersSet.add(curPath);
      }
      cur = next;
    }
    return cur;
  };

  // 1. Import existing directories & files from base ISO
  let totalFiles = 0;
  for (const entry of existingIso.files) {
    const parts = entry.path.split('/').filter(Boolean);
    if (parts.length === 0) continue;
    if (entry.isDirectory) {
      ensureDir(parts, false);
    } else {
      const dirNode = ensureDir(parts.slice(0, -1), false);
      const fileName = normalizeIsoSegment(parts[parts.length - 1], false);
      dirNode.childrenFiles.set(fileName, {
        name: fileName,
        size: entry.size,
        sliceSource: baseIsoBlob.slice(entry.byteOffset, entry.byteOffset + entry.size),
      });
    }
  }

  // 2. Create any explicit empty subfolders requested
  for (const rawFolder of options?.explicitSubfolders ?? []) {
    const parts = rawFolder
      .replace(/\\/g, '/')
      .split('/')
      .map((s) => s.trim())
      .filter(Boolean);
    if (parts.length > 0) {
      ensureDir(parts, true);
    }
  }

  // 3. Inject / replace new files into target subfolders
  for (const item of injectedFiles) {
    const normPath = normalizeIsoTargetPath(item.path);
    const parts = normPath.split('/').filter(Boolean);
    if (parts.length === 0) continue;
    const dirNode = ensureDir(parts.slice(0, -1), true);
    const fileName = normalizeIsoSegment(parts[parts.length - 1], false);
    dirNode.childrenFiles.set(fileName, {
      name: fileName,
      size: item.data.length,
      sliceSource: item.data,
    });
  }

  // 4. Breadth-first traversal for ECMA-119 Path Table order
  const orderedDirs: DirNode[] = [];
  const queue: DirNode[] = [root];
  while (queue.length > 0) {
    const cur = queue.shift()!;
    cur.pathTableIndex = orderedDirs.length + 1;
    cur.dirSectorCount = estimateDirectorySectors(cur);
    cur.dirByteSize = cur.dirSectorCount * SECTOR_SIZE;
    orderedDirs.push(cur);

    const sortedChildNames = Array.from(cur.childrenDirs.keys()).sort();
    for (const cName of sortedChildNames) {
      queue.push(cur.childrenDirs.get(cName)!);
    }
  }

  // 5. Assign LBAs sequentially:
  //    Sectors 0..15 : System Area (32 KB)
  //    Sector 16     : PVD
  //    Sector 17     : Terminator
  //    Sector 18..   : L-Path Table + M-Path Table
  //    Next..        : Directory Tables
  //    Next..        : File Data Payloads
  const prelimLTable = buildPathTable(orderedDirs, true);
  const pathTableByteLen = prelimLTable.length;
  const pathTableSectors = Math.max(1, Math.ceil(pathTableByteLen / SECTOR_SIZE));

  let lbaCursor = 18;
  const lPathTableLba = lbaCursor;
  lbaCursor += pathTableSectors;
  const mPathTableLba = lbaCursor;
  lbaCursor += pathTableSectors;

  for (const dir of orderedDirs) {
    dir.lba = lbaCursor;
    lbaCursor += dir.dirSectorCount;
  }

  // Assign file LBAs (sorted deterministically)
  const filePayloadsOrdered: Array<{ lba: number; size: number; source: Blob | Uint8Array }> = [];
  for (const dir of orderedDirs) {
    const fNames = Array.from(dir.childrenFiles.keys()).sort();
    for (const fName of fNames) {
      const f = dir.childrenFiles.get(fName)! as {
        name: string;
        size: number;
        sliceSource: Blob | Uint8Array;
        lba?: number;
      };
      f.lba = lbaCursor;
      filePayloadsOrdered.push({ lba: lbaCursor, size: f.size, source: f.sliceSource });
      const fileSectors = Math.max(1, Math.ceil(f.size / SECTOR_SIZE));
      lbaCursor += fileSectors;
      totalFiles++;
    }
  }

  const totalSectors = lbaCursor;

  // 6. Encode final L/M Path Tables and Directory Buffers now that LBAs are finalized
  const lPathRaw = buildPathTable(orderedDirs, true);
  const mPathRaw = buildPathTable(orderedDirs, false);
  const lPathPadded = new Uint8Array(pathTableSectors * SECTOR_SIZE);
  const mPathPadded = new Uint8Array(pathTableSectors * SECTOR_SIZE);
  lPathPadded.set(lPathRaw);
  mPathPadded.set(mPathRaw);

  for (const dir of orderedDirs) {
    dir.sectorBuffer = encodeDirectoryTable(dir, now);
  }

  // 7. Build System Area (sectors 0..15) + PVD (sector 16) + Terminator (sector 17)
  const sysAreaBytes = new Uint8Array(16 * SECTOR_SIZE);
  if (baseIsoBlob.size >= 16 * SECTOR_SIZE) {
    const origSys = new Uint8Array(await baseIsoBlob.slice(0, 16 * SECTOR_SIZE).arrayBuffer());
    sysAreaBytes.set(origSys);
  }

  const pvd = new Uint8Array(SECTOR_SIZE);
  pvd.fill(0x20, 8, 72);
  pvd.fill(0x20, 190, 813);
  const pvdView = new DataView(pvd.buffer);
  const enc = new TextEncoder();
  const writePaddedAscii = (off: number, len: number, str: string) => {
    const bytes = enc.encode(str.slice(0, len));
    pvd.fill(0x20, off, off + len);
    pvd.set(bytes, off);
  };

  pvd[0] = 1; // Type: Primary Volume Descriptor
  pvd.set(enc.encode('CD001'), 1);
  pvd[6] = 1; // Version
  writePaddedAscii(8, 32, existingIso.volume.systemId || 'PSP GAME');
  writePaddedAscii(40, 32, (options?.volumeId || existingIso.volume.volumeId || 'PSP_DLC_EXPANDED').toUpperCase());
  pvdView.setUint32(80, totalSectors, true);
  pvdView.setUint32(84, totalSectors, false);
  pvdView.setUint16(120, 1, true); // Volume Set Size LE
  pvdView.setUint16(122, 1, false); // Volume Set Size BE
  pvdView.setUint16(124, 1, true); // Sequence Number LE
  pvdView.setUint16(126, 1, false); // Sequence Number BE
  pvdView.setUint16(128, SECTOR_SIZE, true); // Logical Block Size LE
  pvdView.setUint16(130, SECTOR_SIZE, false); // Logical Block Size BE
  pvdView.setUint32(132, pathTableByteLen, true); // Path Table Size LE
  pvdView.setUint32(136, pathTableByteLen, false); // Path Table Size BE
  pvdView.setUint32(140, lPathTableLba, true); // L-Path Table LBA
  pvdView.setUint32(148, mPathTableLba, false); // M-Path Table LBA

  // Root Directory Record at offset 156 (34 bytes)
  const rootRecord = buildDirRecordBytes(new Uint8Array([0x00]), root.lba, root.dirByteSize, true, now);
  pvd.set(rootRecord, 156);

  writePaddedAscii(318, 128, existingIso.volume.publisher || 'PSP EBOOT INSPECTOR');
  writePaddedAscii(446, 128, existingIso.volume.dataPreparer || 'ECMA-119 ISO EXPANDER');
  writePaddedAscii(574, 128, existingIso.volume.applicationId || 'PSP ISO 9660');

  const pad2 = (n: number) => String(n).padStart(2, '0');
  const dec16 = `${now.getFullYear()}${pad2(now.getMonth() + 1)}${pad2(now.getDate())}${pad2(now.getHours())}${pad2(now.getMinutes())}${pad2(now.getSeconds())}00`;
  pvd.set(enc.encode(dec16), 813);
  pvd[829] = 0;
  pvd.set(enc.encode(dec16), 830);
  pvd[846] = 0;
  pvd[881] = 1; // File Structure Version = 1

  const term = new Uint8Array(SECTOR_SIZE);
  term[0] = 255;
  term.set(enc.encode('CD001'), 1);
  term[6] = 1;

  // 8. Assemble streaming BlobParts
  const parts: BlobPart[] = [
    sysAreaBytes as unknown as BlobPart,
    pvd as unknown as BlobPart,
    term as unknown as BlobPart,
    lPathPadded as unknown as BlobPart,
    mPathPadded as unknown as BlobPart,
  ];

  for (const dir of orderedDirs) {
    parts.push(dir.sectorBuffer as unknown as BlobPart);
  }

  for (const fp of filePayloadsOrdered) {
    if (fp.size === 0) {
      parts.push(new Uint8Array(SECTOR_SIZE) as unknown as BlobPart);
      continue;
    }
    if (fp.source instanceof Blob) {
      parts.push(fp.source);
    } else {
      parts.push(fp.source as unknown as BlobPart);
    }
    const rem = fp.size % SECTOR_SIZE;
    if (rem !== 0) {
      parts.push(new Uint8Array(SECTOR_SIZE - rem) as unknown as BlobPart);
    }
  }

  return {
    isoBlob: new Blob(parts, { type: 'application/octet-stream' }),
    totalSectors,
    totalBytes: totalSectors * SECTOR_SIZE,
    totalFiles,
    totalDirs: orderedDirs.length - 1,
    createdSubfolders: Array.from(createdSubfoldersSet),
  };
}

export function buildModDlcReplacementTemplates(
  options: { includeVideoPmf?: boolean } = {}
): InjectedIsoFileInput[] {
  const enc = new TextEncoder();
  const includeVideoPmf = options.includeVideoPmf ?? false;
  const makeMagic = (magic: string, len: number, tag: string) => {
    const u = new Uint8Array(len);
    u.set(enc.encode(magic), 0);
    u.set(enc.encode(tag), 16);
    return u;
  };

  // 1. CASILLAS_ROSTER: Tabla de reemplazo de casillas de Roster (256 personajes + 46 mapas)
  const rosterBin = new Uint8Array(2048);
  const rDv = new DataView(rosterBin.buffer);
  rosterBin.set(enc.encode('RSTR'), 0);
  rDv.setUint32(4, 256, true); // Max character slots (0x100)
  rDv.setUint32(8, 46, true); // Max map slots (0x2E)
  rDv.setUint32(12, 1, true); // Override original game roster flag = 1
  rosterBin.set(enc.encode('disc0:/PSP_GAME/MOD/DLC/PERSONAJES/\0'), 32);
  rosterBin.set(enc.encode('disc0:/PSP_GAME/MOD/DLC/MAPAS/\0'), 80);

  // 2. BARRA_DE_VIDA: Textura TIM2 base de reemplazo HUD (barra de vida / ki)
  const lifeBarTm2 = new Uint8Array(512);
  lifeBarTm2.set(enc.encode('TIM2'), 0);
  lifeBarTm2[4] = 4;
  lifeBarTm2[6] = 1;
  lifeBarTm2.set(enc.encode('HUD_BARRA_VIDA_REPLACE'), 32);

  // 3. LOBBY: Escena / fondo de Lobby de reemplazo
  const lobbyGim = makeMagic('MIG.00.1PSP', 512, 'LOBBY_REPLACE_BG');

  // 4. MUSICA_AT3: Audio RIFF base
  const bgmAt3 = new Uint8Array(512);
  const aDv = new DataView(bgmAt3.buffer);
  bgmAt3.set(enc.encode('RIFF'), 0);
  aDv.setUint32(4, 504, true);
  bgmAt3.set(enc.encode('WAVE'), 8);
  bgmAt3.set(enc.encode('fmt '), 12);
  aDv.setUint32(16, 16, true);
  aDv.setUint16(20, 1, true);
  aDv.setUint16(22, 1, true);
  aDv.setUint32(24, 22050, true);
  aDv.setUint32(28, 44100, true);
  aDv.setUint16(32, 2, true);
  aDv.setUint16(34, 16, true);
  bgmAt3.set(enc.encode('data'), 36);
  aDv.setUint32(40, 440, true);

  // 5. OBJ: Malla Wavefront .OBJ base para importar/convertir a GMO
  const objBytes = enc.encode(
    '# PSP MOD DLC Base OBJ\no Slot_DLC\nv 0.0 1.0 0.0\nv -0.5 0.0 0.5\nv 0.5 0.0 -0.5\nf 1 2 3\n'
  );

  // 6. PERSONAJES: CHAR077.BIN con cabecera 64B (8 colores)
  const charMod = makeMagic('OMG.00.1PSP', 512, 'CHAR_DLC_SLOT_077');

  // 7. MAPAS & MINIMAPAS
  const mapMod = makeMagic('MAP_STAGE_MOD', 512, 'STAGE_DLC_11');
  const miniMod = makeMagic('MIG.00.1PSP', 512, 'MINIMAP_RADAR_DLC');

  // 8. VIDEOS_PMF (Opcional): Contenedor nativo PlayStation Movie Format (PSMF0014, 480x272 @ 29.97fps + ATRAC3+)
  const pmfMod = new Uint8Array(2048);
  const pmfDv = new DataView(pmfMod.buffer);
  pmfMod.set(enc.encode('PSMF0014'), 0);
  pmfDv.setUint32(8, 0x00000800, false); // Stream data offset BE (2048 B)
  pmfDv.setUint32(12, 0x00000000, false); // Stream size placeholder BE
  pmfMod.set(enc.encode('480x272_AVC_MAIN_L21_2997_AT3'), 64);

  // 9. Manifiesto de rutas de reemplazo
  const readmeLines = [
    'ESTRUCTURA /PSP_GAME/MOD/DLC/ (REEMPLAZO ORIGINAL DEL JUEGO)',
    '==============================================================',
    'disc0:/PSP_GAME/MOD/DLC/PERSONAJES/      -> Modelos 3D .GMO/.BIN (CHAR077+)',
    'disc0:/PSP_GAME/MOD/DLC/MAPAS/           -> Escenarios .MAP/.BIN (MAPS11+)',
    'disc0:/PSP_GAME/MOD/DLC/MINIMAPAS/       -> Radares HUD .GIM/.TM2',
    'disc0:/PSP_GAME/MOD/DLC/MUSICA_AT3/      -> Pistas de audio .AT3',
    'disc0:/PSP_GAME/MOD/DLC/OBJ/             -> Modelos Wavefront .OBJ',
    'disc0:/PSP_GAME/MOD/DLC/LOBBY/           -> Fondos y sala Lobby .GIM/.MAP',
    'disc0:/PSP_GAME/MOD/DLC/CASILLAS_ROSTER/ -> Casillas DLC que reemplazan el Roster original',
    'disc0:/PSP_GAME/MOD/DLC/BARRA_DE_VIDA/   -> Texturas HUD de reemplazo (Barra de Vida / Energía)',
  ];
  if (includeVideoPmf) {
    readmeLines.push(
      'disc0:/PSP_GAME/MOD/DLC/VIDEOS_PMF/      -> Videos DLC nativos .PMF (PSMF0014, 480x272, 29.97fps, ATRAC3+)'
    );
  }
  const readme = enc.encode(readmeLines.join('\n'));

  const out: InjectedIsoFileInput[] = [
    { path: '/PSP_GAME/MOD/DLC/CASILLAS_ROSTER/ROSTER_DLC.BIN', data: rosterBin },
    { path: '/PSP_GAME/MOD/DLC/BARRA_DE_VIDA/HUD_VIDA.TM2', data: lifeBarTm2 },
    { path: '/PSP_GAME/MOD/DLC/LOBBY/LOBBY_MOD.GIM', data: lobbyGim },
    { path: '/PSP_GAME/MOD/DLC/MUSICA_AT3/BGM_MOD01.AT3', data: bgmAt3 },
    { path: '/PSP_GAME/MOD/DLC/OBJ/MODELO_MOD.OBJ', data: objBytes },
    { path: '/PSP_GAME/MOD/DLC/PERSONAJES/CHAR077.BIN', data: charMod },
    { path: '/PSP_GAME/MOD/DLC/MAPAS/MAPS11.BIN', data: mapMod },
    { path: '/PSP_GAME/MOD/DLC/MINIMAPAS/MINIMAP11.GIM', data: miniMod },
    { path: '/PSP_GAME/MOD/RUTAS_MOD.TXT', data: readme },
  ];
  if (includeVideoPmf) {
    out.push({ path: '/PSP_GAME/MOD/DLC/VIDEOS_PMF/INTRO_DLC01.PMF', data: pmfMod });
  }
  return out;
}

export interface Lobby256Char46MapPackOptions {
  mode: 'INDEXED_BIN' | 'INDIVIDUAL_FILES' | 'BOTH';
  charCount?: number;
  mapCount?: number;
  includeLobby?: boolean;
  includeRoster?: boolean;
  includeLifeBar?: boolean;
  includeVideoPmf?: boolean;
}

export function buildLobby256Char46MapPack(
  options: Lobby256Char46MapPackOptions = { mode: 'BOTH' }
): InjectedIsoFileInput[] {
  const enc = new TextEncoder();
  const charCount = Math.max(1, Math.min(256, options.charCount ?? 256));
  const mapCount = Math.max(1, Math.min(99, options.mapCount ?? 46));
  const includeLobby = options.includeLobby ?? true;
  const includeRoster = options.includeRoster ?? true;
  const includeLifeBar = options.includeLifeBar ?? true;
  const includeVideoPmf = options.includeVideoPmf ?? false;

  const files: InjectedIsoFileInput[] = [];

  const makeHeaderBuf = (magic: string, size: number, tag: string, slotNum = 0, subCount = 0) => {
    const u = new Uint8Array(size);
    u.set(enc.encode(magic), 0);
    const dv = new DataView(u.buffer);
    dv.setUint32(16, slotNum, true);
    dv.setUint32(20, subCount, true);
    u.set(enc.encode(tag.slice(0, 40)), 24);
    return u;
  };

  // 1. LOBBY (/PSP_GAME/MOD/DLC/LOBBY/)
  if (includeLobby) {
    files.push({
      path: '/PSP_GAME/MOD/DLC/LOBBY/LOBBY_MOD.GIM',
      data: makeHeaderBuf('MIG.00.1PSP', 512, 'LOBBY_DLC_256_46_BG', charCount, mapCount),
    });
    files.push({
      path: '/PSP_GAME/MOD/DLC/LOBBY/LOBBY_STAGE.MAP',
      data: makeHeaderBuf('MAP_LOBBY_3D', 512, 'LOBBY_3D_SCENE_DLC', charCount, mapCount),
    });

    const lobbyCfg = new Uint8Array(512);
    const lDv = new DataView(lobbyCfg.buffer);
    lobbyCfg.set(enc.encode('LBYC'), 0);
    lDv.setUint32(4, 1, true); // Version 1
    lDv.setUint32(8, charCount, true); // 256 Personajes
    lDv.setUint32(12, mapCount, true); // 46 Mapas
    lDv.setUint32(16, mapCount, true); // 46 Minimapas
    lDv.setUint32(20, 8, true); // 8 Colores por personaje
    lobbyCfg.set(enc.encode('disc0:/PSP_GAME/MOD/DLC/CASILLAS_ROSTER/ROSTER_256_46.BIN\0'), 32);
    lobbyCfg.set(enc.encode('disc0:/PSP_GAME/MOD/DLC/MINIMAPAS/\0'), 128);
    lobbyCfg.set(enc.encode('disc0:/PSP_GAME/MOD/DLC/PERSONAJES/\0'), 192);
    files.push({
      path: '/PSP_GAME/MOD/DLC/LOBBY/LOBBY_CONFIG.BIN',
      data: lobbyCfg,
    });
  }

  // 2. CASILLAS ROSTER (/PSP_GAME/MOD/DLC/CASILLAS_ROSTER/)
  if (includeRoster) {
    const roster = new Uint8Array(2048);
    const rDv = new DataView(roster.buffer);
    roster.set(enc.encode('RSTR'), 0);
    rDv.setUint32(4, charCount, true); // 256 Personajes
    rDv.setUint32(8, mapCount, true); // 46 Mapas
    rDv.setUint32(12, mapCount, true); // 46 Minimapas
    rDv.setUint32(16, 8, true); // 8 Colores
    rDv.setUint32(20, 1, true); // Override original game roster
    roster.set(enc.encode('disc0:/PSP_GAME/MOD/DLC/PERSONAJES/\0'), 32);
    roster.set(enc.encode('disc0:/PSP_GAME/MOD/DLC/MAPAS/\0'), 80);
    roster.set(enc.encode('disc0:/PSP_GAME/MOD/DLC/MINIMAPAS/\0'), 128);
    roster.set(enc.encode('disc0:/PSP_GAME/MOD/DLC/LOBBY/LOBBY_CONFIG.BIN\0'), 176);
    files.push({
      path: '/PSP_GAME/MOD/DLC/CASILLAS_ROSTER/ROSTER_256_46.BIN',
      data: roster,
    });
  }

  // 3. Contenedores Indexados (CHAR256.BIN: 256x8 = 2048 entradas = 16384 B; MAPS46.BIN: 46+46 = 92 entradas)
  if (options.mode === 'INDEXED_BIN' || options.mode === 'BOTH') {
    const charEntries = charCount * 8; // 2048 entries
    const charHeaderAligned = Math.ceil((16 + charEntries * 8) / 2048) * 2048;
    const charSlotPayload = 256;
    const charBin = new Uint8Array(charHeaderAligned + charCount * charSlotPayload);
    const cDv = new DataView(charBin.buffer);
    charBin.set(enc.encode('DLC\0'), 0);
    cDv.setUint32(4, charEntries, true);
    cDv.setUint32(8, charCount, true);
    cDv.setUint32(12, 8, true);
    for (let ch = 0; ch < charCount; ch++) {
      const dataOff = charHeaderAligned + ch * charSlotPayload;
      charBin.set(enc.encode('OMG.00.1PSP'), dataOff);
      charBin.set(enc.encode(`CHAR_${String(ch + 1).padStart(3, '0')}`), dataOff + 16);
      for (let col = 0; col < 8; col++) {
        const idx = ch * 8 + col;
        const tOff = 16 + idx * 8;
        cDv.setUint32(tOff, dataOff, true);
        cDv.setUint32(tOff + 4, charSlotPayload, true);
      }
    }
    files.push({
      path:
        options.mode === 'BOTH'
          ? '/PSP_GAME/MOD/DLC/PERSONAJES/CHAR256_MASTER.BIN'
          : '/PSP_GAME/MOD/DLC/PERSONAJES/CHAR256.BIN',
      data: charBin,
    });

    const mapEntries = mapCount * 2; // 46 mapas + 46 minimapas = 92 entradas
    const mapHeaderAligned = Math.ceil((16 + mapEntries * 8) / 2048) * 2048;
    const mapSlotPayload = 256;
    const mapsBin = new Uint8Array(mapHeaderAligned + mapEntries * mapSlotPayload);
    const mDv = new DataView(mapsBin.buffer);
    mapsBin.set(enc.encode('DLC\0'), 0);
    mDv.setUint32(4, mapEntries, true);
    mDv.setUint32(8, mapCount, true);
    mDv.setUint32(12, mapCount, true);
    for (let m = 0; m < mapCount; m++) {
      const stageOff = mapHeaderAligned + m * mapSlotPayload;
      mapsBin.set(enc.encode('MAP_STAGE_DLC'), stageOff);
      mapsBin.set(enc.encode(`MAP_${String(m + 1).padStart(2, '0')}`), stageOff + 16);
      mDv.setUint32(16 + m * 8, stageOff, true);
      mDv.setUint32(16 + m * 8 + 4, mapSlotPayload, true);

      const miniIdx = mapCount + m;
      const miniOff = mapHeaderAligned + miniIdx * mapSlotPayload;
      mapsBin.set(enc.encode('TIM2'), miniOff);
      mapsBin[miniOff + 4] = 4;
      mapsBin.set(enc.encode(`MINIMAP_${String(m + 1).padStart(2, '0')}`), miniOff + 16);
      mDv.setUint32(16 + miniIdx * 8, miniOff, true);
      mDv.setUint32(16 + miniIdx * 8 + 4, mapSlotPayload, true);
    }
    files.push({
      path:
        options.mode === 'BOTH'
          ? '/PSP_GAME/MOD/DLC/MAPAS/MAPS46_MASTER.BIN'
          : '/PSP_GAME/MOD/DLC/MAPAS/MAPS46.BIN',
      data: mapsBin,
    });
  }

  // 4. Archivos Individuales: 256 Personajes + 46 Mapas
  if (options.mode === 'INDIVIDUAL_FILES' || options.mode === 'BOTH') {
    for (let i = 1; i <= charCount; i++) {
      const idStr = String(i).padStart(3, '0');
      files.push({
        path: `/PSP_GAME/MOD/DLC/PERSONAJES/CHAR${idStr}.BIN`,
        data: makeHeaderBuf('OMG.00.1PSP', 128, `CHAR_DLC_${idStr}_8COL`, i, 8),
      });
    }
    for (let m = 1; m <= mapCount; m++) {
      const idStr = String(m).padStart(2, '0');
      files.push({
        path: `/PSP_GAME/MOD/DLC/MAPAS/MAPS${idStr}.BIN`,
        data: makeHeaderBuf('MAP_STAGE_MOD', 128, `STAGE_DLC_${idStr}`, m, 1),
      });
    }
  }

  // 5. 46 Minimapas individuales .TM2 (128x128 TIM2) siempre generados para los 46 escenarios
  for (let m = 1; m <= mapCount; m++) {
    const idStr = String(m).padStart(2, '0');
    const tm2 = new Uint8Array(128);
    tm2.set(enc.encode('TIM2'), 0);
    tm2[4] = 4;
    tm2[6] = 1;
    const dv = new DataView(tm2.buffer);
    dv.setUint16(28, 128, true); // 128px width
    dv.setUint16(30, 128, true); // 128px height
    tm2.set(enc.encode(`MINIMAP_RADAR_${idStr}`), 32);
    files.push({
      path: `/PSP_GAME/MOD/DLC/MINIMAPAS/MINIMAP${idStr}.TM2`,
      data: tm2,
    });
  }

  // 6. HUD Barra de Vida + Video PMF base opcionales
  if (includeLifeBar) {
    const hud = makeHeaderBuf('TIM2', 256, 'HUD_BARRA_VIDA_256', charCount, 1);
    hud[4] = 4;
    hud[6] = 1;
    files.push({
      path: '/PSP_GAME/MOD/DLC/BARRA_DE_VIDA/HUD_VIDA.TM2',
      data: hud,
    });
  }

  if (includeVideoPmf) {
    const pmf = new Uint8Array(2048);
    const pmfDv = new DataView(pmf.buffer);
    pmf.set(enc.encode('PSMF0014'), 0);
    pmfDv.setUint32(8, 0x00000800, false);
    pmf.set(enc.encode('480x272_AVC_MAIN_L21_2997_AT3'), 64);
    files.push({
      path: '/PSP_GAME/MOD/DLC/VIDEOS_PMF/INTRO_DLC01.PMF',
      data: pmf,
    });
  }

  const manifest = enc.encode(
    [
      `PACK DLC COMPLETO: LOBBY + ${charCount} PERSONAJES + ${mapCount} MAPAS + ${mapCount} MINIMAPAS`,
      '=========================================================================',
      `Modo generado : ${options.mode}`,
      `Personajes    : ${charCount} slots (8 colores c/u = ${charCount * 8} combinaciones)`,
      `Mapas         : ${mapCount} escenarios en disc0:/PSP_GAME/MOD/DLC/MAPAS/`,
      `Minimapas     : ${mapCount} radares 128x128 .TM2 en disc0:/PSP_GAME/MOD/DLC/MINIMAPAS/`,
      'Lobby         : LOBBY_MOD.GIM + LOBBY_STAGE.MAP + LOBBY_CONFIG.BIN',
      'Roster        : CASILLAS_ROSTER/ROSTER_256_46.BIN',
    ].join('\n')
  );
  files.push({
    path: '/PSP_GAME/MOD/RUTAS_MOD.TXT',
    data: manifest,
  });

  return files;
}

export function exportModFolderZip(
  files: InjectedIsoFileInput[],
  explicitSubfolders: string[]
): Blob {
  const zipEntries: ZipInputEntry[] = [];
  const fileMap = new Map<string, Uint8Array>();

  for (const f of files) {
    const clean = normalizeIsoTargetPath(f.path).replace(/^\/+/, '');
    fileMap.set(clean, f.data);
  }

  for (const dir of explicitSubfolders) {
    const cleanDir = normalizeIsoTargetPath(dir).replace(/^\/+/, '');
    const hasChildFile = Array.from(fileMap.keys()).some((k) => k.startsWith(`${cleanDir}/`));
    if (!hasChildFile) {
      fileMap.set(
        `${cleanDir}/CARPETA_ACTIVA.TXT`,
        new TextEncoder().encode(`Subcarpeta ISO PSP lista para reemplazo: /${cleanDir}/\n`)
      );
    }
  }

  for (const [path, data] of fileMap.entries()) {
    zipEntries.push({ path, data });
  }

  return buildZipBlob(zipEntries);
}

export function buildIsoExpanderPythonScript(): string {
  return `#!/usr/bin/env python3
"""
Expansor ISO 9660 (ECMA-119) para PSP con Subcarpetas y Permisos ISO
Lee una .ISO base por bloques sin saturar RAM, agrega una carpeta local con
subcarpetas (ej. PSP_GAME/DLC/Personajes, Musica_AT3, Mapas) y reconstruye
el PVD (sector 16), Path Tables L/M y LBA alineados a 2048 bytes con
bandera de directorio 0x02 y permiso de archivo ;1.
"""

import argparse
import datetime
import struct
from pathlib import Path

SECTOR = 2048


def pad2048(n: int) -> int:
    return ((n + SECTOR - 1) // SECTOR) * SECTOR


def iso_date7(now: datetime.datetime) -> bytes:
    return bytes([
        max(0, now.year - 1900) & 0xFF,
        now.month & 0xFF,
        now.day & 0xFF,
        now.hour & 0xFF,
        now.minute & 0xFF,
        now.second & 0xFF,
        0,
    ])


def read_iso_dir_records(buf: bytes) -> list[tuple[str, bool, int, int]]:
    out = []
    pos = 0
    while pos < len(buf):
        rec_len = buf[pos]
        if rec_len == 0:
            pos = ((pos // SECTOR) + 1) * SECTOR
            continue
        if pos + rec_len > len(buf) or rec_len < 34:
            break
        lba = struct.unpack_from("<I", buf, pos + 2)[0]
        size = struct.unpack_from("<I", buf, pos + 10)[0]
        is_dir = (buf[pos + 25] & 0x02) != 0
        id_len = buf[pos + 32]
        raw_id = buf[pos + 33 : pos + 33 + id_len]
        if not (id_len == 1 and raw_id in (b"\\x00", b"\\x01")):
            name = raw_id.decode("ascii", errors="ignore").split(";")[0]
            out.append((name, is_dir, lba, size))
        pos += rec_len
    return out


class IsoNode:
    def __init__(self, name: str, parent=None):
        self.name = name
        self.parent = parent
        self.dirs: dict[str, "IsoNode"] = {}
        self.files: dict[str, tuple[str, int, tuple]] = {}
        self.pt_index = 1
        self.lba = 0
        self.dir_size = SECTOR
        self.dir_sectors = 1


def make_dir_rec(name_bytes: bytes, lba: int, size: int, is_dir: bool, now: datetime.datetime) -> bytes:
    base_len = 33 + len(name_bytes)
    rec_len = base_len + (base_len % 2)
    rec = bytearray(rec_len)
    rec[0] = rec_len
    struct.pack_into("<I", rec, 2, lba)
    struct.pack_into(">I", rec, 6, lba)
    struct.pack_into("<I", rec, 10, size)
    struct.pack_into(">I", rec, 14, size)
    rec[18:25] = iso_date7(now)
    rec[25] = 0x02 if is_dir else 0x00
    struct.pack_into("<H", rec, 28, 1)
    struct.pack_into(">H", rec, 30, 1)
    rec[32] = len(name_bytes)
    rec[33 : 33 + len(name_bytes)] = name_bytes
    return bytes(rec)


def expand_iso(base_iso: Path, add_dir: Path, out_iso: Path) -> None:
    now = datetime.datetime.now()
    root = IsoNode("")

    def ensure_dir(parts: list[str]) -> IsoNode:
        cur = root
        for part in parts:
            seg = part.upper()[:31]
            if seg not in cur.dirs:
                cur.dirs[seg] = IsoNode(seg, cur)
            cur = cur.dirs[seg]
        return cur

    with base_iso.open("rb") as f:
        sys_area = f.read(16 * SECTOR)
        pvd_orig = f.read(SECTOR)
        if pvd_orig[1:6] != b"CD001":
            raise ValueError("La imagen base no tiene un PVD ISO 9660 CD001 valido.")
        root_lba = struct.unpack_from("<I", pvd_orig, 158)[0]
        root_sz = struct.unpack_from("<I", pvd_orig, 166)[0]

        def walk_iso(node: IsoNode, lba: int, size: int, depth: int = 0) -> None:
            if depth > 8:
                return
            f.seek(lba * SECTOR)
            data = f.read(size)
            for name, is_dir, c_lba, c_sz in read_iso_dir_records(data):
                seg = name.upper()[:31]
                if is_dir:
                    child = IsoNode(seg, node)
                    node.dirs[seg] = child
                    walk_iso(child, c_lba, c_sz, depth + 1)
                else:
                    node.files[seg] = (seg, c_sz, ("iso", c_lba * SECTOR, c_sz))

        walk_iso(root, root_lba, root_sz)

    # Mezclar carpetas y subcarpetas locales
    for item in sorted(add_dir.rglob("*")):
        rel = item.relative_to(add_dir)
        parts = [p.upper()[:31] for p in rel.parts]
        if item.is_dir():
            ensure_dir(parts)
        else:
            parent_node = ensure_dir(parts[:-1])
            fname = parts[-1]
            parent_node.files[fname] = (fname, item.stat().st_size, ("disk", item))

    # BFS ECMA-119
    ordered: list[IsoNode] = []
    q = [root]
    while q:
        cur = q.pop(0)
        cur.pt_index = len(ordered) + 1
        ordered.append(cur)
        for k in sorted(cur.dirs):
            q.append(cur.dirs[k])

    def estimate_dir_sectors(node: IsoNode) -> int:
        lens = [34, 34]
        for k in sorted(node.dirs):
            n = 33 + len(k.encode("ascii"))
            lens.append(n + (n % 2))
        for k in sorted(node.files):
            n = 33 + len((k + ";1").encode("ascii"))
            lens.append(n + (n % 2))
        cursor = 0
        for ln in lens:
            if (cursor % SECTOR) + ln > SECTOR:
                cursor += SECTOR - (cursor % SECTOR)
            cursor += ln
        return max(1, pad2048(cursor) // SECTOR)

    for d in ordered:
        d.dir_sectors = estimate_dir_sectors(d)
        d.dir_size = d.dir_sectors * SECTOR

    def build_pt(le: bool) -> bytes:
        chunks = []
        fmt_u32 = "<I" if le else ">I"
        fmt_u16 = "<H" if le else ">H"
        for d in ordered:
            ident = b"\\x00" if d.parent is None else d.name.encode("ascii")
            rec_len = 8 + len(ident) + (len(ident) % 2)
            rec = bytearray(rec_len)
            rec[0] = len(ident)
            struct.pack_into(fmt_u32, rec, 2, d.lba)
            struct.pack_into(fmt_u16, rec, 6, d.parent.pt_index if d.parent else 1)
            rec[8 : 8 + len(ident)] = ident
            chunks.append(bytes(rec))
        return b"".join(chunks)

    pt_raw_len = len(build_pt(True))
    pt_sectors = max(1, pad2048(pt_raw_len) // SECTOR)

    cursor = 18
    l_pt_lba = cursor
    cursor += pt_sectors
    m_pt_lba = cursor
    cursor += pt_sectors

    for d in ordered:
        d.lba = cursor
        cursor += d.dir_sectors

    file_queue = []
    for d in ordered:
        for k in sorted(d.files):
            fname, fsize, src = d.files[k]
            file_lba = cursor
            file_queue.append((d, fname, file_lba, fsize, src))
            cursor += max(1, pad2048(fsize) // SECTOR)

    total_sectors = cursor
    l_pt = build_pt(True).ljust(pt_sectors * SECTOR, b"\\x00")
    m_pt = build_pt(False).ljust(pt_sectors * SECTOR, b"\\x00")

    file_lba_map = {(id(d), fname): flba for (d, fname, flba, _, _) in file_queue}

    pvd = bytearray(pvd_orig)
    struct.pack_into("<I", pvd, 80, total_sectors)
    struct.pack_into(">I", pvd, 84, total_sectors)
    struct.pack_into("<I", pvd, 132, pt_raw_len)
    struct.pack_into(">I", pvd, 136, pt_raw_len)
    struct.pack_into("<I", pvd, 140, l_pt_lba)
    struct.pack_into(">I", pvd, 148, m_pt_lba)
    pvd[156:190] = make_dir_rec(b"\\x00", root.lba, root.dir_size, True, now)

    term = bytearray(SECTOR)
    term[0] = 255
    term[1:6] = b"CD001"
    term[6] = 1

    with base_iso.open("rb") as f_in, out_iso.open("wb") as f_out:
        f_out.write(sys_area)
        f_out.write(pvd)
        f_out.write(term)
        f_out.write(l_pt)
        f_out.write(m_pt)

        for d in ordered:
            recs = [
                make_dir_rec(b"\\x00", d.lba, d.dir_size, True, now),
                make_dir_rec(b"\\x01", d.parent.lba if d.parent else d.lba, d.parent.dir_size if d.parent else d.dir_size, True, now),
            ]
            for k in sorted(d.dirs):
                ch = d.dirs[k]
                recs.append(make_dir_rec(ch.name.encode("ascii"), ch.lba, ch.dir_size, True, now))
            for k in sorted(d.files):
                fname, fsize, _ = d.files[k]
                flba = file_lba_map[(id(d), fname)]
                recs.append(make_dir_rec((fname + ";1").encode("ascii"), flba, fsize, False, now))

            dir_buf = bytearray(d.dir_size)
            pos = 0
            for r in recs:
                if (pos % SECTOR) + len(r) > SECTOR:
                    pos += SECTOR - (pos % SECTOR)
                dir_buf[pos : pos + len(r)] = r
                pos += len(r)
            f_out.write(dir_buf)

        for _, _, _, fsize, src in file_queue:
            if fsize == 0:
                f_out.write(b"\\x00" * SECTOR)
                continue
            if src[0] == "iso":
                f_in.seek(src[1])
                rem = fsize
                while rem > 0:
                    chunk = f_in.read(min(rem, 1024 * 1024))
                    f_out.write(chunk)
                    rem -= len(chunk)
            else:
                with src[1].open("rb") as sf:
                    while True:
                        chunk = sf.read(1024 * 1024)
                        if not chunk:
                            break
                        f_out.write(chunk)
            tail = fsize % SECTOR
            if tail:
                f_out.write(b"\\x00" * (SECTOR - tail))

    print(f"ISO expandida generada: {out_iso} ({total_sectors} sectores / {total_sectors * SECTOR} bytes)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Expande una ISO PSP agregando subcarpetas con permisos ISO 9660.")
    ap.add_argument("base_iso", type=Path, help="ISO PSP original")
    ap.add_argument("add_dir", type=Path, help="Carpeta raiz a inyectar (ej. ./mi_expansion con PSP_GAME/DLC/...)")
    ap.add_argument("--out", type=Path, default=Path("./PSP_EXPANDIDA.ISO"), help="Archivo .ISO resultante")
    args = ap.parse_args()
    expand_iso(args.base_iso, args.add_dir, args.out)
`;
}
