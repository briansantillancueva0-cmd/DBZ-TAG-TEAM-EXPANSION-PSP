import { buildZipBlob } from './zipBuilder';

export interface MipsVmSnapshot {
  pc: number;
  hi: number;
  lo: number;
  cycles: number;
  halted: boolean;
  haltReason: string | null;
  regs: Uint32Array;
  disasmWindow: Array<{ addr: number; word: number; text: string; isCurrent: boolean }>;
  syscallLogs: string[];
  loadedElfName: string | null;
  ramLimitMb: number;
}

export const MIPS_REG_NAMES = [
  '$zero', '$at', '$v0', '$v1', '$a0', '$a1', '$a2', '$a3',
  '$t0', '$t1', '$t2', '$t3', '$t4', '$t5', '$t6', '$t7',
  '$s0', '$s1', '$s2', '$s3', '$s4', '$s5', '$s6', '$s7',
  '$t8', '$t9', '$k0', '$k1', '$gp', '$sp', '$fp', '$ra',
];

function hex32(v: number): string {
  return `0x${(v >>> 0).toString(16).toUpperCase().padStart(8, '0')}`;
}

function signExt16(imm: number): number {
  return (imm << 16) >> 16;
}

export function disassembleMipsWord(word: number, pc: number): string {
  const w = word >>> 0;
  if (w === 0) return 'nop';
  const op = (w >>> 26) & 0x3f;
  const rs = (w >>> 21) & 0x1f;
  const rt = (w >>> 16) & 0x1f;
  const rd = (w >>> 11) & 0x1f;
  const shamt = (w >>> 6) & 0x1f;
  const funct = w & 0x3f;
  const imm = w & 0xffff;
  const simm = signExt16(imm);

  if (op === 0x00) {
    switch (funct) {
      case 0x00:
        return `sll ${MIPS_REG_NAMES[rd]}, ${MIPS_REG_NAMES[rt]}, ${shamt}`;
      case 0x02:
        return `srl ${MIPS_REG_NAMES[rd]}, ${MIPS_REG_NAMES[rt]}, ${shamt}`;
      case 0x03:
        return `sra ${MIPS_REG_NAMES[rd]}, ${MIPS_REG_NAMES[rt]}, ${shamt}`;
      case 0x08:
        return `jr ${MIPS_REG_NAMES[rs]}`;
      case 0x09:
        return `jalr ${MIPS_REG_NAMES[rd]}, ${MIPS_REG_NAMES[rs]}`;
      case 0x0c:
        return `syscall 0x${((w >>> 6) & 0xfffff).toString(16).toUpperCase()}`;
      case 0x20:
      case 0x21:
        return `addu ${MIPS_REG_NAMES[rd]}, ${MIPS_REG_NAMES[rs]}, ${MIPS_REG_NAMES[rt]}`;
      case 0x22:
      case 0x23:
        return `subu ${MIPS_REG_NAMES[rd]}, ${MIPS_REG_NAMES[rs]}, ${MIPS_REG_NAMES[rt]}`;
      case 0x24:
        return `and ${MIPS_REG_NAMES[rd]}, ${MIPS_REG_NAMES[rs]}, ${MIPS_REG_NAMES[rt]}`;
      case 0x25:
        return `or ${MIPS_REG_NAMES[rd]}, ${MIPS_REG_NAMES[rs]}, ${MIPS_REG_NAMES[rt]}`;
      case 0x26:
        return `xor ${MIPS_REG_NAMES[rd]}, ${MIPS_REG_NAMES[rs]}, ${MIPS_REG_NAMES[rt]}`;
      case 0x2a:
        return `slt ${MIPS_REG_NAMES[rd]}, ${MIPS_REG_NAMES[rs]}, ${MIPS_REG_NAMES[rt]}`;
      case 0x2b:
        return `sltu ${MIPS_REG_NAMES[rd]}, ${MIPS_REG_NAMES[rs]}, ${MIPS_REG_NAMES[rt]}`;
      default:
        return `special(0x${funct.toString(16).toUpperCase()})`;
    }
  }

  switch (op) {
    case 0x02: {
      const target = ((pc & 0xf0000000) | ((w & 0x03ffffff) << 2)) >>> 0;
      return `j ${hex32(target)}`;
    }
    case 0x03: {
      const target = ((pc & 0xf0000000) | ((w & 0x03ffffff) << 2)) >>> 0;
      return `jal ${hex32(target)}`;
    }
    case 0x04:
      return `beq ${MIPS_REG_NAMES[rs]}, ${MIPS_REG_NAMES[rt]}, ${hex32((pc + 4 + simm * 4) >>> 0)}`;
    case 0x05:
      return `bne ${MIPS_REG_NAMES[rs]}, ${MIPS_REG_NAMES[rt]}, ${hex32((pc + 4 + simm * 4) >>> 0)}`;
    case 0x08:
    case 0x09:
      return `addiu ${MIPS_REG_NAMES[rt]}, ${MIPS_REG_NAMES[rs]}, ${simm}`;
    case 0x0a:
      return `slti ${MIPS_REG_NAMES[rt]}, ${MIPS_REG_NAMES[rs]}, ${simm}`;
    case 0x0b:
      return `sltiu ${MIPS_REG_NAMES[rt]}, ${MIPS_REG_NAMES[rs]}, 0x${imm.toString(16).toUpperCase()}`;
    case 0x0c:
      return `andi ${MIPS_REG_NAMES[rt]}, ${MIPS_REG_NAMES[rs]}, 0x${imm.toString(16).toUpperCase()}`;
    case 0x0d:
      return `ori ${MIPS_REG_NAMES[rt]}, ${MIPS_REG_NAMES[rs]}, 0x${imm.toString(16).toUpperCase()}`;
    case 0x0f:
      return `lui ${MIPS_REG_NAMES[rt]}, 0x${imm.toString(16).toUpperCase().padStart(4, '0')}`;
    case 0x20:
      return `lb ${MIPS_REG_NAMES[rt]}, ${simm}(${MIPS_REG_NAMES[rs]})`;
    case 0x23:
      return `lw ${MIPS_REG_NAMES[rt]}, ${simm}(${MIPS_REG_NAMES[rs]})`;
    case 0x24:
      return `lbu ${MIPS_REG_NAMES[rt]}, ${simm}(${MIPS_REG_NAMES[rs]})`;
    case 0x28:
      return `sb ${MIPS_REG_NAMES[rt]}, ${simm}(${MIPS_REG_NAMES[rs]})`;
    case 0x2b:
      return `sw ${MIPS_REG_NAMES[rt]}, ${simm}(${MIPS_REG_NAMES[rs]})`;
    default:
      return `.word ${hex32(w)}`;
  }
}

/**
 * Lightweight paged MIPS R4000 Allegrex Interpreter + PSP HLE Syscall VM
 * Supports mapping real ELF32 EBOOT.BIN PT_LOAD segments up to 256 MB (0x08000000 - 0x18000000).
 */
export class PspAllegrexVm {
  private pages = new Map<number, Uint8Array>();
  public regs = new Uint32Array(32);
  public pc = 0x08804000;
  public hi = 0;
  public lo = 0;
  public cycles = 0;
  public halted = false;
  public haltReason: string | null = null;
  public syscallLogs: string[] = [];
  public loadedElfName: string | null = null;
  public ramLimitMb: number;

  constructor(ramLimitMb = 256) {
    this.ramLimitMb = ramLimitMb;
    this.reset(ramLimitMb);
  }

  public reset(ramLimitMb = this.ramLimitMb) {
    this.pages.clear();
    this.regs.fill(0);
    this.ramLimitMb = ramLimitMb;
    this.pc = 0x08804000;
    this.hi = 0;
    this.lo = 0;
    this.cycles = 0;
    this.halted = false;
    this.haltReason = null;
    this.loadedElfName = null;
    this.regs[29] = (0x08000000 + Math.min(256, ramLimitMb) * 1024 * 1024 - 0x100) >>> 0; // $sp
    this.regs[31] = 0x088040fc; // $ra return trap
    this.syscallLogs = [
      `[VM INIT] Allegrex MIPS32 R4000 · RAM ${ramLimitMb} MB · $sp=${hex32(this.regs[29])}`,
    ];
  }

  private getPage(addr: number, create = false): { page: Uint8Array | null; offset: number } {
    const a = addr >>> 0;
    const pageIdx = a >>> 16; // 64 KB pages
    const offset = a & 0xffff;
    let page = this.pages.get(pageIdx) ?? null;
    if (!page && create) {
      page = new Uint8Array(65536);
      this.pages.set(pageIdx, page);
    }
    return { page, offset };
  }

  public writeU8(addr: number, val: number) {
    const { page, offset } = this.getPage(addr, true);
    if (page) page[offset] = val & 0xff;
  }

  public readU8(addr: number): number {
    const { page, offset } = this.getPage(addr, false);
    return page ? page[offset] : 0;
  }

  public writeU32(addr: number, val: number) {
    const v = val >>> 0;
    this.writeU8(addr, v & 0xff);
    this.writeU8(addr + 1, (v >>> 8) & 0xff);
    this.writeU8(addr + 2, (v >>> 16) & 0xff);
    this.writeU8(addr + 3, (v >>> 24) & 0xff);
  }

  public readU32(addr: number): number {
    const b0 = this.readU8(addr);
    const b1 = this.readU8(addr + 1);
    const b2 = this.readU8(addr + 2);
    const b3 = this.readU8(addr + 3);
    return (b0 | (b1 << 8) | (b2 << 16) | (b3 << 24)) >>> 0;
  }

  public writeAscii(addr: number, str: string) {
    for (let i = 0; i < str.length; i++) {
      this.writeU8(addr + i, str.charCodeAt(i) & 0xff);
    }
    this.writeU8(addr + str.length, 0);
  }

  public readAscii(addr: number, maxLen = 96): string {
    let out = '';
    for (let i = 0; i < maxLen; i++) {
      const ch = this.readU8(addr + i);
      if (ch === 0) break;
      out += ch >= 32 && ch < 127 ? String.fromCharCode(ch) : '.';
    }
    return out;
  }

  /**
   * Loads an unencrypted ELF32 PSP EBOOT.BIN into virtual RAM and sets PC = e_entry.
   * Returns true if ELF32 segments were mapped; false if ~PSP encrypted or invalid (falls back to boot stub).
   */
  public loadElfOrFallbackStub(rawBytes: Uint8Array | null, label: string): boolean {
    this.reset(this.ramLimitMb);
    if (
      rawBytes &&
      rawBytes.length >= 64 &&
      rawBytes[0] === 0x7f &&
      rawBytes[1] === 0x45 &&
      rawBytes[2] === 0x4c &&
      rawBytes[3] === 0x46
    ) {
      const dv = new DataView(rawBytes.buffer, rawBytes.byteOffset, rawBytes.byteLength);
      const entry = dv.getUint32(24, true);
      const phoff = dv.getUint32(28, true);
      const phentsize = dv.getUint16(42, true);
      const phnum = dv.getUint16(44, true);

      let mappedSegs = 0;
      for (let i = 0; i < phnum; i++) {
        const off = phoff + i * phentsize;
        if (off + 32 > rawBytes.length) break;
        const pType = dv.getUint32(off, true);
        if (pType !== 1) continue; // PT_LOAD
        const pOffset = dv.getUint32(off + 4, true);
        let pVaddr = dv.getUint32(off + 8, true);
        const pFilesz = dv.getUint32(off + 16, true);
        if (pVaddr < 0x08000000) {
          pVaddr = (0x08804000 + pVaddr) >>> 0;
        }
        const limit = Math.min(pFilesz, rawBytes.length - pOffset, 12 * 1024 * 1024);
        for (let b = 0; b < limit; b++) {
          this.writeU8(pVaddr + b, rawBytes[pOffset + b]);
        }
        mappedSegs++;
      }

      this.pc = entry >= 0x08000000 ? entry : (0x08804000 + entry) >>> 0;
      this.loadedElfName = label;
      this.syscallLogs.unshift(
        `[ELF LOADER] ${label}: ${mappedSegs} PT_LOAD mapeados · Entry ${hex32(this.pc)}`
      );
      return true;
    }

    // Load built-in DBZ Tag Team 256 MIPS32 Boot Kernel Stub
    this.installBuiltInDbzBootStub(label);
    return false;
  }

  private installBuiltInDbzBootStub(label: string) {
    this.loadedElfName = `${label} (Stub MIPS32 DBZ Tag 256)`;
    const base = 0x08804000;
    this.pc = base;
    this.writeAscii(0x08900000, 'disc0:/PSP_GAME/DLC/PERSONAJES/CHAR256_INDEX.BIN');
    this.writeAscii(0x08900080, 'disc0:/PSP_GAME/DLC/MAPAS/MAP_MUSIC_DLC_INDEX.json');

    // Hand-assembled little-endian MIPS32 program:
    // 1. lui $a0, 0x0890 ; ori $a0, $a0, 0x0000 (DLC path)
    // 2. ori $a1, $zero, 0x0001 (O_RDONLY)
    // 3. syscall 0x2010 (HLE sceIoOpen)
    // 4. syscall 0x2001 (HLE sceKernelMaxFreeMemSize -> $v0)
    // 5. sltiu $t0, $zero, 0x0100 (Check 256 roster flag)
    // 6. lui $t1, 0x1800 (256 MB RAM ceiling)
    // 7. lui $a0, 0x0890 ; ori $a0, $a0, 0x0080 (Map/Music path)
    // 8. syscall 0x2010 (HLE sceIoOpen)
    // 9. syscall 0x20FF (HLE Boot OK / Halt)
    const prog: number[] = [
      0x3c040890, // lui $a0, 0x0890
      0x34840000, // ori $a0, $a0, 0x0000
      0x34050001, // ori $a1, $zero, 1
      0x0008040c, // syscall 0x2010 (sceIoOpen)
      0x0008004c, // syscall 0x2001 (sceKernelMaxFreeMemSize)
      0x2c080100, // sltiu $t0, $zero, 0x0100
      0x3c091800, // lui $t1, 0x1800
      0x3c040890, // lui $a0, 0x0890
      0x34840080, // ori $a0, $a0, 0x0080
      0x0008040c, // syscall 0x2010
      0x00083fcc, // syscall 0x20FF (Halt ready)
    ];

    prog.forEach((word, idx) => {
      this.writeU32(base + idx * 4, word);
    });
    this.syscallLogs.unshift(
      `[STUB MIPS32] Programa de arranque Tag Team 256 cargado en ${hex32(base)}`
    );
  }

  public step(maxInstructions = 1) {
    for (let stepIdx = 0; stepIdx < maxInstructions; stepIdx++) {
      if (this.halted) break;
      const word = this.readU32(this.pc);
      const nextPc = (this.pc + 4) >>> 0;
      const op = (word >>> 26) & 0x3f;
      const rs = (word >>> 21) & 0x1f;
      const rt = (word >>> 16) & 0x1f;
      const rd = (word >>> 11) & 0x1f;
      const shamt = (word >>> 6) & 0x1f;
      const funct = word & 0x3f;
      const imm = word & 0xffff;
      const simm = signExt16(imm);

      this.pc = nextPc;
      this.cycles++;

      if (word === 0) {
        this.regs[0] = 0;
        continue;
      }

      if (op === 0x00) {
        switch (funct) {
          case 0x00:
            this.regs[rd] = (this.regs[rt] << shamt) >>> 0;
            break;
          case 0x02:
            this.regs[rd] = (this.regs[rt] >>> shamt) >>> 0;
            break;
          case 0x03:
            this.regs[rd] = ((this.regs[rt] | 0) >> shamt) >>> 0;
            break;
          case 0x08:
            this.pc = this.regs[rs] >>> 0;
            break;
          case 0x09:
            this.regs[rd] = nextPc;
            this.pc = this.regs[rs] >>> 0;
            break;
          case 0x0c: {
            const code = (word >>> 6) & 0xfffff;
            this.handleSyscall(code);
            break;
          }
          case 0x20:
          case 0x21:
            this.regs[rd] = (this.regs[rs] + this.regs[rt]) >>> 0;
            break;
          case 0x22:
          case 0x23:
            this.regs[rd] = (this.regs[rs] - this.regs[rt]) >>> 0;
            break;
          case 0x24:
            this.regs[rd] = (this.regs[rs] & this.regs[rt]) >>> 0;
            break;
          case 0x25:
            this.regs[rd] = (this.regs[rs] | this.regs[rt]) >>> 0;
            break;
          case 0x26:
            this.regs[rd] = (this.regs[rs] ^ this.regs[rt]) >>> 0;
            break;
          case 0x2a:
            this.regs[rd] = (this.regs[rs] | 0) < (this.regs[rt] | 0) ? 1 : 0;
            break;
          case 0x2b:
            this.regs[rd] = (this.regs[rs] >>> 0) < (this.regs[rt] >>> 0) ? 1 : 0;
            break;
        }
      } else {
        switch (op) {
          case 0x02:
            this.pc = ((nextPc & 0xf0000000) | ((word & 0x03ffffff) << 2)) >>> 0;
            break;
          case 0x03:
            this.regs[31] = nextPc;
            this.pc = ((nextPc & 0xf0000000) | ((word & 0x03ffffff) << 2)) >>> 0;
            break;
          case 0x04:
            if (this.regs[rs] === this.regs[rt]) this.pc = (nextPc + simm * 4) >>> 0;
            break;
          case 0x05:
            if (this.regs[rs] !== this.regs[rt]) this.pc = (nextPc + simm * 4) >>> 0;
            break;
          case 0x08:
          case 0x09:
            this.regs[rt] = (this.regs[rs] + simm) >>> 0;
            break;
          case 0x0a:
            this.regs[rt] = (this.regs[rs] | 0) < simm ? 1 : 0;
            break;
          case 0x0b:
            this.regs[rt] = (this.regs[rs] >>> 0) < (imm >>> 0) ? 1 : 0;
            break;
          case 0x0c:
            this.regs[rt] = (this.regs[rs] & imm) >>> 0;
            break;
          case 0x0d:
            this.regs[rt] = (this.regs[rs] | imm) >>> 0;
            break;
          case 0x0f:
            this.regs[rt] = (imm << 16) >>> 0;
            break;
          case 0x20: {
            const b = this.readU8((this.regs[rs] + simm) >>> 0);
            this.regs[rt] = ((b << 24) >> 24) >>> 0;
            break;
          }
          case 0x23:
            this.regs[rt] = this.readU32((this.regs[rs] + simm) >>> 0);
            break;
          case 0x24:
            this.regs[rt] = this.readU8((this.regs[rs] + simm) >>> 0);
            break;
          case 0x28:
            this.writeU8((this.regs[rs] + simm) >>> 0, this.regs[rt]);
            break;
          case 0x2b:
            this.writeU32((this.regs[rs] + simm) >>> 0, this.regs[rt]);
            break;
        }
      }

      this.regs[0] = 0;

      if (this.cycles > 2000 && op === 0 && word === 0) {
        this.halted = true;
        this.haltReason = 'Fin de secuencia / NOP continuo';
      }
    }
  }

  private handleSyscall(code: number) {
    if (code === 0x2001) {
      // sceKernelMaxFreeMemSize
      const userFreeBytes = Math.max(8, this.ramLimitMb - 8) * 1024 * 1024;
      this.regs[2] = userFreeBytes >>> 0; // $v0
      this.syscallLogs.unshift(
        `[SYSCALL sceKernelMaxFreeMemSize] -> $v0=${hex32(userFreeBytes)} (${this.ramLimitMb - 8} MB libres)`
      );
    } else if (code === 0x2010) {
      // sceIoOpen($a0 path, $a1 flags)
      const pathStr = this.readAscii(this.regs[4], 96);
      this.regs[2] = 0x00000003; // fake fd = 3
      this.syscallLogs.unshift(`[SYSCALL sceIoOpen] "${pathStr}" -> fd=3`);
    } else if (code === 0x20ff) {
      this.halted = true;
      this.haltReason = 'HLE Boot OK (Listo para DLC 256 + Combate)';
      this.syscallLogs.unshift('[SYSCALL HLE_BOOT_DONE] Kernel inicializado correctamente.');
    } else {
      this.syscallLogs.unshift(`[SYSCALL 0x${code.toString(16).toUpperCase()}] @ PC=${hex32((this.pc - 4) >>> 0)}`);
    }
    this.syscallLogs = this.syscallLogs.slice(0, 20);
  }

  public getSnapshot(): MipsVmSnapshot {
    const disasmWindow: MipsVmSnapshot['disasmWindow'] = [];
    const startAddr = Math.max(0x08000000, (this.pc - 16) >>> 0);
    for (let i = 0; i < 12; i++) {
      const addr = (startAddr + i * 4) >>> 0;
      const word = this.readU32(addr);
      disasmWindow.push({
        addr,
        word,
        text: disassembleMipsWord(word, addr),
        isCurrent: addr === (this.pc >>> 0),
      });
    }
    return {
      pc: this.pc >>> 0,
      hi: this.hi >>> 0,
      lo: this.lo >>> 0,
      cycles: this.cycles,
      halted: this.halted,
      haltReason: this.haltReason,
      regs: new Uint32Array(this.regs),
      disasmWindow,
      syscallLogs: [...this.syscallLogs],
      loadedElfName: this.loadedElfName,
      ramLimitMb: this.ramLimitMb,
    };
  }
}

export interface PspEmulatorSourceFile {
  path: string;
  title: string;
  language: 'cpp' | 'h' | 'cmake';
  description: string;
  content: string;
}

export function buildPspEmulatorSourceBundle(
  gameId = 'ULUS10537',
  ramLimitMb = 256
): PspEmulatorSourceFile[] {
  const ramHex = `0x${(ramLimitMb * 1024 * 1024).toString(16).toUpperCase().padStart(8, '0')}`;
  const files: PspEmulatorSourceFile[] = [
    {
      path: 'src/psp_allegrex_cpu.h',
      title: 'psp_allegrex_cpu.h (CPU MIPS R4000 Allegrex)',
      language: 'h',
      description: 'Definición de registros CPU Allegrex (GPR 32-bit, HI/LO, PC, estado VFPU y Bus 256 MB).',
      content: `#pragma once
#include <cstdint>
#include <functional>

namespace psp_core {

struct AllegrexState {
  uint32_t gpr[32]{};
  uint32_t pc = 0x08804000;
  uint32_t next_pc = 0x08804004;
  uint32_t hi = 0;
  uint32_t lo = 0;
  uint64_t cycles = 0;
  bool halted = false;
};

class MemoryBus256 {
public:
  virtual ~MemoryBus256() = default;
  virtual uint8_t  read8(uint32_t addr) = 0;
  virtual uint32_t read32(uint32_t addr) = 0;
  virtual void     write8(uint32_t addr, uint8_t val) = 0;
  virtual void     write32(uint32_t addr, uint32_t val) = 0;
};

using SyscallHandler = std::function<void(uint32_t code, AllegrexState& cpu, MemoryBus256& mem)>;

class AllegrexCpu {
public:
  explicit AllegrexCpu(MemoryBus256& mem, SyscallHandler on_syscall);
  void reset(uint32_t entry_pc, uint32_t stack_top);
  void step(int max_cycles);
  const AllegrexState& state() const { return state_; }

private:
  MemoryBus256& mem_;
  SyscallHandler on_syscall_;
  AllegrexState state_{};
};

} // namespace psp_core
`,
    },
    {
      path: 'src/psp_allegrex_cpu.cpp',
      title: 'psp_allegrex_cpu.cpp (Intérprete MIPS32)',
      language: 'cpp',
      description: 'Ciclo Fetch/Decode/Execute MIPS32 con saltos, LUI/ADDIU/ORI, accesos a memoria y trampas SYSCALL HLE.',
      content: `#include "psp_allegrex_cpu.h"

namespace psp_core {

static inline int32_t sign_ext16(uint32_t imm) {
  return static_cast<int16_t>(imm & 0xFFFF);
}

AllegrexCpu::AllegrexCpu(MemoryBus256& mem, SyscallHandler on_syscall)
    : mem_(mem), on_syscall_(std::move(on_syscall)) {}

void AllegrexCpu::reset(uint32_t entry_pc, uint32_t stack_top) {
  state_ = AllegrexState{};
  state_.pc = entry_pc;
  state_.next_pc = entry_pc + 4;
  state_.gpr[29] = stack_top; // $sp
}

void AllegrexCpu::step(int max_cycles) {
  for (int i = 0; i < max_cycles && !state_.halted; ++i) {
    uint32_t word = mem_.read32(state_.pc);
    uint32_t pc_plus_4 = state_.pc + 4;
    state_.pc = pc_plus_4;
    state_.cycles++;

    if (word == 0) continue; // NOP

    uint32_t op    = (word >> 26) & 0x3F;
    uint32_t rs    = (word >> 21) & 0x1F;
    uint32_t rt    = (word >> 16) & 0x1F;
    uint32_t rd    = (word >> 11) & 0x1F;
    uint32_t shamt = (word >> 6)  & 0x1F;
    uint32_t funct = word & 0x3F;
    uint32_t imm   = word & 0xFFFF;
    int32_t  simm  = sign_ext16(imm);

    if (op == 0x00) {
      switch (funct) {
        case 0x00: state_.gpr[rd] = state_.gpr[rt] << shamt; break; // SLL
        case 0x02: state_.gpr[rd] = state_.gpr[rt] >> shamt; break; // SRL
        case 0x08: state_.pc = state_.gpr[rs]; break;               // JR
        case 0x09: state_.gpr[rd] = pc_plus_4; state_.pc = state_.gpr[rs]; break; // JALR
        case 0x0C:
          if (on_syscall_) on_syscall_((word >> 6) & 0xFFFFF, state_, mem_);
          break;
        case 0x21: state_.gpr[rd] = state_.gpr[rs] + state_.gpr[rt]; break; // ADDU
        case 0x23: state_.gpr[rd] = state_.gpr[rs] - state_.gpr[rt]; break; // SUBU
        case 0x24: state_.gpr[rd] = state_.gpr[rs] & state_.gpr[rt]; break; // AND
        case 0x25: state_.gpr[rd] = state_.gpr[rs] | state_.gpr[rt]; break; // OR
        case 0x2B: state_.gpr[rd] = (state_.gpr[rs] < state_.gpr[rt]) ? 1U : 0U; break; // SLTU
        default: break;
      }
    } else {
      switch (op) {
        case 0x02: state_.pc = (pc_plus_4 & 0xF0000000U) | ((word & 0x03FFFFFFU) << 2); break; // J
        case 0x03: state_.gpr[31] = pc_plus_4; state_.pc = (pc_plus_4 & 0xF0000000U) | ((word & 0x03FFFFFFU) << 2); break; // JAL
        case 0x04: if (state_.gpr[rs] == state_.gpr[rt]) state_.pc = pc_plus_4 + (simm * 4); break; // BEQ
        case 0x05: if (state_.gpr[rs] != state_.gpr[rt]) state_.pc = pc_plus_4 + (simm * 4); break; // BNE
        case 0x09: state_.gpr[rt] = state_.gpr[rs] + simm; break; // ADDIU
        case 0x0B: state_.gpr[rt] = (state_.gpr[rs] < imm) ? 1U : 0U; break; // SLTIU (Límite 256)
        case 0x0D: state_.gpr[rt] = state_.gpr[rs] | imm; break;  // ORI
        case 0x0F: state_.gpr[rt] = imm << 16; break;             // LUI
        case 0x23: state_.gpr[rt] = mem_.read32(state_.gpr[rs] + simm); break; // LW
        case 0x2B: mem_.write32(state_.gpr[rs] + simm, state_.gpr[rt]); break; // SW
        default: break;
      }
    }
    state_.gpr[0] = 0;
  }
}

} // namespace psp_core
`,
    },
    {
      path: 'src/psp_memmap_256mb.cpp',
      title: `psp_memmap_256mb.cpp (RAM Mod ${ramLimitMb} MB · 0x08000000)`,
      language: 'cpp',
      description: `Mapa de memoria PSP expandido a ${ramLimitMb} MB (${ramHex}) y soporte VRAM 480x272 para Tag Team 256.`,
      content: `#include "psp_allegrex_cpu.h"
#include <vector>

namespace psp_core {

// Perfil Mod Nativo ${ramLimitMb} MB para ${gameId} (256 Personajes + 46 Mapas + Chibis)
constexpr uint32_t PSP_RAM_BASE = 0x08000000U;
constexpr uint32_t PSP_RAM_SIZE = ${ramHex}U; // ${ramLimitMb} MB
constexpr uint32_t PSP_VRAM_BASE = 0x04000000U;
constexpr uint32_t PSP_VRAM_SIZE = 0x00800000U; // 8 MB VRAM extendida

class PspMemory256 final : public MemoryBus256 {
public:
  PspMemory256()
      : ram_(PSP_RAM_SIZE, 0), vram_(PSP_VRAM_SIZE, 0) {}

  uint8_t read8(uint32_t addr) override {
    uint32_t phys = addr & 0x1FFFFFFFU;
    if (phys >= PSP_RAM_BASE && phys < PSP_RAM_BASE + PSP_RAM_SIZE) {
      return ram_[phys - PSP_RAM_BASE];
    }
    if (phys >= PSP_VRAM_BASE && phys < PSP_VRAM_BASE + PSP_VRAM_SIZE) {
      return vram_[phys - PSP_VRAM_BASE];
    }
    return 0;
  }

  uint32_t read32(uint32_t addr) override {
    return static_cast<uint32_t>(read8(addr)) |
           (static_cast<uint32_t>(read8(addr + 1)) << 8) |
           (static_cast<uint32_t>(read8(addr + 2)) << 16) |
           (static_cast<uint32_t>(read8(addr + 3)) << 24);
  }

  void write8(uint32_t addr, uint8_t val) override {
    uint32_t phys = addr & 0x1FFFFFFFU;
    if (phys >= PSP_RAM_BASE && phys < PSP_RAM_BASE + PSP_RAM_SIZE) {
      ram_[phys - PSP_RAM_BASE] = val;
    } else if (phys >= PSP_VRAM_BASE && phys < PSP_VRAM_BASE + PSP_VRAM_SIZE) {
      vram_[phys - PSP_VRAM_BASE] = val;
    }
  }

  void write32(uint32_t addr, uint32_t val) override {
    write8(addr, val & 0xFF);
    write8(addr + 1, (val >> 8) & 0xFF);
    write8(addr + 2, (val >> 16) & 0xFF);
    write8(addr + 3, (val >> 24) & 0xFF);
  }

  uint32_t max_user_free_bytes() const {
    return PSP_RAM_SIZE - 0x00800000U; // Descuenta 8 MB Kernel PSP
  }

private:
  std::vector<uint8_t> ram_;
  std::vector<uint8_t> vram_;
};

} // namespace psp_core
`,
    },
    {
      path: 'src/psp_hle_sceio_dlc.cpp',
      title: 'psp_hle_sceio_dlc.cpp (HLE sceIoOpen + Redirección DLC 256)',
      language: 'cpp',
      description: 'Despachador de syscalls PSP (Kernel Memory, I/O disc0:/PSP_GAME/DLC/ y lectura de ROSTER_MAP_256.json).',
      content: `#include "psp_allegrex_cpu.h"
#include <string>

namespace psp_core {

static std::string read_cstr(MemoryBus256& mem, uint32_t addr) {
  std::string out;
  for (int i = 0; i < 256; ++i) {
    uint8_t ch = mem.read8(addr + i);
    if (!ch) break;
    out.push_back(static_cast<char>(ch));
  }
  return out;
}

std::string remap_usrdir_to_dlc(const std::string& psp_path) {
  const std::string prefix = "disc0:/PSP_GAME/USRDIR/";
  if (psp_path.rfind(prefix, 0) == 0) {
    return "disc0:/PSP_GAME/DLC/" + psp_path.substr(prefix.size());
  }
  return psp_path;
}

void handle_psp_syscall(uint32_t code, AllegrexState& cpu, MemoryBus256& mem) {
  switch (code) {
    case 0x2001: // sceKernelMaxFreeMemSize() -> $v0
      cpu.gpr[2] = (${ramHex}U - 0x00800000U);
      break;
    case 0x2010: { // sceIoOpen(file, flags, mode)
      std::string raw_path = read_cstr(mem, cpu.gpr[4]);
      std::string dlc_path = remap_usrdir_to_dlc(raw_path);
      // Abrir archivo desde ISO / carpeta local DLC (${gameId})
      (void)dlc_path;
      cpu.gpr[2] = 3; // descriptor válido
      break;
    }
    case 0x2030: // sceDisplaySetFrameBuf (480x272 RGBA8888 / 565)
      cpu.gpr[2] = 0;
      break;
    case 0x20FF:
      cpu.halted = true;
      break;
    default:
      cpu.gpr[2] = 0;
      break;
  }
}

} // namespace psp_core
`,
    },
    {
      path: 'CMakeLists.txt',
      title: 'CMakeLists.txt (Compilación Nativa + WebAssembly)',
      language: 'cmake',
      description: 'Configuración CMake para compilar el núcleo PSP Tag Team 256 MB en Windows/Linux/Android NDK o Emscripten WASM.',
      content: `cmake_minimum_required(VERSION 3.16)
project(psp_tag_team_256_core LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_library(psp_tag_team_core STATIC
  src/psp_allegrex_cpu.cpp
  src/psp_memmap_256mb.cpp
  src/psp_hle_sceio_dlc.cpp
)

target_include_directories(psp_tag_team_core PUBLIC src)

if(EMSCRIPTEN)
  set_target_properties(psp_tag_team_core PROPERTIES
    LINK_FLAGS "-sALLOW_MEMORY_GROWTH=1 -sMAXIMUM_MEMORY=512MB"
  )
endif()
`,
    },
  ];
  return files;
}

export function buildPspEmulatorSourceZip(gameId = 'ULUS10537', ramLimitMb = 256): Blob {
  const files = buildPspEmulatorSourceBundle(gameId, ramLimitMb);
  const enc = new TextEncoder();
  return buildZipBlob(
    files.map((f) => ({
      path: f.path,
      data: enc.encode(f.content),
    }))
  );
}
