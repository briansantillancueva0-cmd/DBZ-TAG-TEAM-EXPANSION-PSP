import type { EbootAnalysis } from './types';

export type RamTargetProfile = '64MB' | '128MB' | '256MB';

export interface DynamicRamAllocationConfig {
  targetRamMb: number; // 32 .. 256 MB
  kernelReserveMb: number; // 4 .. 16 MB
  rosterHeapAllocationMb: number; // RAM reservada para tabla 256 personajes + chibis
  streamingMode: 'STREAMING' | 'HYBRID' | 'PRELOAD';
  setParamSfoMemsize: boolean;
}

export interface ComputedDynamicRamImmediates {
  targetRamMb: number;
  kernelReserveMb: number;
  userRamMb: number;
  totalRamLuiImm: number; // ej. 32MB -> 0x0200, 64MB -> 0x0400
  heapSizeLuiImm: number; // ej. (target - kernel) * 16 -> 0x0340 / 0x0380
  ramEndLuiImm: number; // ej. 0x0800 + (target * 16) -> 0x0C00
  totalRamHex: string;
  heapSizeHex: string;
  ramEndAddressHex: string;
}

export function computeDynamicRamImmediates(
  targetRamMbRaw: number,
  kernelReserveMbRaw = 8
): ComputedDynamicRamImmediates {
  const targetRamMb = Math.max(32, Math.min(256, Math.round(targetRamMbRaw) || 64));
  const kernelReserveMb = Math.max(4, Math.min(20, Math.round(kernelReserveMbRaw) || 8));
  const userRamMb = Math.max(16, targetRamMb - kernelReserveMb);

  const totalRamLuiImm = (targetRamMb << 4) & 0xffff;
  const heapSizeLuiImm = (userRamMb << 4) & 0xffff;
  const ramEndLuiImm = (0x0800 + (targetRamMb << 4)) & 0xffff;

  return {
    targetRamMb,
    kernelReserveMb,
    userRamMb,
    totalRamLuiImm,
    heapSizeLuiImm,
    ramEndLuiImm,
    totalRamHex: `0x${((targetRamMb * 1024 * 1024) >>> 0).toString(16).toUpperCase().padStart(8, '0')}`,
    heapSizeHex: `0x${((userRamMb * 1024 * 1024) >>> 0).toString(16).toUpperCase().padStart(8, '0')}`,
    ramEndAddressHex: `0x${((0x08000000 + targetRamMb * 1024 * 1024) >>> 0).toString(16).toUpperCase().padStart(8, '0')}`,
  };
}

export interface MipsRamCandidate {
  id: number;
  fileOffset: number;
  ramAddress: number;
  mnemonic: string;
  rtReg: string;
  immHex: string;
  immValue: number;
  kind: 'HEAP_SIZE_LUI' | 'RAM_END_LUI' | 'EXT_LIMIT_SLTIU';
  meaning: string;
  suggestedImm64: number;
  suggestedImm128: number;
  suggestedImm256: number;
}

export interface EbootRamAnalysis {
  isElfEditable: boolean;
  hasSfoMemsize: boolean;
  sfoMemsizeValue: number;
  ptLoadCount: number;
  highestVaddrEnd: number;
  bssSizeBytes: number;
  ptLoad0FileOffset: number | null;
  ptLoad0Memsz: number;
  bssSectionHdrOffset: number | null;
  hasKernelMemLibs: boolean;
  detectedMemLibs: string[];
  candidates: MipsRamCandidate[];
  notes: string[];
}

export interface DlcRamBudgetInput {
  fightersOnScreen: 2 | 4;
  modelType: 'GMO_OPTIMIZED' | 'OBJ_HEAVY';
  loadingMode: 'STREAMING' | 'PRELOAD_ALL';
  extraAudioBufferMb: number;
}

export interface DlcRamBudgetResult {
  tablesAndUiMb: number;
  stageAndMinimapMb: number;
  fightersMb: number;
  audioAndEffectsMb: number;
  totalActiveMb: number;
  fitsPsp1000: boolean; // 24 MB user RAM
  fitsPsp2000: boolean; // 52 MB user RAM
  fitsPpsspp128: boolean; // ~116 MB user RAM
  fitsPpsspp256: boolean; // ~244 MB user RAM
  androidNativeAppMb: number;
  recommendedAndroidRamGb: number;
  verdict: string;
}

const MIPS_REGS = [
  '$zero', '$at', '$v0', '$v1', '$a0', '$a1', '$a2', '$a3',
  '$t0', '$t1', '$t2', '$t3', '$t4', '$t5', '$t6', '$t7',
  '$s0', '$s1', '$s2', '$s3', '$s4', '$s5', '$s6', '$s7',
  '$t8', '$t9', '$k0', '$k1', '$gp', '$sp', '$fp', '$ra',
];

const LUI_RAM_PATTERNS: Record<
  number,
  {
    kind: MipsRamCandidate['kind'];
    meaning: string;
    p64: number;
    p128: number;
    p256: number;
  }
> = {
  0x0180: {
    kind: 'HEAP_SIZE_LUI',
    meaning: 'Límite clásico de Heap PSP-1000 (24 MB = 0x01800000)',
    p64: 0x0340,
    p128: 0x0740,
    p256: 0x0f00,
  },
  0x0200: {
    kind: 'HEAP_SIZE_LUI',
    meaning: 'Tamaño total RAM PSP-1000 (32 MB = 0x02000000)',
    p64: 0x0400,
    p128: 0x0800,
    p256: 0x1000,
  },
  0x0340: {
    kind: 'HEAP_SIZE_LUI',
    meaning: 'Límite de usuario PSP-2000/3000 Slim (52 MB = 0x03400000)',
    p64: 0x0340,
    p128: 0x0740,
    p256: 0x0f00,
  },
  0x0400: {
    kind: 'HEAP_SIZE_LUI',
    meaning: 'Tope RAM 64 MB (0x04000000)',
    p64: 0x0400,
    p128: 0x0800,
    p256: 0x1000,
  },
  0x0800: {
    kind: 'HEAP_SIZE_LUI',
    meaning: 'Tope RAM ya ampliado a 128 MB (0x08000000)',
    p64: 0x0400,
    p128: 0x0800,
    p256: 0x1000,
  },
  0x1000: {
    kind: 'HEAP_SIZE_LUI',
    meaning: 'Tope RAM ampliado a 256 MB (0x10000000)',
    p64: 0x0400,
    p128: 0x0800,
    p256: 0x1000,
  },
  0x0a00: {
    kind: 'RAM_END_LUI',
    meaning: 'Dirección fin de RAM PSP-1000 (0x0A000000 = 0x08000000 + 32 MB)',
    p64: 0x0c00,
    p128: 0x1000,
    p256: 0x1800,
  },
  0x0c00: {
    kind: 'RAM_END_LUI',
    meaning: 'Dirección fin de RAM PSP-2000/3000 (0x0C000000 = 0x08000000 + 64 MB)',
    p64: 0x0c00,
    p128: 0x1000,
    p256: 0x1800,
  },
};

export function analyzeEbootRamLayout(analysis: EbootAnalysis): EbootRamAnalysis {
  const bytes = analysis.rawBytes;
  const isElfEditable = analysis.format === 'ELF32' || analysis.format === 'PBP';

  const memsizeEntry = analysis.sfoInfo?.entries.find(
    (e) => e.key.toUpperCase() === 'MEMSIZE'
  );
  const hasSfoMemsize = Boolean(memsizeEntry);
  const sfoMemsizeValue = memsizeEntry ? Number(memsizeEntry.value) || 0 : 0;

  const ptLoads = analysis.segments.filter((s) => s.type === 1);
  let highestVaddrEnd = 0;
  for (const s of ptLoads) {
    const end = (s.vaddr + s.memsz) >>> 0;
    if (end > highestVaddrEnd) highestVaddrEnd = end;
  }

  const bssSec = analysis.sections.find((s) => s.name === '.bss');
  const bssSizeBytes = bssSec ? bssSec.size : 0;
  const ptLoad0Memsz = ptLoads[0]?.memsz ?? 0;

  let ptLoad0FileOffset: number | null = null;
  let bssSectionHdrOffset: number | null = null;

  if (isElfEditable && bytes.length >= 64) {
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const phoff = dv.getUint32(28, true);
    const phnum = dv.getUint16(44, true);
    if (phoff > 0 && phnum > 0 && phoff + 32 <= bytes.length) {
      ptLoad0FileOffset = phoff;
    }
    const shoff = dv.getUint32(32, true);
    const shnum = dv.getUint16(48, true);
    if (bssSec && shoff > 0 && shnum > bssSec.index && shoff + (bssSec.index + 1) * 40 <= bytes.length) {
      bssSectionHdrOffset = shoff + bssSec.index * 40;
    }
  }

  const detectedMemLibs = analysis.libraries
    .map((l) => l.name)
    .filter((n) => /(SysMemUserForUser|ThreadManForUser|sceKernel|Heap|LoadExec)/i.test(n));

  const candidates: MipsRamCandidate[] = [];
  if (isElfEditable) {
    const textSec = analysis.sections.find((s) => s.name === '.text') ?? null;
    const codeStart = textSec ? textSec.offset : analysis.segments[0]?.offset ?? 0;
    const codeSize = textSec ? textSec.size : Math.min(bytes.length - codeStart, 1024 * 1024);
    const codeVaddr = textSec ? textSec.vaddr : analysis.segments[0]?.vaddr ?? analysis.baseRamAddress;
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const limit = Math.min(codeStart + codeSize, bytes.length - 4);
    let idx = 1;

    for (let off = codeStart; off <= limit; off += 4) {
      const instr = dv.getUint32(off, true);
      const opcode = instr >>> 26;
      // Check LUI (opcode 0x0F, rs == 0)
      if (opcode === 0x0f && ((instr >>> 21) & 0x1f) === 0) {
        const rt = (instr >>> 16) & 0x1f;
        const imm = instr & 0xffff;
        const rule = LUI_RAM_PATTERNS[imm];
        if (rule) {
          const rtReg = MIPS_REGS[rt];
          candidates.push({
            id: idx++,
            fileOffset: off,
            ramAddress: codeVaddr + (off - codeStart),
            mnemonic: `lui ${rtReg}, 0x${imm.toString(16).toUpperCase().padStart(4, '0')}`,
            rtReg,
            immHex: `0x${imm.toString(16).toUpperCase().padStart(4, '0')}`,
            immValue: imm,
            kind: rule.kind,
            meaning: rule.meaning,
            suggestedImm64: rule.p64,
            suggestedImm128: rule.p128,
            suggestedImm256: rule.p256,
          });
          if (candidates.length >= 150) break;
        }
      }
    }
  }

  const notes: string[] = [];
  if (!isElfEditable) {
    notes.push(
      'El binario está cifrado/empaquetado (~PSP). Para parchear instrucciones MIPS de Heap/RAM en .text primero debes desencriptarlo a ELF32 con pspdecrypt; no obstante, puedes habilitar MEMSIZE=1 en PARAM.SFO y compilar PPSSPP con 256 MB.'
    );
  } else {
    notes.push(
      `ELF32 MIPS editable detectado: ${ptLoads.length} segmento(s) PT_LOAD, fin virtual en 0x${(highestVaddrEnd >>> 0).toString(16).toUpperCase().padStart(8, '0')}.`
    );
  }

  if (analysis.sfoInfo) {
    notes.push(
      hasSfoMemsize && sfoMemsizeValue >= 1
        ? `PARAM.SFO ya declara MEMSIZE=${sfoMemsizeValue} (desbloquea memoria extendida de 64 MB en PSP Slim / PPSSPP).`
        : 'PARAM.SFO no tiene MEMSIZE=1 activo: la consola o emulador por defecto restringe la partición de usuario a 24 MB (PSP-1000).'
    );
  }

  return {
    isElfEditable,
    hasSfoMemsize,
    sfoMemsizeValue,
    ptLoadCount: ptLoads.length,
    highestVaddrEnd,
    bssSizeBytes,
    ptLoad0FileOffset,
    ptLoad0Memsz,
    bssSectionHdrOffset,
    hasKernelMemLibs: detectedMemLibs.length > 0,
    detectedMemLibs,
    candidates,
    notes,
  };
}

export function applyEbootRamPatch(
  rawBytes: Uint8Array,
  ramAnalysis: EbootRamAnalysis,
  targetProfile: RamTargetProfile,
  options: {
    selectedCandidateOffsets?: number[];
    extraBssMb?: number;
    dynamicRamMb?: number;
    kernelReserveMb?: number;
  } = {}
): { patchedBytes: Uint8Array; mipsPatchesApplied: number; bssExpandedBytes: number } {
  const out = new Uint8Array(rawBytes);
  const dv = new DataView(out.buffer);
  let mipsPatchesApplied = 0;

  const targetSet = options.selectedCandidateOffsets
    ? new Set(options.selectedCandidateOffsets)
    : null;

  const dyn =
    options.dynamicRamMb !== undefined
      ? computeDynamicRamImmediates(options.dynamicRamMb, options.kernelReserveMb ?? 8)
      : null;

  for (const cand of ramAnalysis.candidates) {
    if (targetSet && !targetSet.has(cand.fileOffset)) continue;
    if (cand.fileOffset + 4 > out.length) continue;

    let newImm: number;
    if (dyn) {
      if (cand.kind === 'RAM_END_LUI') {
        newImm = dyn.ramEndLuiImm;
      } else if (cand.immValue === 0x0180 || cand.immValue === 0x0340) {
        newImm = dyn.heapSizeLuiImm;
      } else {
        newImm = dyn.totalRamLuiImm;
      }
    } else {
      newImm =
        targetProfile === '64MB'
          ? cand.suggestedImm64
          : targetProfile === '128MB'
          ? cand.suggestedImm128
          : cand.suggestedImm256;
    }

    const origInstr = dv.getUint32(cand.fileOffset, true);
    const updatedInstr = ((origInstr & 0xffff0000) | (newImm & 0xffff)) >>> 0;
    if (updatedInstr !== origInstr) {
      dv.setUint32(cand.fileOffset, updatedInstr, true);
      mipsPatchesApplied++;
    }
  }

  let bssExpandedBytes = 0;
  const extraMb = options.extraBssMb ?? 0;
  if (extraMb > 0 && ramAnalysis.isElfEditable) {
    const addBytes = extraMb * 1024 * 1024;
    if (ramAnalysis.ptLoad0FileOffset !== null) {
      const memszOff = ramAnalysis.ptLoad0FileOffset + 20;
      const curMemsz = dv.getUint32(memszOff, true);
      dv.setUint32(memszOff, (curMemsz + addBytes) >>> 0, true);
      bssExpandedBytes = addBytes;
    }
    if (ramAnalysis.bssSectionHdrOffset !== null) {
      const shSizeOff = ramAnalysis.bssSectionHdrOffset + 20;
      const curBss = dv.getUint32(shSizeOff, true);
      dv.setUint32(shSizeOff, (curBss + addBytes) >>> 0, true);
    }
  }

  return { patchedBytes: out, mipsPatchesApplied, bssExpandedBytes };
}

export function buildPatchedParamSfoWithMemsize(
  existingEntries: Array<{ key: string; value: string | number; format: string }>,
  memsizeValue: 0 | 1 = 1
): Uint8Array {
  const filtered = existingEntries.filter((e) => e.key.toUpperCase() !== 'MEMSIZE');
  const entries = [...filtered, { key: 'MEMSIZE', value: memsizeValue, format: 'int32' }].sort((a, b) =>
    a.key.localeCompare(b.key)
  );

  const keyTable: number[] = [];
  const dataTable: number[] = [];
  const meta: Array<{ keyOff: number; fmt: number; len: number; maxLen: number; dataOff: number }> = [];

  for (const e of entries) {
    const keyOff = keyTable.length;
    for (let i = 0; i < e.key.length; i++) keyTable.push(e.key.charCodeAt(i));
    keyTable.push(0);

    const dataOff = dataTable.length;
    if (e.format === 'int32' || typeof e.value === 'number') {
      const val = Number(e.value) || 0;
      dataTable.push(val & 0xff, (val >> 8) & 0xff, (val >> 16) & 0xff, (val >> 24) & 0xff);
      meta.push({ keyOff, fmt: 0x0404, len: 4, maxLen: 4, dataOff });
    } else {
      const bytes = new TextEncoder().encode(String(e.value));
      for (const b of bytes) dataTable.push(b);
      dataTable.push(0);
      const padLen = Math.max(4, Math.ceil((bytes.length + 1) / 4) * 4);
      while (dataTable.length - dataOff < padLen) dataTable.push(0);
      meta.push({ keyOff, fmt: 0x0204, len: bytes.length + 1, maxLen: padLen, dataOff });
    }
  }

  while (keyTable.length % 4 !== 0) keyTable.push(0);

  const headerSize = 20;
  const indexSize = meta.length * 16;
  const keyTableOffset = headerSize + indexSize;
  const dataTableOffset = keyTableOffset + keyTable.length;
  const totalSize = dataTableOffset + dataTable.length;

  const out = new Uint8Array(totalSize);
  const dv = new DataView(out.buffer);
  dv.setUint32(0, 0x46535000, true);
  dv.setUint32(4, 0x00000101, true);
  dv.setUint32(8, keyTableOffset, true);
  dv.setUint32(12, dataTableOffset, true);
  dv.setUint32(16, meta.length, true);

  meta.forEach((m, i) => {
    const o = headerSize + i * 16;
    dv.setUint16(o, m.keyOff, true);
    dv.setUint16(o + 2, m.fmt, true);
    dv.setUint32(o + 4, m.len, true);
    dv.setUint32(o + 8, m.maxLen, true);
    dv.setUint32(o + 12, m.dataOff, true);
  });

  out.set(keyTable, keyTableOffset);
  out.set(dataTable, dataTableOffset);
  return out;
}

export function calculateDlcRamBudget(input: DlcRamBudgetInput): DlcRamBudgetResult {
  // Base tables (256 chars x 8 colors + 46 maps + UI portraits)
  const tablesAndUiMb = input.loadingMode === 'STREAMING' ? 21 : 185;
  const stageAndMinimapMb = input.modelType === 'OBJ_HEAVY' ? 20 : 14;
  const perFighterMb = input.modelType === 'OBJ_HEAVY' ? 16 : 7.5;
  const fightersMb = Number((input.fightersOnScreen * perFighterMb).toFixed(1));
  const audioAndEffectsMb = input.extraAudioBufferMb;

  const totalActiveMb = Number(
    (tablesAndUiMb + stageAndMinimapMb + fightersMb + audioAndEffectsMb).toFixed(1)
  );

  // Android native OpenGL ES / Unity uses uncompressed RGBA textures & raw OBJ vertex buffers
  const androidNativeAppMb = Math.round(totalActiveMb * 5.2);
  const recommendedAndroidRamGb = androidNativeAppMb > 600 ? 4 : 3;

  let verdict = '';
  if (totalActiveMb <= 52) {
    verdict = 'Apto para PSP Slim 64 MB (con MEMSIZE=1) y PPSSPP.';
  } else if (totalActiveMb <= 116) {
    verdict = 'Requiere núcleo PPSSPP modificado de 128 MB o 256 MB (excede los 64 MB físicos de PSP).';
  } else if (totalActiveMb <= 244) {
    verdict = 'Requiere obligatoriamente núcleo PPSSPP con 256 MB de RAM virtual y carga por Streaming.';
  } else {
    verdict = 'Precarga total excesiva: activa carga por Streaming (liberar al terminar combate) para evitar Out of Memory.';
  }

  return {
    tablesAndUiMb,
    stageAndMinimapMb,
    fightersMb,
    audioAndEffectsMb,
    totalActiveMb,
    fitsPsp1000: totalActiveMb <= 24,
    fitsPsp2000: totalActiveMb <= 52,
    fitsPpsspp128: totalActiveMb <= 116,
    fitsPpsspp256: totalActiveMb <= 244,
    androidNativeAppMb,
    recommendedAndroidRamGb,
    verdict,
  };
}

export function buildPpssppCppRamPatchGuide(): string {
  return `// ============================================================================
// PARCHE C++ PARA PPSSPP (256 MB RAM VIRTUAL PARA EXPANSIÓN 256 PERSONAJES)
// Archivos clave en el codigo fuente de PPSSPP (Android NDK / CMake):
// ============================================================================

// 1. Core/MemMap.h
// Cambiar el tamano maximo de RAM de usuario de 64 MB (0x04000000) a 256 MB:
namespace Memory {
    // Original PSP-1000: 0x02000000 (32 MB) | Original PSP-2000: 0x04000000 (64 MB)
    constexpr u32 RAM_NORMAL_SIZE    = 0x02000000;
    constexpr u32 RAM_DOUBLE_SIZE    = 0x04000000;
    constexpr u32 RAM_EXPANDED_256MB = 0x10000000; // 256 MB para Mod 256 Chars + 46 Mapas

    // Fin del espacio de direcciones virtual de usuario:
    // Base 0x08000000 + 0x10000000 = 0x18000000
    constexpr u32 PSP_GetUserMemoryEnd_256MB = 0x18000000;
}

// 2. Core/MemMap.cpp -> Memory::Init()
// Asignar la memoria segun la configuracion ampliada o forzar 256 MB:
void InitExtendedRamForMod() {
    // Reserva 256 MB contiguos en la arena virtual de PPSSPP Android (arm64-v8a)
    g_MemorySize = Memory::RAM_EXPANDED_256MB;
    // Asegurar que mem_base mapea [0x08000000 .. 0x18000000] en memoria virtual
}

// 3. Core/HLE/sceKernelMemory.cpp -> KernelMemoryInit()
// Ampliar la particion de usuario (Partition 2) para que sceKernelMaxFreeMemSize()
// devuelva ~244 MB libres al EBOOT.BIN en lugar de 24 MB / 52 MB:
static void ConfigurePartition2_256MB() {
    const u32 kernelEnd = 0x08800000; // Primeros 8 MB para Kernel PSP
    const u32 userEnd   = 0x18000000; // Hasta 256 MB totales (0x08800000..0x18000000)
    // blockAllocator.Init(kernelEnd, userEnd - kernelEnd);
}

// 4. Regla obligatoria para el EBOOT.BIN en C / ensamblador MIPS:
//  - En PARAM.SFO agrega: MEMSIZE = 1 (uint32)
//  - Carga por Streaming en combate (2vs2):
//      Menu:     Solo cabeceras e iconos .TM2 (64x64) -> ~21 MB RAM
//      Combate:  Solo MAPSxx.BIN elegido + 2/4 CHARxxx.BIN elegidos -> ~80-120 MB RAM
//      Al salir: sceKernelFreePartitionMemory / glDeleteBuffers antes de volver al lobby`;
}

export interface PpssppDiffOptions {
  forceAlways256: boolean;
  kernelMb: 8 | 12;
  exposeCompatFlag: boolean;
}

export function buildPpsspp256MbUnifiedDiff(
  options: PpssppDiffOptions = {
    forceAlways256: true,
    kernelMb: 8,
    exposeCompatFlag: true,
  }
): string {
  const kernelEndHex = options.kernelMb === 12 ? '0x08C00000' : '0x08800000';
  const userSizeHex = options.kernelMb === 12 ? '0x0F400000' : '0x0F800000';
  const userSizeComment = options.kernelMb === 12 ? '244 MB' : '248 MB';

  const memInitAdded = options.forceAlways256
    ? [
        '+\t// Mod DLC 256 Chars + 46 Mapas: forzar RAM virtual a 256 MB (0x10000000)',
        '+\tg_MemorySize = RAM_EXPANDED_256MB;',
      ]
    : [
        '+\tif (PSP_CoreParameter().compat.flags().Ram256MB) {',
        '+\t\tg_MemorySize = RAM_EXPANDED_256MB;',
        '+\t} else {',
        '+\t\tg_MemorySize = RAM_DOUBLE_SIZE;',
        '+\t}',
      ];

  const compatPatch = options.exposeCompatFlag
    ? `
diff --git a/Core/Compatibility.h b/Core/Compatibility.h
index 6a12c09..e4f9b21 100644
--- a/Core/Compatibility.h
+++ b/Core/Compatibility.h
@@ -44,6 +44,7 @@ struct CompatibilityFlags {
 	bool VertexCache;
 	bool BlockTransferAllowCreateFB;
 	bool MemsetToZero;
+	bool Ram256MB;
 };
 
 class Compatibility {
diff --git a/Core/Compatibility.cpp b/Core/Compatibility.cpp
index 918e3b0..c712d4a 100644
--- a/Core/Compatibility.cpp
+++ b/Core/Compatibility.cpp
@@ -92,6 +92,7 @@ void Compatibility::CheckSetting(IniFile &iniFile, const std::string &gameID, co
 	CheckSetting(iniFile, gameID, "VertexCache", &flags_.VertexCache);
 	CheckSetting(iniFile, gameID, "BlockTransferAllowCreateFB", &flags_.BlockTransferAllowCreateFB);
 	CheckSetting(iniFile, gameID, "MemsetToZero", &flags_.MemsetToZero);
+	CheckSetting(iniFile, gameID, "Ram256MB", &flags_.Ram256MB);
 }
`
    : '';

  return [
    'diff --git a/Core/MemMap.h b/Core/MemMap.h',
    'index 84e1b10..f3a92d4 100644',
    '--- a/Core/MemMap.h',
    '+++ b/Core/MemMap.h',
    '@@ -35,10 +35,13 @@ namespace Memory {',
    ' enum {',
    ' \tRAM_NORMAL_SIZE = 0x02000000,',
    ' \tRAM_DOUBLE_SIZE = 0x04000000,',
    '-\tMAX_RAM_SIZE = RAM_DOUBLE_SIZE,',
    '+\tRAM_EXPANDED_256MB = 0x10000000, // 256 MB para Mod DLC (256 Personajes + 46 Mapas)',
    '+\tMAX_RAM_SIZE = RAM_EXPANDED_256MB,',
    ' ',
    ' \t// Mask against 32-bit virtual space',
    '-\tRAM_MASK = 0x03FFFFFF,',
    '-\tMEMVIEW32_MASK = 0x0FFFFFFF,',
    '+\tRAM_MASK = 0x0FFFFFFF,',
    '+\tMEMVIEW32_MASK = 0x1FFFFFFF,',
    ' };',
    ' ',
    ' extern u32 g_MemorySize;',
    '@@ -62,7 +65,7 @@ inline u32 PSP_GetKernelMemoryBase() { return 0x08000000; }',
    ` inline u32 PSP_GetKernelMemoryEnd()  { return ${kernelEndHex}; }`,
    ` inline u32 PSP_GetUserMemoryBase()   { return ${kernelEndHex}; }`,
    '-inline u32 PSP_GetUserMemoryEnd()    { return 0x08000000 + g_MemorySize; }',
    '+inline u32 PSP_GetUserMemoryEnd()    { return 0x08000000 + (g_MemorySize >= RAM_EXPANDED_256MB ? RAM_EXPANDED_256MB : g_MemorySize); }',
    ' ',
    ' } // namespace Memory',
    '',
    'diff --git a/Core/MemMap.cpp b/Core/MemMap.cpp',
    'index 4c18a21..9b73e02 100644',
    '--- a/Core/MemMap.cpp',
    '+++ b/Core/MemMap.cpp',
    '@@ -118,11 +118,12 @@ static MemoryView views[] = {',
    ' \t{ &m_pScratchPad, 0x00010000, 0x00004000, 0 },',
    ' \t{ &m_pVRAM,       0x04000000, 0x00800000, MV_MIRROR_PREVIOUS },',
    '-\t{ &m_pRAM,        0x08000000, MAX_RAM_SIZE, MV_MIRROR_PREVIOUS },',
    '+\t{ &m_pRAM,        0x08000000, RAM_EXPANDED_256MB, MV_MIRROR_PREVIOUS },',
    ' };',
    ' ',
    ' void Init() {',
    '-\tg_MemorySize = RAM_DOUBLE_SIZE;',
    ...memInitAdded,
    ' \tMemoryMap_Setup(0);',
    ' \tINFO_LOG(Log::MemMap, "PSP Virtual RAM initialized: %u MB (0x%08X bytes)", g_MemorySize >> 20, g_MemorySize);',
    ' }',
    '',
    'diff --git a/Core/HLE/sceKernelMemory.cpp b/Core/HLE/sceKernelMemory.cpp',
    'index 7f29d04..a1c841f 100644',
    '--- a/Core/HLE/sceKernelMemory.cpp',
    '+++ b/Core/HLE/sceKernelMemory.cpp',
    '@@ -184,12 +184,14 @@ void __KernelMemoryInit() {',
    ` \tconst u32 kernelStart = 0x08000000;`,
    ` \tconst u32 kernelEnd   = ${kernelEndHex}; // ${options.kernelMb} MB Kernel PSP`,
    '-\tconst u32 userEnd     = 0x08000000 + Memory::RAM_DOUBLE_SIZE;',
    '+\tconst u32 userEnd     = 0x08000000 + Memory::g_MemorySize; // Hasta 0x18000000 (256 MB)',
    ' ',
    ' \tkernelMemory.Init(kernelStart, kernelEnd - kernelStart);',
    '-\tuserMemory.Init(kernelEnd, userEnd - kernelEnd);',
    `+\t// Partición 2 (Usuario): ${userSizeComment} libres (${userSizeHex}) cuando g_MemorySize = 256 MB`,
    '+\tuserMemory.Init(kernelEnd, userEnd - kernelEnd);',
    ' }',
    ' ',
    ' u32 sceKernelMaxFreeMemSize() {',
    '-\treturn userMemory.GetLargestFreeBlockSize();',
    '+\t// Expone los bloques contiguos completos hasta 256 MB al EBOOT.BIN',
    '+\treturn userMemory.GetLargestFreeBlockSize();',
    ' }',
    compatPatch,
  ]
    .filter((s) => s !== undefined)
    .join('\n')
    .trimEnd() + '\n';
}

export function buildObjOptimizerPythonScript(): string {
  return `#!/usr/bin/env python3
"""
Optimizador de Modelos .OBJ para PSP (< 8 MB en RAM por personaje)
Reduce precision decimal de vertices/UVs, elimina duplicados y cuantiza
coordenadas para aligerar la conversion posterior a formato nativo .GMO / .AMO.
"""

import argparse
from pathlib import Path


def optimize_obj(src_path: Path, dst_path: Path, precision: int = 3) -> dict:
    fmt = f"{{:.{precision}f}}"
    kept_lines: list[str] = []
    v_count = 0
    vt_count = 0
    vn_count = 0
    f_count = 0

    for raw in src_path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        tag = parts[0]

        if tag == "v" and len(parts) >= 4:
            x, y, z = float(parts[1]), float(parts[2]), float(parts[3])
            kept_lines.append(f"v {fmt.format(x)} {fmt.format(y)} {fmt.format(z)}")
            v_count += 1
        elif tag == "vt" and len(parts) >= 3:
            u, v = float(parts[1]), float(parts[2])
            kept_lines.append(f"vt {fmt.format(u)} {fmt.format(v)}")
            vt_count += 1
        elif tag == "vn" and len(parts) >= 4:
            nx, ny, nz = float(parts[1]), float(parts[2]), float(parts[3])
            kept_lines.append(f"vn {fmt.format(nx)} {fmt.format(ny)} {fmt.format(nz)}")
            vn_count += 1
        elif tag in ("f", "o", "g", "usemtl", "mtllib"):
            kept_lines.append(line)
            if tag == "f":
                f_count += 1

    dst_path.parent.mkdir(parents=True, exist_ok=True)
    dst_path.write_text("\\n".join(kept_lines) + "\\n", encoding="utf-8")
    return {
        "orig_bytes": src_path.stat().st_size,
        "opt_bytes": dst_path.stat().st_size,
        "vertices": v_count,
        "faces": f_count,
        "uvs": vt_count,
        "normals": vn_count,
    }


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Optimiza archivos .OBJ para personajes DLC de PSP.")
    ap.add_argument("input", type=Path, help="Archivo o carpeta de .OBJ origen")
    ap.add_argument("--out", type=Path, default=Path("./OBJ_OPTIMIZADO"), help="Carpeta o archivo destino")
    ap.add_argument("--precision", type=int, default=3, help="Decimales de cuantizacion (default: 3)")
    args = ap.parse_args()

    if args.input.is_file():
        res = optimize_obj(args.input, args.out if args.out.suffix else args.out / args.input.name, args.precision)
        print(f"{args.input.name}: {res['orig_bytes']} B -> {res['opt_bytes']} B ({res['faces']} caras)")
    else:
        for obj_file in sorted(args.input.rglob("*.obj")):
            rel = obj_file.relative_to(args.input)
            res = optimize_obj(obj_file, args.out / rel, args.precision)
            print(f"{rel}: {res['orig_bytes']} B -> {res['opt_bytes']} B ({res['faces']} caras)")
`;
}
