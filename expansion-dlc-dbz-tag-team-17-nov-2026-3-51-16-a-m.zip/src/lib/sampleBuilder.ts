// Generates a genuine, spec-compliant synthetic PSP ELF32 (MIPS Allegrex) and mini ISO 9660
// test image in memory containing PARAM.SFO, EBOOT.BIN, PACKFILE.BIN, and real-signature USRDIR assets
// (Characters .GMO, Maps .MAP, Textures .GIM, Music .AT3, Minimaps .GIM) plus Spanish & Shift-JIS strings.

function writeStr(buf: Uint8Array, off: number, str: string) {
  for (let i = 0; i < str.length; i++) {
    buf[off + i] = str.charCodeAt(i) & 0xff;
  }
}

function writeWin1252(buf: Uint8Array, off: number, str: string) {
  for (let i = 0; i < str.length; i++) {
    buf[off + i] = str.charCodeAt(i) & 0xff;
  }
}

export function buildSamplePspElf(): Uint8Array {
  const totalSize = 0x980;
  const buf = new Uint8Array(totalSize);
  const view = new DataView(buf.buffer);
  const baseVram = 0x08804000;

  // ELF Header
  buf[0] = 0x7f;
  buf[1] = 0x45;
  buf[2] = 0x4c;
  buf[3] = 0x46;
  buf[4] = 1;
  buf[5] = 1;
  buf[6] = 1;
  view.setUint16(16, 2, true);
  view.setUint16(18, 8, true);
  view.setUint32(20, 1, true);
  view.setUint32(24, baseVram + 0x100, true);
  view.setUint32(28, 0x34, true);
  view.setUint32(32, 0x7e0, true);
  view.setUint32(36, 0x10a23001, true);
  view.setUint16(40, 52, true);
  view.setUint16(42, 32, true);
  view.setUint16(44, 1, true);
  view.setUint16(46, 40, true);
  view.setUint16(48, 8, true);
  view.setUint16(50, 7, true);

  // Program Header
  view.setUint32(0x34, 1, true);
  view.setUint32(0x38, 0x100, true);
  view.setUint32(0x3c, baseVram + 0x100, true);
  view.setUint32(0x40, 0x240, true);
  view.setUint32(0x44, 0x5c0, true);
  view.setUint32(0x48, 0x1200, true);
  view.setUint32(0x4c, 7, true);
  view.setUint32(0x50, 0x10, true);

  // .text MIPS instructions
  const encodeJal = (targetAddr: number) => (0x0c000000 | ((targetAddr >>> 2) & 0x03ffffff)) >>> 0;
  const encodeLui = (rt: number, imm: number) => (0x3c000000 | (rt << 16) | (imm & 0xffff)) >>> 0;
  const encodeAddiu = (rs: number, rt: number, imm: number) =>
    (0x24000000 | (rs << 21) | (rt << 16) | (imm & 0xffff)) >>> 0;

  const subInit = baseVram + 0x140;
  const subLoop = baseVram + 0x180;
  const subLoadAsset = baseVram + 0x1c0;

  view.setUint32(0x100, encodeJal(subInit), true);
  view.setUint32(0x104, 0x00000000, true);
  view.setUint32(0x108, encodeLui(4, 0x0880), true);
  view.setUint32(0x10c, encodeAddiu(4, 4, 0x4300), true);
  view.setUint32(0x110, encodeJal(subLoadAsset), true);
  view.setUint32(0x114, 0x00000000, true);
  view.setUint32(0x118, encodeJal(subLoop), true);
  view.setUint32(0x11c, 0x00000000, true);

  view.setUint32(0x140, encodeLui(5, 0x0880), true);
  view.setUint32(0x144, encodeAddiu(5, 5, 0x4330), true);
  view.setUint32(0x148, 0x03e00008, true);
  view.setUint32(0x14c, 0x00000000, true);

  view.setUint32(0x180, encodeJal(subLoadAsset), true);
  view.setUint32(0x184, 0x00000000, true);
  view.setUint32(0x188, 0x03e00008, true);
  view.setUint32(0x18c, 0x00000000, true);

  view.setUint32(0x1c0, encodeLui(6, 0x0880), true);
  view.setUint32(0x1c4, encodeAddiu(6, 6, 0x4368), true);
  view.setUint32(0x1c8, 0x03e00008, true);
  view.setUint32(0x1cc, 0x00000000, true);

  // Límites MIPS de ejemplo para verificación DLC (sltiu $v0, $a0, 0x46 / 0x4C / 0x10)
  const encodeSltiu = (rs: number, rt: number, imm: number) =>
    (0x2c000000 | (rs << 21) | (rt << 16) | (imm & 0xffff)) >>> 0;
  view.setUint32(0x1d0, encodeSltiu(4, 2, 0x46), true); // 70 personajes base -> cambiar a 0xFF
  view.setUint32(0x1d4, encodeSltiu(4, 2, 0x4c), true); // 76 personajes base -> cambiar a 0xFF
  view.setUint32(0x1d8, encodeSltiu(4, 2, 0x10), true); // 16 mapas base -> cambiar a 0x2E
  view.setUint32(0x1dc, 0x03e00008, true);
  view.setUint32(0x1e0, 0x00000000, true);

  // Instrucciones LUI de límite de Heap/RAM en .text (24 MB / 64 MB / Fin RAM)
  view.setUint32(0x1e4, encodeLui(4, 0x0180), true); // lui $a0, 0x0180 (24 MB heap)
  view.setUint32(0x1e8, encodeLui(5, 0x0400), true); // lui $a1, 0x0400 (64 MB cap)
  view.setUint32(0x1ec, encodeLui(3, 0x0a00), true); // lui $v1, 0x0A00 (fin RAM 32 MB)
  view.setUint32(0x1f0, 0x03e00008, true);
  view.setUint32(0x1f4, 0x00000000, true);

  // .rodata.sceModuleInfo
  view.setUint16(0x240, 0x0000, true);
  buf[0x242] = 1;
  buf[0x243] = 1;
  writeStr(buf, 0x244, 'SamplePSPModule');
  view.setUint32(0x260, baseVram + 0x670, true);
  view.setUint32(0x264, baseVram + 0x280, true);
  view.setUint32(0x268, baseVram + 0x280, true);
  view.setUint32(0x26c, baseVram + 0x280, true);
  view.setUint32(0x270, baseVram + 0x2e4, true);

  // .rodata strings (paths + Spanish Win-1252 text + Shift-JIS text + SDK libs)
  writeStr(buf, 0x300, 'disc0:/PSP_GAME/USRDIR/PACKFILE.BIN\0');
  writeStr(buf, 0x330, 'disc0:/PSP_GAME/USRDIR/CHARA/HERO_01.GMO\0');
  writeStr(buf, 0x360, 'disc0:/PSP_GAME/USRDIR/MAP/STAGE_01.MAP\0');
  writeStr(buf, 0x390, 'disc0:/PSP_GAME/USRDIR/MINIMAP/RADAR_01.GIM\0');
  writeStr(buf, 0x3c4, 'disc0:/PSP_GAME/USRDIR/TEX/UI_ATLAS.GIM\0');
  writeStr(buf, 0x3f4, 'disc0:/PSP_GAME/USRDIR/BGM/THEME_01.AT3\0');
  writeStr(buf, 0x424, 'ms0:/PSP/SAVEDATA/ULES99999/PARAM.SFO\0');
  writeWin1252(buf, 0x454, '¡Misión iniciada! Héroe en España\0');
  // Shift-JIS sample "ステージ" (0x83 0x58 0x83 0x65 0x81 0x5B 0x83 0x57)
  buf.set([0x83, 0x58, 0x83, 0x65, 0x81, 0x5b, 0x83, 0x57, 0x00], 0x480);
  writeStr(buf, 0x494, 'DEBUG: Allegrex Engine Initialized OK\0');
  writeStr(buf, 0x4c0, 'sceDisplay\0');
  writeStr(buf, 0x4ce, 'sceCtrl\0');
  writeStr(buf, 0x4d8, 'sceIoFileMgrForUser\0');
  writeStr(buf, 0x4f0, 'sceGe_user\0');
  writeStr(buf, 0x4fe, 'sceAtrac3plus\0');
  // Rutas DLC de expansión terminadas en 0x00 dentro de .rodata (0x300..0x660)
  writeStr(buf, 0x5b0, 'disc0:/PSP_GAME/DLC/CHAR%03d.BIN\0');
  writeStr(buf, 0x5d4, 'disc0:/PSP_GAME/DLC/MAPS%02d.BIN\0');
  writeStr(buf, 0x5f8, 'disc0:/PSP_GAME/DLC/BGM%03d.AT3\0');

  // .lib.stub
  const stubs = [
    { nameOff: 0x4c0, nids: 4, stubOff: 0x200 },
    { nameOff: 0x4ce, nids: 3, stubOff: 0x210 },
    { nameOff: 0x4d8, nids: 8, stubOff: 0x220 },
    { nameOff: 0x4f0, nids: 6, stubOff: 0x230 },
    { nameOff: 0x4fe, nids: 5, stubOff: 0x238 },
  ];
  stubs.forEach((st, i) => {
    const o = 0x280 + i * 20;
    view.setUint32(o, baseVram + st.nameOff, true);
    buf[o + 4] = 0;
    buf[o + 5] = 1;
    view.setUint16(o + 6, 0x4001, true);
    buf[o + 8] = 5;
    buf[o + 9] = 0;
    view.setUint16(o + 10, st.nids, true);
    view.setUint32(o + 12, baseVram + 0x560 + i * 16, true);
    view.setUint32(o + 16, baseVram + st.stubOff, true);
  });

  // .data
  writeStr(buf, 0x670, 'PSP_DEMO_ENGINE_V1.02\0');

  // .shstrtab
  const shNames = [
    '',
    '.text',
    '.rodata.sceModuleInfo',
    '.lib.stub',
    '.rodata',
    '.data',
    '.bss',
    '.shstrtab',
  ];
  const shNameOffsets: number[] = [];
  let strCursor = 0;
  for (const n of shNames) {
    shNameOffsets.push(strCursor);
    writeStr(buf, 0x6e0 + strCursor, `${n}\0`);
    strCursor += n.length + 1;
  }

  // Section Headers at 0x07e0
  const secDefs = [
    { nameOff: 0, type: 0, flags: 0, addr: 0, off: 0, size: 0 },
    { nameOff: shNameOffsets[1], type: 1, flags: 6, addr: baseVram + 0x100, off: 0x100, size: 0x140 },
    { nameOff: shNameOffsets[2], type: 1, flags: 2, addr: baseVram + 0x240, off: 0x240, size: 0x34 },
    { nameOff: shNameOffsets[3], type: 1, flags: 2, addr: baseVram + 0x280, off: 0x280, size: 0x64 },
    { nameOff: shNameOffsets[4], type: 1, flags: 2, addr: baseVram + 0x300, off: 0x300, size: 0x360 },
    { nameOff: shNameOffsets[5], type: 1, flags: 3, addr: baseVram + 0x670, off: 0x670, size: 0x50 },
    { nameOff: shNameOffsets[6], type: 8, flags: 3, addr: baseVram + 0x6c0, off: 0x6c0, size: 0xc20 },
    { nameOff: shNameOffsets[7], type: 3, flags: 0, addr: 0, off: 0x6e0, size: strCursor },
  ];
  secDefs.forEach((s, i) => {
    const o = 0x7e0 + i * 40;
    view.setUint32(o, s.nameOff, true);
    view.setUint32(o + 4, s.type, true);
    view.setUint32(o + 8, s.flags, true);
    view.setUint32(o + 12, s.addr, true);
    view.setUint32(o + 16, s.off, true);
    view.setUint32(o + 20, s.size, true);
    view.setUint32(o + 32, 4, true);
  });

  return buf;
}

export function buildSamplePackfileBin(): Uint8Array {
  const buf = new Uint8Array(4096);
  const view = new DataView(buf.buffer);

  // Custom PACK header + internal filename table
  writeStr(buf, 0x00, 'PACK');
  view.setUint32(0x04, 6, true);
  writeStr(buf, 0x20, 'chara/hero_main.gmo\0');
  writeStr(buf, 0x40, 'map/castle_stage01.map\0');
  writeStr(buf, 0x60, 'minimap/radar_castle.gim\0');
  writeStr(buf, 0x80, 'tex/hud_icons.tm2\0');
  writeStr(buf, 0xa0, 'bgm/battle_theme.at3\0');
  writeWin1252(buf, 0xe0, 'Texto Español: ¡Nueva Misión disponible! Años luz.\0');

  // Embedded magic-signed assets inside PACKFILE.BIN
  writeStr(buf, 0x200, 'OMG.00.1PSP');
  writeStr(buf, 0x210, 'hero_main');
  writeStr(buf, 0x400, 'MIG.00.1PSP');
  writeStr(buf, 0x410, 'minimap_radar_01');
  writeStr(buf, 0x600, 'TIM2');
  writeStr(buf, 0x800, 'RIFF');
  view.setUint32(0x804, 512, true);
  writeStr(buf, 0x808, 'WAVE');
  writeStr(buf, 0xb00, 'PSMF0014');

  return buf;
}

export function buildSampleParamSfo(): Uint8Array {
  const entries = [
    { key: 'BOOTABLE', fmt: 0x0404, val: 1 },
    { key: 'CATEGORY', fmt: 0x0204, val: 'UG' },
    { key: 'DISC_ID', fmt: 0x0204, val: 'ULES99999' },
    { key: 'DISC_VERSION', fmt: 0x0204, val: '1.00' },
    { key: 'PSP_SYSTEM_VER', fmt: 0x0204, val: '6.60' },
    { key: 'TITLE', fmt: 0x0204, val: 'Allegrex Lab Sample Disc' },
  ];

  const keyTable: number[] = [];
  const dataTable: number[] = [];
  const indexMeta: Array<{ keyOff: number; fmt: number; len: number; maxLen: number; dataOff: number }> = [];

  for (const e of entries) {
    const keyOff = keyTable.length;
    for (let i = 0; i < e.key.length; i++) keyTable.push(e.key.charCodeAt(i));
    keyTable.push(0);

    const dataOff = dataTable.length;
    if (typeof e.val === 'number') {
      dataTable.push(e.val & 0xff, (e.val >> 8) & 0xff, (e.val >> 16) & 0xff, (e.val >> 24) & 0xff);
      indexMeta.push({ keyOff, fmt: e.fmt, len: 4, maxLen: 4, dataOff });
    } else {
      const bytes = new TextEncoder().encode(e.val);
      for (const b of bytes) dataTable.push(b);
      dataTable.push(0);
      const padLen = Math.ceil((bytes.length + 1) / 4) * 4;
      while (dataTable.length - dataOff < padLen) dataTable.push(0);
      indexMeta.push({ keyOff, fmt: e.fmt, len: bytes.length + 1, maxLen: padLen, dataOff });
    }
  }

  while (keyTable.length % 4 !== 0) keyTable.push(0);

  const headerSize = 20;
  const indexSize = indexMeta.length * 16;
  const keyTableOffset = headerSize + indexSize;
  const dataTableOffset = keyTableOffset + keyTable.length;
  const totalSize = dataTableOffset + dataTable.length;

  const out = new Uint8Array(totalSize);
  const view = new DataView(out.buffer);
  view.setUint32(0, 0x46535000, true);
  view.setUint32(4, 0x00000101, true);
  view.setUint32(8, keyTableOffset, true);
  view.setUint32(12, dataTableOffset, true);
  view.setUint32(16, indexMeta.length, true);

  indexMeta.forEach((m, i) => {
    const o = headerSize + i * 16;
    view.setUint16(o, m.keyOff, true);
    view.setUint16(o + 2, m.fmt, true);
    view.setUint32(o + 4, m.len, true);
    view.setUint32(o + 8, m.maxLen, true);
    view.setUint32(o + 12, m.dataOff, true);
  });

  out.set(keyTable, keyTableOffset);
  out.set(dataTable, dataTableOffset);
  return out;
}

function writeIsoDirEntry(
  buf: Uint8Array,
  pos: number,
  nameBytes: Uint8Array,
  lba: number,
  size: number,
  isDir: boolean
): number {
  const recLen = 33 + nameBytes.length + ((33 + nameBytes.length) % 2);
  const view = new DataView(buf.buffer);
  buf[pos] = recLen;
  buf[pos + 1] = 0;
  view.setUint32(pos + 2, lba, true);
  view.setUint32(pos + 6, lba, false);
  view.setUint32(pos + 10, size, true);
  view.setUint32(pos + 14, size, false);
  buf[pos + 25] = isDir ? 0x02 : 0x00;
  view.setUint16(pos + 28, 1, true);
  view.setUint16(pos + 30, 1, false);
  buf[pos + 32] = nameBytes.length;
  buf.set(nameBytes, pos + 33);
  return recLen;
}

function makeHeaderPayload(magic: string, size: number): Uint8Array {
  const arr = new Uint8Array(size);
  writeStr(arr, 0, magic);
  return arr;
}

function buildSampleSequentialCharBin(populatedColors: number): Uint8Array {
  const buf = new Uint8Array(512);
  const view = new DataView(buf.buffer);
  let cursor = 64;
  for (let c = 0; c < populatedColors && c < 8; c++) {
    view.setUint32(c * 8, cursor, true);
    view.setUint32(c * 8 + 4, 48, true);
    writeStr(buf, cursor, 'OMG.00.1PSP');
    cursor += 48;
  }
  return buf;
}

function buildSampleSequentialMapBin(): Uint8Array {
  const buf = new Uint8Array(512);
  const view = new DataView(buf.buffer);
  view.setUint32(0, 16, true);
  view.setUint32(4, 240, true);
  view.setUint32(8, 256, true);
  view.setUint32(12, 128, true);
  writeStr(buf, 16, 'MAP_STAGE_DLC');
  writeStr(buf, 256, 'TIM2');
  return buf;
}

function buildSampleDlcContainerBin(entries: number, populated: number): Uint8Array {
  const buf = new Uint8Array(1024);
  const view = new DataView(buf.buffer);
  writeStr(buf, 0, 'DLC\0');
  view.setUint32(4, entries, true);
  let cursor = 16 + entries * 8;
  for (let i = 0; i < entries; i++) {
    const tableOff = 8 + i * 8;
    if (i < populated && cursor + 32 <= buf.length) {
      view.setUint32(tableOff, cursor, true);
      view.setUint32(tableOff + 4, 32, true);
      writeStr(buf, cursor, 'OMG.00.1PSP');
      cursor += 32;
    } else {
      view.setUint32(tableOff, 0, true);
      view.setUint32(tableOff + 4, 0, true);
    }
  }
  return buf;
}

export function buildSamplePck1Bin(): Uint8Array {
  // PCK1 TOC Layout: [PCK1][count=6 @ 0x04][16B header][(offset,size)x6 @ 0x10..0x40]
  const totalSize = 4096;
  const buf = new Uint8Array(totalSize);
  const dv = new DataView(buf.buffer);

  writeStr(buf, 0, 'PCK1');
  dv.setUint32(4, 6, true);
  dv.setUint32(8, 16, true);
  dv.setUint32(12, totalSize, true);

  const payloads: Uint8Array[] = [];

  // 1. Personaje (OMG.00.1PSP)
  const pChar = new Uint8Array(256);
  writeStr(pChar, 0, 'OMG.00.1PSP');
  writeStr(pChar, 16, 'chara_hero_v2');
  payloads.push(pChar);

  // 2. Mapa (MAP_STAGE)
  const pMap = new Uint8Array(256);
  writeStr(pMap, 0, 'MAP_STAGE_02');
  writeStr(pMap, 16, 'stage_volcano_arena');
  payloads.push(pMap);

  // 3. Minimapa (MIG.00.1PSP + radar hint)
  const pMini = new Uint8Array(256);
  writeStr(pMini, 0, 'MIG.00.1PSP');
  writeStr(pMini, 16, 'minimap_radar_02');
  payloads.push(pMini);

  // 4. Modelo Wavefront .OBJ
  const objText =
    '# PSP Lab Sample Mesh\no Hero_Blade\nv 0.0000 1.2500 0.0000\nv -0.5000 0.0000 0.2500\nv 0.5000 0.0000 -0.2500\nf 1 2 3\n';
  const pObj = new TextEncoder().encode(objText);
  payloads.push(pObj);

  // 5. Musica ATRAC3+ (.AT3 RIFF header + valid PCM/RIFF placeholder wave)
  const pAt3 = new Uint8Array(1024);
  const at3View = new DataView(pAt3.buffer);
  writeStr(pAt3, 0, 'RIFF');
  at3View.setUint32(4, 1016, true);
  writeStr(pAt3, 8, 'WAVE');
  writeStr(pAt3, 12, 'fmt ');
  at3View.setUint32(16, 16, true);
  at3View.setUint16(20, 1, true); // PCM compatible for quick browser preview / RIFF signature
  at3View.setUint16(22, 1, true);
  at3View.setUint32(24, 22050, true);
  at3View.setUint32(28, 44100, true);
  at3View.setUint16(32, 2, true);
  at3View.setUint16(34, 16, true);
  writeStr(pAt3, 36, 'data');
  at3View.setUint32(40, 960, true);
  for (let i = 0; i < 480; i++) {
    const sample = Math.round(Math.sin(i * 0.14) * 6000);
    at3View.setInt16(44 + i * 2, sample, true);
  }
  payloads.push(pAt3);

  // 6. Imagen TIM2
  const pImg = new Uint8Array(256);
  writeStr(pImg, 0, 'TIM2');
  pImg[4] = 4;
  pImg[6] = 1;
  payloads.push(pImg);

  let cursor = 0x80;
  for (let i = 0; i < payloads.length; i++) {
    const payload = payloads[i];
    dv.setUint32(16 + i * 8, cursor, true);
    dv.setUint32(16 + i * 8 + 4, payload.length, true);
    buf.set(payload, cursor);
    cursor = (cursor + payload.length + 15) & ~15;
  }

  return buf;
}

export function buildSamplePspIsoBlob(): Blob {
  const SECTOR = 2048;
  const totalSectors = 48;
  const iso = new Uint8Array(totalSectors * SECTOR);
  const view = new DataView(iso.buffer);

  const ebootBytes = buildSamplePspElf();
  const sfoBytes = buildSampleParamSfo();
  const packBytes = buildSamplePackfileBin();
  const pck1Bytes = buildSamplePck1Bin();
  const char077Bytes = buildSampleSequentialCharBin(8);
  const char078Bytes = buildSampleSequentialCharBin(4);
  const char080Bytes = buildSampleSequentialCharBin(8);
  const maps11Bytes = buildSampleSequentialMapBin();
  const bgm001Bytes = makeHeaderPayload('RIFF\xF8\x03\x00\x00WAVE', 1024);
  const char77Container = buildSampleDlcContainerBin(8, 5);

  // PVD
  const pvdOff = 16 * SECTOR;
  iso[pvdOff] = 1;
  writeStr(iso, pvdOff + 1, 'CD001');
  iso[pvdOff + 6] = 1;
  writeStr(iso, pvdOff + 8, 'PSP GAME                        ');
  writeStr(iso, pvdOff + 40, 'PSP_LAB_SAMPLE_ISO              ');
  view.setUint32(pvdOff + 80, totalSectors, true);
  view.setUint32(pvdOff + 84, totalSectors, false);
  view.setUint16(pvdOff + 128, SECTOR, true);
  view.setUint16(pvdOff + 130, SECTOR, false);
  writeStr(iso, pvdOff + 318, 'PSP EBOOT INSPECTOR LAB');
  writeStr(iso, pvdOff + 813, '2026111615000000');
  writeIsoDirEntry(iso, pvdOff + 156, new Uint8Array([0]), 18, SECTOR, true);

  // Terminator
  iso[17 * SECTOR] = 255;
  writeStr(iso, 17 * SECTOR + 1, 'CD001');
  iso[17 * SECTOR + 6] = 1;

  // 18: Root
  let p = 18 * SECTOR;
  p += writeIsoDirEntry(iso, p, new Uint8Array([0]), 18, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new Uint8Array([1]), 18, SECTOR, true);
  writeIsoDirEntry(iso, p, new TextEncoder().encode('PSP_GAME'), 19, SECTOR, true);

  // 19: PSP_GAME
  p = 19 * SECTOR;
  p += writeIsoDirEntry(iso, p, new Uint8Array([0]), 19, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new Uint8Array([1]), 18, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('PARAM.SFO;1'), 22, sfoBytes.length, false);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('SYSDIR'), 20, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('USRDIR'), 21, SECTOR, true);
  writeIsoDirEntry(iso, p, new TextEncoder().encode('DLC'), 38, SECTOR, true);

  // 20: SYSDIR
  p = 20 * SECTOR;
  p += writeIsoDirEntry(iso, p, new Uint8Array([0]), 20, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new Uint8Array([1]), 19, SECTOR, true);
  writeIsoDirEntry(iso, p, new TextEncoder().encode('EBOOT.BIN;1'), 23, ebootBytes.length, false);

  // 21: USRDIR -> CHARA, MAP, TEX, BGM, MINIMAP + PACKFILE.BIN + DLC_PACK.PCK
  p = 21 * SECTOR;
  p += writeIsoDirEntry(iso, p, new Uint8Array([0]), 21, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new Uint8Array([1]), 19, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('CHARA'), 25, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('MAP'), 26, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('TEX'), 27, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('BGM'), 28, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('MINIMAP'), 29, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('PACKFILE.BIN;1'), 36, packBytes.length, false);
  writeIsoDirEntry(iso, p, new TextEncoder().encode('DLC_PACK.PCK;1'), 46, pck1Bytes.length, false);

  // 25: CHARA
  p = 25 * SECTOR;
  p += writeIsoDirEntry(iso, p, new Uint8Array([0]), 25, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new Uint8Array([1]), 21, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('HERO_01.GMO;1'), 30, 1536, false);
  writeIsoDirEntry(iso, p, new TextEncoder().encode('BOSS_02.GMO;1'), 31, 1792, false);

  // 26: MAP
  p = 26 * SECTOR;
  p += writeIsoDirEntry(iso, p, new Uint8Array([0]), 26, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new Uint8Array([1]), 21, SECTOR, true);
  writeIsoDirEntry(iso, p, new TextEncoder().encode('STAGE_01.MAP;1'), 32, 1600, false);

  // 27: TEX
  p = 27 * SECTOR;
  p += writeIsoDirEntry(iso, p, new Uint8Array([0]), 27, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new Uint8Array([1]), 21, SECTOR, true);
  writeIsoDirEntry(iso, p, new TextEncoder().encode('UI_ATLAS.GIM;1'), 33, 1280, false);

  // 28: BGM
  p = 28 * SECTOR;
  p += writeIsoDirEntry(iso, p, new Uint8Array([0]), 28, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new Uint8Array([1]), 21, SECTOR, true);
  writeIsoDirEntry(iso, p, new TextEncoder().encode('THEME_01.AT3;1'), 34, 1920, false);

  // 29: MINIMAP
  p = 29 * SECTOR;
  p += writeIsoDirEntry(iso, p, new Uint8Array([0]), 29, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new Uint8Array([1]), 21, SECTOR, true);
  writeIsoDirEntry(iso, p, new TextEncoder().encode('RADAR_01.GIM;1'), 35, 1024, false);

  // 38: DLC (Sequential + DLC\0 indexed sample; CHAR079.BIN omitted intentionally to demonstrate gap warning)
  p = 38 * SECTOR;
  p += writeIsoDirEntry(iso, p, new Uint8Array([0]), 38, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new Uint8Array([1]), 19, SECTOR, true);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('CHAR077.BIN;1'), 39, char077Bytes.length, false);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('CHAR078.BIN;1'), 40, char078Bytes.length, false);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('CHAR080.BIN;1'), 41, char080Bytes.length, false);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('MAPS11.BIN;1'), 42, maps11Bytes.length, false);
  p += writeIsoDirEntry(iso, p, new TextEncoder().encode('BGM001.AT3;1'), 43, bgm001Bytes.length, false);
  writeIsoDirEntry(iso, p, new TextEncoder().encode('CHAR77.BIN;1'), 44, char77Container.length, false);

  iso.set(sfoBytes, 22 * SECTOR);
  iso.set(ebootBytes, 23 * SECTOR);
  iso.set(makeHeaderPayload('OMG.00.1PSP', 1536), 30 * SECTOR);
  iso.set(makeHeaderPayload('OMG.00.1PSP', 1792), 31 * SECTOR);
  iso.set(makeHeaderPayload('MAP_STAGE_01', 1600), 32 * SECTOR);
  iso.set(makeHeaderPayload('MIG.00.1PSP', 1280), 33 * SECTOR);
  iso.set(makeHeaderPayload('RIFF\x70\x07\x00\x00WAVE', 1920), 34 * SECTOR);
  iso.set(makeHeaderPayload('MIG.00.1PSP', 1024), 35 * SECTOR);
  iso.set(packBytes, 36 * SECTOR);
  iso.set(char077Bytes, 39 * SECTOR);
  iso.set(char078Bytes, 40 * SECTOR);
  iso.set(char080Bytes, 41 * SECTOR);
  iso.set(maps11Bytes, 42 * SECTOR);
  iso.set(bgm001Bytes, 43 * SECTOR);
  iso.set(char77Container, 44 * SECTOR);
  iso.set(pck1Bytes, 46 * SECTOR);

  return new Blob([iso], { type: 'application/octet-stream' });
}
