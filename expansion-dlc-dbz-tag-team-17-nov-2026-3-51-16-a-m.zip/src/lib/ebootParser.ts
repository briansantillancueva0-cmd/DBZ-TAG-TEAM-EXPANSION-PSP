import { parseParamSfo } from './sfo';
import type {
  AddressEntry,
  EbootAnalysis,
  ElfHeaderInfo,
  ElfProgramSegment,
  ElfSectionInfo,
  ImportedLibrary,
  IsoInspectionResult,
  PbpHeaderInfo,
  PspHeaderInfo,
  SceModuleInfo,
  SfoMetadata,
} from './types';

const PSP_LIBRARY_PURPOSES: Record<string, string> = {
  sceDisplay: 'Control de pantalla LCD, framebuffer, sincronización VBlank y resolución 480x272.',
  sceDisplay_driver: 'Controlador de bajo nivel del hardware de pantalla PSP.',
  sceCtrl: 'Lectura de controles físicos (D-Pad, stick analógico, botones X/O/□/△, gatillos L/R).',
  sceCtrl_driver: 'Controlador de entrada de hardware en modo kernel.',
  sceIoFileMgrForUser: 'Gestión de archivos en UMD (disc0:/), Memory Stick (ms0:/) y flash.',
  sceIoFileMgrForKernel: 'Gestión de E/S de archivos con privilegios de kernel.',
  sceGe_user: 'Motor Gráfico 3D (Graphics Engine): listas de display, vértices y GPU PSP.',
  sceGu: 'Librería gráfica de alto nivel (PSP Graphics Utility) sobre sceGe.',
  sceAudio: 'Salida de audio PCM estéreo, canales de sonido y mezcla.',
  sceSasCore: 'Sintetizador de audio por hardware (voces ADPCM/PCM).',
  sceAtrac3plus: 'Decodificación de audio comprimido ATRAC3+ (música y voces en juegos).',
  sceMpeg: 'Reproducción de cinemáticas de video PMF / H.264 por hardware Media Engine.',
  sceUtility: 'Diálogos del sistema: guardado/carga (Savedata), teclado OSK, red y mensajes.',
  sceKernel: 'Núcleo del sistema operativo PSP: hilos (threads), semáforos, memoria y timers.',
  ThreadManForUser: 'Administración de hilos de ejecución, mutex, colas de mensajes y eventos.',
  SysMemUserForUser: 'Asignación y liberación de bloques en la RAM principal de 32/64 MB.',
  LoadExecForUser: 'Carga y reinicio de ejecutables, salida al menú XMB.',
  ModuleMgrForUser: 'Carga dinámica de módulos PRX adicionales desde disc0:/ o flash0:/.',
  scePower: 'Gestión de energía, frecuencia de CPU/Bus (222/333 MHz) y estado de batería.',
  sceRtc: 'Reloj en tiempo real (Real-Time Clock) y cálculo de fechas.',
  sceWlanDrv: 'Controlador de antena Wi-Fi (802.11b) y modo Ad-Hoc local.',
  sceNet: 'Pila de red TCP/IP y sockets para multijugador.',
  sceNetAdhoc: 'Comunicación multijugador local Ad-Hoc entre consolas PSP.',
  sceNetAdhocMatching: 'Búsqueda de salas y emparejamiento de jugadores Ad-Hoc.',
  sceUmdUser: 'Detección de disco UMD, estado de bandeja y montaje de disc0:/.',
  sceImpose: 'Configuración global del sistema (volumen, idioma, botón confirmar).',
  sceOpenPSID: 'Identificador único de consola y utilidades de sesión.',
  sceHprm: 'Control remoto en línea de auriculares PSP.',
  sceUsb: 'Comunicación USB con PC o periféricos (cámara Chotto Shot, GPS).',
};

const SECTION_PURPOSES: Record<string, string> = {
  '.text': 'Código máquina ejecutable MIPS Allegrex (instrucciones de 32 bits del juego/app).',
  '.init': 'Rutinas de inicialización previas a la función main().',
  '.fini': 'Rutinas de finalización al cerrar el módulo.',
  '.sceStub.text': 'Trampolines (stubs) de llamada mediante syscall a librerías del sistema PSP.',
  '.rodata': 'Datos de solo lectura: cadenas de texto, tablas constantes, rutas disc0:/ y coeficientes.',
  '.rodata.sceModuleInfo': 'Estructura sceModuleInfo con el nombre del módulo, atributos y punteros a tablas NID.',
  '.rodata.sceNid': 'Tabla de identificadores numéricos (NIDs) de funciones importadas/exportadas.',
  '.rodata.sceResident': 'Nombres de librerías residentes exportadas por el módulo.',
  '.lib.ent': 'Cabecera de tabla de exportaciones del módulo.',
  '.lib.ent.top': 'Inicio de tabla de exportaciones.',
  '.lib.ent.btm': 'Fin de tabla de exportaciones.',
  '.lib.stub': 'Tabla de librerías importadas del sistema PSP (sceDisplay, sceCtrl, etc.).',
  '.lib.stub.top': 'Inicio de tabla de stubs importados.',
  '.lib.stub.btm': 'Fin de tabla de stubs importados.',
  '.data': 'Variables globales y estáticas inicializadas en memoria RAM.',
  '.sdata': 'Datos pequeños direccionables rápido vía registro $gp.',
  '.sbss': 'Variables globales pequeñas sin inicializar (puestas a cero al cargar).',
  '.bss': 'Reserva de memoria RAM sin inicializar (buffers, pilas, estados en tiempo de ejecución).',
  '.shstrtab': 'Tabla de nombres de secciones ELF.',
  '.strtab': 'Tabla de cadenas de símbolos.',
  '.symtab': 'Tabla de símbolos y nombres de funciones (presente en ELF no stripped).',
};

function readNullAscii(bytes: Uint8Array, offset: number, maxLen = 128): string {
  if (offset < 0 || offset >= bytes.length) return '';
  let end = offset;
  const limit = Math.min(bytes.length, offset + maxLen);
  while (end < limit && bytes[end] !== 0) end++;
  return new TextDecoder('ascii', { fatal: false }).decode(bytes.subarray(offset, end));
}

function decodeModAttr(attr: number): string[] {
  const labels: string[] = [];
  if ((attr & 0x1000) !== 0) labels.push('Modo Kernel (0x1000)');
  else labels.push('Modo Usuario (0x0000)');
  if ((attr & 0x0800) !== 0) labels.push('Módulo VSH');
  if ((attr & 0x0001) !== 0) labels.push('No reiniciable');
  if ((attr & 0x0002) !== 0) labels.push('No descargable');
  return labels;
}

function decodeCompAttr(attr: number): string[] {
  const labels: string[] = [];
  if ((attr & 0x0001) !== 0) labels.push('Comprimido (GZIP/KL4E)');
  if ((attr & 0x0200) !== 0) labels.push('Cifrado Kirk (~PSP)');
  if (labels.length === 0) labels.push('Sin compresión / Estándar');
  return labels;
}

function decodeDevkitVersion(ver: number): string {
  if (!ver || ver === 0xffffffff) return 'No especificado';
  const major = (ver >>> 24) & 0xff;
  const minor = (ver >>> 16) & 0xff;
  const rev = (ver >>> 8) & 0xff;
  return `SDK ${major}.${minor.toString().padStart(2, '0')}.${rev.toString().padStart(2, '0')} (0x${ver.toString(16).toUpperCase().padStart(8, '0')})`;
}

function vaddrToFileOffset(vaddr: number, segments: ElfProgramSegment[], sections: ElfSectionInfo[]): number | null {
  for (const seg of segments) {
    if (seg.filesz > 0 && vaddr >= seg.vaddr && vaddr < seg.vaddr + seg.filesz) {
      return seg.offset + (vaddr - seg.vaddr);
    }
  }
  for (const sec of sections) {
    if (sec.size > 0 && sec.vaddr > 0 && vaddr >= sec.vaddr && vaddr < sec.vaddr + sec.size) {
      return sec.offset + (vaddr - sec.vaddr);
    }
  }
  return null;
}

function fileOffsetToVaddr(
  fileOffset: number,
  segments: ElfProgramSegment[],
  sections: ElfSectionInfo[],
  fallbackBase: number
): { vaddr: number; sectionName: string } {
  for (const sec of sections) {
    if (sec.size > 0 && sec.offset > 0 && fileOffset >= sec.offset && fileOffset < sec.offset + sec.size) {
      const base = sec.vaddr > 0 ? sec.vaddr : fallbackBase + sec.offset;
      return { vaddr: base + (fileOffset - sec.offset), sectionName: sec.name };
    }
  }
  for (const seg of segments) {
    if (seg.filesz > 0 && fileOffset >= seg.offset && fileOffset < seg.offset + seg.filesz) {
      return { vaddr: seg.vaddr + (fileOffset - seg.offset), sectionName: `PT_LOAD#${seg.index}` };
    }
  }
  return { vaddr: fallbackBase + fileOffset, sectionName: 'Archivo (Base estimada)' };
}

function describeLibrary(name: string): string {
  if (PSP_LIBRARY_PURPOSES[name]) return PSP_LIBRARY_PURPOSES[name];
  const base = name.replace(/_driver$|ForUser$|ForKernel$|_user$/, '');
  if (PSP_LIBRARY_PURPOSES[base]) return PSP_LIBRARY_PURPOSES[base];
  if (name.startsWith('sceNet')) return 'Servicios de red y comunicación multijugador PSP.';
  if (name.startsWith('sceKernel') || name.includes('Kernel')) return 'Servicios del núcleo del sistema operativo PSP.';
  if (name.startsWith('sceIo')) return 'Operaciones de lectura/escritura en sistemas de archivos PSP.';
  if (name.startsWith('sceGe') || name.startsWith('sceGu')) return 'Renderizado gráfico 2D/3D y manejo de GPU.';
  if (name.startsWith('sceAudio') || name.startsWith('sceAtrac')) return 'Procesamiento y reproducción de audio.';
  return 'Módulo o librería de enlace del entorno Sony PSP SDK.';
}

function classifyString(text: string): { category: AddressEntry['category']; label: string; description: string } | null {
  if (/^(disc0|ms0|flash0|flash1|host0|umd0):/i.test(text)) {
    return {
      category: 'STRING_PATH',
      label: 'Ruta de dispositivo PSP',
      description: 'Ruta interna usada por sceIoOpen para cargar recursos o módulos del juego.',
    };
  }
  if (/\.(prx|bin|cpk|pmf|at3|gim|gmo|png|iso|sfo|dat|pac|afs|txd|ini|cfg|xml|txt)$/i.test(text)) {
    return {
      category: 'STRING_PATH',
      label: 'Referencia a archivo de recurso',
      description: 'Nombre o ruta relativa de recurso empaquetado del juego o módulo PRX.',
    };
  }
  if (/^sce[A-Z][A-Za-z0-9_]{2,}$/.test(text) || /^(ThreadMan|SysMem|LoadExec|ModuleMgr|IoFileMgr)/.test(text)) {
    return {
      category: 'STRING_SCE',
      label: 'Símbolo / Librería Sony PSP',
      description: describeLibrary(text),
    };
  }
  if (/(error|fail|warning|debug|assert|version|build|copyright|init|load|main|save|memory)/i.test(text)) {
    return {
      category: 'STRING_DEBUG',
      label: 'Cadena de estado / depuración',
      description: 'Mensaje interno de diagnóstico, inicialización o control de flujo.',
    };
  }
  if (text.length >= 8) {
    return {
      category: 'STRING_DEBUG',
      label: 'Cadena ASCII indexada',
      description: 'Texto o identificador estático almacenado dentro del binario.',
    };
  }
  return null;
}

function scanStringsAndAddresses(
  bytes: Uint8Array,
  segments: ElfProgramSegment[],
  sections: ElfSectionInfo[],
  fallbackBase: number
): AddressEntry[] {
  const results: AddressEntry[] = [];
  let current = '';
  let startOff = -1;
  let idx = 1;

  const flush = () => {
    if (current.length >= 5) {
      const cls = classifyString(current);
      if (cls) {
        const mapped = fileOffsetToVaddr(startOff, segments, sections, fallbackBase);
        results.push({
          index: idx++,
          category: cls.category,
          categoryLabel: cls.label,
          label: current.length > 110 ? `${current.slice(0, 107)}...` : current,
          fileOffset: startOff,
          ramAddress: mapped.vaddr,
          sizeOrValue: `${current.length} B`,
          sectionName: mapped.sectionName,
          description: cls.description,
        });
      }
    }
    current = '';
    startOff = -1;
  };

  const maxScan = Math.min(bytes.length, 8 * 1024 * 1024);
  for (let i = 0; i < maxScan; i++) {
    const b = bytes[i];
    if (b >= 32 && b <= 126) {
      if (startOff === -1) startOff = i;
      current += String.fromCharCode(b);
    } else {
      flush();
    }
  }
  flush();

  return results;
}

function scanMipsCodeReferences(
  bytes: Uint8Array,
  segments: ElfProgramSegment[],
  sections: ElfSectionInfo[]
): AddressEntry[] {
  const textSec = sections.find((s) => s.name === '.text') ?? null;
  const codeStart = textSec ? textSec.offset : segments[0]?.offset ?? 0;
  const codeSize = textSec ? textSec.size : Math.min(bytes.length - codeStart, 512 * 1024);
  const codeVaddr = textSec ? textSec.vaddr : segments[0]?.vaddr ?? 0x08804000;

  if (codeSize < 8 || codeStart + codeSize > bytes.length) return [];

  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const jalCounts = new Map<number, { count: number; firstCallerOff: number; firstCallerVaddr: number }>();
  const dataPtrs = new Map<number, { instrOff: number; instrVaddr: number; reg: number }>();

  const luiState = new Int32Array(32).fill(-1);
  const luiAddr = new Uint32Array(32);

  const scanLimit = Math.min(codeStart + codeSize, bytes.length - 4);
  for (let off = codeStart; off <= scanLimit; off += 4) {
    const instr = view.getUint32(off, true);
    const opcode = instr >>> 26;
    const vaddr = codeVaddr + (off - codeStart);

    // JAL target: opcode == 3
    if (opcode === 3) {
      const target = ((vaddr + 4) & 0xf0000000) | ((instr & 0x03ffffff) << 2);
      if (target >= 0x08000000 && target < 0x0c000000) {
        const existing = jalCounts.get(target);
        if (existing) {
          existing.count++;
        } else {
          jalCounts.set(target, { count: 1, firstCallerOff: off, firstCallerVaddr: vaddr });
        }
      }
    }

    // LUI rt, imm -> opcode == 0x0F
    if (opcode === 0x0f) {
      const rt = (instr >>> 16) & 0x1f;
      const imm = instr & 0xffff;
      if (rt > 0) {
        luiState[rt] = off;
        luiAddr[rt] = (imm << 16) >>> 0;
      }
    } else if (opcode === 0x09 || opcode === 0x0d) {
      // ADDIU (0x09) or ORI (0x0D)
      const rs = (instr >>> 21) & 0x1f;
      const rt = (instr >>> 16) & 0x1f;
      if (rs > 0 && luiState[rs] !== -1 && off - luiState[rs] <= 16) {
        const imm16 = instr & 0xffff;
        const fullAddr =
          opcode === 0x09
            ? (luiAddr[rs] + ((imm16 << 16) >> 16)) >>> 0
            : (luiAddr[rs] | imm16) >>> 0;
        if (fullAddr >= 0x08800000 && fullAddr < 0x0c000000) {
          const mappedOff = vaddrToFileOffset(fullAddr, segments, sections);
          if (mappedOff !== null && !dataPtrs.has(fullAddr)) {
            dataPtrs.set(fullAddr, { instrOff: luiState[rs], instrVaddr: codeVaddr + (luiState[rs] - codeStart), reg: rt });
          }
        }
        luiState[rs] = -1;
      }
    }
  }

  const out: AddressEntry[] = [];
  let idx = 1;

  // Top JAL subrutinas más invocadas
  const topJals = Array.from(jalCounts.entries())
    .sort((a, b) => b[1].count - a[1].count)
    .slice(0, 60);

  for (const [target, info] of topJals) {
    const targetFileOff = vaddrToFileOffset(target, segments, sections);
    out.push({
      index: idx++,
      category: 'MIPS_JAL',
      categoryLabel: 'Subrutina MIPS (JAL)',
      label: `sub_${target.toString(16).toUpperCase().padStart(8, '0')}`,
      fileOffset: targetFileOff,
      ramAddress: target,
      sizeOrValue: `${info.count} llamadas`,
      sectionName: '.text',
      description: `Función invocada ${info.count} veces (primera llamada en RAM 0x${info.firstCallerVaddr.toString(16).toUpperCase()}).`,
    });
  }

  // Punteros de datos LUI+ADDIU/ORI hacia .rodata / .data
  const ptrList = Array.from(dataPtrs.entries()).slice(0, 60);
  for (const [targetAddr, info] of ptrList) {
    const mappedOff = vaddrToFileOffset(targetAddr, segments, sections);
    let preview = '';
    if (mappedOff !== null) {
      const sample = readNullAscii(bytes, mappedOff, 48).replace(/[^\x20-\x7E]/g, '');
      if (sample.length >= 4) preview = ` -> "${sample}"`;
    }
    out.push({
      index: idx++,
      category: 'MIPS_PTR',
      categoryLabel: 'Puntero MIPS (LUI+ADDIU)',
      label: `ptr_${targetAddr.toString(16).toUpperCase().padStart(8, '0')}${preview}`,
      fileOffset: mappedOff,
      ramAddress: targetAddr,
      sizeOrValue: `desde 0x${info.instrVaddr.toString(16).toUpperCase()}`,
      sectionName: '.rodata/.data',
      description: `Referencia directa de dirección cargada en código MIPS desde offset 0x${info.instrOff.toString(16).toUpperCase()}.`,
    });
  }

  return out;
}

export function analyzeEbootBytes(
  bytes: Uint8Array,
  options: {
    sourceName: string;
    sourceKind: 'ISO' | 'STANDALONE' | 'SAMPLE';
    targetBinaryPath: string;
    isoInfo?: IsoInspectionResult | null;
    sfoInfo?: SfoMetadata | null;
    alternativeBootBinaryPath?: string | null;
  }
): EbootAnalysis {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const magic = bytes.length >= 4 ? view.getUint32(0, true) : 0;
  const notes: string[] = [];

  // Handle PBP ("\0PBP" = 0x50425000)
  if (magic === 0x50425000 && bytes.length >= 40) {
    const version = view.getUint32(4, true);
    const pbpLabels = [
      { name: 'PARAM.SFO', desc: 'Metadatos del homebrew/juego (título, ID, versión).' },
      { name: 'ICON0.PNG', desc: 'Icono estático del menú XMB (144x80).' },
      { name: 'ICON1.PMF', desc: 'Icono animado en video PMF.' },
      { name: 'PIC0.PNG', desc: 'Imagen secundaria de información.' },
      { name: 'PIC1.PNG', desc: 'Fondo de pantalla completo XMB (480x272).' },
      { name: 'SND0.AT3', desc: 'Música de fondo ATRAC3 en el menú XMB.' },
      { name: 'DATA.PSP', desc: 'Binario ejecutable principal (ELF o ~PSP PRX).' },
      { name: 'DATA.PSAR', desc: 'Archivo empaquetado de recursos adicionales.' },
    ];
    const offsets: number[] = [];
    for (let i = 0; i < 8; i++) {
      offsets.push(view.getUint32(8 + i * 4, true));
    }
    const entries = pbpLabels.map((item, i) => {
      const start = offsets[i];
      const end = i < 7 ? offsets[i + 1] : bytes.length;
      return {
        name: item.name,
        offset: start,
        size: Math.max(0, end - start),
        description: item.desc,
      };
    });
    const pbpHeader: PbpHeaderInfo = { version, entries };

    let sfoInfo = options.sfoInfo ?? null;
    const sfoEntry = entries[0];
    if (!sfoInfo && sfoEntry.size > 0 && sfoEntry.offset + sfoEntry.size <= bytes.length) {
      sfoInfo = parseParamSfo(bytes.subarray(sfoEntry.offset, sfoEntry.offset + sfoEntry.size));
    }

    const dataPspEntry = entries[6];
    if (dataPspEntry.size > 16 && dataPspEntry.offset + dataPspEntry.size <= bytes.length) {
      const innerBytes = bytes.subarray(dataPspEntry.offset, dataPspEntry.offset + dataPspEntry.size);
      const inner = analyzeEbootBytes(innerBytes, {
        ...options,
        sfoInfo,
      });
      inner.pbpHeader = pbpHeader;
      inner.format = inner.format === 'PSP_ENCRYPTED' ? 'PSP_ENCRYPTED' : 'PBP';
      inner.formatLabel = `Contenedor PBP (DATA.PSP: ${inner.formatLabel})`;
      inner.analyzedNotes.unshift(
        `Contenedor PBP detectado (v0x${version.toString(16).toUpperCase()}). Se extrajo DATA.PSP desde offset 0x${dataPspEntry.offset.toString(16).toUpperCase()} (${dataPspEntry.size.toLocaleString('es-ES')} bytes).`
      );
      return inner;
    }

    return {
      sourceName: options.sourceName,
      sourceKind: options.sourceKind,
      targetBinaryPath: options.targetBinaryPath,
      fileSize: bytes.length,
      format: 'PBP',
      formatLabel: 'Contenedor PBP de PSP (sin DATA.PSP válido)',
      isEncryptedPsp: false,
      isStrippedElf: false,
      baseRamAddress: 0x08804000,
      elfHeader: null,
      pspHeader: null,
      pbpHeader,
      moduleInfo: null,
      segments: [],
      sections: [],
      libraries: [],
      addresses: [],
      isoInfo: options.isoInfo ?? null,
      sfoInfo,
      alternativeBootBinaryPath: options.alternativeBootBinaryPath ?? null,
      analyzedNotes: ['Archivo PBP analizado; no contiene un DATA.PSP ejecutable estándar.'],
      rawBytes: bytes,
    };
  }

  // Handle ~PSP encrypted/signed PRX ("~PSP" = 0x5053507E)
  if (magic === 0x5053507e && bytes.length >= 0x60) {
    const modAttr = view.getUint16(4, true);
    const compAttr = view.getUint16(6, true);
    const modVerMinor = bytes[8];
    const modVerMajor = bytes[9];
    const modName = readNullAscii(bytes, 0x0a, 28) || 'Sin nombre';
    const elfSize = view.getUint32(0x28, true);
    const pspSize = view.getUint32(0x2c, true);
    const bootEntry = view.getUint32(0x30, true);
    const modInfoOffset = view.getUint32(0x34, true);
    const bssSize = view.getUint32(0x38, true);
    const devkitVersion = view.getUint32(0x58, true);
    const tagVal = view.getUint32(0xd0 < bytes.length ? 0xd0 : 0x5c, true);

    const pspHeader: PspHeaderInfo = {
      modAttr,
      modAttrLabels: decodeModAttr(modAttr),
      compAttr,
      compAttrLabels: decodeCompAttr(compAttr),
      modVerMajor,
      modVerMinor,
      modName,
      elfSize,
      pspSize,
      bootEntry,
      modInfoOffset,
      bssSize,
      devkitVersion,
      devkitVersionLabel: decodeDevkitVersion(devkitVersion),
      tagHex: `0x${tagVal.toString(16).toUpperCase().padStart(8, '0')}`,
    };

    const addresses: AddressEntry[] = [
      {
        index: 1,
        category: 'ENTRY_POINT',
        categoryLabel: 'Entry Point Declarado (~PSP)',
        label: 'boot_entry (Cabecera ~PSP)',
        fileOffset: 0x30,
        ramAddress: 0x08804000 + bootEntry,
        sizeOrValue: `0x${bootEntry.toString(16).toUpperCase()}`,
        sectionName: '~PSP Header',
        description: 'Desplazamiento inicial declarado en la cabecera pública ~PSP antes del módulo ELF interno.',
      },
      {
        index: 2,
        category: 'MODULE_INFO',
        categoryLabel: 'Offset sceModuleInfo (~PSP)',
        label: `modinfo (${modName})`,
        fileOffset: 0x34,
        ramAddress: 0x08804000 + modInfoOffset,
        sizeOrValue: `0x${modInfoOffset.toString(16).toUpperCase()}`,
        sectionName: '~PSP Header',
        description: 'Posición declarada de la estructura sceModuleInfo dentro de la imagen ELF encapsulada.',
      },
    ];

    notes.push(
      'Cabecera ~PSP detectada: este EBOOT.BIN es un PRX oficial firmado/cifrado. Las tablas de secciones ELF internas y el código máquina están sellados dentro del contenedor ~PSP.'
    );
    if (options.alternativeBootBinaryPath) {
      notes.push(
        `Esta imagen ISO también incluye ${options.alternativeBootBinaryPath}. Puedes cambiar al análisis de BOOT.BIN en un clic para verificar si contiene ELF sin envoltorio ~PSP.`
      );
    }

    return {
      sourceName: options.sourceName,
      sourceKind: options.sourceKind,
      targetBinaryPath: options.targetBinaryPath,
      fileSize: bytes.length,
      format: 'PSP_ENCRYPTED',
      formatLabel: 'Ejecutable PSP Firmado/Cifrado (~PSP)',
      isEncryptedPsp: true,
      isStrippedElf: false,
      baseRamAddress: 0x08804000,
      elfHeader: null,
      pspHeader,
      pbpHeader: null,
      moduleInfo: null,
      segments: [],
      sections: [],
      libraries: [],
      addresses,
      isoInfo: options.isoInfo ?? null,
      sfoInfo: options.sfoInfo ?? null,
      alternativeBootBinaryPath: options.alternativeBootBinaryPath ?? null,
      analyzedNotes: notes,
      rawBytes: bytes,
    };
  }

  // Handle ELF32 ("\x7FELF" = 0x464C457F)
  if (magic === 0x464c457f && bytes.length >= 52) {
    const eiClass = bytes[4];
    const eiData = bytes[5];
    const eType = view.getUint16(16, true);
    const eMachine = view.getUint16(18, true);
    const eEntry = view.getUint32(24, true);
    const ePhoff = view.getUint32(28, true);
    const eShoff = view.getUint32(32, true);
    const eFlags = view.getUint32(36, true);
    const ePhEntSize = view.getUint16(42, true);
    const ePhNum = view.getUint16(44, true);
    const eShEntSize = view.getUint16(46, true);
    const eShNum = view.getUint16(48, true);
    const eShStrNdx = view.getUint16(50, true);

    const typeMap: Record<number, string> = {
      1: 'ET_REL (Reubicable)',
      2: 'ET_EXEC (Ejecutable Estático PSP)',
      3: 'ET_DYN (Módulo PRX Reubicable PSP)',
    };

    const elfHeader: ElfHeaderInfo = {
      elfClass: eiClass === 1 ? 'ELF32 (32 bits)' : `Clase ${eiClass}`,
      endianness: eiData === 1 ? 'Little Endian (LSB)' : `Endian ${eiData}`,
      type: eType,
      typeLabel: typeMap[eType] ?? (eType === 0xffa0 ? 'ET_PSP_PRX (0xFFA0)' : `Tipo 0x${eType.toString(16).toUpperCase()}`),
      machine: eMachine,
      machineLabel: eMachine === 8 ? 'MIPS R3000 / Allegrex (EM_MIPS = 8)' : `Arquitectura ${eMachine}`,
      entryPoint: eEntry,
      phoff: ePhoff,
      shoff: eShoff,
      flags: eFlags,
      flagsLabel: `0x${eFlags.toString(16).toUpperCase().padStart(8, '0')}`,
      phnum: ePhNum,
      shnum: eShNum,
      shstrndx: eShStrNdx,
    };

    // Parse Program Headers
    const segments: ElfProgramSegment[] = [];
    if (ePhoff > 0 && ePhNum > 0 && ePhEntSize >= 32) {
      for (let i = 0; i < ePhNum; i++) {
        const off = ePhoff + i * ePhEntSize;
        if (off + 32 > bytes.length) break;
        const pType = view.getUint32(off, true);
        const pOffset = view.getUint32(off + 4, true);
        const pVaddr = view.getUint32(off + 8, true);
        const pPaddr = view.getUint32(off + 12, true);
        const pFilesz = view.getUint32(off + 16, true);
        const pMemsz = view.getUint32(off + 20, true);
        const pFlags = view.getUint32(off + 24, true);
        const pAlign = view.getUint32(off + 28, true);

        const r = (pFlags & 4) !== 0 ? 'R' : '-';
        const w = (pFlags & 2) !== 0 ? 'W' : '-';
        const x = (pFlags & 1) !== 0 ? 'X' : '-';

        segments.push({
          index: i,
          type: pType,
          typeLabel: pType === 1 ? 'PT_LOAD' : pType === 0x700000a0 ? 'PT_PSP_PRX' : `0x${pType.toString(16).toUpperCase()}`,
          offset: pOffset,
          vaddr: pVaddr,
          paddr: pPaddr,
          filesz: pFilesz,
          memsz: pMemsz,
          flags: pFlags,
          flagsText: `${r}${w}${x}`,
          align: pAlign,
        });
      }
    }

    // Parse Section Headers
    const sections: ElfSectionInfo[] = [];
    let isStrippedElf = false;
    if (eShoff > 0 && eShNum > 0 && eShEntSize >= 40 && eShoff + eShNum * eShEntSize <= bytes.length) {
      const shStrOff =
        eShStrNdx < eShNum
          ? view.getUint32(eShoff + eShStrNdx * eShEntSize + 16, true)
          : 0;

      for (let i = 0; i < eShNum; i++) {
        const off = eShoff + i * eShEntSize;
        const shNameIdx = view.getUint32(off, true);
        const shType = view.getUint32(off + 4, true);
        const shFlags = view.getUint32(off + 8, true);
        const shAddr = view.getUint32(off + 12, true);
        const shOffset = view.getUint32(off + 16, true);
        const shSize = view.getUint32(off + 20, true);
        const shAlign = view.getUint32(off + 32, true);

        const name = shStrOff > 0 ? readNullAscii(bytes, shStrOff + shNameIdx, 64) : `sec_${i}`;
        if (!name && i === 0) continue;

        const w = (shFlags & 1) !== 0 ? 'W' : '-';
        const a = (shFlags & 2) !== 0 ? 'A' : '-';
        const x = (shFlags & 4) !== 0 ? 'X' : '-';

        const shTypeMap: Record<number, string> = {
          1: 'PROGBITS',
          2: 'SYMTAB',
          3: 'STRTAB',
          8: 'NOBITS (.bss)',
          9: 'REL',
        };

        sections.push({
          index: i,
          name: name || `(sin nombre #${i})`,
          type: shType,
          typeLabel: shTypeMap[shType] ?? `0x${shType.toString(16).toUpperCase()}`,
          flags: shFlags,
          flagsText: `${a}${w}${x}`,
          vaddr: shAddr,
          offset: shOffset,
          size: shSize,
          align: shAlign,
          purpose: SECTION_PURPOSES[name] ?? 'Sección auxiliar del formato ELF32.',
        });
      }
    } else {
      isStrippedElf = true;
      notes.push(
        'Tabla de secciones ELF eliminada (stripped) o ausente; se emplean los Program Headers (PT_LOAD) y base RAM estándar 0x08804000 para el mapeo.'
      );
    }

    const baseRamAddress =
      segments.find((s) => s.type === 1 && s.vaddr > 0)?.vaddr ??
      sections.find((s) => s.vaddr > 0)?.vaddr ??
      0x08804000;

    // Locate sceModuleInfo
    let moduleInfo: SceModuleInfo | null = null;
    const modInfoSec = sections.find((s) => s.name === '.rodata.sceModuleInfo');
    let modInfoOffset = modInfoSec ? modInfoSec.offset : -1;
    let modInfoRam = modInfoSec ? modInfoSec.vaddr : 0;

    if (modInfoOffset < 0 && segments[0]?.paddr) {
      const pAddr = segments[0].paddr & 0x7fffffff;
      if (pAddr > 0 && pAddr < bytes.length - 52) {
        modInfoOffset = pAddr;
        modInfoRam = fileOffsetToVaddr(modInfoOffset, segments, sections, baseRamAddress).vaddr;
      }
    }

    if (modInfoOffset >= 0 && modInfoOffset + 52 <= bytes.length) {
      const attr = view.getUint16(modInfoOffset, true);
      const verMinor = bytes[modInfoOffset + 2];
      const verMajor = bytes[modInfoOffset + 3];
      const modName = readNullAscii(bytes, modInfoOffset + 4, 28) || 'Sin nombre';
      const gpValue = view.getUint32(modInfoOffset + 32, true);
      const entTop = view.getUint32(modInfoOffset + 36, true);
      const entEnd = view.getUint32(modInfoOffset + 40, true);
      const stubTop = view.getUint32(modInfoOffset + 44, true);
      const stubEnd = view.getUint32(modInfoOffset + 48, true);

      moduleInfo = {
        attributes: attr,
        attributeLabels: decodeModAttr(attr),
        versionMajor: verMajor,
        versionMinor: verMinor,
        name: modName,
        gpValue,
        entTop,
        entEnd,
        stubTop,
        stubEnd,
        fileOffset: modInfoOffset,
        ramAddress: modInfoRam,
      };
    }

    // Parse .lib.stub imported libraries
    const libraries: ImportedLibrary[] = [];
    const stubSec = sections.find((s) => s.name === '.lib.stub');
    let stubStartOff = stubSec ? stubSec.offset : -1;
    let stubByteSize = stubSec ? stubSec.size : 0;

    if (stubStartOff < 0 && moduleInfo && moduleInfo.stubEnd > moduleInfo.stubTop) {
      const mapped = vaddrToFileOffset(moduleInfo.stubTop, segments, sections);
      if (mapped !== null) {
        stubStartOff = mapped;
        stubByteSize = moduleInfo.stubEnd - moduleInfo.stubTop;
      }
    }

    if (stubStartOff >= 0 && stubByteSize >= 20) {
      let pos = stubStartOff;
      const limit = Math.min(bytes.length, stubStartOff + stubByteSize);
      while (pos + 20 <= limit) {
        const nameVaddr = view.getUint32(pos, true);
        const verMin = bytes[pos + 4];
        const verMaj = bytes[pos + 5];
        const stubFlags = view.getUint16(pos + 6, true);
        const stubWords = bytes[pos + 8];
        const nidCount = view.getUint16(pos + 10, true);
        const nidTableAddr = view.getUint32(pos + 12, true);
        const stubAddr = view.getUint32(pos + 16, true);

        const nameOff = vaddrToFileOffset(nameVaddr, segments, sections);
        const libName = nameOff !== null ? readNullAscii(bytes, nameOff, 64) : '';
        if (libName) {
          libraries.push({
            name: libName,
            version: `${verMaj}.${verMin}`,
            flags: stubFlags,
            nidCount,
            stubAddr,
            nidTableAddr,
            purpose: describeLibrary(libName),
          });
        }
        const step = Math.max(20, stubWords * 4);
        pos += step;
      }
    }

    // Build unified Address Index
    const addresses: AddressEntry[] = [];
    let addrIdx = 1;

    const entryFileOff = vaddrToFileOffset(eEntry, segments, sections);
    addresses.push({
      index: addrIdx++,
      category: 'ENTRY_POINT',
      categoryLabel: 'Entry Point (Inicio CPU MIPS)',
      label: '_start / e_entry',
      fileOffset: entryFileOff,
      ramAddress: eEntry,
      sizeOrValue: '4 B (MIPS)',
      sectionName: '.text',
      description: 'Dirección exacta en RAM donde la CPU Allegrex inicia la ejecución del programa.',
    });

    if (moduleInfo) {
      addresses.push({
        index: addrIdx++,
        category: 'MODULE_INFO',
        categoryLabel: 'Estructura sceModuleInfo',
        label: moduleInfo.name,
        fileOffset: moduleInfo.fileOffset,
        ramAddress: moduleInfo.ramAddress,
        sizeOrValue: '52 B',
        sectionName: '.rodata.sceModuleInfo',
        description: `Descriptor principal del módulo (${moduleInfo.attributeLabels.join(', ')}), $gp=0x${moduleInfo.gpValue.toString(16).toUpperCase()}.`,
      });
    }

    for (const seg of segments) {
      addresses.push({
        index: addrIdx++,
        category: 'SEGMENT',
        categoryLabel: 'Segmento ELF (Program Header)',
        label: `${seg.typeLabel} #${seg.index} (${seg.flagsText})`,
        fileOffset: seg.offset,
        ramAddress: seg.vaddr,
        sizeOrValue: `${seg.filesz.toLocaleString('es-ES')} B archivo / ${seg.memsz.toLocaleString('es-ES')} B RAM`,
        sectionName: `Segmento #${seg.index}`,
        description: 'Bloque mapeado directamente desde el archivo EBOOT.BIN hacia la memoria física/virtual de la PSP.',
      });
    }

    for (const sec of sections) {
      if (sec.size === 0 && sec.vaddr === 0) continue;
      addresses.push({
        index: addrIdx++,
        category: 'SECTION',
        categoryLabel: 'Sección ELF32',
        label: sec.name,
        fileOffset: sec.offset > 0 ? sec.offset : null,
        ramAddress: sec.vaddr > 0 ? sec.vaddr : null,
        sizeOrValue: `${sec.size.toLocaleString('es-ES')} B`,
        sectionName: sec.name,
        description: sec.purpose,
      });
    }

    for (const lib of libraries) {
      const stubOff = vaddrToFileOffset(lib.stubAddr, segments, sections);
      addresses.push({
        index: addrIdx++,
        category: 'LIBRARY_STUB',
        categoryLabel: 'Librería Importada (.lib.stub)',
        label: `${lib.name} (${lib.nidCount} NIDs)`,
        fileOffset: stubOff,
        ramAddress: lib.stubAddr,
        sizeOrValue: `${lib.nidCount} funciones`,
        sectionName: '.sceStub.text',
        description: lib.purpose,
      });
    }

    const mipsRefs = scanMipsCodeReferences(bytes, segments, sections);
    for (const ref of mipsRefs) {
      addresses.push({ ...ref, index: addrIdx++ });
    }

    const stringRefs = scanStringsAndAddresses(bytes, segments, sections, baseRamAddress);
    for (const str of stringRefs) {
      addresses.push({ ...str, index: addrIdx++ });
    }

    notes.push(
      `Ejecutable ELF32 MIPS detectado. Punto de entrada en 0x${eEntry.toString(16).toUpperCase().padStart(8, '0')}, ${sections.length} secciones y ${addresses.length} direcciones indexadas.`
    );

    return {
      sourceName: options.sourceName,
      sourceKind: options.sourceKind,
      targetBinaryPath: options.targetBinaryPath,
      fileSize: bytes.length,
      format: 'ELF32',
      formatLabel: 'Ejecutable ELF32 Desencriptado (MIPS Allegrex)',
      isEncryptedPsp: false,
      isStrippedElf,
      baseRamAddress,
      elfHeader,
      pspHeader: null,
      pbpHeader: null,
      moduleInfo,
      segments,
      sections,
      libraries,
      addresses,
      isoInfo: options.isoInfo ?? null,
      sfoInfo: options.sfoInfo ?? null,
      alternativeBootBinaryPath: options.alternativeBootBinaryPath ?? null,
      analyzedNotes: notes,
      rawBytes: bytes,
    };
  }

  // Fallback unknown format: still index strings so user gets diagnostic insight
  const fallbackStrings = scanStringsAndAddresses(bytes, [], [], 0x08804000);
  return {
    sourceName: options.sourceName,
    sourceKind: options.sourceKind,
    targetBinaryPath: options.targetBinaryPath,
    fileSize: bytes.length,
    format: 'UNKNOWN',
    formatLabel: `Formato desconocido (Magic 0x${magic.toString(16).toUpperCase().padStart(8, '0')})`,
    isEncryptedPsp: false,
    isStrippedElf: false,
    baseRamAddress: 0x08804000,
    elfHeader: null,
    pspHeader: null,
    pbpHeader: null,
    moduleInfo: null,
    segments: [],
    sections: [],
    libraries: [],
    addresses: fallbackStrings,
    isoInfo: options.isoInfo ?? null,
    sfoInfo: options.sfoInfo ?? null,
    alternativeBootBinaryPath: options.alternativeBootBinaryPath ?? null,
    analyzedNotes: [
      'La firma inicial no corresponde a ~PSP, \\x7FELF ni \\0PBP. Se escanearon cadenas ASCII imprimibles para diagnóstico.',
    ],
    rawBytes: bytes,
  };
}
