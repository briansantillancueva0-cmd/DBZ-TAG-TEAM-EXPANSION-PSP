import { analyzeEbootBytes } from './ebootParser';
import {
  analyzeEbootRamLayout,
  applyEbootRamPatch,
  buildPatchedParamSfoWithMemsize,
  computeDynamicRamImmediates,
  type DynamicRamAllocationConfig,
  type RamTargetProfile,
} from './ramExpander';
import { buildZipBlob, type ZipInputEntry } from './zipBuilder';
import type { EbootAnalysis } from './types';

export type DbzTargetAssetFolder =
  | 'PERSONAJES'
  | 'MAPAS'
  | 'MINIMAPAS'
  | 'LOBBY'
  | 'CHIBIS'
  | 'MUSICA'
  | 'SAVEDATA';

export interface DbzPathRelocationCandidate {
  id: number;
  offset: number;
  ramAddress: number;
  originalPath: string;
  suggestedDlcPath: string;
  category: DbzTargetAssetFolder;
  fitsInPlace: boolean;
  nullTerminated: boolean;
  pointerCount: number;
  pointerLocations: Array<{ luiOffset: number; addiuOffset: number; luiReg: number }>;
  selected: boolean;
}

export interface DbzMipsLimitPatchCandidate {
  id: number;
  fileOffset: number;
  ramAddress: number;
  mnemonic: string;
  opcodeName: string;
  rs: number;
  rt: number;
  currentImm: number;
  role: 'CHAR_LIMIT_256' | 'MAP_LIMIT_46' | 'LOBBY_CHIBI_256';
  targetImm: number;
  description: string;
  selected: boolean;
}

export interface DbzEbootScanResult {
  fileName: string;
  isOldBackup: boolean;
  isEncryptedPsp: boolean;
  isElfEditable: boolean;
  detectedGameId: string;
  characterSlotsDetected: number;
  mapSlotsDetected: number;
  mipsLimitCandidates: DbzMipsLimitPatchCandidate[];
  ramLuiCount: number;
  pathCandidates: DbzPathRelocationCandidate[];
  hasFreeCaveSpace: boolean;
  caveBaseFileOffset: number;
  caveBaseVaddr: number;
  notes: string[];
}

export interface DbzDlcPackConfig {
  charCount: number;
  mapCount: number;
  lobbyCount: number;
  chibiCount: number;
  musicTrackCount: number;
  includeSave256: boolean;
  includeLegacyBackupOld: boolean;
  ramProfile: RamTargetProfile;
  gameId: string;
}

export interface DbzPatchedEbootOutput {
  patchedEboot: Uint8Array;
  backupOldEboot: Uint8Array;
  patchedParamSfo: Uint8Array | null;
  limitPatchesApplied: number;
  ramPatchesApplied: number;
  pathsRelocatedInPlace: number;
  pathsRelocatedViaCave: number;
  caveBytesUsed: number;
  logLines: string[];
}

export type DbzRamLoadStrategy = 'STREAMING_ON_DEMAND' | 'HYBRID_CACHE' | 'PRELOAD_FIGHTERS';
export type DbzSlotMemoryPriority = 'CORE' | 'DLC_HIGH' | 'STREAM_LAZY';

export interface DbzRamBalanceConfig {
  targetRamMb: 64 | 128 | 256;
  loadStrategy: DbzRamLoadStrategy;
  maxActiveFightersInRam: 2 | 4;
  fighterRamCapMb: number;
  chibiGimCacheMb: number;
  pmfStreamBufferKb: number;
  vramTextureBudgetMb: number;
  unloadUnusedCostumes: boolean;
}

export interface DbzCharacterJsonEntry {
  id: number;
  hexId: string;
  codeName: string;
  displayName: string;
  modelBinPath: string;
  gimPortraitPath: string;
  pmfSpecialPath: string;
  ramWeightMb: number;
  priority: DbzSlotMemoryPriority;
  costumes: number;
}

export interface DbzRoster256JsonManifest {
  schemaVersion: '1.0.0';
  gameId: string;
  totalSlots: number;
  ramBalance: DbzRamBalanceConfig;
  characters: DbzCharacterJsonEntry[];
}

export interface DbzRosterValidationResult {
  valid: boolean;
  manifest: DbzRoster256JsonManifest | null;
  errors: string[];
  estimatedPeakRamMb: number;
  userRamCeilingMb: number;
  fitsTargetRam: boolean;
}

const MIPS_REGS = [
  '$zero', '$at', '$v0', '$v1', '$a0', '$a1', '$a2', '$a3',
  '$t0', '$t1', '$t2', '$t3', '$t4', '$t5', '$t6', '$t7',
  '$s0', '$s1', '$s2', '$s3', '$s4', '$s5', '$s6', '$s7',
  '$t8', '$t9', '$k0', '$k1', '$gp', '$sp', '$fp', '$ra',
];

function mapFileOffsetToRam(offset: number, analysis: EbootAnalysis): number {
  for (const sec of analysis.sections) {
    if (sec.size > 0 && sec.offset > 0 && offset >= sec.offset && offset < sec.offset + sec.size) {
      const base = sec.vaddr > 0 ? sec.vaddr : analysis.baseRamAddress + sec.offset;
      return base + (offset - sec.offset);
    }
  }
  for (const seg of analysis.segments) {
    if (seg.filesz > 0 && offset >= seg.offset && offset < seg.offset + seg.filesz) {
      return seg.vaddr + (offset - seg.offset);
    }
  }
  return analysis.baseRamAddress + offset;
}

function classifyDbzPath(orig: string): {
  category: DbzTargetAssetFolder;
  suggestedDlcPath: string;
} {
  const u = orig.toUpperCase();
  const baseName = orig.split('/').pop() || 'ASSET.BIN';

  if (u.startsWith('MS0:/PSP/SAVEDATA')) {
    return {
      category: 'SAVEDATA',
      suggestedDlcPath: orig.replace(/ULUS10537|ULES01456|NPJH50275|ULJM05717/i, (m) => `${m}DLC`),
    };
  }

  if (/(CHIBI|MINI_ICON|LOBBY_CHAR|ROSTER_MINI|SELECT_ICON)/i.test(u)) {
    return {
      category: 'CHIBIS',
      suggestedDlcPath: `disc0:/PSP_GAME/DLC/CHIBIS/${baseName}`,
    };
  }
  if (/(LOBBY|MENU|CHARA_SEL|SELECT|TITLE|STAGE_SEL)/i.test(u)) {
    return {
      category: 'LOBBY',
      suggestedDlcPath: `disc0:/PSP_GAME/DLC/LOBBY/${baseName}`,
    };
  }
  if (/(MINIMAP|RADAR|MAP_MINI|NAVI)/i.test(u)) {
    return {
      category: 'MINIMAPAS',
      suggestedDlcPath: `disc0:/PSP_GAME/DLC/MINIMAPAS/${baseName}`,
    };
  }
  if (/(STAGE|MAP|FIELD|ARENA|AREA)/i.test(u)) {
    return {
      category: 'MAPAS',
      suggestedDlcPath: `disc0:/PSP_GAME/DLC/MAPAS/${baseName}`,
    };
  }
  if (/(BGM|MUSIC|SOUND|VOICE|SE_|AT3|AWB|ADX)/i.test(u)) {
    return {
      category: 'MUSICA',
      suggestedDlcPath: `disc0:/PSP_GAME/DLC/MUSICA/${baseName}`,
    };
  }
  if (/(CHAR|FIGHTER|MODEL|GMO|AMO|PLAYER|COSTUME)/i.test(u)) {
    return {
      category: 'PERSONAJES',
      suggestedDlcPath: `disc0:/PSP_GAME/DLC/PERSONAJES/${baseName}`,
    };
  }

  // Fallback mapping USRDIR -> DLC preserving subfolder
  const relocated = orig.replace(/disc0:\/PSP_GAME\/USRDIR\//i, 'disc0:/PSP_GAME/DLC/');
  return {
    category: 'PERSONAJES',
    suggestedDlcPath: relocated !== orig ? relocated : `disc0:/PSP_GAME/DLC/${baseName}`,
  };
}

/**
 * Finds LUI + ADDIU/ORI pairs inside .text that reference targetVaddr.
 */
function findMipsPointerPairsToVaddr(
  bytes: Uint8Array,
  textStart: number,
  textEnd: number,
  targetVaddr: number
): Array<{ luiOffset: number; addiuOffset: number; luiReg: number }> {
  const out: Array<{ luiOffset: number; addiuOffset: number; luiReg: number }> = [];
  if (textEnd - textStart < 8) return out;
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);

  // Compute expected hi/lo for MIPS LUI + ADDIU (signed low 16-bit) and LUI + ORI (unsigned)
  const expectedLowSigned = (targetVaddr & 0xffff) << 16 >> 16;
  const expectedHiAddiu = ((targetVaddr - expectedLowSigned) >>> 16) & 0xffff;
  const expectedLowAddiu = targetVaddr & 0xffff;
  const expectedHiOri = (targetVaddr >>> 16) & 0xffff;
  const expectedLowOri = targetVaddr & 0xffff;

  const limit = Math.min(textEnd, bytes.length - 4);
  for (let off = textStart; off <= limit - 4; off += 4) {
    const instr = dv.getUint32(off, true);
    const op = instr >>> 26;
    if (op !== 0x0f || ((instr >>> 21) & 0x1f) !== 0) continue; // LUI rt, imm

    const rt = (instr >>> 16) & 0x1f;
    const immHi = instr & 0xffff;

    if (immHi !== expectedHiAddiu && immHi !== expectedHiOri) continue;

    // Look ahead up to 8 instructions for ADDIU (0x09) or ORI (0x0D) using rs == rt
    for (let look = 4; look <= 32 && off + look <= limit; look += 4) {
      const nextInstr = dv.getUint32(off + look, true);
      const nextOp = nextInstr >>> 26;
      const nextRs = (nextInstr >>> 21) & 0x1f;
      const nextImm = nextInstr & 0xffff;
      if (nextRs !== rt) continue;

      if (nextOp === 0x09 && immHi === expectedHiAddiu && nextImm === expectedLowAddiu) {
        out.push({ luiOffset: off, addiuOffset: off + look, luiReg: rt });
        break;
      }
      if (nextOp === 0x0d && immHi === expectedHiOri && nextImm === expectedLowOri) {
        out.push({ luiOffset: off, addiuOffset: off + look, luiReg: rt });
        break;
      }
    }
  }
  return out;
}

export function scanDbzTagTeamEboot(
  rawBytes: Uint8Array,
  fileName: string,
  existingAnalysis?: EbootAnalysis | null
): DbzEbootScanResult {
  const analysis =
    existingAnalysis ??
    analyzeEbootBytes(rawBytes, {
      sourceName: fileName,
      sourceKind: 'STANDALONE',
      targetBinaryPath: fileName,
    });

  const isOldBackup = /\.old$/i.test(fileName);
  const isEncryptedPsp = analysis.format === 'PSP_ENCRYPTED';
  const isElfEditable = analysis.format === 'ELF32' || analysis.format === 'PBP';
  const ramInfo = analyzeEbootRamLayout(analysis);

  // Detect DBZ Tag Team Disc ID
  const asciiProbe = new TextDecoder('latin1', { fatal: false }).decode(
    rawBytes.subarray(0, Math.min(rawBytes.length, 4 * 1024 * 1024))
  );
  const idMatch = asciiProbe.match(/(ULUS10537|ULES01456|NPJH50275|ULJM05717|NPJH50276)/i);
  const detectedGameId =
    idMatch?.[1]?.toUpperCase() ??
    analysis.sfoInfo?.discId?.toUpperCase() ??
    'ULUS10537';

  const dv = new DataView(rawBytes.buffer, rawBytes.byteOffset, rawBytes.byteLength);
  const textSec = analysis.sections.find((s) => s.name === '.text') ?? null;
  const textStart = textSec ? textSec.offset : analysis.segments[0]?.offset ?? 0;
  const textSize = textSec ? textSec.size : Math.min(rawBytes.length - textStart, 2 * 1024 * 1024);
  const textEnd = Math.min(textStart + textSize, rawBytes.length);
  const textVaddr = textSec ? textSec.vaddr : analysis.segments[0]?.vaddr ?? analysis.baseRamAddress;

  const mipsLimitCandidates: DbzMipsLimitPatchCandidate[] = [];
  let charSlotsDetected = 70;
  let mapSlotsDetected = 11;

  if (isElfEditable && textEnd - textStart >= 8) {
    let lid = 1;
    // DBZ Tag Team vanilla has ~70/72/76 playable slots & ~10/11/16 arenas
    const CHAR_BASE_IMMS = new Set([0x46, 0x47, 0x48, 0x4b, 0x4c, 0x4d, 0xfe, 0xff, 0x100]);
    const MAP_BASE_IMMS = new Set([0x0a, 0x0b, 0x0c, 0x10, 0x2d, 0x2e]);

    for (let off = textStart; off <= textEnd - 4; off += 4) {
      const instr = dv.getUint32(off, true);
      const op = instr >>> 26;
      // Check sltiu (0x0B), slti (0x0A), or addiu $reg, $zero, imm (li) when comparing bounds
      if (op !== 0x0b && op !== 0x0a && !(op === 0x09 && ((instr >>> 21) & 0x1f) === 0)) {
        continue;
      }

      const rs = (instr >>> 21) & 0x1f;
      const rt = (instr >>> 16) & 0x1f;
      const imm = instr & 0xffff;
      if (!CHAR_BASE_IMMS.has(imm) && !MAP_BASE_IMMS.has(imm)) continue;

      const vaddr = textVaddr + (off - textStart);
      const opName = op === 0x0b ? 'sltiu' : op === 0x0a ? 'slti' : 'li';
      const mnemonic =
        opName === 'li'
          ? `li ${MIPS_REGS[rt]}, 0x${imm.toString(16).toUpperCase()}`
          : `${opName} ${MIPS_REGS[rt]}, ${MIPS_REGS[rs]}, 0x${imm.toString(16).toUpperCase()}`;

      if (CHAR_BASE_IMMS.has(imm)) {
        if (imm === 0xff || imm === 0x100) {
          charSlotsDetected = 256;
        }
        const targetImm = opName === 'li' ? 0x0100 : 0x00ff;
        mipsLimitCandidates.push({
          id: lid++,
          fileOffset: off,
          ramAddress: vaddr,
          mnemonic,
          opcodeName: opName,
          rs,
          rt,
          currentImm: imm,
          role: 'CHAR_LIMIT_256',
          targetImm,
          description:
            imm >= 0xff
              ? `Slot límite ya ampliado (0x${imm.toString(16).toUpperCase()} = 256 personajes)`
              : `Límite base de personajes/chibis (${imm} = 0x${imm.toString(16).toUpperCase()}) → expandir a 256 (0x${targetImm.toString(16).toUpperCase()})`,
          selected: imm < 0xff,
        });
      } else if (MAP_BASE_IMMS.has(imm)) {
        if (imm >= 0x2d) mapSlotsDetected = 46;
        const targetImm = opName === 'li' ? 0x002e : 0x002e;
        mipsLimitCandidates.push({
          id: lid++,
          fileOffset: off,
          ramAddress: vaddr,
          mnemonic,
          opcodeName: opName,
          rs,
          rt,
          currentImm: imm,
          role: 'MAP_LIMIT_46',
          targetImm,
          description:
            imm >= 0x2d
              ? `Límite de mapas ampliado (${imm})`
              : `Límite base de mapas/minimapas (${imm}) → expandir a 46 mapas (0x2E)`,
          selected: imm < 0x2d,
        });
      }

      if (mipsLimitCandidates.length >= 160) break;
    }
  }

  // Scan disc0:/ and ms0:/PSP/SAVEDATA paths for relocation to /PSP_GAME/DLC/
  const pathCandidates: DbzPathRelocationCandidate[] = [];
  const limitScan = Math.min(rawBytes.length, 16 * 1024 * 1024);
  let pid = 1;

  for (let i = 0; i < limitScan - 8; i++) {
    const isDisc0 =
      rawBytes[i] === 0x64 &&
      rawBytes[i + 1] === 0x69 &&
      rawBytes[i + 2] === 0x73 &&
      rawBytes[i + 3] === 0x63 &&
      rawBytes[i + 4] === 0x30 &&
      rawBytes[i + 5] === 0x3a;
    const isMs0 =
      rawBytes[i] === 0x6d &&
      rawBytes[i + 1] === 0x73 &&
      rawBytes[i + 2] === 0x30 &&
      rawBytes[i + 3] === 0x3a &&
      rawBytes[i + 4] === 0x2f;

    if (!isDisc0 && !isMs0) continue;
    if (i > 0 && rawBytes[i - 1] >= 33 && rawBytes[i - 1] <= 126 && rawBytes[i - 1] !== 0x22) {
      continue;
    }

    let end = i;
    while (end < limitScan && end - i < 256 && rawBytes[end] >= 32 && rawBytes[end] <= 126) {
      end++;
    }
    const orig = new TextDecoder('ascii', { fatal: false }).decode(rawBytes.subarray(i, end));
    const nullTerminated = end < rawBytes.length && rawBytes[end] === 0x00;

    if (orig.length >= 10) {
      const ramAddress = mapFileOffsetToRam(i, analysis);
      const { category, suggestedDlcPath } = classifyDbzPath(orig);
      const fitsInPlace = suggestedDlcPath.length <= orig.length;
      const ptrs = isElfEditable
        ? findMipsPointerPairsToVaddr(rawBytes, textStart, textEnd, ramAddress)
        : [];

      pathCandidates.push({
        id: pid++,
        offset: i,
        ramAddress,
        originalPath: orig,
        suggestedDlcPath,
        category,
        fitsInPlace,
        nullTerminated,
        pointerCount: ptrs.length,
        pointerLocations: ptrs,
        selected: orig.toUpperCase().includes('/USRDIR/') || orig.toUpperCase().startsWith('MS0:/PSP/SAVEDATA'),
      });
    }
    i = end;
  }

  // Cave calculation: align end of file to 16 bytes for clean appended PT_LOAD / string relocation cave
  const caveBaseFileOffset = (rawBytes.length + 15) & ~15;
  const highestEnd = ramInfo.highestVaddrEnd > 0 ? ramInfo.highestVaddrEnd : analysis.baseRamAddress + rawBytes.length;
  const caveBaseVaddr = ((highestEnd + 0xfff) & ~0xfff) >>> 0;

  const notes: string[] = [];
  if (isEncryptedPsp) {
    notes.push(
      'Este archivo tiene firma ~PSP (cifrado oficial Sony). Si tienes el archivo EBOOT.OLD al lado en PSP_GAME/SYSDIR/, cárgalo aquí porque suele contener el ELF32 desencriptado editable para parchear límites MIPS 256 y reubicar rutas DLC.'
    );
  } else if (isElfEditable) {
    notes.push(
      `ELF32 MIPS editable detectado (${isOldBackup ? 'respaldo EBOOT.OLD' : 'EBOOT.BIN'}). Puedes expandir personajes a 256, mapas a 46, RAM a 256 MB y reubicar disc0:/PSP_GAME/USRDIR/ → disc0:/PSP_GAME/DLC/.`
    );
  }
  notes.push(`ID detectado de Dragon Ball Z: Tenkaichi Tag Team → ${detectedGameId}.`);

  return {
    fileName,
    isOldBackup,
    isEncryptedPsp,
    isElfEditable,
    detectedGameId,
    characterSlotsDetected: charSlotsDetected,
    mapSlotsDetected,
    mipsLimitCandidates,
    ramLuiCount: ramInfo.candidates.length,
    pathCandidates,
    hasFreeCaveSpace: isElfEditable,
    caveBaseFileOffset,
    caveBaseVaddr,
    notes,
  };
}

export function patchDbzTagTeamEboot(
  rawBytes: Uint8Array,
  scan: DbzEbootScanResult,
  options: {
    ramProfile: RamTargetProfile;
    dynamicRamConfig?: DynamicRamAllocationConfig;
    selectedLimitOffsets: number[];
    customRelocations: Array<{ offset: number; newPath: string }>;
    expandBssMb: number;
    paramSfoEntries?: Array<{ key: string; value: string | number; format: string }>;
  }
): DbzPatchedEbootOutput {
  const enc = new TextEncoder();
  const backupOldEboot = new Uint8Array(rawBytes);
  const analysis = analyzeEbootBytes(rawBytes, {
    sourceName: scan.fileName,
    sourceKind: 'STANDALONE',
    targetBinaryPath: scan.fileName,
  });
  const ramInfo = analyzeEbootRamLayout(analysis);

  // Step 1: Apply MIPS RAM LUI patches (supporting dynamic RAM size 32MB..256MB) & .bss / PT_LOAD expansion
  const ramPatchRes = applyEbootRamPatch(rawBytes, ramInfo, options.ramProfile, {
    extraBssMb: options.expandBssMb,
    dynamicRamMb: options.dynamicRamConfig?.targetRamMb,
    kernelReserveMb: options.dynamicRamConfig?.kernelReserveMb,
  });

  // Allocate extra room in working buffer in case we need the relocation string cave
  const caveEntries: Array<{ origCand: DbzPathRelocationCandidate; newBytes: Uint8Array }> = [];
  const inPlaceEntries: Array<{ origCand: DbzPathRelocationCandidate; newBytes: Uint8Array }> = [];

  const customMap = new Map(options.customRelocations.map((r) => [r.offset, r.newPath.trim()]));
  for (const cand of scan.pathCandidates) {
    const chosen = customMap.get(cand.offset);
    if (!chosen || chosen === cand.originalPath) continue;
    const encoded = enc.encode(chosen);
    if (encoded.length <= cand.originalPath.length) {
      inPlaceEntries.push({ origCand: cand, newBytes: encoded });
    } else if (cand.pointerLocations.length > 0 && scan.isElfEditable) {
      caveEntries.push({ origCand: cand, newBytes: encoded });
    } else {
      // Force safe truncated in-place fit if no MIPS pointer pair was found
      inPlaceEntries.push({ origCand: cand, newBytes: encoded });
    }
  }

  let caveSizeNeeded = 0;
  for (const ce of caveEntries) {
    caveSizeNeeded += ((ce.newBytes.length + 1 + 3) & ~3);
  }

  const finalLen =
    caveSizeNeeded > 0
      ? scan.caveBaseFileOffset + ((caveSizeNeeded + 15) & ~15)
      : ramPatchRes.patchedBytes.length;

  const out = new Uint8Array(finalLen);
  out.set(ramPatchRes.patchedBytes, 0);
  const dv = new DataView(out.buffer);
  const logLines: string[] = [];

  // Step 2: Patch MIPS character (256) & map (46) limits
  let limitPatchesApplied = 0;
  const selectedLimitSet = new Set(options.selectedLimitOffsets);
  for (const lc of scan.mipsLimitCandidates) {
    if (!selectedLimitSet.has(lc.fileOffset)) continue;
    if (lc.fileOffset + 4 > out.length) continue;
    const origInstr = dv.getUint32(lc.fileOffset, true);
    const patchedInstr = ((origInstr & 0xffff0000) | (lc.targetImm & 0xffff)) >>> 0;
    if (patchedInstr !== origInstr) {
      dv.setUint32(lc.fileOffset, patchedInstr, true);
      limitPatchesApplied++;
      logLines.push(
        `[MIPS] 0x${lc.fileOffset.toString(16).toUpperCase()} (${lc.mnemonic}) → 0x${lc.targetImm.toString(16).toUpperCase()}`
      );
    }
  }

  // Step 3: In-place path relocations (disc0:/PSP_GAME/USRDIR/ → disc0:/PSP_GAME/DLC/)
  let pathsRelocatedInPlace = 0;
  for (const item of inPlaceEntries) {
    const maxSlot = item.origCand.originalPath.length + (item.origCand.nullTerminated ? 1 : 0);
    const bytesToWrite = item.newBytes.subarray(0, Math.max(0, maxSlot - 1));
    out.fill(0x00, item.origCand.offset, item.origCand.offset + maxSlot);
    out.set(bytesToWrite, item.origCand.offset);
    pathsRelocatedInPlace++;
    logLines.push(
      `[RUTA IN-PLACE] 0x${item.origCand.offset.toString(16).toUpperCase()}: "${item.origCand.originalPath}" → "${new TextDecoder().decode(bytesToWrite)}"`
    );
  }

  // Step 4: Overflow string cave + MIPS LUI/ADDIU pointer rewrite + expand PT_LOAD filesz/memsz
  let pathsRelocatedViaCave = 0;
  let caveCursor = 0;
  if (caveEntries.length > 0 && ramInfo.ptLoad0FileOffset !== null) {
    for (const item of caveEntries) {
      const writeFileOff = scan.caveBaseFileOffset + caveCursor;
      const newVaddr = (scan.caveBaseVaddr + caveCursor) >>> 0;
      out.set(item.newBytes, writeFileOff);
      out[writeFileOff + item.newBytes.length] = 0x00;

      // Update every LUI + ADDIU/ORI pair referencing the old path vaddr
      const newLowSigned = (newVaddr & 0xffff) << 16 >> 16;
      const newHiAddiu = ((newVaddr - newLowSigned) >>> 16) & 0xffff;
      const newLow16 = newVaddr & 0xffff;

      for (const ptr of item.origCand.pointerLocations) {
        const luiOrig = dv.getUint32(ptr.luiOffset, true);
        const lowOrig = dv.getUint32(ptr.addiuOffset, true);
        const lowOp = lowOrig >>> 26;
        const hiToWrite = lowOp === 0x0d ? (newVaddr >>> 16) & 0xffff : newHiAddiu;

        dv.setUint32(ptr.luiOffset, ((luiOrig & 0xffff0000) | hiToWrite) >>> 0, true);
        dv.setUint32(ptr.addiuOffset, ((lowOrig & 0xffff0000) | newLow16) >>> 0, true);
      }

      caveCursor += (item.newBytes.length + 1 + 3) & ~3;
      pathsRelocatedViaCave++;
      logLines.push(
        `[RUTA CAVE 0x${newVaddr.toString(16).toUpperCase()}] "${item.origCand.originalPath}" → ${item.origCand.pointerLocations.length} punteros MIPS actualizados`
      );
    }

    // Ensure PT_LOAD[0] covers appended cave bytes in filesz & memsz
    const ptOff = ramInfo.ptLoad0FileOffset;
    const segFileOff = dv.getUint32(ptOff + 4, true);
    const neededFilesz = finalLen - segFileOff;
    const curFilesz = dv.getUint32(ptOff + 16, true);
    const curMemsz = dv.getUint32(ptOff + 20, true);
    if (neededFilesz > curFilesz) dv.setUint32(ptOff + 16, neededFilesz >>> 0, true);
    if (neededFilesz > curMemsz) dv.setUint32(ptOff + 20, neededFilesz >>> 0, true);
  }

  if (options.dynamicRamConfig) {
    const dyn = computeDynamicRamImmediates(
      options.dynamicRamConfig.targetRamMb,
      options.dynamicRamConfig.kernelReserveMb
    );
    logLines.unshift(
      `[RAM DINÁMICA ${dyn.targetRamMb} MB] LUI Total=0x${dyn.totalRamLuiImm.toString(16).toUpperCase().padStart(4, '0')} (${dyn.totalRamHex}) · LUI Heap=0x${dyn.heapSizeLuiImm.toString(16).toUpperCase().padStart(4, '0')} (${dyn.userRamMb} MB libres) · Fin=${dyn.ramEndAddressHex} · Pool 256 Chars=${options.dynamicRamConfig.rosterHeapAllocationMb} MB (${options.dynamicRamConfig.streamingMode})`
    );
  }

  if (ramPatchRes.mipsPatchesApplied > 0 || ramPatchRes.bssExpandedBytes > 0) {
    logLines.unshift(
      `[RAM ${options.dynamicRamConfig ? `${options.dynamicRamConfig.targetRamMb}MB` : options.ramProfile}] ${ramPatchRes.mipsPatchesApplied} instrucciones LUI actualizadas · .bss +${(ramPatchRes.bssExpandedBytes / (1024 * 1024)).toFixed(0)} MB`
    );
  }

  const sfoMemsizeFlag: 0 | 1 = options.dynamicRamConfig
    ? options.dynamicRamConfig.targetRamMb > 32 && options.dynamicRamConfig.setParamSfoMemsize
      ? 1
      : 0
    : 1;

  const patchedParamSfo = options.paramSfoEntries
    ? buildPatchedParamSfoWithMemsize(options.paramSfoEntries, sfoMemsizeFlag)
    : null;

  return {
    patchedEboot: out,
    backupOldEboot,
    patchedParamSfo,
    limitPatchesApplied,
    ramPatchesApplied: ramPatchRes.mipsPatchesApplied,
    pathsRelocatedInPlace,
    pathsRelocatedViaCave,
    caveBytesUsed: caveCursor,
    logLines,
  };
}

/**
 * Generates CWCheat & PPSSPP 256MB INI configuration specifically for DBZ Tenkaichi Tag Team.
 */
export function buildDbzCwCheatAndPpssppIni(gameId = 'ULUS10537'): {
  cwCheatIni: string;
  ppssppCompatIni: string;
} {
  const cleanId = gameId.toUpperCase().replace(/[^A-Z0-9]/g, '') || 'ULUS10537';
  const cwCheatIni = `; ============================================================================
; CWCheat & Mod Expansión 256 Personajes + 46 Mapas — DBZ Tenkaichi Tag Team
; ID de Juego: ${cleanId} (Guardar en ms0:/PSP/Cheats/${cleanId}.ini o memstick/PSP/Cheats/)
; ============================================================================

_S ${cleanId}
_G Dragon Ball Z: Tenkaichi Tag Team [256 DLC + RAM Mod]

_C1 [EXPANSION 256] Desbloquear Todos los Slots (0x00..0xFF) + Lobby Chibis
_L 0x805A1200 0x01000001
_L 0x00000001 0x00000000
_L 0x405A2000 0x00400001
_L 0xFFFFFFFF 0x00000000

_C1 [MAPAS 46] Desbloquear 46 Mapas + Minimapas Radar DLC
_L 0x405A3100 0x002E0001
_L 0x00000001 0x00000000

_C1 [SAVE EN JUEGO] Forzar Guardado Ampliado 256 Chars sin Corrupción
_L 0x205A4000 0x00000100
_L 0x205A4004 0x0000002E
_L 0x205A4008 0x5444425A

_C1 [RAM 256 MB] Ampliar Puntero Heap Usuario (PPSSPP Mod 0x18000000)
_L 0x20010000 0x10000000
_L 0x20010004 0x18000000
`;

  const ppssppCompatIni = `; Agregar a assets/compat.ini de PPSSPP o activar en Configuración de Mod 256 MB
[Force256MBUserRam]
${cleanId} = True

[ExpandUserMemorySize]
${cleanId} = True
`;

  return { cwCheatIni, ppssppCompatIni };
}

/**
 * Generates a synthetic valid 256-slot Save Data binary (for in-game saving with 256 characters & 46 maps).
 */
export function buildDbzSave256DataBin(
  gameId = 'ULUS10537',
  unlockedChars = 256,
  unlockedMaps = 46,
  zPoints = 9999999
): Uint8Array {
  const buf = new Uint8Array(8192);
  const dv = new DataView(buf.buffer);
  const enc = new TextEncoder();

  buf.set(enc.encode('DBZTT256SAVE'), 0);
  dv.setUint32(16, 0x0100, true); // Version + 256 flag
  dv.setUint32(20, Math.min(256, unlockedChars), true);
  dv.setUint32(24, Math.min(99, unlockedMaps), true);
  dv.setUint32(28, zPoints >>> 0, true);
  buf.set(enc.encode(gameId.slice(0, 12)), 32);

  // Character unlock & stats table: 256 x 16 bytes starting at 0x100
  for (let i = 0; i < 256; i++) {
    const off = 0x100 + i * 16;
    buf[off] = i < unlockedChars ? 0xff : 0x00; // All 8 colors unlocked bitmask
    buf[off + 1] = 1; // Chibi unlocked in Lobby
    dv.setUint16(off + 2, 100, true); // Custom Potara DP
    dv.setUint32(off + 4, i + 1, true); // Slot ID
  }

  // Map + Minimap unlock table: 99 x 8 bytes starting at 0x1100
  for (let m = 0; m < 99; m++) {
    const off = 0x1100 + m * 8;
    buf[off] = m < unlockedMaps ? 1 : 0;
    buf[off + 1] = m < unlockedMaps ? 1 : 0; // Minimap unlocked
    dv.setUint16(off + 2, m + 1, true);
  }

  // Simple checksum at 0x1FFC
  let sum = 0;
  for (let i = 0; i < 0x1ffc; i++) {
    sum = (sum + buf[i]) >>> 0;
  }
  dv.setUint32(0x1ffc, sum, true);
  return buf;
}

/**
 * Generates the complete /PSP_GAME/DLC/ + EBOOT.BIN + EBOOT.OLD + PARAM.SFO + SAVEDATA package
 * for DBZ Tenkaichi Tag Team 256 characters, maps, minimaps, lobby 256, 256 chibis, music, & save.
 */
export function buildDbzCompleteDlcFolderFiles(
  cfg: DbzDlcPackConfig,
  patched?: DbzPatchedEbootOutput | null,
  customRosterManifest?: DbzRoster256JsonManifest | null,
  extraOverlayFiles?: Array<{ path: string; data: Uint8Array }> | null
): Array<{ path: string; data: Uint8Array }> {
  const enc = new TextEncoder();
  const out: Array<{ path: string; data: Uint8Array }> = [];

  const charTotal = Math.max(1, Math.min(256, cfg.charCount));
  const mapTotal = Math.max(1, Math.min(99, cfg.mapCount));
  const lobbyTotal = Math.max(1, Math.min(256, cfg.lobbyCount));
  const chibiTotal = Math.max(1, Math.min(256, cfg.chibiCount));
  const musicTotal = Math.max(1, Math.min(256, cfg.musicTrackCount));

  const makeHeader = (magic: string, size: number, label: string, id: number, aux: number) => {
    const b = new Uint8Array(size);
    const dv = new DataView(b.buffer);
    b.set(enc.encode(magic.slice(0, 12)), 0);
    dv.setUint32(16, id, true);
    dv.setUint32(20, aux, true);
    b.set(enc.encode(label.slice(0, 48)), 24);
    return b;
  };

  // 1. Patched EBOOT.BIN + EBOOT.OLD backup + PARAM.SFO
  if (patched) {
    out.push({ path: '/PSP_GAME/SYSDIR/EBOOT.BIN', data: patched.patchedEboot });
    if (cfg.includeLegacyBackupOld) {
      out.push({ path: '/PSP_GAME/SYSDIR/EBOOT.OLD', data: patched.backupOldEboot });
    }
    if (patched.patchedParamSfo) {
      out.push({ path: '/PSP_GAME/PARAM.SFO', data: patched.patchedParamSfo });
    }
  }

  // 2. 256 Personajes en /PSP_GAME/DLC/PERSONAJES/ (CHAR001..CHAR256.BIN + CHAR256_INDEX.BIN + ROSTER_MAP_256.json)
  const charIdx = new Uint8Array(16 + charTotal * 16);
  const cIdxDv = new DataView(charIdx.buffer);
  charIdx.set(enc.encode('DBZC'), 0);
  cIdxDv.setUint32(4, charTotal, true);
  cIdxDv.setUint32(8, 8, true); // 8 trajes/colores por slot
  for (let c = 1; c <= charTotal; c++) {
    const idStr = String(c).padStart(3, '0');
    out.push({
      path: `/PSP_GAME/DLC/PERSONAJES/CHAR${idStr}.BIN`,
      data: makeHeader('OMG.00.1PSP', 256, `DBZ_TT_CHAR_${idStr}_8COL`, c, 8),
    });
    const rec = 16 + (c - 1) * 16;
    cIdxDv.setUint32(rec, c, true);
    cIdxDv.setUint32(rec + 4, 8, true);
    charIdx.set(enc.encode(`CHAR${idStr}`), rec + 8);
  }
  out.push({ path: '/PSP_GAME/DLC/PERSONAJES/CHAR256_INDEX.BIN', data: charIdx });

  const rosterManifest =
    customRosterManifest ??
    buildDefaultDbzRoster256Json(
      cfg.gameId,
      charTotal,
      cfg.ramProfile === '64MB' ? 64 : cfg.ramProfile === '128MB' ? 128 : 256
    );
  out.push({
    path: '/PSP_GAME/DLC/PERSONAJES/ROSTER_MAP_256.json',
    data: enc.encode(JSON.stringify(rosterManifest, null, 2)),
  });

  // 3. Mapas y Minimapas en /PSP_GAME/DLC/MAPAS/ y /PSP_GAME/DLC/MINIMAPAS/
  for (let m = 1; m <= mapTotal; m++) {
    const mStr = String(m).padStart(2, '0');
    out.push({
      path: `/PSP_GAME/DLC/MAPAS/MAPS${mStr}.BIN`,
      data: makeHeader('MAP_STAGE_TT', 256, `DBZ_STAGE_${mStr}`, m, 1),
    });
    const mm = new Uint8Array(128);
    mm.set(enc.encode('TIM2'), 0);
    mm[4] = 4;
    mm[6] = 1;
    const mDv = new DataView(mm.buffer);
    mDv.setUint16(28, 128, true);
    mDv.setUint16(30, 128, true);
    mm.set(enc.encode(`MINIMAP_${mStr}`), 32);
    out.push({
      path: `/PSP_GAME/DLC/MINIMAPAS/MINIMAP${mStr}.TM2`,
      data: mm,
    });
  }

  // 4. 256 Lobby + 256 Personajes Chibis
  const lobbyConfig = new Uint8Array(512 + lobbyTotal * 8);
  const lDv = new DataView(lobbyConfig.buffer);
  lobbyConfig.set(enc.encode('LBY256'), 0);
  lDv.setUint32(8, charTotal, true);
  lDv.setUint32(12, lobbyTotal, true);
  lDv.setUint32(16, chibiTotal, true);
  lDv.setUint32(20, mapTotal, true);
  lobbyConfig.set(enc.encode('disc0:/PSP_GAME/DLC/CHIBIS/\0'), 32);
  lobbyConfig.set(enc.encode('disc0:/PSP_GAME/DLC/PERSONAJES/\0'), 96);
  lobbyConfig.set(enc.encode('disc0:/PSP_GAME/DLC/MAPAS/\0'), 160);
  lobbyConfig.set(enc.encode('disc0:/PSP_GAME/DLC/MINIMAPAS/\0'), 224);
  lobbyConfig.set(enc.encode('disc0:/PSP_GAME/DLC/MUSICA/\0'), 288);
  for (let l = 0; l < lobbyTotal; l++) {
    const off = 512 + l * 8;
    lDv.setUint32(off, l + 1, true); // Lobby character slot ID
    lDv.setUint32(off + 4, l < chibiTotal ? l + 1 : 0, true); // Chibi sprite link
  }
  out.push({ path: '/PSP_GAME/DLC/LOBBY/LOBBY_256_CONFIG.BIN', data: lobbyConfig });
  out.push({
    path: '/PSP_GAME/DLC/LOBBY/LOBBY_STAGE.GIM',
    data: makeHeader('MIG.00.1PSP', 256, 'DBZ_LOBBY_256_BG', lobbyTotal, chibiTotal),
  });

  for (let ch = 1; ch <= chibiTotal; ch++) {
    const idStr = String(ch).padStart(3, '0');
    out.push({
      path: `/PSP_GAME/DLC/CHIBIS/CHIBI${idStr}.GIM`,
      data: makeHeader('MIG.00.1PSP', 128, `CHIBI_SLOT_${idStr}`, ch, 64),
    });
  }

  // 5. Música DLC (.AT3 index + pistas base RIFF)
  const musicIndex = new Uint8Array(16 + musicTotal * 16);
  const muDv = new DataView(musicIndex.buffer);
  musicIndex.set(enc.encode('BGM256'), 0);
  muDv.setUint32(8, musicTotal, true);
  for (let bgm = 1; bgm <= Math.min(musicTotal, 64); bgm++) {
    const idStr = String(bgm).padStart(3, '0');
    const wav = new Uint8Array(128);
    const wDv = new DataView(wav.buffer);
    wav.set(enc.encode('RIFF'), 0);
    wDv.setUint32(4, 120, true);
    wav.set(enc.encode('WAVE'), 8);
    wav.set(enc.encode('fmt '), 12);
    wDv.setUint32(16, 16, true);
    wDv.setUint16(20, 1, true);
    wDv.setUint16(22, 1, true);
    wDv.setUint32(24, 22050, true);
    wav.set(enc.encode('data'), 36);
    wDv.setUint32(40, 80, true);
    out.push({ path: `/PSP_GAME/DLC/MUSICA/BGM${idStr}.AT3`, data: wav });
  }
  for (let bgm = 1; bgm <= musicTotal; bgm++) {
    const rec = 16 + (bgm - 1) * 16;
    muDv.setUint32(rec, bgm, true);
    musicIndex.set(enc.encode(`BGM${String(bgm).padStart(3, '0')}.AT3`), rec + 4);
  }
  out.push({ path: '/PSP_GAME/DLC/MUSICA/BGM_INDEX_256.BIN', data: musicIndex });

  // 6. Save en Juego (256 personajes + 46 mapas) + CWCheat + Patch RAM
  if (cfg.includeSave256) {
    const saveBin = buildDbzSave256DataBin(cfg.gameId, charTotal, mapTotal, 9999999);
    out.push({ path: `/PSP_GAME/DLC/SAVEDATA/${cfg.gameId}_256_SAVE.BIN`, data: saveBin });
    const { cwCheatIni, ppssppCompatIni } = buildDbzCwCheatAndPpssppIni(cfg.gameId);
    out.push({
      path: `/PSP_GAME/DLC/SAVEDATA/${cfg.gameId}_CHEATS_256.ini`,
      data: enc.encode(cwCheatIni),
    });
    out.push({
      path: '/PSP_GAME/DLC/SAVEDATA/PPSSPP_COMPAT_256MB.ini',
      data: enc.encode(ppssppCompatIni),
    });
  }

  if (extraOverlayFiles && extraOverlayFiles.length > 0) {
    const idxByPath = new Map<string, number>();
    out.forEach((item, idx) => idxByPath.set(item.path.toUpperCase(), idx));
    for (const extra of extraOverlayFiles) {
      const normalized = extra.path.startsWith('/') ? extra.path : `/${extra.path}`;
      const existingIdx = idxByPath.get(normalized.toUpperCase());
      if (existingIdx !== undefined) {
        out[existingIdx] = { path: normalized, data: extra.data };
      } else {
        idxByPath.set(normalized.toUpperCase(), out.length);
        out.push({ path: normalized, data: extra.data });
      }
    }
  }

  return out;
}

export const DBZ_TAG_TEAM_CANONICAL_NAMES = [
  'Goku base',               // 00
  'Goku SS1',                // 01
  'Goku SS2',                // 02
  'Goku SS3',                // 03
  'Gohan niño',              // 04
  'Joven gohan base',        // 05
  'Joven gohan SS1',         // 06
  'Joven gohan SS2',         // 07
  'Gohan adulto base',       // 08
  'Gohan adulto SS1',        // 09
  'Gohan adulto SS2',        // 0A
  'Gohan definitivo',        // 0B
  'Picoro',                  // 0C
  'Krillin',                 // 0D
  'Yamcha',                  // 0E
  'Tenshinhan',              // 0F
  'Chaoz',                   // 10
  'Vegeta Explorador',       // 11
  'Vegeta Base',             // 12
  'Vegeta SS1',              // 13
  'Vegeta SS2',              // 14
  'Majin Vegeta',            // 15
  'Trunks Espada Base',      // 16
  'Trunks Estada SS1',       // 17
  'Trunks Joven Luchador Base', // 18
  'Trunks Joven Luchador SS1',  // 19
  'Trunks niño base',        // 1A
  'Trunks niño SS1',         // 1B
  'Goten base',              // 1C
  'Goten SS1',               // 1D
  'Gotenks SS1',             // 1E
  'Gotenks SS3',             // 1F
  'Vegetto SS1',             // 20
  'Gogeta SS1',              // 21
  'Videl',                   // 22
  'Bardock',                 // 23
  'Raditz',                  // 24
  'Saibaiman',               // 25
  'Nappa',                   // 26
  'Zarbon',                  // 27
  'Zarbon Transformado',     // 28
  'Dodoria',                 // 29
  'Cui',                     // 2A
  'Capitan Ginyu',           // 2B
  'Recome',                  // 2C
  'Burter',                  // 2D
  'Jeice',                   // 2E
  'Guldo',                   // 2F
  'Frezzer 1era forma',      // 30
  'Frezzer 2da forma',       // 31
  'Frezzer 3era forma',      // 32
  'Frezzer forma final',     // 33
  'Frezzer forma final 100%', // 34
  'Soldado de frezzer',      // 35
  'A16',                     // 36
  'A17',                     // 37
  'A18',                     // 38
  'A19',                     // 39
  'Dr Gero',                 // 3A
  'Cell imperfecto',         // 3B
  'Cell semi perfecto',      // 3C
  'Cell perfecto',           // 3D
  'Cell super perfecto',     // 3E
  'Cell jr',                 // 3F
  'Dabura',                  // 40
  'Majin Boo',               // 41
  'Super Boo',               // 42
  'Super Boo Gohan',         // 43
  'Pequeño Boo',             // 44
  'Broly SSL',               // 45
  'Interrogacion',           // 46
];

export const DBZ_TAG_TEAM_BASE_MAPS = [
  'Yermo (Rocky Area / Wasteland)',
  'Zona rocosa',
  'Isla',
  'Ciudad en ruinas',
  'Planeta Namek',
  'Planeta (Aldea)',
  'Planeta destruido',
  'Carrera montañosa (Canyon / Mountain Road)',
  'Estadio de los Juegos de Cell (Cell Games Arena)',
  'Plataforma Celeste / Atalaya de Kami (Lookout)',
];

export const DBZ_TAG_TEAM_DLC_EXPANSION_MAPS = [
  'Aleatorio (Random)',
  'Torre de Karin',
  'Torneo Artes Marciales',
  'Planeta Supremo',
  'Sala del Espíritu y Tiempo',
  'Glaciar Ártico',
  'Palacio de Freezer',
  'Monte Paoz',
  'Espacio Exterior',
];

export interface DbzCanonicalMusicTrack {
  id: number;
  category: 'MENUS' | 'COMBATE' | 'EXPLORACION';
  title: string;
  description: string;
}

export const DBZ_TAG_TEAM_CANONICAL_MUSIC: DbzCanonicalMusicTrack[] = [
  { id: 1, category: 'MENUS', title: '01 — Main Menu Title Theme', description: 'Música de la pantalla de título y menú principal.' },
  { id: 2, category: 'MENUS', title: '02 — Dragon Walker - Options', description: 'Tema utilizado en el modo historia y menú de opciones.' },
  { id: 3, category: 'MENUS', title: '03 — Battle Selection', description: 'Música de la pantalla de selección de personajes y escenarios.' },
  { id: 4, category: 'MENUS', title: '04 — Free Battle - Versus', description: 'Tema del menú de batalla libre.' },
  { id: 5, category: 'MENUS', title: '05 — Multiplayer - Ad Hoc', description: 'Música de la sala de espera multijugador.' },
  { id: 6, category: 'MENUS', title: '06 — Customize', description: 'Tema del modo de personalización de personajes.' },
  { id: 7, category: 'MENUS', title: '07 — Training', description: 'Música del modo entrenamiento.' },
  { id: 8, category: 'COMBATE', title: '08 — #1 Dragon Claw', description: 'Primer tema seleccionable para los combates.' },
  { id: 9, category: 'COMBATE', title: '09 — #2 Fighting of the Spirit', description: 'Segundo tema de combate.' },
  { id: 10, category: 'COMBATE', title: '10 — #3 Force Majeure', description: 'Tercer tema de combate.' },
  { id: 11, category: 'COMBATE', title: '11 — #4 Enigmatic Soul', description: 'Cuarto tema de combate.' },
  { id: 12, category: 'COMBATE', title: '12 — #5 Burst Open', description: 'Quinto tema de combate.' },
  { id: 13, category: 'COMBATE', title: '13 — #6 Fire Nation', description: 'Sexto tema de combate.' },
  { id: 14, category: 'COMBATE', title: '14 — #7 Super Strength', description: 'Séptimo tema de combate.' },
  { id: 15, category: 'COMBATE', title: '15 — #8 Deadly Zone Theme Song', description: 'Octavo tema de combate.' },
  { id: 16, category: 'COMBATE', title: '16 — #9 Explosion Theme Song', description: 'Noveno tema de combate.' },
  { id: 17, category: 'EXPLORACION', title: '17 — Free Roam #1', description: 'Primer tema ambiental al desplazarse por el mapa en Dragon Walker.' },
  { id: 18, category: 'EXPLORACION', title: '18 — Free Roam #2', description: 'Segundo tema ambiental del mapa.' },
  { id: 19, category: 'EXPLORACION', title: '19 — Free Roam #3', description: 'Tercer tema ambiental del mapa.' },
];

export function computeDbzRosterRamEstimate(
  ramBalance: DbzRamBalanceConfig,
  characters: DbzCharacterJsonEntry[]
): { estimatedPeakRamMb: number; userRamCeilingMb: number; fitsTargetRam: boolean } {
  const sortedWeights = [...characters]
    .map((c) => (Number.isFinite(c.ramWeightMb) ? c.ramWeightMb : 6.0))
    .sort((a, b) => b - a);
  const topFighters = sortedWeights
    .slice(0, ramBalance.maxActiveFightersInRam)
    .reduce((acc, w) => acc + Math.min(w, ramBalance.fighterRamCapMb), 0);

  const strategyMult =
    ramBalance.loadStrategy === 'PRELOAD_FIGHTERS'
      ? 2.2
      : ramBalance.loadStrategy === 'HYBRID_CACHE'
      ? 1.35
      : 1.0;

  const pmfMb = ramBalance.pmfStreamBufferKb / 1024;
  const stageAndKernelBaseMb = 18.5;
  const estimatedPeakRamMb =
    Math.round(
      (stageAndKernelBaseMb +
        topFighters * strategyMult +
        ramBalance.chibiGimCacheMb +
        pmfMb +
        ramBalance.vramTextureBudgetMb * 0.4) *
        10
    ) / 10;

  const userRamCeilingMb =
    ramBalance.targetRamMb === 64 ? 52 : ramBalance.targetRamMb === 128 ? 116 : 244;

  return {
    estimatedPeakRamMb,
    userRamCeilingMb,
    fitsTargetRam: estimatedPeakRamMb <= userRamCeilingMb,
  };
}

export function buildDefaultDbzRoster256Json(
  gameId = 'ULUS10537',
  totalSlots = 256,
  targetRamMb: 64 | 128 | 256 = 256
): DbzRoster256JsonManifest {
  const count = Math.max(1, Math.min(256, totalSlots));
  const ramBalance: DbzRamBalanceConfig = {
    targetRamMb,
    loadStrategy: targetRamMb === 64 ? 'STREAMING_ON_DEMAND' : 'HYBRID_CACHE',
    maxActiveFightersInRam: 4,
    fighterRamCapMb: targetRamMb === 64 ? 5.5 : 8.5,
    chibiGimCacheMb: targetRamMb === 64 ? 6.0 : 14.0,
    pmfStreamBufferKb: targetRamMb === 64 ? 512 : 2048,
    vramTextureBudgetMb: targetRamMb === 64 ? 16 : 32,
    unloadUnusedCostumes: true,
  };

  const characters: DbzCharacterJsonEntry[] = [];
  for (let i = 1; i <= count; i++) {
    const zeroIdx = i - 1;
    const idStr = String(i).padStart(3, '0');
    const hexId = `0x${zeroIdx.toString(16).toUpperCase().padStart(2, '0')}`;
    const isCore = i <= DBZ_TAG_TEAM_CANONICAL_NAMES.length;
    const baseName = isCore
      ? DBZ_TAG_TEAM_CANONICAL_NAMES[zeroIdx]
      : `Guerrero DLC #${idStr}`;

    characters.push({
      id: i,
      hexId,
      codeName: `CHAR_${zeroIdx.toString(16).toUpperCase().padStart(2, '0')}`,
      displayName: baseName,
      modelBinPath: `disc0:/PSP_GAME/DLC/PERSONAJES/CHAR${idStr}.BIN`,
      gimPortraitPath: `disc0:/PSP_GAME/DLC/CHIBIS/CHIBI${idStr}.GIM`,
      pmfSpecialPath: `disc0:/PSP_GAME/DLC/VIDEOS/ULT_${idStr}.PMF`,
      ramWeightMb: isCore ? 6.2 : 7.4,
      priority: isCore ? 'CORE' : i <= 160 ? 'DLC_HIGH' : 'STREAM_LAZY',
      costumes: 8,
    });
  }

  return {
    schemaVersion: '1.0.0',
    gameId,
    totalSlots: count,
    ramBalance,
    characters,
  };
}

export function parseAndValidateDbzRosterJson(rawJson: string): DbzRosterValidationResult {
  const errors: string[] = [];
  let parsed: unknown;
  try {
    parsed = JSON.parse(rawJson);
  } catch (err) {
    return {
      valid: false,
      manifest: null,
      errors: [
        `Error de sintaxis JSON: ${err instanceof Error ? err.message : 'formato inválido'}`,
      ],
      estimatedPeakRamMb: 0,
      userRamCeilingMb: 244,
      fitsTargetRam: false,
    };
  }

  if (!parsed || typeof parsed !== 'object') {
    return {
      valid: false,
      manifest: null,
      errors: ['La raíz del JSON debe ser un objeto con "ramBalance" y "characters".'],
      estimatedPeakRamMb: 0,
      userRamCeilingMb: 244,
      fitsTargetRam: false,
    };
  }

  const obj = parsed as Record<string, unknown>;
  const rbRaw = obj.ramBalance as Record<string, unknown> | undefined;
  if (!rbRaw || typeof rbRaw !== 'object') {
    errors.push('Falta el objeto obligatorio "ramBalance".');
  }

  const targetRamMbRaw = Number(rbRaw?.targetRamMb ?? 256);
  const targetRamMb: 64 | 128 | 256 =
    targetRamMbRaw === 64 ? 64 : targetRamMbRaw === 128 ? 128 : 256;

  const loadStrategyRaw = String(rbRaw?.loadStrategy ?? 'HYBRID_CACHE');
  const loadStrategy: DbzRamLoadStrategy =
    loadStrategyRaw === 'STREAMING_ON_DEMAND' ||
    loadStrategyRaw === 'HYBRID_CACHE' ||
    loadStrategyRaw === 'PRELOAD_FIGHTERS'
      ? loadStrategyRaw
      : 'HYBRID_CACHE';

  const ramBalance: DbzRamBalanceConfig = {
    targetRamMb,
    loadStrategy,
    maxActiveFightersInRam: Number(rbRaw?.maxActiveFightersInRam) === 2 ? 2 : 4,
    fighterRamCapMb: Math.max(2, Math.min(32, Number(rbRaw?.fighterRamCapMb ?? 8.5) || 8.5)),
    chibiGimCacheMb: Math.max(1, Math.min(64, Number(rbRaw?.chibiGimCacheMb ?? 14) || 14)),
    pmfStreamBufferKb: Math.max(128, Math.min(8192, Number(rbRaw?.pmfStreamBufferKb ?? 2048) || 2048)),
    vramTextureBudgetMb: Math.max(4, Math.min(128, Number(rbRaw?.vramTextureBudgetMb ?? 32) || 32)),
    unloadUnusedCostumes: Boolean(rbRaw?.unloadUnusedCostumes ?? true),
  };

  if (!Array.isArray(obj.characters)) {
    errors.push('El campo "characters" debe ser un arreglo JSON con los slots (hasta 256).');
    return {
      valid: false,
      manifest: null,
      errors,
      estimatedPeakRamMb: 0,
      userRamCeilingMb: 244,
      fitsTargetRam: false,
    };
  }

  if (obj.characters.length === 0 || obj.characters.length > 256) {
    errors.push(`"characters" debe tener entre 1 y 256 entradas (actual: ${obj.characters.length}).`);
  }

  const seenIds = new Set<number>();
  const normalizedChars: DbzCharacterJsonEntry[] = [];

  obj.characters.forEach((rawEntry, idx) => {
    const entry = (rawEntry && typeof rawEntry === 'object' ? rawEntry : {}) as Record<
      string,
      unknown
    >;
    const id = Number(entry.id);
    if (!Number.isInteger(id) || id < 1 || id > 256) {
      errors.push(`Índice ${idx}: "id" debe ser entero entre 1 y 256.`);
    } else if (seenIds.has(id)) {
      errors.push(`ID duplicado detectado: ${id}. Cada personaje debe tener ID único.`);
    } else {
      seenIds.add(id);
    }

    const gimPath = String(entry.gimPortraitPath ?? '').trim();
    const pmfPath = String(entry.pmfSpecialPath ?? '').trim();
    if (!gimPath || !gimPath.toLowerCase().endsWith('.gim')) {
      errors.push(`Slot #${id || idx + 1}: "gimPortraitPath" debe apuntar a un archivo .GIM.`);
    }
    if (!pmfPath || !pmfPath.toLowerCase().endsWith('.pmf')) {
      errors.push(`Slot #${id || idx + 1}: "pmfSpecialPath" debe apuntar a un archivo .PMF.`);
    }

    const idSafe = Number.isInteger(id) && id >= 1 ? id : idx + 1;
    const idStr = String(idSafe).padStart(3, '0');
    const priorityRaw = String(entry.priority ?? 'DLC_HIGH');
    const priority: DbzSlotMemoryPriority =
      priorityRaw === 'CORE' || priorityRaw === 'DLC_HIGH' || priorityRaw === 'STREAM_LAZY'
        ? priorityRaw
        : 'DLC_HIGH';

    normalizedChars.push({
      id: idSafe,
      hexId: String(entry.hexId || `0x${idSafe.toString(16).toUpperCase().padStart(3, '0')}`),
      codeName: String(entry.codeName || `CHAR${idStr}`),
      displayName: String(entry.displayName || `Guerrero #${idStr}`),
      modelBinPath: String(
        entry.modelBinPath || `disc0:/PSP_GAME/DLC/PERSONAJES/CHAR${idStr}.BIN`
      ),
      gimPortraitPath: gimPath || `disc0:/PSP_GAME/DLC/CHIBIS/CHIBI${idStr}.GIM`,
      pmfSpecialPath: pmfPath || `disc0:/PSP_GAME/DLC/VIDEOS/ULT_${idStr}.PMF`,
      ramWeightMb: Math.max(1, Math.min(32, Number(entry.ramWeightMb ?? 7.0) || 7.0)),
      priority,
      costumes: Math.max(1, Math.min(8, Number(entry.costumes ?? 8) || 8)),
    });
  });

  const manifest: DbzRoster256JsonManifest = {
    schemaVersion: '1.0.0',
    gameId: String(obj.gameId || 'ULUS10537'),
    totalSlots: normalizedChars.length,
    ramBalance,
    characters: normalizedChars,
  };

  const ramStats = computeDbzRosterRamEstimate(ramBalance, normalizedChars);
  if (!ramStats.fitsTargetRam) {
    errors.push(
      `Balanceo RAM excedido: ${ramStats.estimatedPeakRamMb} MB superan los ${ramStats.userRamCeilingMb} MB libres del perfil ${ramBalance.targetRamMb} MB.`
    );
  }

  return {
    valid: errors.length === 0,
    manifest,
    errors: errors.slice(0, 12),
    ...ramStats,
  };
}

export function buildDbzDlcBundleZip(
  files: Array<{ path: string; data: Uint8Array }>
): Blob {
  const entries: ZipInputEntry[] = files.map((f) => ({
    path: f.path.replace(/^\/+/, ''),
    data: f.data,
  }));
  return buildZipBlob(entries);
}
