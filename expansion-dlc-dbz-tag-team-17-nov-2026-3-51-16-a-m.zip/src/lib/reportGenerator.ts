import { buildGameAssetReport } from './assetClassifier';
import { scanMipsIdLimits, validateIsoLbaAlignment, verifyDisc0Paths } from './dlcVerifier';
import type { EbootAnalysis, IndexedReport, ReportSectionIndex } from './types';

function hex(val: number | null, width = 8): string {
  if (val === null || Number.isNaN(val)) return 'N/A';
  return `0x${(val >>> 0).toString(16).toUpperCase().padStart(width, '0')}`;
}

export function buildIndexedReport(analysis: EbootAnalysis): IndexedReport {
  const generatedAt = new Date().toLocaleString('es-ES');
  const title = analysis.sfoInfo?.title
    ? `${analysis.sfoInfo.title} (${analysis.sfoInfo.discId})`
    : analysis.sourceName;

  const stringEntries = analysis.addresses.filter((a) => a.category.startsWith('STRING_'));
  const mipsEntries = analysis.addresses.filter((a) => a.category === 'MIPS_JAL' || a.category === 'MIPS_PTR');
  const assetReport = buildGameAssetReport(analysis);
  const disc0Checks = verifyDisc0Paths(analysis);
  const isoAlignment = analysis.isoInfo ? validateIsoLbaAlignment(analysis.isoInfo) : null;
  const mipsLimits = scanMipsIdLimits(analysis);
  const dlcIsoFiles =
    analysis.isoInfo?.files.filter(
      (f) => !f.isDirectory && f.path.toUpperCase().startsWith('/PSP_GAME/DLC/')
    ) ?? [];

  const toc: ReportSectionIndex[] = [
    {
      id: 'sec-1',
      code: '1.0',
      title: 'Resumen Ejecutivo y Propósito del Binario',
      countLabel: analysis.format,
    },
    {
      id: 'sec-2',
      code: '2.0',
      title: 'Metadatos de ISO 9660 y PARAM.SFO',
      countLabel: analysis.isoInfo ? `${analysis.isoInfo.totalFiles} archivos` : 'Archivo directo',
    },
    {
      id: 'sec-3',
      code: '3.0',
      title: 'Cabecera Binaria y Estructura sceModuleInfo',
      countLabel: analysis.moduleInfo?.name ?? analysis.pspHeader?.modName ?? 'Cabecera',
    },
    {
      id: 'sec-4',
      code: '4.0',
      title: 'Mapa de Memoria: Segmentos y Secciones ELF32',
      countLabel: `${analysis.sections.length} secciones`,
    },
    {
      id: 'sec-5',
      code: '5.0',
      title: 'Librerías y Funciones del Sistema PSP (NIDs)',
      countLabel: `${analysis.libraries.length} librerías`,
    },
    {
      id: 'sec-6',
      code: '6.0',
      title: 'Índice de Direcciones Clave, Subrutinas MIPS y Cadenas',
      countLabel: `${analysis.addresses.length} direcciones`,
    },
    {
      id: 'sec-7',
      code: '7.0',
      title: 'Árbol de Contenidos del Disco ISO',
      countLabel: analysis.isoInfo ? `${analysis.isoInfo.files.length} entradas` : 'No aplica',
    },
    {
      id: 'sec-8',
      code: '8.0',
      title: 'Personajes, Mapas, Texturas, Música y Minimapas',
      countLabel: `${assetReport.totalCount} activos`,
    },
    {
      id: 'sec-9',
      code: '9.0',
      title: 'Auditoría DLC, Rutas disc0:/, LBA ISO y Límites MIPS',
      countLabel: `${disc0Checks.length} rutas · ${mipsLimits.length} límites`,
    },
  ];

  // Build Plain Text Report
  const txt: string[] = [];
  txt.push('========================================================================');
  txt.push('              INFORME INDEXADO DE EBOOT.BIN / ISO PSP                   ');
  txt.push('========================================================================');
  txt.push(`Archivo analizado : ${analysis.sourceName}`);
  txt.push(`Binario objetivo  : ${analysis.targetBinaryPath}`);
  txt.push(`Formato detectado : ${analysis.formatLabel}`);
  txt.push(`Tamaño binario    : ${analysis.fileSize.toLocaleString('es-ES')} bytes`);
  txt.push(`Fecha de análisis : ${generatedAt}`);
  if (analysis.sfoInfo) {
    txt.push(`Título (SFO)      : ${analysis.sfoInfo.title} [${analysis.sfoInfo.discId}]`);
    txt.push(`Firmware mínimo   : PSP ${analysis.sfoInfo.pspSystemVer} | Versión App: ${analysis.sfoInfo.appVer}`);
  }
  if (analysis.elfHeader) {
    txt.push(`Entry Point (RAM) : ${hex(analysis.elfHeader.entryPoint)}`);
    txt.push(`Arquitectura      : ${analysis.elfHeader.machineLabel}`);
  }
  txt.push('');
  txt.push('--- ÍNDICE GENERAL ---');
  toc.forEach((s) => {
    txt.push(`  [${s.code}] ${s.title.padEnd(56)} (${s.countLabel})`);
  });
  txt.push('');

  txt.push('--- [1.0] PROPÓSITO Y DIAGNÓSTICO ---');
  txt.push('  El archivo EBOOT.BIN es el ejecutable principal de PSP encargado de inicializar');
  txt.push('  los módulos del sistema (pantalla, controles, E/S UMD/MS), montar recursos de');
  txt.push('  PSP_GAME/USRDIR y ejecutar la lógica del juego o aplicación homebrew en MIPS.');
  analysis.analyzedNotes.forEach((n) => txt.push(`  • ${n}`));
  txt.push('');

  if (analysis.pspHeader) {
    txt.push('--- [3.0] CABECERA PÚBLICA ~PSP ---');
    txt.push(`  Nombre del módulo  : ${analysis.pspHeader.modName}`);
    txt.push(`  Versión módulo     : ${analysis.pspHeader.modVerMajor}.${analysis.pspHeader.modVerMinor}`);
    txt.push(`  Atributos módulo   : 0x${analysis.pspHeader.modAttr.toString(16).toUpperCase()} (${analysis.pspHeader.modAttrLabels.join(', ')})`);
    txt.push(`  Compresión/Estado  : 0x${analysis.pspHeader.compAttr.toString(16).toUpperCase()} (${analysis.pspHeader.compAttrLabels.join(', ')})`);
    txt.push(`  Tamaño ELF / PSP   : ${analysis.pspHeader.elfSize} B / ${analysis.pspHeader.pspSize} B`);
    txt.push(`  Entry declarado    : ${hex(analysis.pspHeader.bootEntry)}`);
    txt.push(`  Devkit SDK         : ${analysis.pspHeader.devkitVersionLabel}`);
    txt.push('');
  }

  if (analysis.moduleInfo) {
    txt.push('--- [3.0] ESTRUCTURA sceModuleInfo ---');
    txt.push(`  Nombre interno     : ${analysis.moduleInfo.name}`);
    txt.push(`  Offset / RAM       : ${hex(analysis.moduleInfo.fileOffset, 6)} / ${hex(analysis.moduleInfo.ramAddress)}`);
    txt.push(`  Registro $gp       : ${hex(analysis.moduleInfo.gpValue)}`);
    txt.push(`  Tabla Stubs (NID)  : ${hex(analysis.moduleInfo.stubTop)} .. ${hex(analysis.moduleInfo.stubEnd)}`);
    txt.push('');
  }

  txt.push(`--- [4.0] ÍNDICE DE SEGMENTOS Y SECCIONES (${analysis.sections.length} secciones) ---`);
  if (analysis.sections.length === 0) {
    txt.push('  (Sin tabla de secciones ELF visible)');
  } else {
    analysis.sections.forEach((sec, i) => {
      txt.push(
        `  [${String(i + 1).padStart(2, '0')}] ${sec.name.padEnd(22)} | Offset: ${hex(sec.offset, 6)} | RAM: ${hex(sec.vaddr)} | Perm: ${sec.flagsText} | Tam: ${sec.size} B`
      );
    });
  }
  txt.push('');

  txt.push(`--- [5.0] LIBRERÍAS PSP IMPORTADAS (${analysis.libraries.length} librerías) ---`);
  if (analysis.libraries.length === 0) {
    txt.push('  (No se detectaron stubs .lib.stub en el ejecutable visible)');
  } else {
    analysis.libraries.forEach((lib, i) => {
      txt.push(
        `  [${String(i + 1).padStart(2, '0')}] ${lib.name.padEnd(24)} | v${lib.version} | NIDs: ${String(lib.nidCount).padStart(3)} | Stub RAM: ${hex(lib.stubAddr)} -> ${lib.purpose}`
      );
    });
  }
  txt.push('');

  txt.push(`--- [6.0] ÍNDICE DE DIRECCIONES Y CADENAS (${analysis.addresses.length} hallazgos, mostrando hasta 250) ---`);
  analysis.addresses.slice(0, 250).forEach((item) => {
    txt.push(
      `  #${String(item.index).padStart(3, '0')} | ${item.categoryLabel.padEnd(28)} | File: ${hex(item.fileOffset, 6)} | RAM: ${hex(item.ramAddress)} | ${item.label}`
    );
  });

  if (analysis.isoInfo) {
    txt.push('');
    txt.push(`--- [7.0] ARCHIVOS DEL DISCO ISO (${analysis.isoInfo.files.length} entradas, mostrando hasta 120) ---`);
    analysis.isoInfo.files.slice(0, 120).forEach((f) => {
      const kind = f.isDirectory ? '[DIR ]' : '[FILE]';
      txt.push(
        `  ${kind} LBA ${String(f.lba).padStart(7)} | Offset: ${hex(f.byteOffset, 8)} | ${String(f.size).padStart(10)} B | ${f.path}`
      );
    });
  }

  txt.push('');
  txt.push(`--- [8.0] PERSONAJES, MAPAS, TEXTURAS, MÚSICA Y MINIMAPAS (${assetReport.totalCount} activos) ---`);
  assetReport.summaries.forEach((s) => {
    txt.push(`  • ${s.label}: ${s.count} (${s.isoFileCount} ISO / ${s.ebootRefCount} EBOOT)`);
  });
  assetReport.items.slice(0, 150).forEach((a) => {
    txt.push(
      `  #${String(a.index).padStart(3, '0')} [${a.categoryLabel.padEnd(25)}] | ${a.source.padEnd(9)} | Off: ${hex(a.fileOffset, 6)} | RAM: ${hex(a.ramAddress)} | ${a.pathOrSymbol}`
    );
  });

  txt.push('');
  txt.push('--- [9.0] AUDITORÍA DLC, RUTAS disc0:/, SECTORES LBA Y LÍMITES MIPS ---');
  if (isoAlignment) {
    txt.push(
      `  • Sector lógico PVD: ${isoAlignment.logicalBlockSize} B | Múltiplo 2048: ${isoAlignment.isSizeMultipleOf2048 ? 'SÍ' : 'NO'} | Sin alinear: ${isoAlignment.unalignedFilesCount}`
    );
  }
  txt.push(`  • Rutas disc0:/ / ms0:/ detectadas: ${disc0Checks.length} (${disc0Checks.filter((d) => d.nullTerminated).length} terminadas en 0x00)`);
  disc0Checks.slice(0, 60).forEach((d) => {
    txt.push(
      `    #${String(d.index).padStart(3, '0')} [${d.kind.padEnd(6)}] Off: ${hex(d.fileOffset, 6)} | RAM: ${hex(d.ramAddress)} | 0x00: ${d.nullTerminated ? 'OK' : 'FALTA'} | ${d.path}`
    );
  });
  txt.push(`  • Límites MIPS sltiu/slti en .text: ${mipsLimits.length} candidatos`);
  mipsLimits.slice(0, 60).forEach((m) => {
    txt.push(
      `    #${String(m.index).padStart(3, '0')} [${m.likelyRole.padEnd(10)}] Off: ${hex(m.fileOffset, 6)} | RAM: ${hex(m.ramAddress)} | ${m.mnemonic}`
    );
  });
  txt.push(`  • Archivos en /PSP_GAME/DLC/: ${dlcIsoFiles.length}`);
  dlcIsoFiles.slice(0, 80).forEach((f) => {
    txt.push(`    [DLC] LBA ${String(f.lba).padStart(7)} | ${String(f.size).padStart(10)} B | ${f.path}`);
  });

  // Build Markdown Report
  const md: string[] = [];
  md.push(`# Informe Indexado: ${title}`);
  md.push('');
  md.push(`- **Archivo origen:** \`${analysis.sourceName}\``);
  md.push(`- **Binario analizado:** \`${analysis.targetBinaryPath}\``);
  md.push(`- **Formato:** ${analysis.formatLabel}`);
  md.push(`- **Tamaño:** ${analysis.fileSize.toLocaleString('es-ES')} bytes`);
  if (analysis.elfHeader) {
    md.push(`- **Entry Point (RAM):** \`${hex(analysis.elfHeader.entryPoint)}\``);
  }
  md.push('');
  md.push('## Tabla de Contenidos Indexada');
  toc.forEach((s) => {
    md.push(`- **${s.code}** ${s.title} *(${s.countLabel})*`);
  });
  md.push('');
  md.push('## 1.0 Resumen y Propósito de EBOOT.BIN');
  md.push(
    'El ejecutable `EBOOT.BIN` coordina el arranque del software en la consola PSP: inicializa los controladores mediante stubs NID, carga los recursos de `disc0:/PSP_GAME/USRDIR/` en la memoria principal (`0x08804000+`) y ejecuta las rutinas MIPS Allegrex.'
  );
  md.push('');
  if (analysis.sfoInfo) {
    md.push('## 2.0 Metadatos PARAM.SFO e ISO 9660');
    md.push('| Campo | Valor |');
    md.push('| --- | --- |');
    md.push(`| Título | ${analysis.sfoInfo.title} |`);
    md.push(`| DISC_ID | \`${analysis.sfoInfo.discId}\` |`);
    md.push(`| Versión Sistema PSP | ${analysis.sfoInfo.pspSystemVer} |`);
    md.push(`| Categoría | ${analysis.sfoInfo.categoryLabel} |`);
    if (analysis.isoInfo) {
      md.push(`| Etiqueta Volumen ISO | \`${analysis.isoInfo.volume.volumeId}\` |`);
      md.push(`| Archivos / Carpetas | ${analysis.isoInfo.totalFiles} archivos / ${analysis.isoInfo.totalDirs} directorios |`);
    }
    md.push('');
  }
  md.push('## 4.0 Mapa de Memoria y Secciones ELF32');
  if (analysis.sections.length > 0) {
    md.push('| # | Sección | Offset Archivo | Dirección RAM | Permisos | Tamaño | Propósito |');
    md.push('| --- | --- | --- | --- | --- | --- | --- |');
    analysis.sections.forEach((sec, i) => {
      md.push(
        `| ${i + 1} | \`${sec.name}\` | \`${hex(sec.offset, 6)}\` | \`${hex(sec.vaddr)}\` | \`${sec.flagsText}\` | ${sec.size} B | ${sec.purpose} |`
      );
    });
  } else {
    md.push('No hay secciones ELF descifradas expuestas en este contenedor.');
  }
  md.push('');
  md.push('## 5.0 Librerías PSP Importadas');
  if (analysis.libraries.length > 0) {
    md.push('| Librería | Versión | NIDs | Dirección Stub RAM | Función |');
    md.push('| --- | --- | --- | --- | --- |');
    analysis.libraries.forEach((lib) => {
      md.push(`| \`${lib.name}\` | ${lib.version} | ${lib.nidCount} | \`${hex(lib.stubAddr)}\` | ${lib.purpose} |`);
    });
  } else {
    md.push('No se detectaron tablas `.lib.stub` expuestas.');
  }
  md.push('');
  md.push(`## 6.0 Direcciones Clave, Subrutinas (${mipsEntries.length}) y Cadenas (${stringEntries.length})`);
  md.push('| # | Categoría | Offset Archivo | Dirección RAM | Valor / Etiqueta | Sección |');
  md.push('| --- | --- | --- | --- | --- | --- |');
  analysis.addresses.slice(0, 250).forEach((item) => {
    const safeLabel = item.label.replace(/\|/g, '\\|');
    md.push(
      `| ${item.index} | ${item.categoryLabel} | \`${hex(item.fileOffset, 6)}\` | \`${hex(item.ramAddress)}\` | \`${safeLabel}\` | ${item.sectionName} |`
    );
  });
  md.push('');
  md.push(`## 8.0 Personajes, Mapas, Texturas, Música y Minimapas (${assetReport.totalCount} activos)`);
  md.push('| Categoría | Total | Archivos ISO | Referencias EBOOT | Tamaño ISO |');
  md.push('| --- | ---: | ---: | ---: | ---: |');
  assetReport.summaries.forEach((s) => {
    md.push(`| ${s.label} | ${s.count} | ${s.isoFileCount} | ${s.ebootRefCount} | ${s.totalIsoBytes.toLocaleString('es-ES')} B |`);
  });
  md.push('');
  md.push('## 9.0 Auditoría DLC, Rutas disc0:/, Sectores LBA y Límites MIPS');
  if (isoAlignment) {
    md.push(
      `- **Validación Sector 16 PVD:** ${isoAlignment.logicalBlockSize} B · Múltiplo 2048 B: **${isoAlignment.isSizeMultipleOf2048 ? 'Correcto' : 'Desalineado'}** · Archivos sin alinear: ${isoAlignment.unalignedFilesCount}`
    );
  }
  md.push(`- **Rutas \`disc0:/\` / \`ms0:/\`:** ${disc0Checks.length} detectadas (${disc0Checks.filter((d) => d.nullTerminated).length} con terminador \`0x00\`).`);
  md.push(`- **Límites MIPS \`sltiu/slti\` en \`.text\`:** ${mipsLimits.length} candidatos.`);
  md.push(`- **Archivos en \`/PSP_GAME/DLC/\`:** ${dlcIsoFiles.length}.`);

  // Build CSV Address Table
  const csvRows: string[] = [
    'Indice,Categoria,OffsetArchivo,DireccionRAM,Seccion,TamanoOValor,Etiqueta,Descripcion',
  ];
  for (const item of analysis.addresses) {
    const esc = (s: string) => `"${s.replace(/"/g, '""')}"`;
    csvRows.push(
      [
        item.index,
        esc(item.categoryLabel),
        hex(item.fileOffset, 6),
        hex(item.ramAddress),
        esc(item.sectionName),
        esc(item.sizeOrValue),
        esc(item.label),
        esc(item.description),
      ].join(',')
    );
  }

  const { rawBytes: _omitRaw, ...jsonReady } = analysis;

  return {
    generatedAt,
    title,
    toc,
    plainText: txt.join('\n'),
    markdown: md.join('\n'),
    csv: csvRows.join('\n'),
    json: JSON.stringify(
      {
        generatedAt,
        toc,
        assetReport,
        dlcVerification: {
          isoAlignment,
          disc0Checks,
          mipsLimits,
          dlcIsoFiles,
        },
        analysis: jsonReady,
      },
      null,
      2
    ),
  };
}
