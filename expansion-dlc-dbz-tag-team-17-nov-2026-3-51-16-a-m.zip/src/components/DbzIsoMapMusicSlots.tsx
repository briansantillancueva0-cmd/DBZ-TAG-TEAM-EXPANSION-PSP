import React, { useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Download,
  FileAudio,
  FolderPlus,
  Image as ImageIcon,
  Layers,
  MapPin,
  Music,
  Play,
  Plus,
  Upload,
} from 'lucide-react';
import {
  DBZ_TAG_TEAM_BASE_MAPS,
  DBZ_TAG_TEAM_CANONICAL_MUSIC,
  DBZ_TAG_TEAM_DLC_EXPANSION_MAPS,
} from '../lib/dbzTagTeamExpander';
import type { EbootAnalysis } from '../lib/types';

export interface IsoMapMiniSlot {
  id: number;
  slotCode: string; // M01..M99
  name: string;
  origin: 'ISO_INTERNO' | 'DLC_AGREGADO';
  isoSourcePath: string;
  dlcMapPath: string;
  dlcMinimapPath: string;
  linkedBgmId: number;
  hasCustomMapFile: boolean;
  hasCustomMinimapFile: boolean;
  customMapBytes?: Uint8Array;
  customMinimapBytes?: Uint8Array;
  customMapFileName?: string;
  customMinimapFileName?: string;
}

export interface IsoMusicMiniSlot {
  id: number;
  slotCode: string; // B01..B256
  title: string;
  origin: 'ISO_INTERNO' | 'DLC_AGREGADO';
  isoSourcePath: string;
  dlcAudioPath: string;
  loopEnabled: boolean;
  hasCustomAudioFile: boolean;
  customAudioBytes?: Uint8Array;
  customAudioFileName?: string;
}

interface DbzIsoMapMusicSlotsProps {
  analysis: EbootAnalysis | null;
  gameId: string;
  mapCount: number;
  musicTrackCount: number;
  mapSlots: IsoMapMiniSlot[];
  musicSlots: IsoMusicMiniSlot[];
  onChangeMapSlots: (next: IsoMapMiniSlot[]) => void;
  onChangeMusicSlots: (next: IsoMusicMiniSlot[]) => void;
  onUpdateCounts?: (nextMapCount: number, nextMusicCount: number) => void;
  onSendMapMusicToIsoPacker?: () => void;
}

const DEFAULT_STAGE_NAMES = [
  ...DBZ_TAG_TEAM_BASE_MAPS,
  ...DBZ_TAG_TEAM_DLC_EXPANSION_MAPS,
];

const DEFAULT_BGM_NAMES = DBZ_TAG_TEAM_CANONICAL_MUSIC.map((t) => t.title);

export function buildInitialIsoMapMusicSlots(
  analysis: EbootAnalysis | null,
  mapCount = 46,
  musicTrackCount = 64
): { maps: IsoMapMiniSlot[]; music: IsoMusicMiniSlot[] } {
  const isoFiles = analysis?.isoInfo?.files.filter((f) => !f.isDirectory) ?? [];
  const detectedIsoMaps = isoFiles.filter((f) =>
    /(map|stage|stg|field|area).*\.(bin|pac|gmo|dat|pck)$/i.test(f.path)
  );
  const detectedIsoMinimaps = isoFiles.filter((f) =>
    /(mini|radar|map).*\.(tm2|gim|png|bin)$/i.test(f.path)
  );
  const detectedIsoMusic = isoFiles.filter((f) =>
    /(bgm|music|sound|voice).*\.(at3|awb|adx|wav|ogg)$/i.test(f.path) || /\.(at3|awb)$/i.test(f.name)
  );

  const maps: IsoMapMiniSlot[] = [];
  for (let i = 1; i <= Math.max(1, Math.min(99, mapCount)); i++) {
    const code = String(i).padStart(2, '0');
    const isoMapMatch = detectedIsoMaps[i - 1];
    const isoMiniMatch = detectedIsoMinimaps[i - 1];
    const isIsoOrigin = i <= 10 || Boolean(isoMapMatch);
    const baseLabel =
      i <= DEFAULT_STAGE_NAMES.length
        ? DEFAULT_STAGE_NAMES[i - 1]
        : `Escenario DLC #${code}`;
    maps.push({
      id: i,
      slotCode: `M${code}`,
      name: baseLabel,
      origin: isIsoOrigin ? 'ISO_INTERNO' : 'DLC_AGREGADO',
      isoSourcePath: isoMapMatch
        ? `disc0:${isoMapMatch.path}`
        : i <= 10
        ? `disc0:/PSP_GAME/USRDIR/STAGE/MAPS${code}.BIN`
        : '',
      dlcMapPath: `disc0:/PSP_GAME/DLC/MAPAS/MAPS${code}.BIN`,
      dlcMinimapPath: isoMiniMatch
        ? `disc0:${isoMiniMatch.path}`
        : `disc0:/PSP_GAME/DLC/MINIMAPAS/MINIMAP${code}.TM2`,
      linkedBgmId: Math.min(musicTrackCount, 8 + ((i - 1) % 9)),
      hasCustomMapFile: false,
      hasCustomMinimapFile: false,
    });
  }

  const music: IsoMusicMiniSlot[] = [];
  for (let b = 1; b <= Math.max(1, Math.min(256, musicTrackCount)); b++) {
    const code = String(b).padStart(3, '0');
    const isoAudio = detectedIsoMusic[b - 1];
    const isIsoOrigin = b <= 19 || Boolean(isoAudio);
    music.push({
      id: b,
      slotCode: `B${String(b).padStart(2, '0')}`,
      title: isoAudio
        ? isoAudio.name
        : b <= DEFAULT_BGM_NAMES.length
        ? DEFAULT_BGM_NAMES[b - 1]
        : `${String(b).padStart(2, '0')} — Pista BGM DLC #${code}`,
      origin: isIsoOrigin ? 'ISO_INTERNO' : 'DLC_AGREGADO',
      isoSourcePath: isoAudio
        ? `disc0:${isoAudio.path}`
        : b <= 19
        ? `disc0:/PSP_GAME/USRDIR/SOUND/BGM${code}.AT3`
        : '',
      dlcAudioPath: `disc0:/PSP_GAME/DLC/MUSICA/BGM${code}.AT3`,
      loopEnabled: true,
      hasCustomAudioFile: false,
    });
  }

  return { maps, music };
}

export function buildOverlayFilesFromMiniSlots(
  gameId: string,
  maps: IsoMapMiniSlot[],
  music: IsoMusicMiniSlot[]
): Array<{ path: string; data: Uint8Array }> {
  const enc = new TextEncoder();
  const out: Array<{ path: string; data: Uint8Array }> = [];

  for (const m of maps) {
    if (m.hasCustomMapFile && m.customMapBytes) {
      const clean = m.dlcMapPath.replace(/^disc0:/i, '');
      out.push({ path: clean.startsWith('/') ? clean : `/${clean}`, data: m.customMapBytes });
    }
    if (m.hasCustomMinimapFile && m.customMinimapBytes) {
      const clean = m.dlcMinimapPath.replace(/^disc0:/i, '');
      out.push({ path: clean.startsWith('/') ? clean : `/${clean}`, data: m.customMinimapBytes });
    }
  }

  for (const bgm of music) {
    if (bgm.hasCustomAudioFile && bgm.customAudioBytes) {
      const clean = bgm.dlcAudioPath.replace(/^disc0:/i, '');
      out.push({ path: clean.startsWith('/') ? clean : `/${clean}`, data: bgm.customAudioBytes });
    }
  }

  const indexManifest = {
    gameId,
    totalMapSlots: maps.length,
    totalMusicSlots: music.length,
    maps: maps.map((m) => ({
      id: m.id,
      slotCode: m.slotCode,
      name: m.name,
      origin: m.origin,
      isoSourcePath: m.isoSourcePath,
      dlcMapPath: m.dlcMapPath,
      dlcMinimapPath: m.dlcMinimapPath,
      linkedBgmId: m.linkedBgmId,
      customMapAttached: m.hasCustomMapFile,
      customMinimapAttached: m.hasCustomMinimapFile,
    })),
    music: music.map((b) => ({
      id: b.id,
      slotCode: b.slotCode,
      title: b.title,
      origin: b.origin,
      isoSourcePath: b.isoSourcePath,
      dlcAudioPath: b.dlcAudioPath,
      loopEnabled: b.loopEnabled,
      customAudioAttached: b.hasCustomAudioFile,
    })),
  };

  const bgnNameLines = music.map(
    (b) => `${b.slotCode} | ${String(b.id).padStart(3, '0')} | ${b.title} | ${b.dlcAudioPath} | LOOP=${b.loopEnabled ? 1 : 0}`
  );
  out.push({
    path: '/PSP_GAME/DLC/MUSICA/BGM_TRACK_NAMES.txt',
    data: enc.encode(bgnNameLines.join('\n')),
  });
  out.push({
    path: '/PSP_GAME/DLC/MUSICA/BGM_TRACK_NAMES.json',
    data: enc.encode(
      JSON.stringify(
        {
          gameId,
          totalTracks: music.length,
          tracks: music.map((b) => ({
            id: b.id,
            slotCode: b.slotCode,
            title: b.title,
            dlcAudioPath: b.dlcAudioPath,
            loopEnabled: b.loopEnabled,
            hasCustomAudio: b.hasCustomAudioFile,
          })),
        },
        null,
        2
      )
    ),
  });

  out.push({
    path: '/PSP_GAME/DLC/MAPAS/MAP_ROSTER_NAMES.json',
    data: enc.encode(
      JSON.stringify(
        {
          gameId,
          totalMaps: maps.length,
          roster: maps.map((m) => ({
            id: m.id,
            slotCode: m.slotCode,
            name: m.name,
            dlcMapPath: m.dlcMapPath,
            dlcMinimapPath: m.dlcMinimapPath,
            linkedBgmId: m.linkedBgmId,
            linkedBgmTitle: music.find((b) => b.id === m.linkedBgmId)?.title ?? '',
          })),
        },
        null,
        2
      )
    ),
  });

  out.push({
    path: '/PSP_GAME/DLC/MAPAS/MAP_MUSIC_DLC_INDEX.json',
    data: enc.encode(JSON.stringify(indexManifest, null, 2)),
  });

  return out;
}

export const DbzIsoMapMusicSlots: React.FC<DbzIsoMapMusicSlotsProps> = ({
  analysis,
  gameId,
  mapSlots,
  musicSlots,
  onChangeMapSlots,
  onChangeMusicSlots,
  onUpdateCounts,
  onSendMapMusicToIsoPacker,
}) => {
  const [selectedMapId, setSelectedMapId] = useState<number>(mapSlots[0]?.id ?? 1);
  const [selectedMusicId, setSelectedMusicId] = useState<number>(musicSlots[0]?.id ?? 1);
  const [mapFilter, setMapFilter] = useState<'ALL' | 'ISO_INTERNO' | 'DLC_AGREGADO' | 'CUSTOM'>('ALL');
  const [musicFilter, setMusicFilter] = useState<'ALL' | 'MENUS' | 'COMBATE' | 'EXPLORACION' | 'DLC_AGREGADO' | 'CUSTOM'>('ALL');
  const [mapSearch, setMapSearch] = useState<string>('');
  const [musicSearch, setMusicSearch] = useState<string>('');
  const [timeLimitSec, setTimeLimitSec] = useState<number>(180);
  const [senzuTeamA, setSenzuTeamA] = useState<number>(1);
  const [senzuTeamB, setSenzuTeamB] = useState<number>(1);
  const [statusNote, setStatusNote] = useState<string | null>(null);

  const mapFileInputRef = useRef<HTMLInputElement | null>(null);
  const minimapFileInputRef = useRef<HTMLInputElement | null>(null);
  const audioFileInputRef = useRef<HTMLInputElement | null>(null);
  const multiAudioInputRef = useRef<HTMLInputElement | null>(null);

  const isoDetectedCount = useMemo(() => {
    const files = analysis?.isoInfo?.files.filter((f) => !f.isDirectory) ?? [];
    const isoMaps = files.filter((f) => /(map|stage|stg|field|area)/i.test(f.path)).length;
    const isoAudio = files.filter((f) => /(bgm|music|at3|awb|sound)/i.test(f.path)).length;
    return { total: files.length, isoMaps, isoAudio };
  }, [analysis]);

  const activeMap = useMemo(
    () => mapSlots.find((m) => m.id === selectedMapId) ?? mapSlots[0],
    [mapSlots, selectedMapId]
  );

  const activeMusic = useMemo(
    () => musicSlots.find((b) => b.id === selectedMusicId) ?? musicSlots[0],
    [musicSlots, selectedMusicId]
  );

  const filteredMaps = useMemo(() => {
    const q = mapSearch.trim().toLowerCase();
    return mapSlots.filter((m) => {
      if (mapFilter === 'CUSTOM' && !m.hasCustomMapFile && !m.hasCustomMinimapFile) return false;
      if ((mapFilter === 'ISO_INTERNO' || mapFilter === 'DLC_AGREGADO') && m.origin !== mapFilter) return false;
      if (!q) return true;
      return m.name.toLowerCase().includes(q) || m.slotCode.toLowerCase().includes(q);
    });
  }, [mapSlots, mapFilter, mapSearch]);

  const filteredMusic = useMemo(() => {
    const q = musicSearch.trim().toLowerCase();
    return musicSlots.filter((b) => {
      if (musicFilter === 'CUSTOM' && !b.hasCustomAudioFile) return false;
      if (musicFilter === 'MENUS' && (b.id < 1 || b.id > 7)) return false;
      if (musicFilter === 'COMBATE' && (b.id < 8 || b.id > 16)) return false;
      if (musicFilter === 'EXPLORACION' && (b.id < 17 || b.id > 19)) return false;
      if (musicFilter === 'DLC_AGREGADO' && b.origin !== 'DLC_AGREGADO') return false;
      if (!q) return true;
      return b.title.toLowerCase().includes(q) || b.slotCode.toLowerCase().includes(q);
    });
  }, [musicSlots, musicFilter, musicSearch]);

  const updateMapSlot = (id: number, patch: Partial<IsoMapMiniSlot>) => {
    onChangeMapSlots(mapSlots.map((m) => (m.id === id ? { ...m, ...patch } : m)));
  };

  const updateMusicSlot = (id: number, patch: Partial<IsoMusicMiniSlot>) => {
    onChangeMusicSlots(musicSlots.map((b) => (b.id === id ? { ...b, ...patch } : b)));
  };

  const handleAddDlcMapSlot = () => {
    if (mapSlots.length >= 99) return;
    const nextId = mapSlots.reduce((mx, m) => Math.max(mx, m.id), 0) + 1;
    const code = String(nextId).padStart(2, '0');
    const newSlot: IsoMapMiniSlot = {
      id: nextId,
      slotCode: `M${code}`,
      name: `Escenario DLC Nuevo #${code}`,
      origin: 'DLC_AGREGADO',
      isoSourcePath: '',
      dlcMapPath: `disc0:/PSP_GAME/DLC/MAPAS/MAPS${code}.BIN`,
      dlcMinimapPath: `disc0:/PSP_GAME/DLC/MINIMAPAS/MINIMAP${code}.TM2`,
      linkedBgmId: activeMusic?.id ?? 1,
      hasCustomMapFile: false,
      hasCustomMinimapFile: false,
    };
    const next = [...mapSlots, newSlot];
    onChangeMapSlots(next);
    onUpdateCounts?.(next.length, musicSlots.length);
    setSelectedMapId(nextId);
    setStatusNote(`Minicasilla de Mapa DLC agregada: ${newSlot.slotCode} → ${newSlot.dlcMapPath}`);
  };

  const handleAddDlcMusicSlot = () => {
    if (musicSlots.length >= 256) return;
    const nextId = musicSlots.reduce((mx, b) => Math.max(mx, b.id), 0) + 1;
    const code = String(nextId).padStart(3, '0');
    const newSlot: IsoMusicMiniSlot = {
      id: nextId,
      slotCode: `B${String(nextId).padStart(2, '0')}`,
      title: `Pista Música DLC #${code}`,
      origin: 'DLC_AGREGADO',
      isoSourcePath: '',
      dlcAudioPath: `disc0:/PSP_GAME/DLC/MUSICA/BGM${code}.AT3`,
      loopEnabled: true,
      hasCustomAudioFile: false,
    };
    const next = [...musicSlots, newSlot];
    onChangeMusicSlots(next);
    onUpdateCounts?.(mapSlots.length, next.length);
    setSelectedMusicId(nextId);
    setStatusNote(`Minicasilla de Música DLC agregada: ${newSlot.slotCode} → ${newSlot.dlcAudioPath}`);
  };

  const handleAttachMapFile = async (e: React.ChangeEvent<HTMLInputElement>, kind: 'MAP' | 'MINIMAP') => {
    const file = e.target.files?.[0];
    if (!file || !activeMap) return;
    const bytes = new Uint8Array(await file.arrayBuffer());
    e.target.value = '';
    if (kind === 'MAP') {
      updateMapSlot(activeMap.id, {
        origin: 'DLC_AGREGADO',
        hasCustomMapFile: true,
        customMapBytes: bytes,
        customMapFileName: file.name,
      });
      setStatusNote(
        `Archivo de mapa "${file.name}" (${bytes.length.toLocaleString('es-ES')} B) asignado a minicasilla ${activeMap.slotCode}.`
      );
    } else {
      updateMapSlot(activeMap.id, {
        origin: 'DLC_AGREGADO',
        hasCustomMinimapFile: true,
        customMinimapBytes: bytes,
        customMinimapFileName: file.name,
      });
      setStatusNote(
        `Minimapa "${file.name}" (${bytes.length.toLocaleString('es-ES')} B) asignado a minicasilla ${activeMap.slotCode}.`
      );
    }
  };

  const handleAttachMusicFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activeMusic) return;
    const bytes = new Uint8Array(await file.arrayBuffer());
    e.target.value = '';
    const cleanTitle = file.name.replace(/\.[^.]+$/, '');
    const safeSlug = cleanTitle.replace(/[^a-zA-Z0-9_-]/g, '_').toUpperCase().slice(0, 24) || `BGM_${activeMusic.id}`;
    updateMusicSlot(activeMusic.id, {
      origin: 'DLC_AGREGADO',
      hasCustomAudioFile: true,
      customAudioBytes: bytes,
      customAudioFileName: file.name,
      title: cleanTitle,
      dlcAudioPath: `disc0:/PSP_GAME/DLC/MUSICA/${safeSlug}.AT3`,
    });
    setStatusNote(
      `Pista "${cleanTitle}" (${bytes.length.toLocaleString('es-ES')} B) asignada a ${activeMusic.slotCode} → disc0:/PSP_GAME/DLC/MUSICA/${safeSlug}.AT3`
    );
  };

  const handleBatchAttachMusicWithNames = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    e.target.value = '';
    if (files.length === 0) return;

    let nextMusic = [...musicSlots];
    let addedCount = 0;

    for (const file of files) {
      const bytes = new Uint8Array(await file.arrayBuffer());
      const cleanTitle = file.name.replace(/\.[^.]+$/, '');
      const safeSlug =
        cleanTitle.replace(/[^a-zA-Z0-9_-]/g, '_').toUpperCase().slice(0, 28) ||
        `TRACK_${nextMusic.length + 1}`;
      // Place into first custom-empty DLC slot >= 20, or append up to 256
      const emptyDlcIdx = nextMusic.findIndex((b) => b.id >= 20 && !b.hasCustomAudioFile);
      if (emptyDlcIdx !== -1) {
        const slot = nextMusic[emptyDlcIdx];
        nextMusic[emptyDlcIdx] = {
          ...slot,
          title: cleanTitle,
          origin: 'DLC_AGREGADO',
          hasCustomAudioFile: true,
          customAudioBytes: bytes,
          customAudioFileName: file.name,
          dlcAudioPath: `disc0:/PSP_GAME/DLC/MUSICA/${safeSlug}.AT3`,
        };
        addedCount++;
      } else if (nextMusic.length < 256) {
        const nextId = nextMusic.reduce((mx, b) => Math.max(mx, b.id), 0) + 1;
        nextMusic.push({
          id: nextId,
          slotCode: `B${String(nextId).padStart(2, '0')}`,
          title: cleanTitle,
          origin: 'DLC_AGREGADO',
          isoSourcePath: '',
          dlcAudioPath: `disc0:/PSP_GAME/DLC/MUSICA/${safeSlug}.AT3`,
          loopEnabled: true,
          hasCustomAudioFile: true,
          customAudioBytes: bytes,
          customAudioFileName: file.name,
        });
        addedCount++;
      }
    }

    onChangeMusicSlots(nextMusic);
    onUpdateCounts?.(mapSlots.length, nextMusic.length);
    setMusicFilter('CUSTOM');
    setStatusNote(
      `${addedCount} pista(s) de música agregadas con sus nombres originales a /PSP_GAME/DLC/MUSICA/ y BGM_TRACK_NAMES.json.`
    );
  };

  const handlePreviewAudio = async () => {
    if (!activeMusic?.customAudioBytes) return;
    try {
      const blob = new Blob([activeMusic.customAudioBytes as unknown as BlobPart]);
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audio.onended = () => URL.revokeObjectURL(url);
      await audio.play();
      setStatusNote(`Reproduciendo ${activeMusic.customAudioFileName ?? activeMusic.title}...`);
    } catch {
      setStatusNote('El navegador no decodifica ATRAC3 nativo; se incluirá tal cual en /PSP_GAME/DLC/MUSICA/.');
    }
  };

  const handleExportIndexJson = () => {
    const overlays = buildOverlayFilesFromMiniSlots(gameId, mapSlots, musicSlots);
    const jsonEntry = overlays.find((f) => f.path.endsWith('MAP_MUSIC_DLC_INDEX.json'));
    if (!jsonEntry) return;
    const blob = new Blob([jsonEntry.data as unknown as BlobPart], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${gameId}_MAP_MUSIC_DLC_INDEX.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <input
        ref={mapFileInputRef}
        type="file"
        accept=".bin,.gmo,.pac,.dat,*/*"
        onChange={(e) => void handleAttachMapFile(e, 'MAP')}
        className="hidden"
      />
      <input
        ref={minimapFileInputRef}
        type="file"
        accept=".tm2,.gim,.png,.bin,*/*"
        onChange={(e) => void handleAttachMapFile(e, 'MINIMAP')}
        className="hidden"
      />
      <input
        ref={audioFileInputRef}
        type="file"
        accept=".at3,.wav,.ogg,.mp3,.awb,*/*"
        onChange={(e) => void handleAttachMusicFile(e)}
        className="hidden"
      />
      <input
        ref={multiAudioInputRef}
        type="file"
        multiple
        accept=".at3,.wav,.ogg,.mp3,.awb,*/*"
        onChange={(e) => void handleBatchAttachMusicWithNames(e)}
        className="hidden"
      />

      {/* Top Banner with ISO Internal Detection + Actions */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h3 className="flex items-center gap-2 text-base font-bold text-slate-900 dark:text-white">
              <Layers className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              Seleccionador de Mapas (Roster) y Música con Nombres para ISO DLC
            </h3>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-300">
              Gestiona por separado el <strong>Roster de Mapas (<span className="font-mono">M01–M{String(mapSlots.length).padStart(2, '0')}</span>)</strong> y el <strong>Roster de Música (<span className="font-mono">B01–B{String(musicSlots.length).padStart(2, '0')}</span>)</strong>, agrega varias canciones conservando sus nombres reales en <span className="font-mono">/PSP_GAME/DLC/MUSICA/</span> y vincúlalas a cada escenario.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleAddDlcMapSlot}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
              Añadir Mapa DLC
            </button>
            <button
              type="button"
              onClick={() => multiAudioInputRef.current?.click()}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-amber-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-amber-700 cursor-pointer"
            >
              <FolderPlus className="h-3.5 w-3.5" />
              Agregar Música con Nombres (.AT3/.WAV)
            </button>
            <button
              type="button"
              onClick={handleAddDlcMusicSlot}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-blue-600 bg-white px-3 py-1.5 text-xs font-semibold text-blue-600 hover:bg-blue-50 dark:border-blue-500 dark:bg-slate-900 dark:text-blue-400 cursor-pointer"
            >
              <Music className="h-3.5 w-3.5" />
              + Slot Música Vacío
            </button>
            {onSendMapMusicToIsoPacker && (
              <button
                type="button"
                onClick={onSendMapMusicToIsoPacker}
                className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-emerald-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 cursor-pointer"
              >
                <Layers className="h-3.5 w-3.5" />
                Enviar Mapas + Música a ISO DLC
              </button>
            )}
            <button
              type="button"
              onClick={handleExportIndexJson}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-slate-800 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              Exportar Índice JSON
            </button>
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-4 text-xs font-mono text-slate-600 dark:text-slate-400">
          <span>
            ISO cargada:{' '}
            <strong className="text-slate-900 dark:text-white">
              {analysis?.isoInfo ? `${analysis.sourceName} (${isoDetectedCount.total} archivos)` : 'Modo Plantilla DBZ (sin ISO subida)'}
            </strong>
          </span>
          <span>Mapas en tablero: <strong>{mapSlots.length}</strong></span>
          <span>Pistas Música en tablero: <strong>{musicSlots.length}</strong></span>
        </div>

        {/* Authentic PPSSPP Seleccón de Mapa Rules & Visual Strip */}
        <div className="mt-4 grid grid-cols-1 gap-4 rounded-xl border border-slate-200 bg-slate-50 p-3.5 md:grid-cols-12 dark:border-slate-800 dark:bg-slate-950/60">
          <div className="md:col-span-4 overflow-hidden rounded-lg border border-slate-300 bg-black dark:border-slate-700">
            <img
              src="/assets/aistudio/20261117_025451_c7673c50.jpg"
              alt="Referencia Selección de Mapa PPSSPP DBZ Tag Team"
              className="h-28 w-full object-cover"
            />
          </div>
          <div className="md:col-span-8 flex flex-col justify-between gap-2 text-xs">
            <div className="font-semibold text-slate-900 dark:text-white">
              Reglas de Selección de Mapa y Música (estilo PPSSPP Tag Team)
            </div>
            <div className="grid grid-cols-3 gap-2">
              <label className="block">
                <span className="text-[11px] text-slate-500 dark:text-slate-400">Límite de tiempo</span>
                <select
                  value={timeLimitSec}
                  onChange={(e) => setTimeLimitSec(Number(e.target.value))}
                  className="mt-1 w-full rounded border border-slate-300 bg-white px-2 py-1 font-mono text-xs dark:border-slate-700 dark:bg-slate-900"
                >
                  <option value={99}>99 s</option>
                  <option value={180}>180 s (Estándar)</option>
                  <option value={300}>300 s</option>
                  <option value={999}>Sin límite</option>
                </select>
              </label>
              <label className="block">
                <span className="text-[11px] text-slate-500 dark:text-slate-400">Semillas Senzu Eq. A</span>
                <input
                  type="number"
                  min={0}
                  max={9}
                  value={senzuTeamA}
                  onChange={(e) => setSenzuTeamA(Math.max(0, Math.min(9, Number(e.target.value) || 0)))}
                  className="mt-1 w-full rounded border border-slate-300 bg-white px-2 py-1 font-mono text-xs dark:border-slate-700 dark:bg-slate-900"
                />
              </label>
              <label className="block">
                <span className="text-[11px] text-slate-500 dark:text-slate-400">Semillas Senzu Eq. B</span>
                <input
                  type="number"
                  min={0}
                  max={9}
                  value={senzuTeamB}
                  onChange={(e) => setSenzuTeamB(Math.max(0, Math.min(9, Number(e.target.value) || 0)))}
                  className="mt-1 w-full rounded border border-slate-300 bg-white px-2 py-1 font-mono text-xs dark:border-slate-700 dark:bg-slate-900"
                />
              </label>
            </div>
            <div className="font-mono text-[11px] text-blue-700 dark:text-blue-300">
              Pista por defecto activa en minicasilla: {activeMusic?.title ?? '9. Explosión'} · Tiempo {timeLimitSec === 999 ? '∞' : `${timeLimitSec}s`} · Senzu A:{senzuTeamA} / B:{senzuTeamB}
            </div>
          </div>
        </div>

        {statusNote && (
          <div className="mt-3 flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50/70 px-3 py-2 text-xs text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-200">
            <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
            {statusNote}
          </div>
        )}
      </section>

      {/* Main Split: Map Mini-Slots + Music Mini-Slots */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Map & Minimap Roster Selector + Slot Editor */}
        <section className="lg:col-span-7 space-y-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h4 className="flex items-center gap-1.5 text-sm font-bold text-slate-900 dark:text-white">
              <MapPin className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              Seleccionador / Roster de Mapas ({filteredMaps.length})
            </h4>
            <div className="flex flex-wrap gap-1 text-[11px]">
              {(['ALL', 'ISO_INTERNO', 'DLC_AGREGADO', 'CUSTOM'] as const).map((f) => (
                <button
                  key={f}
                  type="button"
                  onClick={() => setMapFilter(f)}
                  className={`rounded px-2 py-1 font-medium cursor-pointer ${
                    mapFilter === f
                      ? 'bg-slate-900 text-white dark:bg-blue-600'
                      : 'border border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300'
                  }`}
                >
                  {f === 'ALL' ? 'Todos' : f === 'ISO_INTERNO' ? '10 Base ISO' : f === 'DLC_AGREGADO' ? 'DLC' : 'Con Archivo'}
                </button>
              ))}
            </div>
          </div>

          <input
            type="text"
            value={mapSearch}
            onChange={(e) => setMapSearch(e.target.value)}
            placeholder="Buscar en el Roster de Mapas (ej. Namek, Cell, Atalaya, M05)..."
            className="min-h-[34px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          />

          {/* Compact Minicasillas Grid */}
          <div className="grid max-h-72 grid-cols-4 gap-1.5 overflow-y-auto pr-1 sm:grid-cols-6">
            {filteredMaps.map((m) => {
              const selected = activeMap?.id === m.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => {
                    setSelectedMapId(m.id);
                    setSelectedMusicId(m.linkedBgmId);
                  }}
                  title={`${m.slotCode}: ${m.name}\nMapa: ${m.dlcMapPath}\nMinimapa: ${m.dlcMinimapPath}\nBGM: #${m.linkedBgmId}`}
                  className={`rounded-lg border p-1.5 text-left transition-colors cursor-pointer ${
                    selected
                      ? 'border-blue-600 bg-blue-600 text-white'
                      : m.hasCustomMapFile || m.hasCustomMinimapFile
                      ? 'border-emerald-400 bg-emerald-50/70 text-slate-900 dark:border-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-100'
                      : m.origin === 'DLC_AGREGADO'
                      ? 'border-amber-300 bg-amber-50/60 text-slate-900 dark:border-amber-800 dark:bg-amber-950/20 dark:text-amber-100'
                      : 'border-slate-200 bg-slate-50 text-slate-800 hover:border-blue-400 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between font-mono text-[10px] font-bold">
                    <span>{m.slotCode}</span>
                    <span className={selected ? 'text-blue-100' : 'text-slate-400'}>B{String(m.linkedBgmId).padStart(2, '0')}</span>
                  </div>
                  <div className="mt-0.5 truncate text-[10px] font-medium">{m.name}</div>
                  <div className={`mt-0.5 font-mono text-[9px] ${selected ? 'text-blue-100' : 'text-slate-500 dark:text-slate-400'}`}>
                    {m.hasCustomMapFile ? 'BIN OK' : m.origin === 'ISO_INTERNO' ? 'ISO' : 'DLC'}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Active Map Minicasilla Editor */}
          {activeMap && (
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/70">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-2 dark:border-slate-800">
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  Editando Minicasilla {activeMap.slotCode} ({activeMap.origin === 'ISO_INTERNO' ? 'Interno ISO' : 'Slot DLC'})
                </span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => mapFileInputRef.current?.click()}
                    className="inline-flex items-center gap-1 rounded bg-blue-600 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-blue-700 cursor-pointer"
                  >
                    <Upload className="h-3 w-3" />
                    Adjuntar Mapa (.BIN)
                  </button>
                  <button
                    type="button"
                    onClick={() => minimapFileInputRef.current?.click()}
                    className="inline-flex items-center gap-1 rounded border border-slate-300 bg-white px-2.5 py-1 text-[11px] font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
                  >
                    <ImageIcon className="h-3 w-3" />
                    Adjuntar Minimapa (.TM2/.GIM)
                  </button>
                </div>
              </div>

              <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2 text-xs">
                <div>
                  <label className="block font-medium text-slate-600 dark:text-slate-400">Nombre del Mapa</label>
                  <input
                    type="text"
                    value={activeMap.name}
                    onChange={(e) => updateMapSlot(activeMap.id, { name: e.target.value })}
                    className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-600 dark:text-slate-400">Música BGM Vinculada</label>
                  <select
                    value={activeMap.linkedBgmId}
                    onChange={(e) => updateMapSlot(activeMap.id, { linkedBgmId: Number(e.target.value) || 1 })}
                    className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                  >
                    {musicSlots.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.slotCode} · {b.title}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-600 dark:text-slate-400">Ruta Original en ISO</label>
                  <input
                    type="text"
                    value={activeMap.isoSourcePath}
                    placeholder="disc0:/PSP_GAME/USRDIR/..."
                    onChange={(e) => updateMapSlot(activeMap.id, { isoSourcePath: e.target.value })}
                    className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-600 dark:text-slate-400">Ruta Mapa Destino DLC</label>
                  <input
                    type="text"
                    value={activeMap.dlcMapPath}
                    onChange={(e) => updateMapSlot(activeMap.id, { dlcMapPath: e.target.value })}
                    className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block font-medium text-slate-600 dark:text-slate-400">Ruta Minimapa Destino DLC (.TM2 / .GIM)</label>
                  <input
                    type="text"
                    value={activeMap.dlcMinimapPath}
                    onChange={(e) => updateMapSlot(activeMap.id, { dlcMinimapPath: e.target.value })}
                    className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              {(activeMap.customMapFileName || activeMap.customMinimapFileName) && (
                <div className="mt-2 font-mono text-[11px] text-emerald-700 dark:text-emerald-400">
                  Adjuntos listos para empaquetar:{' '}
                  {activeMap.customMapFileName ? `[Mapa: ${activeMap.customMapFileName}] ` : ''}
                  {activeMap.customMinimapFileName ? `[Minimapa: ${activeMap.customMinimapFileName}]` : ''}
                </div>
              )}
            </div>
          )}
        </section>

        {/* Right: Music Roster Selector + Audio Editor */}
        <section className="lg:col-span-5 space-y-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h4 className="flex items-center gap-1.5 text-sm font-bold text-slate-900 dark:text-white">
              <FileAudio className="h-4 w-4 text-amber-500" />
              Seleccionador de Música BGM (.AT3 / ISO DLC) ({filteredMusic.length})
            </h4>
            <div className="flex flex-wrap gap-1 text-[11px]">
              {(['ALL', 'MENUS', 'COMBATE', 'EXPLORACION', 'DLC_AGREGADO', 'CUSTOM'] as const).map((f) => (
                <button
                  key={f}
                  type="button"
                  onClick={() => setMusicFilter(f)}
                  className={`rounded px-2 py-1 font-medium cursor-pointer ${
                    musicFilter === f
                      ? 'bg-slate-900 text-white dark:bg-blue-600'
                      : 'border border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300'
                  }`}
                >
                  {f === 'ALL'
                    ? 'Todas'
                    : f === 'MENUS'
                    ? 'Menús 01–07'
                    : f === 'COMBATE'
                    ? 'Combate 08–16'
                    : f === 'EXPLORACION'
                    ? 'Free Roam'
                    : f === 'DLC_AGREGADO'
                    ? 'DLC'
                    : 'Subidas'}
                </button>
              ))}
            </div>
          </div>

          <input
            type="text"
            value={musicSearch}
            onChange={(e) => setMusicSearch(e.target.value)}
            placeholder="Buscar música por nombre o código (ej. Dragon Claw, Explosion, B09)..."
            className="min-h-[34px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          />

          <div className="grid max-h-72 grid-cols-3 gap-1.5 overflow-y-auto pr-1 sm:grid-cols-4">
            {filteredMusic.map((b) => {
              const selected = activeMusic?.id === b.id;
              return (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => setSelectedMusicId(b.id)}
                  title={`${b.slotCode}: ${b.title}\n${b.dlcAudioPath}`}
                  className={`rounded-lg border p-1.5 text-left transition-colors cursor-pointer ${
                    selected
                      ? 'border-blue-600 bg-blue-600 text-white'
                      : b.hasCustomAudioFile
                      ? 'border-emerald-400 bg-emerald-50/70 text-slate-900 dark:border-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-100'
                      : 'border-slate-200 bg-slate-50 text-slate-800 hover:border-blue-400 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200'
                  }`}
                >
                  <div className="font-mono text-[10px] font-bold">{b.slotCode}</div>
                  <div className="truncate text-[10px] font-medium">{b.title}</div>
                </button>
              );
            })}
          </div>

          {activeMusic && (
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/70">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-2 dark:border-slate-800">
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  Minicasilla {activeMusic.slotCode}
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => audioFileInputRef.current?.click()}
                    className="inline-flex items-center gap-1 rounded bg-amber-600 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-amber-700 cursor-pointer"
                  >
                    <FolderPlus className="h-3 w-3" />
                    Subir .AT3 / .WAV
                  </button>
                  {activeMusic.customAudioBytes && (
                    <button
                      type="button"
                      onClick={() => void handlePreviewAudio()}
                      className="inline-flex items-center gap-1 rounded bg-slate-900 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
                    >
                      <Play className="h-3 w-3" />
                      Probar
                    </button>
                  )}
                </div>
              </div>

              <div className="mt-3 space-y-2.5 text-xs">
                <div>
                  <label className="block font-medium text-slate-600 dark:text-slate-400">Nombre de Pista BGM</label>
                  <input
                    type="text"
                    value={activeMusic.title}
                    onChange={(e) => updateMusicSlot(activeMusic.id, { title: e.target.value })}
                    className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-600 dark:text-slate-400">Ruta Destino en ISO DLC (.AT3)</label>
                  <input
                    type="text"
                    value={activeMusic.dlcAudioPath}
                    onChange={(e) => updateMusicSlot(activeMusic.id, { dlcAudioPath: e.target.value })}
                    className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                  />
                </div>
                {activeMap && (
                  <button
                    type="button"
                    onClick={() => {
                      updateMapSlot(activeMap.id, { linkedBgmId: activeMusic.id });
                      setStatusNote(
                        `Mapa ${activeMap.slotCode} (${activeMap.name}) vinculado a música ${activeMusic.slotCode}: ${activeMusic.title}.`
                      );
                    }}
                    className="w-full rounded-lg border border-blue-600 bg-blue-50 px-3 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-100 dark:border-blue-500 dark:bg-blue-950/30 dark:text-blue-300 cursor-pointer"
                  >
                    Vincular "{activeMusic.title}" al mapa {activeMap.slotCode} ({activeMap.name})
                  </button>
                )}
                <label className="inline-flex items-center gap-2 text-slate-700 dark:text-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={activeMusic.loopEnabled}
                    onChange={(e) => updateMusicSlot(activeMusic.id, { loopEnabled: e.target.checked })}
                    className="h-4 w-4 rounded border-slate-300 accent-blue-600"
                  />
                  Bucle continuo en combate (Loop BGM)
                </label>
              </div>
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
