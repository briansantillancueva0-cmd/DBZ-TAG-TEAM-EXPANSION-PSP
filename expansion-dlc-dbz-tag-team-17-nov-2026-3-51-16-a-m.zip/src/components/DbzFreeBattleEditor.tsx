import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Archive,
  Binary,
  CheckCircle2,
  Download,
  FileAudio,
  FileImage,
  Gamepad2,
  Layers,
  LayoutGrid,
  Map as MapIcon,
  Music,
  PackageOpen,
  RefreshCw,
  Sliders,
  Upload,
  Users,
} from 'lucide-react';
import {
  DBZ_TAG_TEAM_BASE_MAPS,
  DBZ_TAG_TEAM_CANONICAL_MUSIC,
  DBZ_TAG_TEAM_CANONICAL_NAMES,
  DBZ_TAG_TEAM_DLC_EXPANSION_MAPS,
  type DbzRoster256JsonManifest,
} from '../lib/dbzTagTeamExpander';
import { extractIsoFileBytes } from '../lib/iso9660';
import {
  buildMasterPackfileBin,
  buildMinimalPspGimTexture,
  buildMinimalRiffAt3Blob,
  buildPck1Container,
  buildProceduralPspGimTexture,
  extractPck1EntryData,
  parseAndScanPck1Blob,
  renderPspImageBytesToDataUrl,
  type Pck1AnalysisResult,
  type Pck1AssetCategory,
  type Pck1ExtractedEntry,
  type Pck1PackInputEntry,
} from '../lib/pck1Parser';
import type { EbootAnalysis } from '../lib/types';
import type { IsoMapMiniSlot, IsoMusicMiniSlot } from './DbzIsoMapMusicSlots';
import { PspControllerPad, type PspHardwareButton } from './PspControllerPad';

export type FreeBattlePresetId =
  | 'ORIGINAL_4X6_RIGHT'
  | 'TOP_BOTTOM_1P_2P'
  | 'CLASSIC_VS'
  | 'DARK_TEAM_ENEMY'
  | 'DUAL_STRIP'
  | 'HEX_BORDER_256'
  | 'CENTER_GRID_VS'
  | 'SPLIT_SIDES_CENTER';

export interface FreeBattleLayoutConfig {
  presetId: FreeBattlePresetId;
  titleText: string;
  slotCount: 71 | 128 | 256;
  cellShape: 'RECT' | 'HEX';
  cellWidth: number;
  cellHeight: number;
  topBarY: number;
  bottomBarY: number;
  cols: number;
  rows: number;
  bgTopColor: string;
  bgBotColor: string;
  accentColor: string;
  cursorColor: string;
  showCpuDifficulty: boolean;
  showControlsFooter: boolean;
  j1Slot: number;
  j2Slot: number;
  j3Slot: number;
  j4Slot: number;
  selectedMapId: number;
  selectedMusicId: number;
  p1HeaderLabel: string;
  p2HeaderLabel: string;
  enabledMenuStyles?: FreeBattlePresetId[];
  optionsMenuSwitchTrigger?: 'OPCIONES_JUEGO' | 'SELECT_IN_MENU' | 'L_PLUS_R';
}

export interface FreeBattlePresetMeta {
  id: FreeBattlePresetId;
  name: string;
  shortDesc: string;
  imageUrl?: string;
  wireframeTag: string;
  defaults: Partial<FreeBattleLayoutConfig>;
}

export const FREE_BATTLE_PRESETS: FreeBattlePresetMeta[] = [
  {
    id: 'ORIGINAL_4X6_RIGHT',
    name: 'Clásico Tag Team (4×6 Derecha + J1-J4)',
    shortDesc: 'Busto J1 y 4 cartas J1–J4 a la izquierda + matriz 4×6 con flechas de scroll a la derecha.',
    imageUrl: '/assets/aistudio/20261117_025541_80e1b231.jpg',
    wireframeTag: '4×6 DER',
    defaults: {
      titleText: 'SELECCIÓN DE PERSONAJE',
      cellShape: 'RECT',
      cellWidth: 44,
      cellHeight: 30,
      topBarY: 36,
      bottomBarY: 186,
      cols: 4,
      rows: 6,
      bgTopColor: '#0284c7',
      bgBotColor: '#1d4ed8',
      accentColor: '#38bdf8',
      cursorColor: '#facc15',
      p1HeaderLabel: 'A / J1',
      p2HeaderLabel: 'CPU',
    },
  },
  {
    id: 'TOP_BOTTOM_1P_2P',
    name: '1P Superior / 2P Inferior + Busto Central',
    shortDesc: 'Tira superior 1P azul, tira inferior 2P magenta y render gigante en el centro.',
    imageUrl: '/assets/aistudio/20261117_031855_2a2be414.jpg',
    wireframeTag: '1P/2P BAR',
    defaults: {
      titleText: 'SELECCIÓN DE PERSONAJE',
      cellShape: 'RECT',
      cellWidth: 44,
      cellHeight: 30,
      topBarY: 28,
      bottomBarY: 204,
      cols: 8,
      rows: 2,
      bgTopColor: '#4c1d24',
      bgBotColor: '#2c0b12',
      accentColor: '#3b82f6',
      cursorColor: '#facc15',
      p1HeaderLabel: '1P',
      p2HeaderLabel: '2P',
    },
  },
  {
    id: 'CLASSIC_VS',
    name: 'VS Clásico (3 Filas + Render Derecho)',
    shortDesc: 'Cabecera JUGADOR [?] VS [?] [?], bloque de 3 filas abajo-izquierda y luchador a la derecha.',
    imageUrl: '/assets/aistudio/20261117_031821_9d177e32.jpg',
    wireframeTag: 'VS 3FIL',
    defaults: {
      titleText: 'VS Seleccionar personaje',
      cellShape: 'RECT',
      cellWidth: 32,
      cellHeight: 24,
      topBarY: 64,
      bottomBarY: 162,
      cols: 8,
      rows: 3,
      bgTopColor: '#0284c7',
      bgBotColor: '#1e3a8a',
      accentColor: '#38bdf8',
      cursorColor: '#fde047',
      p1HeaderLabel: 'JUGADOR',
      p2HeaderLabel: 'VS CPU',
    },
  },
  {
    id: 'DARK_TEAM_ENEMY',
    name: 'Arena Oscura Tenkaichi 3 (Team / Enemy)',
    shortDesc: 'Fondo oscuro cyan, P1 CPU:Normal, Team J1/J2 vs Enemy J3/J4 y tira horizontal de 19 casillas.',
    imageUrl: '/assets/aistudio/20261117_031731_aac66bc5.jpg',
    wireframeTag: 'BT3 DARK',
    defaults: {
      titleText: 'SELECCIÓN DE PERSONAJE',
      cellShape: 'RECT',
      cellWidth: 23,
      cellHeight: 34,
      topBarY: 102,
      bottomBarY: 206,
      cols: 19,
      rows: 1,
      bgTopColor: '#04121d',
      bgBotColor: '#0b3248',
      accentColor: '#22d3ee',
      cursorColor: '#fde047',
      p1HeaderLabel: 'Team',
      p2HeaderLabel: 'Enemy',
    },
  },
  {
    id: 'DUAL_STRIP',
    name: 'Doble Barra Completa + Overlay PSP',
    shortDesc: 'Barra superior completa de retratos y barra inferior sobre retrato panorámico central.',
    imageUrl: '/assets/aistudio/20261117_031539_17d4df9e.jpg',
    wireframeTag: 'DUAL BAR',
    defaults: {
      titleText: 'SELECCIÓN DE PERSONAJE',
      cellShape: 'RECT',
      cellWidth: 42,
      cellHeight: 28,
      topBarY: 26,
      bottomBarY: 212,
      cols: 10,
      rows: 2,
      bgTopColor: '#0284c7',
      bgBotColor: '#0f172a',
      accentColor: '#60a5fa',
      cursorColor: '#facc15',
      p1HeaderLabel: 'TOP BAR',
      p2HeaderLabel: 'BOT BAR',
    },
  },
  {
    id: 'HEX_BORDER_256',
    name: 'Marco Hexagonal Perimetral 256 (4 Cartas)',
    shortDesc: 'Celdas hexagonales rodeando los 4 bordes para 256 slots + 4 cartas verticales J1/J2/J3/J4.',
    imageUrl: '/assets/aistudio/20261117_031444_522b1574.jpg',
    wireframeTag: 'HEX 256',
    defaults: {
      titleText: 'TAG TEAM 256 HEX',
      cellShape: 'HEX',
      cellWidth: 34,
      cellHeight: 26,
      topBarY: 4,
      bottomBarY: 238,
      cols: 12,
      rows: 4,
      bgTopColor: '#0ea5e9',
      bgBotColor: '#1d4ed8',
      accentColor: '#2dd4bf',
      cursorColor: '#fde047',
      p1HeaderLabel: 'J1/J2',
      p2HeaderLabel: 'J3/J4',
    },
  },
  {
    id: 'CENTER_GRID_VS',
    name: 'Columna Central 4×6 + J1/J2 Arena (BT3)',
    shortDesc: 'Estilo BT3 portátil: luchador J1 izquierdo, matriz vertical 4×6 en el centro y silueta [?] rival derecha.',
    wireframeTag: 'COL CTR',
    defaults: {
      titleText: 'BATALLA LIBRE · COLUMNA CENTRAL',
      cellShape: 'RECT',
      cellWidth: 32,
      cellHeight: 30,
      topBarY: 24,
      bottomBarY: 224,
      cols: 4,
      rows: 6,
      bgTopColor: '#1e3a1e',
      bgBotColor: '#0f2414',
      accentColor: '#22c55e',
      cursorColor: '#fde047',
      p1HeaderLabel: 'J1 VS',
      p2HeaderLabel: 'RIVAL ?',
    },
  },
  {
    id: 'SPLIT_SIDES_CENTER',
    name: 'Bipartito 2×6 Izq/Der + Centro (J1 / J4)',
    shortDesc: 'Paneles 2×6 a izquierda y derecha con flechas, busto central gigante y barra J1–J4 abajo.',
    wireframeTag: '2×6 SPLIT',
    defaults: {
      titleText: 'SELECCIÓN DE PERSONAJE',
      cellShape: 'RECT',
      cellWidth: 44,
      cellHeight: 30,
      topBarY: 28,
      bottomBarY: 204,
      cols: 2,
      rows: 6,
      bgTopColor: '#0284c7',
      bgBotColor: '#1e40af',
      accentColor: '#38bdf8',
      cursorColor: '#fde047',
      p1HeaderLabel: 'J1 kyo',
      p2HeaderLabel: 'J4 CPU',
    },
  },
];

export const ALL_FREE_BATTLE_PRESET_IDS: FreeBattlePresetId[] = FREE_BATTLE_PRESETS.map((p) => p.id);

export function buildDefaultFreeBattleLayout(
  presetId: FreeBattlePresetId = 'DARK_TEAM_ENEMY'
): FreeBattleLayoutConfig {
  const preset = FREE_BATTLE_PRESETS.find((p) => p.id === presetId) ?? FREE_BATTLE_PRESETS[3];
  return {
    presetId,
    titleText: preset.defaults.titleText ?? 'SELECCIÓN DE PERSONAJE',
    slotCount: 256,
    cellShape: preset.defaults.cellShape ?? 'RECT',
    cellWidth: preset.defaults.cellWidth ?? 24,
    cellHeight: preset.defaults.cellHeight ?? 32,
    topBarY: preset.defaults.topBarY ?? 28,
    bottomBarY: preset.defaults.bottomBarY ?? 206,
    cols: preset.defaults.cols ?? 12,
    rows: preset.defaults.rows ?? 2,
    bgTopColor: preset.defaults.bgTopColor ?? '#04121d',
    bgBotColor: preset.defaults.bgBotColor ?? '#0b3248',
    accentColor: preset.defaults.accentColor ?? '#22d3ee',
    cursorColor: preset.defaults.cursorColor ?? '#fde047',
    showCpuDifficulty: true,
    showControlsFooter: true,
    j1Slot: 0x00,
    j2Slot: 0x12,
    j3Slot: 0x3d,
    j4Slot: 0x45,
    selectedMapId: 9,
    selectedMusicId: 16,
    p1HeaderLabel: preset.defaults.p1HeaderLabel ?? 'Team',
    p2HeaderLabel: preset.defaults.p2HeaderLabel ?? 'Enemy',
    enabledMenuStyles: [...ALL_FREE_BATTLE_PRESET_IDS],
    optionsMenuSwitchTrigger: 'OPCIONES_JUEGO',
  };
}

/**
 * Empaqueta la configuración de Batalla Libre en un descriptor binario + JSON dentro de un contenedor PCK1 real.
 */
export function buildMenuOptionsSwitcherEntries(
  layout: FreeBattleLayoutConfig
): Pck1PackInputEntry[] {
  const enabled =
    layout.enabledMenuStyles && layout.enabledMenuStyles.length > 0
      ? layout.enabledMenuStyles
      : ALL_FREE_BATTLE_PRESET_IDS;

  const switcherManifest = {
    format: 'DBZ_TT_MENU_OPTIONS_PCK1_V1',
    defaultFreeBattleMenu: layout.presetId,
    optionsTrigger: layout.optionsMenuSwitchTrigger ?? 'OPCIONES_JUEGO',
    menuStyles: enabled.map((id, idx) => {
      const meta = FREE_BATTLE_PRESETS.find((p) => p.id === id);
      return {
        index: idx,
        id,
        label: meta?.name ?? id,
        pckEntryBin: `MENU_${String(idx).padStart(2, '0')}_${id}.bin`,
        hudGim: `HUD_${String(idx).padStart(2, '0')}_${id}.gim`,
        isDefault: id === layout.presetId,
      };
    }),
  };

  const entries: Pck1PackInputEntry[] = [
    {
      name: 'MENU_OPTIONS_SWITCHER.json',
      data: new TextEncoder().encode(JSON.stringify(switcherManifest, null, 2)),
      category: 'OTROS',
    },
  ];

  enabled.forEach((id, idx) => {
    const cfg = id === layout.presetId ? layout : buildDefaultFreeBattleLayout(id);
    const bin = buildFreeBattleHeaderBin(cfg);
    entries.push({
      name: `MENU_${String(idx).padStart(2, '0')}_${id}.bin`,
      data: bin,
      category: 'OTROS',
    });
  });

  return entries;
}

export function buildFreeBattleUiPckBinary(
  layout: FreeBattleLayoutConfig,
  customAssets: Pck1PackInputEntry[] = []
): Uint8Array {
  const headerBin = buildFreeBattleHeaderBin(layout);
  const jsonBytes = new TextEncoder().encode(JSON.stringify(layout, null, 2));
  const frameGim = buildMinimalPspGimTexture(`HUD_FRAME_${layout.presetId}`, [34, 211, 238]);
  const cursorGim = buildMinimalPspGimTexture(`CURSOR_${layout.presetId}`, [250, 204, 21]);
  const optionEntries = buildMenuOptionsSwitcherEntries(layout);

  return buildPck1Container([
    { name: 'FREE_BATTLE_HDR.bin', data: headerBin },
    { name: 'FREE_BATTLE_LAYOUT.json', data: jsonBytes },
    { name: 'HUD_FRAME.gim', data: frameGim },
    { name: 'HUD_CURSOR.gim', data: cursorGim },
    ...optionEntries,
    ...customAssets,
  ]);
}

export function buildFreeBattleOverlayFiles(
  _gameId: string,
  layout: FreeBattleLayoutConfig,
  customPckBinary?: Uint8Array | null
): Array<{ path: string; data: Uint8Array }> {
  const pckBytes = customPckBinary ?? buildFreeBattleUiPckBinary(layout);
  return [
    {
      path: '/PSP_GAME/DLC/UI/FREE_BATTLE_UI.PCK',
      data: pckBytes,
    },
    {
      path: '/PSP_GAME/DLC/UI/FREE_BATTLE_LAYOUT.json',
      data: new TextEncoder().encode(JSON.stringify(layout, null, 2)),
    },
  ];
}

export type FreeBattleGameMode =
  | 'BATALLA_LIBRE'
  | 'DRAGON_WALKER'
  | 'SELECCION_BATALLA'
  | 'AD_HOC'
  | 'PERSONALIZAR'
  | 'ENTRENAMIENTO'
  | 'OPCIONES';

export const FREE_BATTLE_GAME_MODES: Array<{
  id: FreeBattleGameMode;
  label: string;
  short: string;
  desc: string;
}> = [
  {
    id: 'BATALLA_LIBRE',
    label: 'Batalla Libre (1v1 / 2v2 / 2v1 vs CPU)',
    short: 'BATALLA LIBRE',
    desc: 'Peleas rápidas personalizadas de 1 vs 1, 2 vs 2 o 2 vs 1 contra la CPU.',
  },
  {
    id: 'DRAGON_WALKER',
    label: 'Caminante Dragón (Dragon Walker · Historia)',
    short: 'DRAGON WALKER',
    desc: 'Modo historia principal en mapas 3D desde la Saga Saiyajin hasta Majin Buu.',
  },
  {
    id: 'SELECCION_BATALLA',
    label: 'Selección de Batalla (Batalla 100 / Supervivencia)',
    short: 'BATALLA 100/SURV',
    desc: 'Desafíos Batalla 100, Supervivencia con una sola vida y Combates Libres por equipos.',
  },
  {
    id: 'AD_HOC',
    label: 'Multijugador (Ad-Hoc 4 PSP/PPSSPP)',
    short: 'AD-HOC',
    desc: 'Conecta hasta 4 consolas PSP o PPSSPP en local cooperativo o competitivo.',
  },
  {
    id: 'PERSONALIZAR',
    label: 'Personalizar (Objetos y Puntos D · 256)',
    short: 'PERSONALIZAR',
    desc: 'Equipa objetos y mejoras de ataque, defensa, ki y velocidad mediante puntos D.',
  },
  {
    id: 'ENTRENAMIENTO',
    label: 'Entrenamiento (Práctica Libre sin límite)',
    short: 'ENTRENAMIENTO',
    desc: 'Espacio libre para practicar combos, defensa y ataques combinados en equipo.',
  },
  {
    id: 'OPCIONES',
    label: 'Opciones (CPU / Audio / Controles / Menú PCK1)',
    short: 'OPCIONES',
    desc: 'Ajusta dificultad CPU, volumen SFX/BGM, controles PSP y estilo de Menú Libre PCK1.',
  },
];

export function buildFreeBattleHeaderBin(layout: FreeBattleLayoutConfig): Uint8Array {
  const headerBin = new Uint8Array(64);
  const dv = new DataView(headerBin.buffer);
  headerBin[0] = 0x46;
  headerBin[1] = 0x42;
  headerBin[2] = 0x54;
  headerBin[3] = 0x31;
  const presetIndex = FREE_BATTLE_PRESETS.findIndex((p) => p.id === layout.presetId);
  dv.setUint16(4, Math.max(0, presetIndex), true);
  dv.setUint16(6, layout.slotCount, true);
  dv.setUint16(8, layout.cellShape === 'HEX' ? 1 : 0, true);
  dv.setUint16(10, layout.cellWidth, true);
  dv.setUint16(12, layout.cellHeight, true);
  dv.setUint16(14, layout.topBarY, true);
  dv.setUint16(16, layout.bottomBarY, true);
  dv.setUint16(18, layout.cols, true);
  dv.setUint16(20, layout.rows, true);
  dv.setUint8(22, layout.j1Slot & 0xff);
  dv.setUint8(23, layout.j2Slot & 0xff);
  dv.setUint8(24, layout.j3Slot & 0xff);
  dv.setUint8(25, layout.j4Slot & 0xff);
  dv.setUint16(26, layout.selectedMapId, true);
  dv.setUint16(28, layout.selectedMusicId, true);
  return headerBin;
}

export function buildMasterPackfileFromSuiteState(params: {
  gameId: string;
  layout: FreeBattleLayoutConfig;
  manifest: DbzRoster256JsonManifest;
  mapSlots: IsoMapMiniSlot[];
  musicSlots: IsoMusicMiniSlot[];
  customPortraitsBySlot?: Map<number, Uint8Array>;
  preservedEntries?: Pck1PackInputEntry[];
  extraEntries?: Pck1PackInputEntry[];
}): Uint8Array {
  const {
    gameId,
    layout,
    manifest,
    mapSlots,
    musicSlots,
    customPortraitsBySlot,
    preservedEntries,
    extraEntries,
  } = params;
  const charCount = Math.min(layout.slotCount, Math.max(71, manifest.characters.length || 256));

  const characters = Array.from({ length: charCount }, (_, idx) => {
    const ch = manifest.characters[idx];
    const slotId = idx + 1;
    return {
      slotId: idx,
      hexId: ch?.hexId ?? `0x${idx.toString(16).toUpperCase().padStart(2, '0')}`,
      name: ch?.displayName ?? getSlotCharacterName(idx, manifest),
      modelBinPath:
        ch?.modelBinPath ??
        `disc0:/PSP_GAME/DLC/PERSONAJES/CHAR${String(slotId).padStart(3, '0')}.BIN`,
      gimPortraitPath:
        ch?.gimPortraitPath ??
        `disc0:/PSP_GAME/DLC/CHIBIS/CHIBI${String(slotId).padStart(3, '0')}.GIM`,
      customPortraitBytes: customPortraitsBySlot?.get(slotId),
      modes: [
        'BATALLA_LIBRE',
        'DRAGON_WALKER',
        'SELECCION_BATALLA',
        'AD_HOC',
        'PERSONALIZAR',
        'ENTRENAMIENTO',
        'OPCIONES',
      ],
    };
  });

  const maps =
    mapSlots.length > 0
      ? mapSlots.map((m) => ({
          slotId: m.id,
          name: m.name,
          stagePath: m.dlcMapPath,
          minimapPath: m.dlcMinimapPath,
          linkedMusicTrackId: m.linkedBgmId,
          customMapBytes: m.customMapBytes,
          customMinimapBytes: m.customMinimapBytes,
        }))
      : [...DBZ_TAG_TEAM_BASE_MAPS, ...DBZ_TAG_TEAM_DLC_EXPANSION_MAPS].map((name, idx) => ({
          slotId: idx + 1,
          name,
          stagePath: `disc0:/PSP_GAME/DLC/MAPAS/MAPS${String(idx + 1).padStart(2, '0')}.BIN`,
          minimapPath: `disc0:/PSP_GAME/DLC/MINIMAPAS/MINIMAP${String(idx + 1).padStart(2, '0')}.TM2`,
          linkedMusicTrackId: ((idx % 19) + 1),
        }));

  const music =
    musicSlots.length > 0
      ? musicSlots.map((t) => ({
          trackId: t.id,
          title: t.title,
          dlcPath: t.dlcAudioPath,
          customAudioBytes: t.customAudioBytes,
        }))
      : DBZ_TAG_TEAM_CANONICAL_MUSIC.map((t) => ({
          trackId: t.id,
          title: t.title,
          dlcPath: `disc0:/PSP_GAME/DLC/MUSICA/BGM${String(t.id).padStart(3, '0')}.AT3`,
        }));

  const optionEntries = buildMenuOptionsSwitcherEntries(layout);
  return buildMasterPackfileBin({
    gameId,
    freeBattleHeaderBin: buildFreeBattleHeaderBin(layout),
    freeBattleLayoutJson: JSON.stringify(layout, null, 2),
    characters,
    maps,
    music,
    preservedEntries,
    extraEntries: [...optionEntries, ...(extraEntries ?? [])],
  });
}

type Pck1SuiteBundleType =
  | 'PERSONAJES_DLC'
  | 'MAPAS_MINIMAPAS'
  | 'LOBBY_PERSONAJES'
  | 'MUSICA_AT3'
  | 'UI_BATALLA_LIBRE'
  | 'MASTER_PACKFILE_BIN';

interface DbzFreeBattleEditorProps {
  analysis: EbootAnalysis | null;
  isoFileBlob?: Blob | null;
  gameId: string;
  manifest: DbzRoster256JsonManifest;
  mapSlots: IsoMapMiniSlot[];
  musicSlots: IsoMusicMiniSlot[];
  layout: FreeBattleLayoutConfig;
  onChangeLayout: (next: FreeBattleLayoutConfig) => void;
  onSyncBuiltPckBinary?: (pckBytes: Uint8Array | null) => void;
  onSyncMasterPackfile?: (packfileBytes: Uint8Array | null) => void;
  onSendPackfileToIsoPacker?: (files: Array<{ file: File; relativePath: string }>) => void;
  onInspectAssetBytes?: (bytes: Uint8Array, assetPath: string) => void;
  onLaunchEmulatorWithPreset?: (preset: FreeBattlePresetId) => void;
}

function getSlotCharacterName(slotHexId: number, manifest: DbzRoster256JsonManifest): string {
  const fromManifest = manifest.characters[slotHexId]?.displayName;
  if (fromManifest) return fromManifest;
  if (slotHexId >= 0 && slotHexId < DBZ_TAG_TEAM_CANONICAL_NAMES.length) {
    return DBZ_TAG_TEAM_CANONICAL_NAMES[slotHexId];
  }
  return `Guerrero DLC #${String(slotHexId + 1).padStart(3, '0')}`;
}

function slotColorPalette(slotId: number): [string, string, string] {
  const palettes: Array<[string, string, string]> = [
    ['#f97316', '#1d4ed8', '#0f172a'], // Goku orange/blue/black hair
    ['#1e3a8a', '#f8fafc', '#111827'], // Vegeta
    ['#7e22ce', '#facc15', '#facc15'], // Gohan / SSJ
    ['#15803d', '#9333ea', '#16a34a'], // Piccolo
    ['#e2e8f0', '#6d28d9', '#f8fafc'], // Freezer
    ['#166534', '#0f172a', '#22c55e'], // Cell
    ['#f472b6', '#f8fafc', '#f9a8d4'], // Buu
    ['#22c55e', '#dc2626', '#facc15'], // Broly
  ];
  return palettes[slotId % palettes.length];
}

function downloadUint8(data: Uint8Array, filename: string) {
  const blob = new Blob([data as unknown as BlobPart], { type: 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export const DbzFreeBattleEditor: React.FC<DbzFreeBattleEditorProps> = ({
  analysis,
  isoFileBlob,
  gameId,
  manifest,
  mapSlots,
  musicSlots,
  layout,
  onChangeLayout,
  onSyncBuiltPckBinary,
  onSyncMasterPackfile,
  onSendPackfileToIsoPacker,
  onInspectAssetBytes,
  onLaunchEmulatorWithPreset,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pckUploadRef = useRef<HTMLInputElement | null>(null);
  const replaceEntryUploadRef = useRef<HTMLInputElement | null>(null);
  const addExtraAssetUploadRef = useRef<HTMLInputElement | null>(null);

  const [previewScreen, setPreviewScreen] = useState<'CHAR_SELECT' | 'MAP_SELECT' | 'MENU_OPTIONS'>('CHAR_SELECT');
  const [activeGameMode, setActiveGameMode] = useState<FreeBattleGameMode>('BATALLA_LIBRE');
  const [optionsCursorIdx, setOptionsCursorIdx] = useState<number>(0);
  const [activeAssignTeam, setActiveAssignTeam] = useState<'J1' | 'J2' | 'J3' | 'J4'>('J1');
  const [cursorSlot, setCursorSlot] = useState<number>(layout.j1Slot);
  const [galleryTab, setGalleryTab] = useState<'ROSTER_IMAGES' | 'MAP_IMAGES'>('ROSTER_IMAGES');
  const [galleryPage, setGalleryPage] = useState(0);
  const [decodedThumbMap, setDecodedThumbMap] = useState<Record<number, string>>({});
  const [entryImagePreview, setEntryImagePreview] = useState<{ label: string; url: string } | null>(null);

  // Real PCK1 Loader & Editor state
  const [loadedPckBlob, setLoadedPckBlob] = useState<Blob | null>(null);
  const [loadedPckResult, setLoadedPckResult] = useState<Pck1AnalysisResult | null>(null);
  const [pckCategoryFilter, setPckCategoryFilter] = useState<Pck1AssetCategory | 'ALL'>('ALL');
  const [pckScanning, setPckScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [replacementMap, setReplacementMap] = useState<Record<number, { name: string; data: Uint8Array }>>({});
  const [pendingReplaceId, setPendingReplaceId] = useState<number | null>(null);
  const [extraCustomEntries, setExtraCustomEntries] = useState<Pck1PackInputEntry[]>([]);
  const [lastBuiltSuite, setLastBuiltSuite] = useState<{
    type: Pck1SuiteBundleType;
    fileName: string;
    bytes: Uint8Array;
    entryCount: number;
  } | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const isoPckCandidates = useMemo(() => {
    if (!analysis?.isoInfo) return [];
    return analysis.isoInfo.files.filter(
      (f) => !f.isDirectory && /\.(pck|pak|bin)$/i.test(f.path) && !/eboot|boot/i.test(f.path)
    );
  }, [analysis]);

  const [selectedIsoPckPath, setSelectedIsoPckPath] = useState<string>('');
  useEffect(() => {
    if (isoPckCandidates.length > 0 && !selectedIsoPckPath) {
      const preferred =
        isoPckCandidates.find((c) => /pck|packfile|data|ui|chara|stage/i.test(c.path)) ??
        isoPckCandidates[0];
      setSelectedIsoPckPath(preferred.path);
    }
  }, [isoPckCandidates, selectedIsoPckPath]);

  const enabledMenuStyles: FreeBattlePresetId[] =
    layout.enabledMenuStyles && layout.enabledMenuStyles.length > 0
      ? layout.enabledMenuStyles
      : ALL_FREE_BATTLE_PRESET_IDS;

  const toggleEnabledMenuStyle = (id: FreeBattlePresetId) => {
    const exists = enabledMenuStyles.includes(id);
    if (exists && enabledMenuStyles.length <= 1) {
      setStatusMessage('Debe quedar al menos 1 estilo de menú activo para PCK1.');
      return;
    }
    const next = exists
      ? enabledMenuStyles.filter((x) => x !== id)
      : [...enabledMenuStyles, id];
    onChangeLayout({
      ...layout,
      enabledMenuStyles: next,
    });
  };

  const applyPreset = (presetId: FreeBattlePresetId) => {
    const base = buildDefaultFreeBattleLayout(presetId);
    const nextEnabled = enabledMenuStyles.includes(presetId)
      ? enabledMenuStyles
      : [...enabledMenuStyles, presetId];
    onChangeLayout({
      ...layout,
      ...base,
      j1Slot: layout.j1Slot,
      j2Slot: layout.j2Slot,
      j3Slot: layout.j3Slot,
      j4Slot: layout.j4Slot,
      selectedMapId: layout.selectedMapId,
      selectedMusicId: layout.selectedMusicId,
      slotCount: layout.slotCount,
      enabledMenuStyles: nextEnabled,
      optionsMenuSwitchTrigger: layout.optionsMenuSwitchTrigger ?? 'OPCIONES_JUEGO',
    });
    setStatusMessage(`Menú Libre cambiado a: ${FREE_BATTLE_PRESETS.find((p) => p.id === presetId)?.name} (empacado en PCK1).`);
  };

  // Parse local or ISO PCK1
  const loadPckBlobAndParse = async (blob: Blob, name: string) => {
    setPckScanning(true);
    setScanProgress(5);
    setReplacementMap({});
    try {
      const result = await parseAndScanPck1Blob(blob, name, (pct) => setScanProgress(pct));
      setLoadedPckBlob(blob);
      setLoadedPckResult(result);
      setStatusMessage(
        `PCK1 cargado: ${result.packName} · ${result.entries.length} activos indexados (${result.pck1BlocksFound} bloque(s) PCK1).`
      );
    } catch (err) {
      setStatusMessage(
        err instanceof Error ? `Error al leer PCK1: ${err.message}` : 'No se pudo analizar el archivo PCK1.'
      );
    } finally {
      setPckScanning(false);
    }
  };

  const handleUploadPckFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    await loadPckBlobAndParse(f, f.name);
  };

  const handleLoadIsoPck = async () => {
    if (!isoFileBlob || !analysis?.isoInfo || !selectedIsoPckPath) return;
    const entry = analysis.isoInfo.files.find((f) => f.path === selectedIsoPckPath);
    if (!entry) return;
    setPckScanning(true);
    try {
      const bytes = await extractIsoFileBytes(isoFileBlob, entry);
      const blob = new Blob([bytes as unknown as BlobPart]);
      await loadPckBlobAndParse(blob, entry.path.split('/').pop() || 'PACKFILE.PCK');
    } catch (err) {
      setStatusMessage(
        err instanceof Error ? `Error al extraer de ISO: ${err.message}` : 'Error al extraer archivo de la ISO.'
      );
      setPckScanning(false);
    }
  };

  const handleReplacePckEntryFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || pendingReplaceId === null) return;
    const bytes = new Uint8Array(await file.arrayBuffer());
    setReplacementMap((prev) => ({
      ...prev,
      [pendingReplaceId]: { name: file.name, data: bytes },
    }));
    setStatusMessage(
      `Bloque #${String(pendingReplaceId).padStart(4, '0')} reemplazado con ${file.name} (${bytes.length.toLocaleString('es-ES')} B).`
    );
    setPendingReplaceId(null);
  };

  const handleAddExtraAssetsToPck = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    e.target.value = '';
    if (files.length === 0) return;
    const loaded: Pck1PackInputEntry[] = [];
    for (const f of files) {
      loaded.push({ name: f.name, data: new Uint8Array(await f.arrayBuffer()) });
    }
    setExtraCustomEntries((prev) => [...prev, ...loaded]);
    setStatusMessage(`${loaded.length} archivo(s) añadidos al contenedor PCK1 personalizado.`);
  };

  const handleBuildSuitePck = async (bundleType: Pck1SuiteBundleType) => {
    let entries: Pck1PackInputEntry[] = [];
    let fileName = 'FREE_BATTLE_UI.PCK';

    if (bundleType === 'PERSONAJES_DLC') {
      fileName = `${gameId}_PERSONAJES_DLC_256.PCK`;
      const charCount = Math.min(layout.slotCount, manifest.characters.length || 256);
      entries = Array.from({ length: charCount }, (_, idx) => {
        const ch = manifest.characters[idx];
        const hexId = ch?.hexId ?? `0x${idx.toString(16).toUpperCase().padStart(2, '0')}`;
        const name = ch?.displayName ?? getSlotCharacterName(idx, manifest);
        const hdr = new TextEncoder().encode(
          `#AMO CHARA_DLC ${hexId} ${name} -> ${ch?.modelBinPath ?? ''}\n`
        );
        return { name: `CHAR_${hexId}.amo`, data: hdr, category: 'PERSONAJES' };
      });
    } else if (bundleType === 'MAPAS_MINIMAPAS') {
      fileName = `${gameId}_MAPAS_MINIMAPAS_DLC.PCK`;
      const allMaps =
        mapSlots.length > 0
          ? mapSlots.map((m) => ({
              slotId: m.id,
              name: m.name,
              stageDlcPath: m.dlcMapPath,
              customMapBytes: m.customMapBytes,
              customMinimapBytes: m.customMinimapBytes,
            }))
          : [...DBZ_TAG_TEAM_BASE_MAPS, ...DBZ_TAG_TEAM_DLC_EXPANSION_MAPS].map((name, idx) => ({
              slotId: idx + 1,
              name,
              stageDlcPath: `disc0:/PSP_GAME/DLC/MAPAS/MAP_${String(idx + 1).padStart(2, '0')}.MAP`,
              customMapBytes: undefined as Uint8Array | undefined,
              customMinimapBytes: undefined as Uint8Array | undefined,
            }));

      for (const m of allMaps) {
        const mapData =
          m.customMapBytes ??
          new TextEncoder().encode(
            `MAP ${String(m.slotId).padStart(2, '0')} | ${m.name} | ${m.stageDlcPath}\n`
          );
        const mmapData =
          m.customMinimapBytes ??
          buildMinimalPspGimTexture(
            `MINIMAP_${String(m.slotId).padStart(2, '0')}`,
            [56, 189, 248]
          );
        entries.push({
          name: `MAP_${String(m.slotId).padStart(2, '0')}.map`,
          data: mapData,
          category: 'MAPAS',
        });
        entries.push({
          name: `MINIMAP_${String(m.slotId).padStart(2, '0')}.gim`,
          data: mmapData,
          category: 'MINIMAPAS',
        });
      }
    } else if (bundleType === 'LOBBY_PERSONAJES') {
      fileName = `${gameId}_LOBBY_PERSONAJES_256.PCK`;
      const chCount = Math.min(layout.slotCount, 256);
      entries = Array.from({ length: chCount }, (_, idx) => {
        const name = getSlotCharacterName(idx, manifest);
        const [c1] = slotColorPalette(idx);
        const r = parseInt(c1.slice(1, 3), 16) || 249;
        const g = parseInt(c1.slice(3, 5), 16) || 115;
        const b = parseInt(c1.slice(5, 7), 16) || 22;
        return {
          name: `CHIBI_LOBBY_${String(idx).padStart(3, '0')}_${name.slice(0, 12)}.gim`,
          data: buildMinimalPspGimTexture(`CHIBI_${String(idx).padStart(3, '0')}`, [r, g, b]),
          category: 'IMAGENES',
        };
      });
    } else if (bundleType === 'MUSICA_AT3') {
      fileName = `${gameId}_MUSICA_DLC_AT3.PCK`;
      const tracks =
        musicSlots.length > 0
          ? musicSlots.map((t) => ({
              trackId: t.id,
              title: t.title,
              customAudioBytes: t.customAudioBytes,
            }))
          : DBZ_TAG_TEAM_CANONICAL_MUSIC.map((t) => ({
              trackId: t.id,
              title: t.title,
              customAudioBytes: undefined as Uint8Array | undefined,
            }));
      entries = tracks.slice(0, 64).map((t) => ({
        name: `BGM_${String(t.trackId).padStart(2, '0')}.at3`,
        data: t.customAudioBytes ?? buildMinimalRiffAt3Blob(t.trackId, t.title),
        category: 'MUSICA_AT3',
      }));
    } else if (bundleType === 'MASTER_PACKFILE_BIN') {
      fileName = 'PACKFILE.BIN';
      const preserved: Pck1PackInputEntry[] = [];
      if (loadedPckBlob && loadedPckResult && loadedPckResult.entries.length > 0 && loadedPckResult.packName.toUpperCase() !== 'PACKFILE.BIN') {
        for (const item of loadedPckResult.entries.slice(0, 120)) {
          const rep = replacementMap[item.id];
          if (rep) {
            preserved.push({ name: rep.name, data: rep.data, category: item.category });
          } else {
            const rawData = await extractPck1EntryData(loadedPckBlob, item);
            preserved.push({ name: item.name, data: rawData, category: item.category });
          }
        }
      }
      const packfileBytes = buildMasterPackfileFromSuiteState({
        gameId,
        layout,
        manifest,
        mapSlots,
        musicSlots,
        preservedEntries: preserved.length > 0 ? preserved : undefined,
        extraEntries: extraCustomEntries.length > 0 ? extraCustomEntries : undefined,
      });
      setLastBuiltSuite({
        type: 'MASTER_PACKFILE_BIN',
        fileName: 'PACKFILE.BIN',
        bytes: packfileBytes,
        entryCount: layout.slotCount + (mapSlots.length || 46) * 2 + (musicSlots.length || 19) + 7,
      });
      onSyncMasterPackfile?.(packfileBytes);
      await loadPckBlobAndParse(new Blob([packfileBytes as unknown as BlobPart]), 'PACKFILE.BIN');
      setStatusMessage(
        `PACKFILE.BIN maestro generado (${(packfileBytes.length / 1024).toFixed(1)} KB): incluye Roster Expandida ${layout.slotCount} (Batalla Libre + Otros Modos) con imágenes .GIM + ${mapSlots.length || 46} Mapas/Minimapas DLC.`
      );
      return;
    } else {
      fileName = `${gameId}_FREE_BATTLE_UI.PCK`;
      // If user loaded a real PCK1 file, include its entries (applying replacements) + Free Battle layout!
      if (loadedPckBlob && loadedPckResult && loadedPckResult.entries.length > 0) {
        for (const item of loadedPckResult.entries.slice(0, 180)) {
          const rep = replacementMap[item.id];
          if (rep) {
            entries.push({ name: rep.name, data: rep.data, category: item.category });
          } else {
            const rawData = await extractPck1EntryData(loadedPckBlob, item);
            entries.push({ name: item.name, data: rawData, category: item.category });
          }
        }
      }
      const pckBytes = buildFreeBattleUiPckBinary(layout, [...entries, ...extraCustomEntries]);
      setLastBuiltSuite({
        type: bundleType,
        fileName,
        bytes: pckBytes,
        entryCount: entries.length + extraCustomEntries.length + 4,
      });
      onSyncBuiltPckBinary?.(pckBytes);
      await loadPckBlobAndParse(new Blob([pckBytes as unknown as BlobPart]), fileName);
      return;
    }

    const combined = [...entries, ...extraCustomEntries];
    const pckBytes = buildPck1Container(combined);
    setLastBuiltSuite({
      type: bundleType,
      fileName,
      bytes: pckBytes,
      entryCount: combined.length,
    });
    await loadPckBlobAndParse(new Blob([pckBytes as unknown as BlobPart]), fileName);
  };

  const handleInjectMasterPackfileToIso = async () => {
    const packfileBytes = buildMasterPackfileFromSuiteState({
      gameId,
      layout,
      manifest,
      mapSlots,
      musicSlots,
      extraEntries: extraCustomEntries.length > 0 ? extraCustomEntries : undefined,
    });
    const uiPckBytes = buildFreeBattleUiPckBinary(layout, extraCustomEntries);
    onSyncMasterPackfile?.(packfileBytes);
    onSyncBuiltPckBinary?.(uiPckBytes);
    await loadPckBlobAndParse(new Blob([packfileBytes as unknown as BlobPart]), 'PACKFILE.BIN');

    if (onSendPackfileToIsoPacker) {
      const files = [
        {
          file: new File([packfileBytes as unknown as BlobPart], 'PACKFILE.BIN', {
            type: 'application/octet-stream',
          }),
          relativePath: 'PSP_GAME/USRDIR/PACKFILE.BIN',
        },
        {
          file: new File([uiPckBytes as unknown as BlobPart], 'FREE_BATTLE_UI.PCK', {
            type: 'application/octet-stream',
          }),
          relativePath: 'PSP_GAME/DLC/UI/FREE_BATTLE_UI.PCK',
        },
      ];
      onSendPackfileToIsoPacker(files);
    } else {
      downloadUint8(packfileBytes, 'PACKFILE.BIN');
    }
  };

  // Interactive PSP Hardware Controls dispatcher for Free Battle + Map Selector + Options Menu Switcher
  const handlePspButtonPress = (btn: PspHardwareButton) => {
    const stepCols = Math.max(2, Math.min(20, layout.cols));
    if (btn === 'HOME') {
      if (previewScreen === 'MENU_OPTIONS') {
        setPreviewScreen('CHAR_SELECT');
      } else {
        const idx = enabledMenuStyles.indexOf(layout.presetId);
        setOptionsCursorIdx(idx >= 0 ? idx : 0);
        setPreviewScreen('MENU_OPTIONS');
      }
      return;
    }

    if (previewScreen === 'MENU_OPTIONS') {
      const totalOpts = enabledMenuStyles.length;
      if (btn === 'DOWN' || btn === 'RIGHT' || btn === 'R') {
        const nextIdx = (optionsCursorIdx + 1) % totalOpts;
        setOptionsCursorIdx(nextIdx);
        applyPreset(enabledMenuStyles[nextIdx]);
      } else if (btn === 'UP' || btn === 'LEFT' || btn === 'L') {
        const nextIdx = (optionsCursorIdx - 1 + totalOpts) % totalOpts;
        setOptionsCursorIdx(nextIdx);
        applyPreset(enabledMenuStyles[nextIdx]);
      } else if (btn === 'CROSS' || btn === 'START') {
        const targetId = enabledMenuStyles[optionsCursorIdx % totalOpts];
        applyPreset(targetId);
        setPreviewScreen('CHAR_SELECT');
      } else if (btn === 'CIRCLE' || btn === 'SQUARE') {
        setPreviewScreen('CHAR_SELECT');
      }
      return;
    }

    if (btn === 'SQUARE') {
      setPreviewScreen((s) => (s === 'CHAR_SELECT' ? 'MAP_SELECT' : 'CHAR_SELECT'));
      return;
    }
    if (btn === 'SELECT') {
      const order: Array<'J1' | 'J2' | 'J3' | 'J4'> = ['J1', 'J2', 'J3', 'J4'];
      setActiveAssignTeam((cur) => order[(order.indexOf(cur) + 1) % order.length]);
      return;
    }

    if (previewScreen === 'MAP_SELECT') {
      const totalMaps = Math.max(11, mapSlots.length || 46);
      if (btn === 'RIGHT' || btn === 'DOWN') {
        onChangeLayout({ ...layout, selectedMapId: (layout.selectedMapId % totalMaps) + 1 });
      } else if (btn === 'LEFT' || btn === 'UP') {
        onChangeLayout({
          ...layout,
          selectedMapId: ((layout.selectedMapId - 2 + totalMaps) % totalMaps) + 1,
        });
      } else if (btn === 'R' || btn === 'L') {
        const totalMusic = Math.max(19, musicSlots.length || 19);
        const dir = btn === 'R' ? 1 : -1;
        const nextMusic = ((layout.selectedMusicId - 1 + dir + totalMusic) % totalMusic) + 1;
        onChangeLayout({ ...layout, selectedMusicId: nextMusic });
      } else if (btn === 'CIRCLE') {
        setPreviewScreen('CHAR_SELECT');
      } else if (btn === 'CROSS' || btn === 'START') {
        setStatusMessage(
          `Escenario #${String(layout.selectedMapId).padStart(2, '0')} y BGM #${String(
            layout.selectedMusicId
          ).padStart(2, '0')} fijados en PACKFILE.BIN.`
        );
      }
      return;
    }

    // CHAR_SELECT mode navigation
    if (btn === 'RIGHT') {
      setCursorSlot((c) => (c + 1) % layout.slotCount);
    } else if (btn === 'LEFT') {
      setCursorSlot((c) => (c - 1 + layout.slotCount) % layout.slotCount);
    } else if (btn === 'DOWN') {
      setCursorSlot((c) => (c + stepCols) % layout.slotCount);
    } else if (btn === 'UP') {
      setCursorSlot((c) => (c - stepCols + layout.slotCount) % layout.slotCount);
    } else if (btn === 'R') {
      setCursorSlot((c) => (c + 24) % layout.slotCount);
    } else if (btn === 'L') {
      setCursorSlot((c) => (c - 24 + layout.slotCount) % layout.slotCount);
    } else if (btn === 'CROSS') {
      onChangeLayout({
        ...layout,
        j1Slot: activeAssignTeam === 'J1' ? cursorSlot : layout.j1Slot,
        j2Slot: activeAssignTeam === 'J2' ? cursorSlot : layout.j2Slot,
        j3Slot: activeAssignTeam === 'J3' ? cursorSlot : layout.j3Slot,
        j4Slot: activeAssignTeam === 'J4' ? cursorSlot : layout.j4Slot,
      });
    } else if (btn === 'TRIANGLE') {
      const rand = Math.floor(Math.random() * layout.slotCount);
      setCursorSlot(rand);
    } else if (btn === 'START') {
      setPreviewScreen('MAP_SELECT');
    }
  };

  // Visual Gallery thumbnails (.GIM rendered to DataURL) for Roster & Map Selector DLC
  const galleryItems = useMemo(() => {
    const pageSize = 24;
    if (galleryTab === 'ROSTER_IMAGES') {
      const total = layout.slotCount;
      const start = (galleryPage * pageSize) % total;
      const count = Math.min(pageSize, total - start);
      return Array.from({ length: count }, (_, i) => {
        const slotId = start + i;
        const name = getSlotCharacterName(slotId, manifest);
        const [c1, c2, hair] = slotColorPalette(slotId);
        const toRgb = (hexStr: string): [number, number, number] => [
          parseInt(hexStr.slice(1, 3), 16) || 120,
          parseInt(hexStr.slice(3, 5), 16) || 120,
          parseInt(hexStr.slice(5, 7), 16) || 120,
        ];
        const gim = buildProceduralPspGimTexture(
          `CHAR_${slotId}`,
          { primary: toRgb(c1), secondary: toRgb(c2), hair: toRgb(hair) },
          'PORTRAIT',
          slotId
        );
        return {
          id: slotId,
          code: `0x${slotId.toString(16).toUpperCase().padStart(2, '0')}`,
          title: name,
          sub: `${activeGameMode === 'BATALLA_LIBRE' ? 'Batalla Libre' : 'Otros Modos'} · CHIBI${String(slotId + 1).padStart(3, '0')}.GIM`,
          imageUrl: renderPspImageBytesToDataUrl(gim),
          minimapUrl: null as string | null,
        };
      });
    } else {
      const totalMaps = mapSlots.length > 0 ? mapSlots.length : 46;
      const start = (galleryPage * 12) % totalMaps;
      const count = Math.min(12, totalMaps - start);
      return Array.from({ length: count }, (_, i) => {
        const mIdx = start + i;
        const slot = mapSlots[mIdx];
        const slotId = slot?.id ?? mIdx + 1;
        const mName =
          slot?.name ??
          DBZ_TAG_TEAM_BASE_MAPS[mIdx] ??
          DBZ_TAG_TEAM_DLC_EXPANSION_MAPS[mIdx - 10] ??
          `Escenario DLC #${slotId}`;
        const palettes: Array<[number, number, number]> = [
          [146, 64, 14],
          [22, 163, 74],
          [63, 63, 70],
          [4, 120, 87],
          [29, 78, 216],
          [88, 28, 135],
        ];
        const p = palettes[slotId % palettes.length];
        const stageGim = buildProceduralPspGimTexture(
          `MAP_${slotId}`,
          { primary: p, secondary: [15, 23, 42], hair: [250, 204, 21] },
          'MAP',
          slotId
        );
        const radarGim = buildProceduralPspGimTexture(
          `MINIMAP_${slotId}`,
          { primary: p, secondary: [6, 78, 59] },
          'MINIMAP',
          slotId
        );
        return {
          id: slotId,
          code: `M${String(slotId).padStart(2, '0')}`,
          title: mName,
          sub: `MAPS${String(slotId).padStart(2, '0')}.BIN + MINIMAP${String(slotId).padStart(2, '0')}.GIM`,
          imageUrl: renderPspImageBytesToDataUrl(stageGim),
          minimapUrl: renderPspImageBytesToDataUrl(radarGim),
        };
      });
    }
  }, [galleryTab, galleryPage, layout.slotCount, manifest, mapSlots, activeGameMode]);

  // Preload thumbnails for visible PCK1 image entries
  useEffect(() => {
    setDecodedThumbMap({});
    if (!loadedPckBlob || !loadedPckResult) return;
    let cancelled = false;
    const imgEntries = loadedPckResult.entries
      .filter((e) => e.category === 'IMAGENES' || e.category === 'MINIMAPAS')
      .slice(0, 36);
    void (async () => {
      const next: Record<number, string> = {};
      for (const item of imgEntries) {
        if (cancelled) break;
        const data = await extractPck1EntryData(loadedPckBlob, item);
        const url = renderPspImageBytesToDataUrl(data);
        if (url) next[item.id] = url;
      }
      if (!cancelled) setDecodedThumbMap(next);
    })();
    return () => {
      cancelled = true;
    };
  }, [loadedPckBlob, loadedPckResult]);

  // Interactive 480x272 PSP Free Battle Canvas Renderer
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = 480;
    const H = 272;
    ctx.clearRect(0, 0, W, H);

    // Background Gradient
    const grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, layout.bgTopColor);
    grad.addColorStop(1, layout.bgBotColor);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // Subtle Speedlines / Dragon Radar Circles
    ctx.strokeStyle = 'rgba(255,255,255,0.08)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 6; i++) {
      ctx.beginPath();
      ctx.arc(360, 130, 35 + i * 26, 0, Math.PI * 2);
      ctx.stroke();
    }

    const drawMiniPortrait = (
      x: number,
      y: number,
      w: number,
      h: number,
      slotId: number,
      selected: boolean,
      shape: 'RECT' | 'HEX'
    ) => {
      const [c1, c2, hair] = slotColorPalette(slotId);
      ctx.save();
      if (shape === 'HEX') {
        const inset = Math.min(6, w * 0.2);
        ctx.beginPath();
        ctx.moveTo(x + inset, y);
        ctx.lineTo(x + w - inset, y);
        ctx.lineTo(x + w, y + h / 2);
        ctx.lineTo(x + w - inset, y + h);
        ctx.lineTo(x + inset, y + h);
        ctx.lineTo(x, y + h / 2);
        ctx.closePath();
        ctx.clip();
      }

      ctx.fillStyle = c2;
      ctx.fillRect(x, y, w, h);
      // Shoulders / Gi
      ctx.fillStyle = c1;
      ctx.fillRect(x + 2, y + h * 0.56, w - 4, h * 0.44);
      // Face
      ctx.fillStyle = '#fed7aa';
      ctx.beginPath();
      ctx.arc(x + w / 2, y + h * 0.46, Math.min(w, h) * 0.25, 0, Math.PI * 2);
      ctx.fill();
      // Spiky hair crest
      ctx.fillStyle = hair;
      ctx.beginPath();
      ctx.moveTo(x + w * 0.2, y + h * 0.36);
      ctx.lineTo(x + w * 0.35, y + h * 0.1);
      ctx.lineTo(x + w * 0.5, y + h * 0.18);
      ctx.lineTo(x + w * 0.72, y + h * 0.08);
      ctx.lineTo(x + w * 0.82, y + h * 0.38);
      ctx.closePath();
      ctx.fill();

      // Slot Hex label
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(x, y + h - 9, w, 9);
      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 7px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(slotId.toString(16).toUpperCase().padStart(2, '0'), x + w / 2, y + h - 2);
      ctx.restore();

      // Border
      ctx.strokeStyle = selected ? layout.cursorColor : 'rgba(255,255,255,0.45)';
      ctx.lineWidth = selected ? 2 : 1;
      if (shape === 'HEX') {
        const inset = Math.min(6, w * 0.2);
        ctx.beginPath();
        ctx.moveTo(x + inset, y);
        ctx.lineTo(x + w - inset, y);
        ctx.lineTo(x + w, y + h / 2);
        ctx.lineTo(x + w - inset, y + h);
        ctx.lineTo(x + inset, y + h);
        ctx.lineTo(x, y + h / 2);
        ctx.closePath();
        ctx.stroke();
      } else {
        ctx.strokeRect(x, y, w, h);
      }
    };

    const drawCenterFighterPose = (cx: number, cy: number, scale: number, slotId: number) => {
      const [gi, belt, hair] = slotColorPalette(slotId);
      ctx.save();
      ctx.translate(cx, cy);
      ctx.scale(scale, scale);
      // Aura glow
      const auraGrad = ctx.createRadialGradient(0, 0, 5, 0, 0, 62);
      auraGrad.addColorStop(0, 'rgba(250,204,21,0.45)');
      auraGrad.addColorStop(1, 'rgba(250,204,21,0)');
      ctx.fillStyle = auraGrad;
      ctx.beginPath();
      ctx.arc(0, 0, 62, 0, Math.PI * 2);
      ctx.fill();
      // Torso
      ctx.fillStyle = gi;
      ctx.beginPath();
      ctx.moveTo(-24, 52);
      ctx.lineTo(-18, -6);
      ctx.lineTo(18, -6);
      ctx.lineTo(24, 52);
      ctx.closePath();
      ctx.fill();
      // Undershirt V
      ctx.fillStyle = belt;
      ctx.beginPath();
      ctx.moveTo(-9, -6);
      ctx.lineTo(0, 16);
      ctx.lineTo(9, -6);
      ctx.closePath();
      ctx.fill();
      // Head
      ctx.fillStyle = '#fed7aa';
      ctx.beginPath();
      ctx.arc(0, -22, 15, 0, Math.PI * 2);
      ctx.fill();
      // Spikes
      ctx.fillStyle = hair;
      ctx.beginPath();
      ctx.moveTo(-16, -24);
      ctx.lineTo(-26, -42);
      ctx.lineTo(-8, -36);
      ctx.lineTo(0, -56);
      ctx.lineTo(10, -37);
      ctx.lineTo(27, -43);
      ctx.lineTo(15, -24);
      ctx.closePath();
      ctx.fill();
      // Eyes
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(-7, -23, 5, 2.5);
      ctx.fillRect(2, -23, 5, 2.5);
      ctx.restore();
    };

    if (previewScreen === 'MENU_OPTIONS') {
      // In-game PSP Options screen to switch Batalla Libre layout between other PCK1 presets
      ctx.fillStyle = '#075985';
      ctx.fillRect(0, 0, W, 24);
      ctx.fillStyle = '#facc15';
      ctx.font = 'bold 12px sans-serif';
      ctx.fillText('OPCIONES → CAMBIAR MENÚ BATALLA LIBRE (PCK1)', 12, 16);

      ctx.fillStyle = 'rgba(15,23,42,0.78)';
      ctx.fillRect(14, 32, W - 28, 212);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(14, 32, W - 28, 212);

      ctx.fillStyle = '#e0f2fe';
      ctx.font = 'bold 10px monospace';
      ctx.fillText(
        `ESTILOS INCLUIDOS EN PACKFILE.BIN / FREE_BATTLE_UI.PCK (${enabledMenuStyles.length}):`,
        24,
        48
      );

      enabledMenuStyles.slice(0, 8).forEach((id, idx) => {
        const meta = FREE_BATTLE_PRESETS.find((p) => p.id === id);
        const isCurrent = layout.presetId === id;
        const isFocus = optionsCursorIdx % enabledMenuStyles.length === idx;
        const ry = 56 + idx * 22;
        ctx.fillStyle = isFocus
          ? 'rgba(250,204,21,0.22)'
          : isCurrent
          ? 'rgba(56,189,248,0.16)'
          : 'rgba(255,255,255,0.04)';
        ctx.fillRect(22, ry, W - 44, 19);
        if (isFocus) {
          ctx.strokeStyle = '#facc15';
          ctx.strokeRect(22, ry, W - 44, 19);
        }
        ctx.fillStyle = isFocus ? '#fde047' : '#f8fafc';
        ctx.font = 'bold 10px sans-serif';
        ctx.fillText(
          `${isFocus ? '▶' : ' '} ${idx + 1}. ${meta?.name ?? id}`,
          28,
          ry + 13
        );
        ctx.fillStyle = isCurrent ? '#4ade80' : '#94a3b8';
        ctx.font = 'bold 9px monospace';
        ctx.textAlign = 'right';
        ctx.fillText(isCurrent ? 'ACTIVO · PCK1' : meta?.wireframeTag ?? 'PCK1', W - 28, ry + 13);
        ctx.textAlign = 'left';
      });

      ctx.fillStyle = 'rgba(2, 132, 199, 0.92)';
      ctx.fillRect(0, H - 18, W, 18);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 9px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(
        '[↑↓] Cambiar Estilo PCK1   [✕] Aplicar Menú Libre   [○/HOME] Volver',
        W / 2,
        H - 5
      );
      ctx.textAlign = 'left';
    } else if (previewScreen === 'MAP_SELECT') {
      // Map + Minimap + Music AT3 Preview
      const matchedMap = mapSlots.find((m) => m.id === layout.selectedMapId);
      const mapItem = matchedMap
        ? { slotId: matchedMap.id, name: matchedMap.name }
        : {
            slotId: layout.selectedMapId,
            name:
              DBZ_TAG_TEAM_BASE_MAPS[layout.selectedMapId - 1] ??
              DBZ_TAG_TEAM_DLC_EXPANSION_MAPS[layout.selectedMapId - 11] ??
              `Escenario DLC #${layout.selectedMapId}`,
          };
      const matchedBgm = musicSlots.find((m) => m.id === layout.selectedMusicId);
      const bgmItem = matchedBgm
        ? { trackId: matchedBgm.id, title: matchedBgm.title }
        : {
            trackId: layout.selectedMusicId,
            title:
              DBZ_TAG_TEAM_CANONICAL_MUSIC.find((t) => t.id === layout.selectedMusicId)?.title ??
              `${String(layout.selectedMusicId).padStart(2, '0')} — Pista DLC AT3`,
          };

      // Top bar
      ctx.fillStyle = layout.accentColor;
      ctx.fillRect(0, 0, W, 24);
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 13px sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('SELECCIÓN DE MAPA Y MINIMAPA (PCK1)', 14, 17);

      // Left stage + radar minimap
      ctx.fillStyle = 'rgba(15,23,42,0.7)';
      ctx.fillRect(14, 34, 240, 118);
      ctx.strokeStyle = layout.cursorColor;
      ctx.strokeRect(14, 34, 240, 118);
      drawCenterFighterPose(134, 98, 0.72, layout.j1Slot);

      // Radar Minimap corner inside map preview
      ctx.fillStyle = 'rgba(6, 78, 59, 0.85)';
      ctx.beginPath();
      ctx.arc(224, 62, 22, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#34d399';
      ctx.stroke();
      ctx.fillStyle = '#facc15';
      ctx.fillRect(218, 59, 4, 4);
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(229, 63, 4, 4);

      ctx.fillStyle = '#fef08a';
      ctx.fillRect(14, 134, 240, 18);
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText(`${mapItem.slotId}. ${mapItem.name}`, 22, 147);

      // Right info boxes
      ctx.fillStyle = 'rgba(255,255,255,0.12)';
      ctx.fillRect(268, 38, 198, 28);
      ctx.fillRect(268, 74, 198, 28);
      ctx.fillRect(268, 110, 198, 28);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px monospace';
      ctx.fillText(`Equipo A: ${getSlotCharacterName(layout.j1Slot, manifest).slice(0, 13)}`, 276, 56);
      ctx.fillText(`Equipo B: ${getSlotCharacterName(layout.j3Slot, manifest).slice(0, 13)}`, 276, 92);
      ctx.fillText(`Formato: PCK1 MAPAS+MINIMAPAS`, 276, 128);

      // Map minislots row
      for (let i = 0; i < 6; i++) {
        const mId = ((layout.selectedMapId - 2 + i + 45) % 46) + 1;
        const mx = 16 + i * 76;
        const isCur = mId === layout.selectedMapId;
        ctx.fillStyle = isCur ? '#0369a1' : '#1e293b';
        ctx.fillRect(mx, 166, 70, 42);
        ctx.strokeStyle = isCur ? layout.cursorColor : '#64748b';
        ctx.lineWidth = isCur ? 2 : 1;
        ctx.strokeRect(mx, 166, 70, 42);
        ctx.fillStyle = '#f8fafc';
        ctx.font = 'bold 9px monospace';
        ctx.fillText(`MAP ${String(mId).padStart(2, '0')}`, mx + 8, 190);
      }

      // Music bar
      ctx.fillStyle = '#fef08a';
      ctx.fillRect(14, 218, 452, 22);
      ctx.fillStyle = '#0f172a';
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText(`♪ MUSICA AT3: ${bgmItem.title} (${layout.slotCount} slots DLC)`, 24, 233);
    } else {
      // Top header bar (skip on HEX_BORDER_256 top border overlay)
      if (layout.presetId !== 'HEX_BORDER_256') {
        ctx.fillStyle = layout.accentColor;
        ctx.fillRect(0, 0, W, 22);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 12px sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(layout.titleText, 14, 15);

        ctx.font = 'bold 9px monospace';
        ctx.textAlign = 'right';
        const modeTag =
          FREE_BATTLE_GAME_MODES.find((m) => m.id === activeGameMode)?.short ?? 'BATALLA LIBRE';
        ctx.fillText(`${modeTag} · ${layout.slotCount} SLOTS · HOME:OPCIONES`, W - 12, 14);
        ctx.textAlign = 'left';
      }

      if (layout.presetId === 'ORIGINAL_4X6_RIGHT') {
        // Left big bust + Dragon Ball 4-star circle + bottom J1..J4 strip; Right 4x6 grid
        ctx.fillStyle = '#fef9c3';
        ctx.fillRect(6, 28, 258, 148);
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(216, 86, 42, 0, Math.PI * 2);
        ctx.fill();
        drawCenterFighterPose(126, 110, 1.18, cursorSlot);

        // Nameplate
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        ctx.fillRect(126, 152, 134, 18);
        ctx.fillStyle = '#b91c1c';
        ctx.font = 'bold 11px sans-serif';
        ctx.fillText(getSlotCharacterName(cursorSlot, manifest).slice(0, 16), 132, 165);

        // Left team strip J1..J4
        const team = [layout.j1Slot, layout.j2Slot, layout.j3Slot, layout.j4Slot];
        team.forEach((s, idx) => {
          drawMiniPortrait(6 + idx * 64, 184, 60, 48, s, activeAssignTeam === `J${idx + 1}`, 'RECT');
          ctx.fillStyle = '#dc2626';
          ctx.font = 'bold 10px sans-serif';
          ctx.fillText(`J${idx + 1}`, 10 + idx * 64, 195);
        });

        // Right 4x6 grid
        const pageSize = 24;
        const pageStart = Math.floor(cursorSlot / pageSize) * pageSize;
        for (let r = 0; r < 6; r++) {
          for (let c = 0; c < 4; c++) {
            const idx = (pageStart + r * 4 + c) % layout.slotCount;
            drawMiniPortrait(
              276 + c * 46,
              32 + r * 34,
              43,
              31,
              idx,
              idx === cursorSlot,
              layout.cellShape
            );
          }
        }
      } else if (layout.presetId === 'CENTER_GRID_VS') {
        // BT3 Portable style: Left J1 render, Center 4x6 portrait column, Right silhouette [?]
        ctx.fillStyle = 'rgba(15, 23, 42, 0.45)';
        ctx.fillRect(0, 22, W, H - 40);
        drawCenterFighterPose(74, 136, 1.25, layout.j1Slot);
        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 10px sans-serif';
        ctx.fillText(getSlotCharacterName(layout.j1Slot, manifest).slice(0, 15), 24, 52);

        // Center 4x6 grid
        ctx.fillStyle = 'rgba(2, 132, 199, 0.35)';
        ctx.fillRect(154, 24, 150, 218);
        const pageStart = Math.floor(cursorSlot / 24) * 24;
        for (let r = 0; r < 6; r++) {
          for (let c = 0; c < 4; c++) {
            const idx = (pageStart + r * 4 + c) % layout.slotCount;
            drawMiniPortrait(
              160 + c * 35,
              30 + r * 34,
              32,
              30,
              idx,
              idx === cursorSlot,
              layout.cellShape
            );
          }
        }

        // Right rival silhouette [?]
        ctx.fillStyle = '#312e81';
        ctx.beginPath();
        ctx.ellipse(394, 138, 46, 86, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#f97316';
        ctx.font = 'bold 42px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('?', 394, 102);
        ctx.textAlign = 'left';
      } else if (layout.presetId === 'SPLIT_SIDES_CENTER') {
        // Left 2x6 grid + Right 2x6 grid + Center fighter & bottom J1..J4 row
        const pageStart = Math.floor(cursorSlot / 24) * 24;
        for (let r = 0; r < 6; r++) {
          for (let c = 0; c < 2; c++) {
            const idxL = (pageStart + r * 2 + c) % layout.slotCount;
            const idxR = (pageStart + 12 + r * 2 + c) % layout.slotCount;
            drawMiniPortrait(6 + c * 46, 36 + r * 33, 44, 30, idxL, idxL === cursorSlot, layout.cellShape);
            drawMiniPortrait(380 + c * 46, 36 + r * 33, 44, 30, idxR, idxR === cursorSlot, layout.cellShape);
          }
        }
        drawCenterFighterPose(240, 118, 1.32, cursorSlot);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 10px sans-serif';
        ctx.fillText(`J1 ${getSlotCharacterName(layout.j1Slot, manifest).slice(0, 12)}`, 14, 32);

        const bottomSlots = [layout.j1Slot, layout.j2Slot, layout.j3Slot, layout.j4Slot];
        bottomSlots.forEach((s, idx) => {
          drawMiniPortrait(108 + idx * 66, 198, 62, 46, s, activeAssignTeam === `J${idx + 1}`, 'RECT');
          ctx.fillStyle = '#f87171';
          ctx.font = 'bold 9px monospace';
          ctx.fillText(`J${idx + 1}`, 112 + idx * 66, 209);
        });
      } else if (layout.presetId === 'TOP_BOTTOM_1P_2P') {
        // Big center render
        drawCenterFighterPose(240, 126, 1.35, cursorSlot);

        // 1P Top Strip
        ctx.fillStyle = '#1e40af';
        ctx.fillRect(4, layout.topBarY, W - 8, layout.cellHeight + 6);
        ctx.fillStyle = '#f8fafc';
        ctx.font = 'bold 13px sans-serif';
        ctx.fillText(layout.p1HeaderLabel, 12, layout.topBarY + 21);
        const start1 = Math.max(0, cursorSlot - 3);
        for (let i = 0; i < layout.cols; i++) {
          const s = (start1 + i) % layout.slotCount;
          drawMiniPortrait(
            48 + i * (layout.cellWidth + 4),
            layout.topBarY + 3,
            layout.cellWidth,
            layout.cellHeight,
            s,
            s === layout.j1Slot || s === cursorSlot,
            layout.cellShape
          );
        }

        // 2P Bottom Strip
        ctx.fillStyle = '#831843';
        ctx.fillRect(4, layout.bottomBarY, W - 8, layout.cellHeight + 6);
        const start2 = Math.max(0, layout.j3Slot - 2);
        for (let i = 0; i < layout.cols; i++) {
          const s = (start2 + i) % layout.slotCount;
          drawMiniPortrait(
            10 + i * (layout.cellWidth + 4),
            layout.bottomBarY + 3,
            layout.cellWidth,
            layout.cellHeight,
            s,
            s === layout.j3Slot,
            layout.cellShape
          );
        }
        ctx.fillStyle = '#fbcfe8';
        ctx.font = 'bold 13px sans-serif';
        ctx.fillText(layout.p2HeaderLabel, W - 34, layout.bottomBarY + 21);
      } else if (layout.presetId === 'CLASSIC_VS') {
        // Right full character showcase
        drawCenterFighterPose(382, 138, 1.25, cursorSlot);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 11px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(getSlotCharacterName(cursorSlot, manifest), 382, 232);
        ctx.textAlign = 'left';

        // VS Header
        ctx.fillStyle = 'rgba(255,255,255,0.14)';
        ctx.fillRect(14, 34, 108, 16);
        ctx.fillStyle = '#fde047';
        ctx.font = 'bold 9px sans-serif';
        ctx.fillText(layout.p1HeaderLabel, 20, 45);

        const vsSlots = [layout.j1Slot, layout.j2Slot, layout.j3Slot, layout.j4Slot];
        vsSlots.forEach((s, i) => {
          const bx = i < 2 ? 14 + i * 52 : 146 + (i - 2) * 52;
          drawMiniPortrait(bx, 60, 44, 34, s, false, layout.cellShape);
        });
        ctx.fillStyle = '#fde047';
        ctx.font = 'bold 14px serif';
        ctx.fillText('VS', 120, 82);

        // 3-row bottom left grid
        const base = Math.max(0, Math.floor(cursorSlot / (layout.cols * 3)) * (layout.cols * 3));
        for (let r = 0; r < 3; r++) {
          for (let c = 0; c < layout.cols; c++) {
            const idx = (base + r * layout.cols + c) % layout.slotCount;
            drawMiniPortrait(
              10 + c * (layout.cellWidth + 2),
              148 + r * (layout.cellHeight + 2),
              layout.cellWidth,
              layout.cellHeight,
              idx,
              idx === cursorSlot,
              layout.cellShape
            );
          }
        }
      } else if (layout.presetId === 'DARK_TEAM_ENEMY') {
        if (layout.showCpuDifficulty) {
          ctx.fillStyle = 'rgba(255,255,255,0.28)';
          ctx.font = 'bold 20px sans-serif';
          ctx.fillText('P1', 36, 48);
          ctx.fillStyle = '#c084fc';
          ctx.font = 'bold 10px sans-serif';
          ctx.fillText('CPU:Normal', 72, 47);
        }

        // Giant Center Render
        drawCenterFighterPose(240, 118, 1.32, cursorSlot);
        ctx.fillStyle = '#f8fafc';
        ctx.font = 'bold 11px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(getSlotCharacterName(cursorSlot, manifest), 240, 194);
        ctx.textAlign = 'left';

        // Left Team (J1 / J2) + Right Enemy (J3 / J4)
        ctx.fillStyle = 'rgba(255,255,255,0.12)';
        ctx.fillRect(14, 80, 134, 14);
        ctx.fillRect(332, 80, 134, 14);
        ctx.fillStyle = '#cbd5e1';
        ctx.font = 'bold 9px sans-serif';
        ctx.fillText(layout.p1HeaderLabel, 74, 90);
        ctx.fillText(layout.p2HeaderLabel, 384, 90);

        drawMiniPortrait(40, layout.topBarY, 34, 34, layout.j1Slot, activeAssignTeam === 'J1', 'RECT');
        drawMiniPortrait(84, layout.topBarY, 34, 34, layout.j2Slot, activeAssignTeam === 'J2', 'RECT');
        drawMiniPortrait(360, layout.topBarY, 34, 34, layout.j3Slot, activeAssignTeam === 'J3', 'RECT');
        drawMiniPortrait(404, layout.topBarY, 34, 34, layout.j4Slot, activeAssignTeam === 'J4', 'RECT');

        ctx.fillStyle = '#f87171';
        ctx.font = 'bold 9px sans-serif';
        ctx.fillText('J1', 51, layout.topBarY + 46);
        ctx.fillStyle = '#60a5fa';
        ctx.fillText('J2', 95, layout.topBarY + 46);
        ctx.fillStyle = '#facc15';
        ctx.fillText('J3', 371, layout.topBarY + 46);
        ctx.fillStyle = '#4ade80';
        ctx.fillText('J4', 415, layout.topBarY + 46);

        // Bottom 19-slot strip
        const stripCount = Math.min(19, Math.max(8, layout.cols));
        const startIdx = Math.max(0, cursorSlot - Math.floor(stripCount / 2));
        for (let i = 0; i < stripCount; i++) {
          const slot = (startIdx + i) % layout.slotCount;
          drawMiniPortrait(
            8 + i * (layout.cellWidth + 1.5),
            layout.bottomBarY,
            layout.cellWidth,
            layout.cellHeight,
            slot,
            slot === cursorSlot,
            layout.cellShape
          );
        }
      } else if (layout.presetId === 'DUAL_STRIP') {
        drawCenterFighterPose(240, 134, 1.38, cursorSlot);
        const startTop = Math.max(0, cursorSlot - 4);
        for (let i = 0; i < 10; i++) {
          const s = (startTop + i) % layout.slotCount;
          drawMiniPortrait(
            8 + i * 46,
            layout.topBarY,
            layout.cellWidth,
            layout.cellHeight,
            s,
            s === cursorSlot,
            layout.cellShape
          );
        }
        const startBot = (startTop + 10) % layout.slotCount;
        for (let i = 0; i < 10; i++) {
          const s = (startBot + i) % layout.slotCount;
          drawMiniPortrait(
            8 + i * 46,
            layout.bottomBarY,
            layout.cellWidth,
            layout.cellHeight,
            s,
            false,
            layout.cellShape
          );
        }
      } else {
        // HEX_BORDER_256: perimeter hexagonal frames + 4 full vertical fighter columns
        const teamSlots = [layout.j1Slot, layout.j2Slot, layout.j3Slot, layout.j4Slot];
        for (let i = 0; i < 4; i++) {
          const colX = 48 + i * 96;
          drawCenterFighterPose(colX + 46, 136, 0.92, teamSlots[i]);
          if (i < 3) {
            ctx.strokeStyle = '#0f172a';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(colX + 94, 34);
            ctx.lineTo(colX + 94, 236);
            ctx.stroke();
          }
          ctx.fillStyle = '#0f172a';
          ctx.font = 'bold 9px monospace';
          ctx.fillText(`J${i + 1}`, colX + 8, 46);
        }

        const topCount = 11;
        const startHex = Math.max(0, cursorSlot - 3);
        for (let i = 0; i < topCount; i++) {
          const s = (startHex + i) % layout.slotCount;
          drawMiniPortrait(8 + i * 42, 4, layout.cellWidth, layout.cellHeight, s, s === cursorSlot, 'HEX');
          drawMiniPortrait(
            8 + i * 42,
            242,
            layout.cellWidth,
            layout.cellHeight,
            (s + 11) % layout.slotCount,
            false,
            'HEX'
          );
        }
        // Left & right side hexes
        for (let r = 0; r < 5; r++) {
          const sl = (startHex + 22 + r) % layout.slotCount;
          const sr = (startHex + 27 + r) % layout.slotCount;
          drawMiniPortrait(8, 36 + r * 40, 34, 26, sl, false, 'HEX');
          drawMiniPortrait(W - 42, 36 + r * 40, 34, 26, sr, false, 'HEX');
        }
      }

      // Controls Footer Bar
      if (layout.showControlsFooter && layout.presetId !== 'HEX_BORDER_256') {
        ctx.fillStyle = 'rgba(2, 132, 199, 0.92)';
        ctx.fillRect(0, H - 18, W, 18);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 9px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(
          `[START] Omitir   [△] Aleatorio   [✕] Confirmar (${activeAssignTeam})   [○] Atrás`,
          W / 2,
          H - 5
        );
        ctx.textAlign = 'left';
      }
    }
  }, [layout, previewScreen, activeGameMode, cursorSlot, optionsCursorIdx, enabledMenuStyles, activeAssignTeam, manifest, mapSlots, musicSlots]);

  // Interactive canvas click: assign next/clicked slot or move cursor
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 480;
    const y = ((e.clientY - rect.top) / rect.height) * 272;

    if (previewScreen === 'MAP_SELECT') {
      const nextMap = (layout.selectedMapId % 46) + 1;
      onChangeLayout({ ...layout, selectedMapId: nextMap });
      return;
    }

    // Approximate clicked character step
    const stepIdx = Math.max(0, Math.floor((x / 480) * 10) + (y > 140 ? 10 : 0));
    const targetSlot = (Math.floor(cursorSlot / 20) * 20 + stepIdx) % layout.slotCount;
    setCursorSlot(targetSlot);
    onChangeLayout({
      ...layout,
      j1Slot: activeAssignTeam === 'J1' ? targetSlot : layout.j1Slot,
      j2Slot: activeAssignTeam === 'J2' ? targetSlot : layout.j2Slot,
      j3Slot: activeAssignTeam === 'J3' ? targetSlot : layout.j3Slot,
      j4Slot: activeAssignTeam === 'J4' ? targetSlot : layout.j4Slot,
    });
  };

  const filteredPckEntries = useMemo(() => {
    if (!loadedPckResult) return [];
    if (pckCategoryFilter === 'ALL') return loadedPckResult.entries;
    return loadedPckResult.entries.filter((e) => e.category === pckCategoryFilter);
  }, [loadedPckResult, pckCategoryFilter]);

  return (
    <div className="space-y-6">
      <input
        ref={pckUploadRef}
        type="file"
        accept=".pck,.bin,.pak,.dat,*/*"
        onChange={(e) => void handleUploadPckFile(e)}
        className="hidden"
      />
      <input
        ref={replaceEntryUploadRef}
        type="file"
        accept="*/*"
        onChange={(e) => void handleReplacePckEntryFile(e)}
        className="hidden"
      />
      <input
        ref={addExtraAssetUploadRef}
        type="file"
        multiple
        accept="*/*"
        onChange={(e) => void handleAddExtraAssetsToPck(e)}
        className="hidden"
      />

      {/* Top Suite Banner & Direct PCK1 Suite Generators */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-3xl">
            <h3 className="flex items-center gap-2 text-base font-semibold text-slate-900 dark:text-white">
              <LayoutGrid className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              Editor de Batalla Libre + Cargador / Empaquetador <span className="font-mono">PCK1</span> (Personajes DLC, Mapas/Minimapas, Lobby y Música AT3)
            </h3>
            <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
              Carga contenedores reales <span className="font-mono">PCK1</span> o <span className="font-mono">PACKFILE.BIN</span>, personaliza las 5 pantallas de selección de Batalla Libre, edita o reemplaza recursos internos y genera paquetes <span className="font-mono">.PCK</span> listos para <span className="font-mono">/PSP_GAME/DLC/</span>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => pckUploadRef.current?.click()}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
            >
              <Upload className="h-3.5 w-3.5" />
              Cargar Archivo .PCK / PCK1
            </button>
            {isoPckCandidates.length > 0 && (
              <div className="flex items-center gap-1.5">
                <select
                  value={selectedIsoPckPath}
                  onChange={(e) => setSelectedIsoPckPath(e.target.value)}
                  className="min-h-[38px] max-w-[180px] rounded-lg border border-slate-300 bg-slate-50 px-2 font-mono text-[11px] text-slate-800 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
                >
                  {isoPckCandidates.map((c) => (
                    <option key={c.path} value={c.path}>
                      {c.path}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => void handleLoadIsoPck()}
                  className="inline-flex min-h-[38px] items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
                >
                  <PackageOpen className="h-3.5 w-3.5" />
                  Abrir de ISO
                </button>
              </div>
            )}
            {onLaunchEmulatorWithPreset && (
              <button
                type="button"
                onClick={() => onLaunchEmulatorWithPreset(layout.presetId)}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-amber-400 hover:bg-slate-800 cursor-pointer"
              >
                <Gamepad2 className="h-4 w-4" />
                Probar HUD en Emulador PSP
              </button>
            )}
          </div>
        </div>

        {/* 6 PCK1 Generators: Personajes DLC, Mapas+Minimapas, Lobby Personajes, Musica AT3, UI Batalla Libre + PACKFILE.BIN Maestro */}
        <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-6 text-xs">
          <button
            type="button"
            onClick={() => void handleBuildSuitePck('PERSONAJES_DLC')}
            className="flex flex-col items-start gap-1 rounded-lg border border-slate-200 bg-slate-50 p-3 text-left transition-colors hover:border-blue-500 hover:bg-blue-50/40 dark:border-slate-800 dark:bg-slate-950 cursor-pointer"
          >
            <div className="flex items-center gap-1.5 font-semibold text-slate-900 dark:text-white">
              <Users className="h-3.5 w-3.5 text-blue-600" />
              Personajes DLC PCK1
            </div>
            <div className="text-[10px] text-slate-500 dark:text-slate-400">
              Empaqueta {layout.slotCount} modelos <span className="font-mono">.AMO/.GIM</span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => void handleBuildSuitePck('MAPAS_MINIMAPAS')}
            className="flex flex-col items-start gap-1 rounded-lg border border-slate-200 bg-slate-50 p-3 text-left transition-colors hover:border-emerald-500 hover:bg-emerald-50/40 dark:border-slate-800 dark:bg-slate-950 cursor-pointer"
          >
            <div className="flex items-center gap-1.5 font-semibold text-slate-900 dark:text-white">
              <MapIcon className="h-3.5 w-3.5 text-emerald-600" />
              Mapas + Minimapas PCK1
            </div>
            <div className="text-[10px] text-slate-500 dark:text-slate-400">
              {mapSlots.length || 46} escenarios <span className="font-mono">.MAP</span> + radar <span className="font-mono">.GIM</span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => void handleBuildSuitePck('LOBBY_PERSONAJES')}
            className="flex flex-col items-start gap-1 rounded-lg border border-slate-200 bg-slate-50 p-3 text-left transition-colors hover:border-amber-500 hover:bg-amber-50/40 dark:border-slate-800 dark:bg-slate-950 cursor-pointer"
          >
            <div className="flex items-center gap-1.5 font-semibold text-slate-900 dark:text-white">
              <FileImage className="h-3.5 w-3.5 text-amber-600" />
              Lobby Chibis 256 PCK1
            </div>
            <div className="text-[10px] text-slate-500 dark:text-slate-400">
              Iconos lobby + retratos <span className="font-mono">MIG.00.1PSP</span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => void handleBuildSuitePck('MUSICA_AT3')}
            className="flex flex-col items-start gap-1 rounded-lg border border-slate-200 bg-slate-50 p-3 text-left transition-colors hover:border-purple-500 hover:bg-purple-50/40 dark:border-slate-800 dark:bg-slate-950 cursor-pointer"
          >
            <div className="flex items-center gap-1.5 font-semibold text-slate-900 dark:text-white">
              <Music className="h-3.5 w-3.5 text-purple-600" />
              Música .AT3 PCK1
            </div>
            <div className="text-[10px] text-slate-500 dark:text-slate-400">
              {musicSlots.length || 64} pistas <span className="font-mono">RIFF ATRAC3+</span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => void handleBuildSuitePck('UI_BATALLA_LIBRE')}
            className="flex flex-col items-start gap-1 rounded-lg border border-blue-500 bg-blue-50/60 p-3 text-left transition-colors hover:bg-blue-100/70 dark:border-blue-800 dark:bg-blue-950/30 cursor-pointer"
          >
            <div className="flex items-center gap-1.5 font-semibold text-blue-900 dark:text-blue-200">
              <Archive className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
              Compilar UI Batalla Libre
            </div>
            <div className="text-[10px] text-blue-700 dark:text-blue-300">
              Genera <span className="font-mono">FREE_BATTLE_UI.PCK</span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => void handleInjectMasterPackfileToIso()}
            className="flex flex-col items-start gap-1 rounded-lg border-2 border-emerald-600 bg-emerald-600 p-3 text-left text-white transition-colors hover:bg-emerald-700 cursor-pointer"
          >
            <div className="flex items-center gap-1.5 font-semibold">
              <Layers className="h-3.5 w-3.5" />
              {onSendPackfileToIsoPacker ? 'Inyectar PACKFILE.BIN en ISO' : 'Generar PACKFILE.BIN Maestro'}
            </div>
            <div className="text-[10px] text-emerald-100">
              Batalla Libre + Otros + 46 Mapas + Imágenes <span className="font-mono">.GIM</span>
            </div>
          </button>
        </div>

        {statusMessage && (
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-emerald-200 bg-emerald-50/70 px-3.5 py-2 text-xs text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-200">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />
              {statusMessage}
            </span>
            {lastBuiltSuite && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => downloadUint8(lastBuiltSuite.bytes, lastBuiltSuite.fileName)}
                  className="inline-flex items-center gap-1 rounded bg-emerald-700 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-emerald-800 cursor-pointer"
                >
                  <Download className="h-3 w-3" />
                  Descargar {lastBuiltSuite.fileName} ({lastBuiltSuite.bytes.length.toLocaleString('es-ES')} B)
                </button>
                {onInspectAssetBytes && (
                  <button
                    type="button"
                    onClick={() => onInspectAssetBytes(lastBuiltSuite.bytes, lastBuiltSuite.fileName)}
                    className="inline-flex items-center gap-1 rounded border border-emerald-700 px-2.5 py-1 text-[11px] font-semibold text-emerald-900 hover:bg-emerald-100 dark:text-emerald-200 cursor-pointer"
                  >
                    <Binary className="h-3 w-3" />
                    Ver en HxD
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </section>

      {/* 8 Free Battle UI Visual Presets + Editor de Menú Opciones para Cambiar entre Otros PCK1 */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h4 className="text-sm font-semibold text-slate-900 dark:text-white">
              1. Editor de Menús y Opciones: Cambiar Menú Libre entre Otros <span className="font-mono">PCK1</span> ({FREE_BATTLE_PRESETS.length} Estilos PSP)
            </h4>
            <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
              Elige el estilo principal para <strong>Batalla Libre</strong> y marca qué otros menús <span className="font-mono">PCK1</span> quieres incluir en el selector del <strong>Menú Opciones</strong> del juego.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-[11px]">
            <label className="flex items-center gap-1.5 font-medium text-slate-700 dark:text-slate-300">
              <span>Cambiar desde juego con:</span>
              <select
                value={layout.optionsMenuSwitchTrigger ?? 'OPCIONES_JUEGO'}
                onChange={(e) =>
                  onChangeLayout({
                    ...layout,
                    optionsMenuSwitchTrigger: e.target.value as FreeBattleLayoutConfig['optionsMenuSwitchTrigger'],
                  })
                }
                className="min-h-[30px] rounded border border-slate-300 bg-slate-50 px-2 font-mono text-[11px] text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              >
                <option value="OPCIONES_JUEGO">Menú Opciones → Estilo PCK1</option>
                <option value="SELECT_IN_MENU">Botón SELECT en Batalla Libre</option>
                <option value="L_PLUS_R">Atajo L + R en Selección</option>
              </select>
            </label>
            <button
              type="button"
              onClick={() => setPreviewScreen('MENU_OPTIONS')}
              className="rounded-md bg-amber-600 px-3 py-1.5 font-semibold text-white hover:bg-amber-700 cursor-pointer"
            >
              Abrir Menú Opciones en PSP
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {FREE_BATTLE_PRESETS.map((preset) => {
            const active = layout.presetId === preset.id;
            const includedInOptions = enabledMenuStyles.includes(preset.id);
            return (
              <div
                key={preset.id}
                className={`flex flex-col overflow-hidden rounded-xl border transition-all ${
                  active
                    ? 'border-blue-600 ring-2 ring-blue-500/30 bg-blue-50/40 dark:bg-blue-950/30'
                    : 'border-slate-200 bg-slate-50 hover:border-blue-400 dark:border-slate-800 dark:bg-slate-950'
                }`}
              >
                <button
                  type="button"
                  onClick={() => applyPreset(preset.id)}
                  className="flex flex-1 flex-col text-left cursor-pointer"
                >
                  {preset.imageUrl ? (
                    <img
                      src={preset.imageUrl}
                      alt={preset.name}
                      className="h-24 w-full object-cover"
                    />
                  ) : (
                    <div className="flex h-24 w-full flex-col items-center justify-center bg-gradient-to-br from-slate-800 via-blue-950 to-slate-900 p-2 text-center">
                      <span className="rounded border border-cyan-400/50 bg-cyan-500/20 px-2 py-0.5 font-mono text-[10px] font-bold text-cyan-200">
                        {preset.wireframeTag} · PCK1
                      </span>
                      <span className="mt-1.5 font-mono text-[10px] text-slate-300">
                        {preset.defaults.cols} cols × {preset.defaults.rows} filas
                      </span>
                    </div>
                  )}
                  <div className="flex-1 p-2.5 text-xs">
                    <div className="font-semibold text-slate-900 dark:text-white">{preset.name}</div>
                    <p className="mt-1 text-[11px] leading-snug text-slate-500 dark:text-slate-400">
                      {preset.shortDesc}
                    </p>
                  </div>
                </button>
                <div className="flex items-center justify-between border-t border-slate-200 bg-white/80 px-2.5 py-1.5 text-[11px] dark:border-slate-800 dark:bg-slate-900/80">
                  <label className="inline-flex items-center gap-1.5 text-slate-700 dark:text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includedInOptions}
                      onChange={() => toggleEnabledMenuStyle(preset.id)}
                      className="h-3.5 w-3.5 rounded border-slate-300 accent-blue-600"
                    />
                    En Opciones PCK1
                  </label>
                  <button
                    type="button"
                    onClick={() => applyPreset(preset.id)}
                    className={`font-mono text-[10px] font-bold cursor-pointer ${
                      active ? 'text-blue-600 dark:text-blue-400' : 'text-slate-500 hover:text-blue-600'
                    }`}
                  >
                    {active ? 'ACTIVO' : 'Usar'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Live 480x272 Interactive Canvas + HUD Parameter Controls */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Live 480x272 PSP Viewport + Hardware PSP Controls */}
        <div className="lg:col-span-7 space-y-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm font-semibold text-slate-900 dark:text-white">
                Vista Previa PSP (480×272)
              </span>
              <div className="inline-flex rounded-lg border border-slate-200 p-0.5 text-[11px] dark:border-slate-700">
                <button
                  type="button"
                  onClick={() => setPreviewScreen('CHAR_SELECT')}
                  className={`rounded px-2.5 py-1 font-semibold cursor-pointer ${
                    previewScreen === 'CHAR_SELECT'
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  Batalla Libre / Otros
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewScreen('MAP_SELECT')}
                  className={`rounded px-2.5 py-1 font-semibold cursor-pointer ${
                    previewScreen === 'MAP_SELECT'
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  Selector Mapas DLC
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewScreen('MENU_OPTIONS')}
                  className={`rounded px-2.5 py-1 font-semibold cursor-pointer ${
                    previewScreen === 'MENU_OPTIONS'
                      ? 'bg-amber-600 text-white'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  Menú Opciones ({enabledMenuStyles.length})
                </button>
              </div>
              <select
                value={activeGameMode}
                onChange={(e) => setActiveGameMode(e.target.value as FreeBattleGameMode)}
                aria-label="Modo del juego para roster expandida"
                className="min-h-[28px] rounded-lg border border-slate-300 bg-slate-50 px-2 font-mono text-[11px] font-semibold text-slate-800 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
              >
                {FREE_BATTLE_GAME_MODES.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-1 text-[11px]">
              {(['J1', 'J2', 'J3', 'J4'] as const).map((tm) => (
                <button
                  key={tm}
                  type="button"
                  onClick={() => setActiveAssignTeam(tm)}
                  className={`rounded border px-2 py-0.5 font-mono font-bold cursor-pointer ${
                    activeAssignTeam === tm
                      ? 'border-amber-500 bg-amber-500 text-slate-950'
                      : 'border-slate-300 text-slate-700 dark:border-slate-700 dark:text-slate-300'
                  }`}
                >
                  {tm}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-hidden rounded-lg border-2 border-slate-900 bg-black shadow-inner">
            <canvas
              ref={canvasRef}
              width={480}
              height={272}
              onClick={handleCanvasClick}
              className="w-full cursor-crosshair select-none"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 dark:text-slate-300">
            <div className="font-mono text-[11px]">
              Cursor: <span className="font-bold text-blue-600 dark:text-blue-400">0x{cursorSlot.toString(16).toUpperCase().padStart(2, '0')}</span> ({getSlotCharacterName(cursorSlot, manifest)})
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setCursorSlot((c) => (c - 1 + layout.slotCount) % layout.slotCount)}
                className="rounded border border-slate-300 px-2.5 py-1 text-[11px] font-semibold hover:bg-slate-50 dark:border-slate-700 cursor-pointer"
              >
                ← Slot Anterior
              </button>
              <button
                type="button"
                onClick={() => setCursorSlot((c) => (c + 1) % layout.slotCount)}
                className="rounded border border-slate-300 px-2.5 py-1 text-[11px] font-semibold hover:bg-slate-50 dark:border-slate-700 cursor-pointer"
              >
                Slot Siguiente →
              </button>
            </div>
          </div>

          <PspControllerPad
            compact
            title="Controles PSP en Vivo (Batalla Libre + Mapas DLC + Menú Opciones)"
            onButtonPress={handlePspButtonPress}
            hints={{
              L: 'Pág-',
              R: 'Pág+',
              CROSS:
                previewScreen === 'MENU_OPTIONS'
                  ? 'Elegir Estilo'
                  : previewScreen === 'CHAR_SELECT'
                  ? `Asignar ${activeAssignTeam}`
                  : 'Fijar Mapa',
              SQUARE: 'Mapas/Chars',
              TRIANGLE: 'Aleatorio',
              SELECT: 'Turno J1-J4',
              HOME: 'Opciones Menú',
              START: 'Confirmar',
            }}
          />
        </div>

        {/* Right: Coordinates, Dimensions & Slot Colors */}
        <div className="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 space-y-4 text-xs">
          <h4 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
            <Sliders className="h-4 w-4 text-blue-600" />
            Parámetros HUD y Geometría del Menú (Exportado a PCK1)
          </h4>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">Título Superior</label>
              <input
                type="text"
                value={layout.titleText}
                onChange={(e) => onChangeLayout({ ...layout, titleText: e.target.value })}
                className="mt-1 min-h-[34px] w-full rounded border border-slate-300 bg-slate-50 px-2.5 text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">Slots de Roster</label>
              <select
                value={layout.slotCount}
                onChange={(e) =>
                  onChangeLayout({ ...layout, slotCount: Number(e.target.value) as 71 | 128 | 256 })
                }
                className="mt-1 min-h-[34px] w-full rounded border border-slate-300 bg-slate-50 px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              >
                <option value={71}>71 Slots (Base 0x00–0x46)</option>
                <option value={128}>128 Slots (Expansión Media)</option>
                <option value={256}>256 Slots (Full DLC 0x00–0xFF)</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">Forma de Casilla</label>
              <select
                value={layout.cellShape}
                onChange={(e) =>
                  onChangeLayout({ ...layout, cellShape: e.target.value as 'RECT' | 'HEX' })
                }
                className="mt-1 min-h-[34px] w-full rounded border border-slate-300 bg-slate-50 px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              >
                <option value="RECT">Rectangular Clásica</option>
                <option value="HEX">Hexagonal (256 Marco)</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">Columnas visibles</label>
              <input
                type="number"
                min={4}
                max={20}
                value={layout.cols}
                onChange={(e) => onChangeLayout({ ...layout, cols: Math.max(4, Math.min(20, Number(e.target.value) || 8)) })}
                className="mt-1 min-h-[34px] w-full rounded border border-slate-300 bg-slate-50 px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">Ancho Casilla (px)</label>
              <input
                type="number"
                min={16}
                max={64}
                value={layout.cellWidth}
                onChange={(e) =>
                  onChangeLayout({ ...layout, cellWidth: Math.max(16, Math.min(64, Number(e.target.value) || 28)) })
                }
                className="mt-1 min-h-[34px] w-full rounded border border-slate-300 bg-slate-50 px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">Alto Casilla (px)</label>
              <input
                type="number"
                min={16}
                max={54}
                value={layout.cellHeight}
                onChange={(e) =>
                  onChangeLayout({ ...layout, cellHeight: Math.max(16, Math.min(54, Number(e.target.value) || 28)) })
                }
                className="mt-1 min-h-[34px] w-full rounded border border-slate-300 bg-slate-50 px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">Posición Y Superior</label>
              <input
                type="number"
                min={0}
                max={200}
                value={layout.topBarY}
                onChange={(e) =>
                  onChangeLayout({ ...layout, topBarY: Math.max(0, Math.min(200, Number(e.target.value) || 28)) })
                }
                className="mt-1 min-h-[34px] w-full rounded border border-slate-300 bg-slate-50 px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">Posición Y Inferior</label>
              <input
                type="number"
                min={100}
                max={250}
                value={layout.bottomBarY}
                onChange={(e) =>
                  onChangeLayout({ ...layout, bottomBarY: Math.max(100, Math.min(250, Number(e.target.value) || 206)) })
                }
                className="mt-1 min-h-[34px] w-full rounded border border-slate-300 bg-slate-50 px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2 pt-1">
            <label className="flex flex-col items-center gap-1 rounded border border-slate-200 p-2 dark:border-slate-800">
              <span className="text-[10px] text-slate-500">Fondo Sup</span>
              <input
                type="color"
                value={layout.bgTopColor}
                onChange={(e) => onChangeLayout({ ...layout, bgTopColor: e.target.value })}
                className="h-6 w-full cursor-pointer"
              />
            </label>
            <label className="flex flex-col items-center gap-1 rounded border border-slate-200 p-2 dark:border-slate-800">
              <span className="text-[10px] text-slate-500">Fondo Inf</span>
              <input
                type="color"
                value={layout.bgBotColor}
                onChange={(e) => onChangeLayout({ ...layout, bgBotColor: e.target.value })}
                className="h-6 w-full cursor-pointer"
              />
            </label>
            <label className="flex flex-col items-center gap-1 rounded border border-slate-200 p-2 dark:border-slate-800">
              <span className="text-[10px] text-slate-500">Acento HUD</span>
              <input
                type="color"
                value={layout.accentColor}
                onChange={(e) => onChangeLayout({ ...layout, accentColor: e.target.value })}
                className="h-6 w-full cursor-pointer"
              />
            </label>
            <label className="flex flex-col items-center gap-1 rounded border border-slate-200 p-2 dark:border-slate-800">
              <span className="text-[10px] text-slate-500">Cursor</span>
              <input
                type="color"
                value={layout.cursorColor}
                onChange={(e) => onChangeLayout({ ...layout, cursorColor: e.target.value })}
                className="h-6 w-full cursor-pointer"
              />
            </label>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">Escenario Activo</label>
              <select
                value={layout.selectedMapId}
                onChange={(e) => onChangeLayout({ ...layout, selectedMapId: Number(e.target.value) })}
                className="mt-1 min-h-[34px] w-full rounded border border-slate-300 bg-slate-50 px-2 font-mono text-[11px] text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              >
                {[...DBZ_TAG_TEAM_BASE_MAPS, ...DBZ_TAG_TEAM_DLC_EXPANSION_MAPS].slice(0, 46).map((mapName, idx) => (
                  <option key={idx + 1} value={idx + 1}>
                    {String(idx + 1).padStart(2, '0')} · {mapName}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">Música AT3 Activa</label>
              <select
                value={layout.selectedMusicId}
                onChange={(e) => onChangeLayout({ ...layout, selectedMusicId: Number(e.target.value) })}
                className="mt-1 min-h-[34px] w-full rounded border border-slate-300 bg-slate-50 px-2 font-mono text-[11px] text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              >
                {musicSlots.slice(0, 32).map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.title}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Visual Gallery of Images (.GIM) packed into /PSP_GAME/USRDIR/PACKFILE.BIN */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3 dark:border-slate-800">
          <div>
            <h4 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
              <FileImage className="h-4 w-4 text-emerald-600" />
              Imágenes <span className="font-mono">MIG.00.1PSP (.GIM)</span> dentro de <span className="font-mono">PACKFILE.BIN</span> (Batalla Libre, Otros Modos y Mapas DLC)
            </h4>
            <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
              Cada slot del roster ({layout.slotCount}) y cada mapa DLC ({mapSlots.length || 46}) genera su textura <span className="font-mono">.GIM</span> real embebida en <span className="font-mono">/PSP_GAME/USRDIR/PACKFILE.BIN</span> para que aparezca con sus imágenes dentro de la ISO.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex rounded-lg border border-slate-200 p-0.5 text-xs dark:border-slate-700">
              <button
                type="button"
                onClick={() => {
                  setGalleryTab('ROSTER_IMAGES');
                  setGalleryPage(0);
                }}
                className={`rounded-md px-3 py-1 font-semibold cursor-pointer ${
                  galleryTab === 'ROSTER_IMAGES'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Roster {layout.slotCount} (Batalla Libre y Otros)
              </button>
              <button
                type="button"
                onClick={() => {
                  setGalleryTab('MAP_IMAGES');
                  setGalleryPage(0);
                }}
                className={`rounded-md px-3 py-1 font-semibold cursor-pointer ${
                  galleryTab === 'MAP_IMAGES'
                    ? 'bg-emerald-600 text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Seleccionador Mapas DLC ({mapSlots.length || 46})
              </button>
            </div>

            <button
              type="button"
              onClick={() => setGalleryPage((p) => Math.max(0, p - 1))}
              className="rounded border border-slate-300 px-2.5 py-1 text-xs font-semibold hover:bg-slate-50 dark:border-slate-700 cursor-pointer"
            >
              ◀ Pág-
            </button>
            <button
              type="button"
              onClick={() => setGalleryPage((p) => p + 1)}
              className="rounded border border-slate-300 px-2.5 py-1 text-xs font-semibold hover:bg-slate-50 dark:border-slate-700 cursor-pointer"
            >
              Pág+ ▶
            </button>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4 md:grid-cols-6">
          {galleryItems.map((item) => (
            <button
              key={`${galleryTab}-${item.id}`}
              type="button"
              onClick={() => {
                if (galleryTab === 'ROSTER_IMAGES') {
                  setCursorSlot(item.id);
                  setPreviewScreen('CHAR_SELECT');
                } else {
                  onChangeLayout({ ...layout, selectedMapId: item.id });
                  setPreviewScreen('MAP_SELECT');
                }
              }}
              className="flex flex-col gap-1.5 rounded-lg border border-slate-200 bg-slate-50 p-2 text-left transition-colors hover:border-blue-500 dark:border-slate-800 dark:bg-slate-950 cursor-pointer"
            >
              <div className="flex items-center gap-1.5">
                {item.imageUrl && (
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    className="h-12 w-12 rounded border border-slate-300 object-cover dark:border-slate-700"
                    style={{ imageRendering: 'pixelated' }}
                  />
                )}
                {item.minimapUrl && (
                  <img
                    src={item.minimapUrl}
                    alt={`Minimapa ${item.title}`}
                    className="h-12 w-12 rounded border border-emerald-500/60 object-cover"
                    style={{ imageRendering: 'pixelated' }}
                  />
                )}
              </div>
              <div className="truncate font-mono text-[11px] font-bold text-slate-900 dark:text-white" title={item.title}>
                {item.code} · {item.title}
              </div>
              <div className="truncate font-mono text-[9px] text-slate-500 dark:text-slate-400">
                {item.sub}
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Loaded PCK1 Inspector & Block Replacement Table */}
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-4 dark:border-slate-800">
          <div>
            <h4 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
              <Layers className="h-4 w-4 text-blue-600" />
              Contenido del Archivo <span className="font-mono">PCK1 / PACKFILE.BIN</span> ({loadedPckResult ? `${loadedPckResult.packName} · ${loadedPckResult.entries.length} entradas` : 'Sin cargar'})
            </h4>
            <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
              Inspecciona o reemplaza cualquier retrato <span className="font-mono">.GIM</span>, minimapa, mapa, roster o pista de Música <span className="font-mono">.AT3</span> dentro de <span className="font-mono">PACKFILE.BIN</span>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => addExtraAssetUploadRef.current?.click()}
              className="inline-flex min-h-[32px] items-center gap-1 rounded-lg border border-slate-300 bg-white px-2.5 text-[11px] font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
            >
              <Upload className="h-3 w-3" />
              Añadir Textura/Audio al PCK1 ({extraCustomEntries.length})
            </button>
            <button
              type="button"
              onClick={() => void handleBuildSuitePck('MASTER_PACKFILE_BIN')}
              className="inline-flex min-h-[32px] items-center gap-1 rounded-lg bg-emerald-700 px-3 text-[11px] font-semibold text-white hover:bg-emerald-800 cursor-pointer"
            >
              <RefreshCw className="h-3 w-3" />
              Compilar PACKFILE.BIN Completo
            </button>
          </div>
        </div>

        {entryImagePreview && (
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 bg-blue-50/70 px-4 py-3 text-xs dark:border-slate-800 dark:bg-blue-950/30">
            <div className="font-mono font-semibold text-slate-900 dark:text-white">
              Imagen decodificada de PACKFILE.BIN: {entryImagePreview.label}
            </div>
            <div className="flex items-center gap-3">
              <img
                src={entryImagePreview.url}
                alt={entryImagePreview.label}
                className="h-16 w-16 rounded border border-slate-300 bg-slate-950 dark:border-slate-700"
                style={{ imageRendering: 'pixelated' }}
              />
              <button
                type="button"
                onClick={() => setEntryImagePreview(null)}
                className="rounded border border-slate-300 px-2 py-1 text-[11px] font-semibold dark:border-slate-700 cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        )}

        {pckScanning && (
          <div className="p-4 text-xs text-blue-600 dark:text-blue-400">
            Analizando estructura PCK1 ({scanProgress}%)...
          </div>
        )}

        {loadedPckResult ? (
          <>
            <div className="flex flex-wrap gap-1.5 border-b border-slate-100 bg-slate-50/70 px-4 py-2.5 dark:border-slate-800 dark:bg-slate-950/60">
              {(['ALL', 'PERSONAJES', 'MAPAS', 'MINIMAPAS', 'IMAGENES', 'MUSICA_AT3', 'OTROS'] as const).map(
                (cat) => {
                  const count =
                    cat === 'ALL'
                      ? loadedPckResult.entries.length
                      : loadedPckResult.entries.filter((e) => e.category === cat).length;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setPckCategoryFilter(cat)}
                      className={`rounded px-2.5 py-1 text-[11px] font-medium cursor-pointer ${
                        pckCategoryFilter === cat
                          ? 'bg-slate-900 text-white dark:bg-blue-600'
                          : 'border border-slate-200 bg-white text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300'
                      }`}
                    >
                      {cat === 'ALL' ? 'Todos' : cat} ({count})
                    </button>
                  );
                }
              )}
            </div>

            <div className="max-h-72 overflow-auto">
              <table className="w-full border-collapse text-left text-xs">
                <thead className="sticky top-0 z-10 border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                  <tr>
                    <th className="px-3 py-2 font-semibold">#ID</th>
                    <th className="px-3 py-2 font-semibold">Vista</th>
                    <th className="px-3 py-2 font-semibold">Nombre / Archivo</th>
                    <th className="px-3 py-2 font-semibold">Categoría</th>
                    <th className="px-3 py-2 font-semibold">Firma</th>
                    <th className="px-3 py-2 font-semibold">Tamaño</th>
                    <th className="px-3 py-2 text-right font-semibold">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredPckEntries.slice(0, 120).map((entry: Pck1ExtractedEntry) => {
                    const rep = replacementMap[entry.id];
                    const thumbUrl = decodedThumbMap[entry.id];
                    return (
                      <tr key={entry.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                        <td className="px-3 py-2 font-mono text-[11px] text-slate-500">
                          {String(entry.id).padStart(4, '0')}
                        </td>
                        <td className="px-3 py-1.5">
                          {thumbUrl ? (
                            <img
                              src={thumbUrl}
                              alt={entry.name}
                              className="h-7 w-7 rounded border border-slate-300 bg-slate-950 dark:border-slate-700"
                              style={{ imageRendering: 'pixelated' }}
                            />
                          ) : (
                            <span className="font-mono text-[10px] text-slate-400">—</span>
                          )}
                        </td>
                        <td className="px-3 py-2 font-mono text-[11px] font-semibold text-slate-900 dark:text-white">
                          {rep ? `${rep.name} (Reemplazado)` : entry.name}
                        </td>
                        <td className="px-3 py-2 text-[11px]">
                          <span className="inline-flex items-center gap-1 font-medium text-blue-700 dark:text-blue-300">
                            {entry.category === 'MUSICA_AT3' && <FileAudio className="h-3 w-3" />}
                            {entry.categoryLabel}
                          </span>
                        </td>
                        <td className="px-3 py-2 font-mono text-[11px] text-slate-600 dark:text-slate-300">
                          {entry.signature}
                        </td>
                        <td className="px-3 py-2 font-mono text-[11px] tabular-nums">
                          {(rep ? rep.data.length : entry.uncompressedSize).toLocaleString('es-ES')} B
                        </td>
                        <td className="px-3 py-2 text-right whitespace-nowrap space-x-1.5">
                          {loadedPckBlob && (entry.category === 'IMAGENES' || entry.category === 'MINIMAPAS') && (
                            <button
                              type="button"
                              onClick={async () => {
                                const data = rep
                                  ? rep.data
                                  : await extractPck1EntryData(loadedPckBlob, entry);
                                const url = renderPspImageBytesToDataUrl(data);
                                if (url) setEntryImagePreview({ label: entry.name, url });
                              }}
                              className="rounded border border-emerald-500 px-2 py-0.5 text-[11px] font-medium text-emerald-700 hover:bg-emerald-50 dark:text-emerald-300 cursor-pointer"
                            >
                              Ver Img
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              setPendingReplaceId(entry.id);
                              replaceEntryUploadRef.current?.click();
                            }}
                            className="rounded border border-slate-300 px-2 py-0.5 text-[11px] font-medium hover:bg-slate-100 dark:border-slate-700 cursor-pointer"
                          >
                            Reemplazar
                          </button>
                          {loadedPckBlob && onInspectAssetBytes && (
                            <button
                              type="button"
                              onClick={async () => {
                                const data = rep
                                  ? rep.data
                                  : await extractPck1EntryData(loadedPckBlob, entry);
                                onInspectAssetBytes(data, rep ? rep.name : entry.name);
                              }}
                              className="rounded bg-slate-900 px-2 py-0.5 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
                            >
                              HxD
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        ) : (
          <div className="p-6 text-center text-xs text-slate-500 dark:text-slate-400">
            Haz clic en <strong>"Cargar Archivo .PCK / PCK1"</strong> o en <strong>"Inyectar PACKFILE.BIN en ISO"</strong> para generar y ver las imágenes de Roster (Batalla Libre + Otros) y Mapas DLC dentro de <span className="font-mono">PACKFILE.BIN</span>.
          </div>
        )}
      </section>
    </div>
  );
};
