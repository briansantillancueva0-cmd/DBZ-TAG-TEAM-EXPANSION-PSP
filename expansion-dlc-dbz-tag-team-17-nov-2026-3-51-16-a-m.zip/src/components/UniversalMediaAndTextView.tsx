import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Archive,
  Binary,
  Box,
  CheckCircle2,
  Cpu,
  Download,
  EyeOff,
  FileCode2,
  FileText,
  Film,
  FolderInput,
  Image as ImageIcon,
  Layers,
  LockOpen,
  Music,
  Search,
  Sparkles,
  Type,
  Upload,
} from 'lucide-react';
import type { TextEncodingMode } from '../lib/codeTable';
import { readDroppedItemsWithFolders } from '../lib/isoPacker';
import {
  analyzeTextFromBlob,
  exportTextAnalysis,
  isLegibleTextEntry,
  type TextAnalysisSummary,
  type TextStringCategory,
} from '../lib/textAnalyzer';
import {
  classifyUniversalBlob,
  decryptDatLegibleTextBlocksForHxd,
  decryptOrUnpackBlob,
  decompressEmbeddedStreamAt,
  exportLegibleHxdBlocksZip,
  extractAllDatContents,
  extractAwbTrackBlob,
  extractAwbTracksToZip,
  generateBandaiNamcoQuickBmsScript,
  scanUniversalItems,
  UNIVERSAL_CATEGORY_META,
  unpackDatSubfilesToZip,
  type AwbTrackEntry,
  type DatSignatureHit,
  type FullDatExtractionSummary,
  type LegibleHxdExtractionResult,
  type LegibleTextBlockForHxd,
  type TranslationRole,
  type UniversalClassifiedItem,
  type UniversalDecryptResult,
  type UniversalMediaCategory,
  type UniversalSourceItem,
} from '../lib/universalInspector';
import { OreimoPatchPanel } from './OreimoPatchPanel';
import { QuickBmsPanel } from './QuickBmsPanel';
import type { EbootAnalysis } from '../lib/types';

export type UniversalSubTab =
  | 'identifier'
  | 'decryptor'
  | 'text_analyzer'
  | 'quickbms'
  | 'oreimo_patch';

interface UniversalMediaAndTextViewProps {
  analysis: EbootAnalysis | null;
  isoFileBlob: Blob | null;
  initialSubTab?: UniversalSubTab;
  onInspectAssetBytes?: (
    bytes: Uint8Array,
    assetPath: string,
    preferredEncoding?: TextEncodingMode,
    preferredOffset?: number
  ) => void;
  onJumpToHex?: (offset: number) => void;
  onSendPatchedToIsoPacker?: (files: Array<{ file: File; relativePath: string }>) => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes.toLocaleString('es-ES')} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

function hex(val: number, width = 8): string {
  return `0x${(val >>> 0).toString(16).toUpperCase().padStart(width, '0')}`;
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

const CATEGORY_ICON: Record<UniversalMediaCategory, React.ReactNode> = {
  VIDEO: <Film className="h-4 w-4 text-blue-600 dark:text-blue-400" />,
  TEXT: <FileText className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />,
  AUDIO: <Music className="h-4 w-4 text-violet-600 dark:text-violet-400" />,
  IMAGE: <ImageIcon className="h-4 w-4 text-amber-600 dark:text-amber-400" />,
  MODEL3D: <Box className="h-4 w-4 text-cyan-600 dark:text-cyan-400" />,
  EXECUTABLE_CONTAINER: <Cpu className="h-4 w-4 text-slate-600 dark:text-slate-300" />,
};

const TEXT_CATEGORY_LABEL: Record<TextStringCategory, string> = {
  DIALOGUE: 'Diálogos / Narrativa',
  UI_MENU: 'UI / Menús',
  SAVE_ITEM_ERROR: 'Objetos / Guardado / Error',
  PSP_PATH: 'Rutas PSP',
  SYSTEM_DEBUG: 'Sistema / PRX',
};

const PRIMARY_ENCODING_LABEL: Record<TextAnalysisSummary['detectedPrimaryEncoding'], string> = {
  shift_jis: 'Shift-JIS (Japonés PSP)',
  'utf-8': 'UTF-8 / ASCII',
  'utf-16le': 'UTF-16LE',
  mixed: 'Mixto (Shift-JIS + UTF-8)',
};

export const UniversalMediaAndTextView: React.FC<UniversalMediaAndTextViewProps> = ({
  analysis,
  isoFileBlob,
  initialSubTab = 'identifier',
  onInspectAssetBytes,
  onJumpToHex,
  onSendPatchedToIsoPacker,
}) => {
  const [subTab, setSubTab] = useState<UniversalSubTab>(initialSubTab);

  // --- Universal Identifier State ---
  const [classifiedItems, setClassifiedItems] = useState<UniversalClassifiedItem[]>([]);
  const [scanningItems, setScanningItems] = useState(false);
  const [scanProgress, setScanProgress] = useState<{ done: number; total: number } | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<UniversalMediaCategory | 'ALL'>('ALL');
  const [roleFilter, setRoleFilter] = useState<TranslationRole | 'ALL'>('ALL');
  const [hideIgnoreNoText, setHideIgnoreNoText] = useState(false);
  const [identifierQuery, setIdentifierQuery] = useState('');
  const [dropActive, setDropActive] = useState(false);
  const [sourceBanner, setSourceBanner] = useState<string | null>(null);

  // --- Decryptor State ---
  const [selectedItem, setSelectedItem] = useState<UniversalClassifiedItem | null>(null);
  const [decrypting, setDecrypting] = useState(false);
  const [decryptError, setDecryptError] = useState<string | null>(null);
  const [decryptResult, setDecryptResult] = useState<UniversalDecryptResult | null>(null);
  const [datScanLimitMb, setDatScanLimitMb] = useState<number>(9999);
  const [awbTrackQuery, setAwbTrackQuery] = useState('');
  const [zippingAwb, setZippingAwb] = useState(false);
  const [awbZipProgress, setAwbZipProgress] = useState<{ done: number; total: number } | null>(null);
  const [zippingDat, setZippingDat] = useState(false);
  const [datZipProgress, setDatZipProgress] = useState<{ done: number; total: number } | null>(null);
  const [fullExtracting, setFullExtracting] = useState(false);
  const [fullExtractProgress, setFullExtractProgress] = useState<{
    phase: string;
    done: number;
    total: number;
  } | null>(null);
  const [fullExtractSummary, setFullExtractSummary] = useState<FullDatExtractionSummary | null>(null);
  const [fullExtractError, setFullExtractError] = useState<string | null>(null);
  const [decompressedHitMap, setDecompressedHitMap] = useState<
    Record<number, { bytes: Uint8Array; innerFormat: string; suggestedExt: string }>
  >({});
  const [decompressingOffset, setDecompressingOffset] = useState<number | null>(null);
  const [legibleHxdExtracting, setLegibleHxdExtracting] = useState(false);
  const [legibleHxdProgress, setLegibleHxdProgress] = useState<{
    phase: string;
    done: number;
    total: number;
  } | null>(null);
  const [legibleHxdResults, setLegibleHxdResults] = useState<LegibleHxdExtractionResult[]>([]);
  const [legibleHxdError, setLegibleHxdError] = useState<string | null>(null);
  const [legibleHxdQuery, setLegibleHxdQuery] = useState('');
  const [zippingLegibleIdx, setZippingLegibleIdx] = useState<number | null>(null);

  // --- Universal Text Analyzer State ---
  const [textTargetName, setTextTargetName] = useState<string | null>(null);
  const [textTargetBlob, setTextTargetBlob] = useState<Blob | null>(null);
  const [textEncoding, setTextEncoding] = useState<TextEncodingMode | 'AUTO_MULTI'>('AUTO_MULTI');
  const [textMinLen, setTextMinLen] = useState<number>(4);
  const [textMaxMb, setTextMaxMb] = useState<number>(16);
  const [includeCompressedBlocks, setIncludeCompressedBlocks] = useState<boolean>(true);
  const [onlyLegibleText, setOnlyLegibleText] = useState<boolean>(false);
  const [textCategoryFilter, setTextCategoryFilter] = useState<TextStringCategory | 'ALL'>('ALL');
  const [textSearchQuery, setTextSearchQuery] = useState('');
  const [analyzingText, setAnalyzingText] = useState(false);
  const [textScanProgress, setTextScanProgress] = useState<{ scanned: number; total: number } | null>(null);
  const [textSummary, setTextSummary] = useState<TextAnalysisSummary | null>(null);
  const [textError, setTextError] = useState<string | null>(null);

  // --- QuickBMS Panel Target State ---
  const [quickBmsTarget, setQuickBmsTarget] = useState<{
    blob: Blob;
    fileName: string;
    path?: string;
  } | null>(null);

  const folderInputRef = useRef<HTMLInputElement | null>(null);
  const filesInputRef = useRef<HTMLInputElement | null>(null);
  const decryptSingleInputRef = useRef<HTMLInputElement | null>(null);
  const datBatchInputRef = useRef<HTMLInputElement | null>(null);
  const legibleHxdInputRef = useRef<HTMLInputElement | null>(null);
  const textSingleInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setSubTab(initialSubTab);
  }, [initialSubTab]);

  // Revoke any image preview blob URL when decryptResult changes
  useEffect(() => {
    const url = decryptResult?.imageInfo?.previewUrl;
    return () => {
      if (url && url.startsWith('blob:')) {
        URL.revokeObjectURL(url);
      }
    };
  }, [decryptResult]);

  // Auto-populate identifier from loaded ISO when entering if empty
  useEffect(() => {
    if (analysis?.isoInfo && isoFileBlob && classifiedItems.length === 0) {
      void handleImportFromLoadedIso();
    }
  }, [analysis?.isoInfo, isoFileBlob]); // eslint-disable-line react-hooks/exhaustive-deps

  const runClassification = async (items: UniversalSourceItem[], banner: string) => {
    if (items.length === 0) return;
    setScanningItems(true);
    setScanProgress({ done: 0, total: items.length });
    try {
      const classified = await scanUniversalItems(items, (done, total) =>
        setScanProgress({ done, total })
      );
      setClassifiedItems(classified);
      setSourceBanner(banner);
    } finally {
      setScanningItems(false);
      setScanProgress(null);
    }
  };

  const handleImportFromLoadedIso = async () => {
    if (!analysis?.isoInfo || !isoFileBlob) return;
    const sources: UniversalSourceItem[] = analysis.isoInfo.files
      .filter((f) => !f.isDirectory)
      .map((f, idx) => ({
        id: `iso-${idx}-${f.path}`,
        name: f.name,
        path: f.path,
        size: f.size,
        origin: 'ISO',
        blob: isoFileBlob.slice(f.byteOffset, f.byteOffset + f.size),
      }));
    await runClassification(
      sources,
      `ISO cargada: ${analysis.sourceName} (${sources.length} archivos clasificados por magic bytes)`
    );
  };

  const handleFolderUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (!list || list.length === 0) return;
    const sources: UniversalSourceItem[] = Array.from(list).map((file, idx) => ({
      id: `fld-${idx}-${file.webkitRelativePath || file.name}`,
      name: file.name,
      path: `/${(file.webkitRelativePath || file.name).replace(/^\/+/, '')}`,
      size: file.size,
      origin: 'FOLDER',
      blob: file,
    }));
    await runClassification(
      sources,
      `Carpeta local cargada (${sources.length} archivos analizados sin saturar RAM)`
    );
    e.target.value = '';
  };

  const handleFilesUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (!list || list.length === 0) return;
    const sources: UniversalSourceItem[] = Array.from(list).map((file, idx) => ({
      id: `file-${idx}-${file.name}-${Date.now()}`,
      name: file.name,
      path: `/${file.name}`,
      size: file.size,
      origin: 'FILE',
      blob: file,
    }));
    await runClassification(sources, `${sources.length} archivos cargados manualmente`);
    e.target.value = '';
  };

  const handleDropToIdentifier = async (e: React.DragEvent<HTMLElement>) => {
    e.preventDefault();
    setDropActive(false);
    const items = await readDroppedItemsWithFolders(e.dataTransfer);
    if (items.length === 0) return;
    const sources: UniversalSourceItem[] = items.map((it, idx) => ({
      id: `drop-${idx}-${it.relativePath}`,
      name: it.file.name,
      path: `/${it.relativePath.replace(/^\/+/, '')}`,
      size: it.file.size,
      origin: it.relativePath.includes('/') ? 'FOLDER' : 'FILE',
      blob: it.file,
    }));
    await runClassification(
      sources,
      `Carpeta / archivos soltados (${sources.length} elementos identificados)`
    );
  };

  const openBlobInHxd = async (
    blob: Blob,
    path: string,
    preferredEncoding: TextEncodingMode = 'shift_jis',
    preferredOffset?: number
  ) => {
    if (!onInspectAssetBytes) return;
    const limit = Math.min(blob.size, 16 * 1024 * 1024);
    const buf = new Uint8Array(await blob.slice(0, limit).arrayBuffer());
    onInspectAssetBytes(buf, path, preferredEncoding, preferredOffset);
  };

  // --- Decryptor Trigger ---
  const openInDecryptor = async (
    item: UniversalClassifiedItem,
    overrideMaxDatMb?: number
  ) => {
    setSelectedItem(item);
    setSubTab('decryptor');
    setDecrypting(true);
    setDecryptError(null);
    setDecompressedHitMap({});
    setAwbTrackQuery('');
    try {
      const limitBytes =
        (overrideMaxDatMb ?? datScanLimitMb) >= 9999
          ? item.size
          : (overrideMaxDatMb ?? datScanLimitMb) * 1024 * 1024;
      const res = await decryptOrUnpackBlob(item, limitBytes);
      setDecryptResult(res);
    } catch (err) {
      setDecryptError(
        err instanceof Error ? err.message : 'Error al desencriptar / inspeccionar el archivo.'
      );
      setDecryptResult(null);
    } finally {
      setDecrypting(false);
    }
  };

  const openInQuickBms = (blob: Blob, fileName: string, path?: string) => {
    setQuickBmsTarget({ blob, fileName, path });
    setSubTab('quickbms');
  };

  const handleOpenFromQuickBmsInDecryptor = async (
    blob: Blob,
    fileName: string,
    path?: string
  ) => {
    const classified = await classifyUniversalBlob({
      id: `qbms-${Date.now()}`,
      name: fileName,
      path: path || `/${fileName}`,
      size: blob.size,
      origin: 'FILE',
      blob,
    });
    await openInDecryptor(classified);
  };

  const handleUploadForDecryptor = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const classified = await classifyUniversalBlob({
      id: `single-${Date.now()}`,
      name: file.name,
      path: `/${file.name}`,
      size: file.size,
      origin: 'FILE',
      blob: file,
    });
    e.target.value = '';
    await openInDecryptor(classified);
  };

  const handleDecompressDatHit = async (hit: DatSignatureHit) => {
    if (!selectedItem || !hit.canDecompress) return;
    setDecompressingOffset(hit.offset);
    setDecryptError(null);
    try {
      const res = await decompressEmbeddedStreamAt(
        selectedItem.blob,
        hit.offset,
        hit.canDecompress
      );
      setDecompressedHitMap((prev) => ({
        ...prev,
        [hit.offset]: res,
      }));
    } catch (err) {
      setDecryptError(
        `No se pudo descomprimir bloque en ${hex(hit.offset)}: ${
          err instanceof Error ? err.message : 'flujo incompleto o clave custom.'
        }`
      );
    } finally {
      setDecompressingOffset(null);
    }
  };

  const handleExportAwbZip = async (tracks: AwbTrackEntry[], fileName: string) => {
    if (!selectedItem) return;
    setZippingAwb(true);
    setAwbZipProgress({ done: 0, total: Math.min(tracks.length, 500) });
    try {
      const zipBlob = await extractAwbTracksToZip(
        selectedItem.blob,
        fileName,
        tracks,
        500,
        (done, total) => setAwbZipProgress({ done, total })
      );
      const base = fileName.replace(/\.awb$/i, '');
      downloadBlob(zipBlob, `${base}_PISTAS_AFS2.zip`);
    } finally {
      setZippingAwb(false);
      setAwbZipProgress(null);
    }
  };

  const handleExportDatZip = async (hits: DatSignatureHit[], fileName: string) => {
    if (!selectedItem) return;
    setZippingDat(true);
    setDatZipProgress({ done: 0, total: hits.length });
    try {
      const zipBlob = await unpackDatSubfilesToZip(
        selectedItem.blob,
        fileName,
        hits,
        100000,
        (done, t) => setDatZipProgress({ done, total: t })
      );
      const base = fileName.replace(/\.[^.]+$/, '');
      downloadBlob(zipBlob, `${base}_SUBARCHIVOS_DAT.zip`);
    } finally {
      setZippingDat(false);
      setDatZipProgress(null);
    }
  };

  const runFullDatExtraction = async (
    targets: Array<{ blob: Blob; fileName: string }>,
    mode: 'zip' | 'directory'
  ) => {
    if (targets.length === 0) return;
    setFullExtracting(true);
    setFullExtractError(null);
    setFullExtractSummary(null);
    setFullExtractProgress({ phase: 'Iniciando escaneo completo 100%…', done: 0, total: 1 });

    try {
      let dirHandle: unknown = undefined;
      if (mode === 'directory') {
        const picker = (
          window as unknown as {
            showDirectoryPicker?: (opts?: { mode?: 'readwrite' }) => Promise<unknown>;
          }
        ).showDirectoryPicker;
        if (!picker) {
          throw new Error(
            'Tu navegador o vista previa embebida no permite elegir carpetas locales directamente; usa el botón "Extraer TODO (.ZIP Completo)".'
          );
        }
        dirHandle = await picker({ mode: 'readwrite' });
      }

      const summary = await extractAllDatContents(targets, {
        targetDirHandle: dirHandle,
        includeRawContainerSlices: true,
        onProgress: (phase, done, total) => setFullExtractProgress({ phase, done, total }),
      });

      setFullExtractSummary(summary);
      if (summary.zipBlob) {
        const prefix =
          targets.length === 1
            ? targets[0].fileName.replace(/\.[^.]+$/, '')
            : 'FIRST_Y_RES_DAT_EXTRAIDO';
        downloadBlob(summary.zipBlob, `${prefix}_TODO_DESENCRIPTADO.zip`);
      }
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        setFullExtractError('Selección de carpeta cancelada.');
      } else {
        setFullExtractError(
          err instanceof Error
            ? err.message
            : 'No se pudo completar la extracción total del .DAT.'
        );
      }
    } finally {
      setFullExtracting(false);
      setFullExtractProgress(null);
    }
  };

  const handleDatBatchUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const list = Array.from(files);
    e.target.value = '';

    // Also populate classifiedItems or open first item in decryptor if single
    const targets = list.map((f) => ({ blob: f, fileName: f.name }));
    if (list.length >= 1) {
      const firstClassified = await classifyUniversalBlob({
        id: `dat-${Date.now()}`,
        name: list[0].name,
        path: `/${list[0].name}`,
        size: list[0].size,
        origin: 'FILE',
        blob: list[0],
      });
      setSelectedItem(firstClassified);
      setSubTab('decryptor');
      const res = await decryptOrUnpackBlob(firstClassified, firstClassified.size);
      setDecryptResult(res);
    }
    await runFullDatExtraction(targets, 'zip');
  };

  const runLegibleHxdDecryption = async (
    targets: Array<{ blob: Blob; fileName: string }>
  ) => {
    if (targets.length === 0) return;
    setSubTab('decryptor');
    setLegibleHxdExtracting(true);
    setLegibleHxdError(null);
    setLegibleHxdResults([]);
    setLegibleHxdQuery('');
    setLegibleHxdProgress({
      phase: `Iniciando desencriptado de textos legibles (${targets.map((t) => t.fileName).join(', ')})…`,
      done: 0,
      total: 1,
    });

    try {
      const collected: LegibleHxdExtractionResult[] = [];
      for (const target of targets) {
        const res = await decryptDatLegibleTextBlocksForHxd(
          target.blob,
          target.fileName,
          (phase, done, total) => {
            setLegibleHxdProgress({
              phase: `${target.fileName}: ${phase}`,
              done,
              total,
            });
          }
        );
        collected.push(res);
      }
      setLegibleHxdResults(collected);
    } catch (err) {
      setLegibleHxdError(
        err instanceof Error
          ? err.message
          : 'Error al desencriptar textos legibles para HxD.'
      );
    } finally {
      setLegibleHxdExtracting(false);
      setLegibleHxdProgress(null);
    }
  };

  const handleLegibleHxdFilesUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const targets = Array.from(files).map((f) => ({ blob: f, fileName: f.name }));
    e.target.value = '';
    await runLegibleHxdDecryption(targets);
  };

  const handleDownloadLegibleZip = async (res: LegibleHxdExtractionResult, idx: number) => {
    setZippingLegibleIdx(idx);
    try {
      const zipBlob = await exportLegibleHxdBlocksZip(res);
      const base = res.fileName.replace(/\.[^.]+$/, '');
      downloadBlob(zipBlob, `${base}_TEXTOS_LEGIBLES_HXD.zip`);
    } finally {
      setZippingLegibleIdx(null);
    }
  };

  // --- Text Analyzer Trigger ---
  const runTextAnalyzerOnBlob = async (
    blob: Blob,
    fileName: string,
    overrideEncoding?: TextEncodingMode | 'AUTO_MULTI',
    overrideMinLen?: number,
    overrideMaxMb?: number,
    overrideIncludeCompressed?: boolean
  ) => {
    setTextTargetBlob(blob);
    setTextTargetName(fileName);
    setSubTab('text_analyzer');
    setAnalyzingText(true);
    setTextError(null);
    setTextScanProgress({ scanned: 0, total: blob.size });

    try {
      const mb = overrideMaxMb ?? textMaxMb;
      const maxBytes = mb >= 9999 ? blob.size : mb * 1024 * 1024;
      const summary = await analyzeTextFromBlob(blob, fileName, {
        encoding: overrideEncoding ?? textEncoding,
        minLength: overrideMinLen ?? textMinLen,
        maxScanBytes: maxBytes,
        includeCompressedBlocks: overrideIncludeCompressed ?? includeCompressedBlocks,
        onProgress: (scanned, total) => setTextScanProgress({ scanned, total }),
      });
      setTextSummary(summary);
    } catch (err) {
      setTextError(
        err instanceof Error ? err.message : 'Error al analizar cadenas de texto.'
      );
    } finally {
      setAnalyzingText(false);
      setTextScanProgress(null);
    }
  };

  const handleUploadForTextAnalyzer = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';
    void runTextAnalyzerOnBlob(file, file.name);
  };

  // Computed counts for Identifier cards
  const categoryCounts = useMemo(() => {
    const counts: Record<UniversalMediaCategory, number> = {
      VIDEO: 0,
      TEXT: 0,
      AUDIO: 0,
      IMAGE: 0,
      MODEL3D: 0,
      EXECUTABLE_CONTAINER: 0,
    };
    for (const it of classifiedItems) {
      counts[it.category]++;
    }
    return counts;
  }, [classifiedItems]);

  const roleGroups = useMemo(() => {
    const primaryTargets = classifiedItems.filter((it) => it.translationRole === 'PRIMARY_TEXT');
    const fontTargets = classifiedItems.filter((it) => it.translationRole === 'FONT_TYPOGRAPHY');
    const ignoreTargets = classifiedItems.filter((it) => it.translationRole === 'IGNORE_NO_TEXT');
    const pgfItem = fontTargets.find((it) => it.name.toUpperCase().endsWith('.PGF')) ?? null;
    const datExtractTargets = classifiedItems.filter((it) => {
      const u = it.name.toUpperCase();
      return (
        u === 'FIRST.DAT' ||
        u === 'RES.DAT' ||
        u === 'DATA.BIN' ||
        (u.endsWith('.DAT') && u !== 'DUMMY.DAT')
      );
    });
    return { primaryTargets, fontTargets, ignoreTargets, pgfItem, datExtractTargets };
  }, [classifiedItems]);

  const filteredClassified = useMemo(() => {
    const q = identifierQuery.trim().toLowerCase();
    return classifiedItems.filter((it) => {
      if (hideIgnoreNoText && it.translationRole === 'IGNORE_NO_TEXT') return false;
      if (roleFilter !== 'ALL' && it.translationRole !== roleFilter) return false;
      if (categoryFilter !== 'ALL' && it.category !== categoryFilter) return false;
      if (!q) return true;
      return (
        it.path.toLowerCase().includes(q) ||
        it.formatCode.toLowerCase().includes(q) ||
        it.formatLabel.toLowerCase().includes(q) ||
        it.translationRoleLabel.toLowerCase().includes(q)
      );
    });
  }, [classifiedItems, categoryFilter, roleFilter, hideIgnoreNoText, identifierQuery]);

  const filteredAwbTracks = useMemo(() => {
    if (!decryptResult?.awbTracks) return [];
    const q = awbTrackQuery.trim().toLowerCase();
    if (!q) return decryptResult.awbTracks;
    return decryptResult.awbTracks.filter(
      (t) =>
        String(t.cueId).includes(q) ||
        String(t.index).includes(q) ||
        t.codecLabel.toLowerCase().includes(q) ||
        t.codecExt.toLowerCase().includes(q)
    );
  }, [decryptResult?.awbTracks, awbTrackQuery]);

  const filteredTextEntries = useMemo(() => {
    if (!textSummary) return [];
    const q = textSearchQuery.trim().toLowerCase();
    return textSummary.entries.filter((e) => {
      if (onlyLegibleText && !isLegibleTextEntry(e)) return false;
      if (textCategoryFilter !== 'ALL' && e.category !== textCategoryFilter) return false;
      if (!q) return true;
      return (
        e.text.toLowerCase().includes(q) ||
        hex(e.offset).toLowerCase().includes(q) ||
        e.sourceBlock.toLowerCase().includes(q)
      );
    });
  }, [textSummary, textCategoryFilter, textSearchQuery, onlyLegibleText]);

  return (
    <div className="space-y-6">
      {/* Hidden inputs */}
      <input
        ref={folderInputRef}
        type="file"
        multiple
        onChange={(e) => void handleFolderUpload(e)}
        className="hidden"
        {...({ webkitdirectory: '', directory: '' } as Record<string, string>)}
      />
      <input
        ref={filesInputRef}
        type="file"
        multiple
        onChange={(e) => void handleFilesUpload(e)}
        className="hidden"
      />
      <input
        ref={decryptSingleInputRef}
        type="file"
        onChange={(e) => void handleUploadForDecryptor(e)}
        className="hidden"
      />
      <input
        ref={datBatchInputRef}
        type="file"
        multiple
        accept=".dat,.bin,.pres,*/*"
        onChange={(e) => void handleDatBatchUpload(e)}
        className="hidden"
      />
      <input
        ref={legibleHxdInputRef}
        type="file"
        multiple
        accept=".dat,.bin,.pres,*/*"
        onChange={(e) => void handleLegibleHxdFilesUpload(e)}
        className="hidden"
      />
      <input
        ref={textSingleInputRef}
        type="file"
        onChange={handleUploadForTextAnalyzer}
        className="hidden"
      />

      {/* Workspace Header & Sub-Tab Switcher */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="max-w-2xl">
            <h1 className="text-lg font-semibold text-slate-900 dark:text-white">
              Identificador Multimedia, Desencriptador .DAT/.BIN y Analizador de Textos
            </h1>
            <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
              Identifica objetivos de texto (<span className="font-mono">RES.DAT</span>, <span className="font-mono">first.dat</span>, <span className="font-mono">DATA.BIN</span>, <span className="font-mono">EBOOT.BIN/BOOT.BIN</span>), audita tipografías (<span className="font-mono">font.pgf</span> / <span className="font-mono">libfont.prx</span>), separa recursos sin texto (<span className="font-mono">.awb</span>, <span className="font-mono">.pmf</span>, <span className="font-mono">.png</span>, <span className="font-mono">DUMMY.DAT</span>) y abre cualquier binario en HxD con <span className="font-semibold">Shift-JIS / UTF-8</span>.
            </p>
          </div>

          <div className="inline-flex flex-wrap items-center rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
            <button
              type="button"
              onClick={() => setSubTab('identifier')}
              className={`min-h-[38px] rounded-md px-3 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                subTab === 'identifier'
                  ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
              }`}
            >
              1. Identificador ({classifiedItems.length})
            </button>
            <button
              type="button"
              onClick={() => setSubTab('decryptor')}
              className={`min-h-[38px] rounded-md px-3 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                subTab === 'decryptor'
                  ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
              }`}
            >
              2. Desencriptador / .DAT
            </button>
            <button
              type="button"
              onClick={() => setSubTab('text_analyzer')}
              className={`min-h-[38px] rounded-md px-3 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                subTab === 'text_analyzer'
                  ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
              }`}
            >
              3. Analizador de Textos
            </button>
            <button
              type="button"
              onClick={() => setSubTab('quickbms')}
              className={`min-h-[38px] rounded-md px-3 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                subTab === 'quickbms'
                  ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
              }`}
            >
              4. Generador QuickBMS (.bms)
            </button>
            <button
              type="button"
              onClick={() => setSubTab('oreimo_patch')}
              className={`min-h-[38px] rounded-md px-3 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                subTab === 'oreimo_patch'
                  ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
              }`}
            >
              5. Parche Traducción (Oreimo)
            </button>
          </div>
        </div>
      </section>

      {/* ==================== TAB 1: UNIVERSAL IDENTIFIER ==================== */}
      {subTab === 'identifier' && (
        <div className="space-y-6">
          <section
            onDragOver={(e) => {
              e.preventDefault();
              setDropActive(true);
            }}
            onDragLeave={() => setDropActive(false)}
            onDrop={(e) => void handleDropToIdentifier(e)}
            className={`rounded-xl border-2 border-dashed p-5 transition-colors ${
              dropActive
                ? 'border-blue-600 bg-blue-50/60 dark:border-blue-500 dark:bg-blue-950/20'
                : 'border-slate-300 bg-white dark:border-slate-800 dark:bg-slate-900'
            }`}
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
                  Cargar Carpeta del Juego PSP, ISO o Archivos para Identificar
                </h2>
                <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  Lectura streaming de 4 KB por cabecera: soporta carpetas de 1.3 GB+ con <span className="font-mono">voice.awb</span> (837 MB) o <span className="font-mono">RES.DAT</span> (201 MB) al instante.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => folderInputRef.current?.click()}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <FolderInput className="h-4 w-4" />
                  Cargar Carpeta del Juego
                </button>
                <button
                  type="button"
                  onClick={() => filesInputRef.current?.click()}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Upload className="h-3.5 w-3.5" />
                  Cargar Archivos
                </button>
                {analysis?.isoInfo && isoFileBlob && (
                  <button
                    type="button"
                    onClick={() => void handleImportFromLoadedIso()}
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Layers className="h-3.5 w-3.5" />
                    Escanear ISO Cargada
                  </button>
                )}
              </div>
            </div>

            {scanningItems && scanProgress && (
              <div className="mt-3 text-xs text-blue-700 dark:text-blue-300 font-mono tabular-nums">
                Identificando cabeceras: {scanProgress.done} / {scanProgress.total} archivos...
              </div>
            )}

            {sourceBanner && (
              <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-700 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300">
                {sourceBanner}
              </div>
            )}
          </section>

          {/* Direct 1-Click Extractor for first.dat & RES.DAT */}
          <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
                  Desencriptar y Extraer TODO: <span className="font-mono">first.dat</span> + <span className="font-mono">RES.DAT</span>
                </h2>
                <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  Escanea al 100% las tablas <span className="font-mono">PRES TOC</span> y flujos <span className="font-mono">BLZ4 / BLZ2 / ZLIB / GZIP</span>, descomprime subarchivos recursivamente y extrae todos los datos + textos <span className="font-mono">Shift-JIS / UTF-8</span>.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {roleGroups.datExtractTargets.length > 0 ? (
                  <>
                    <button
                      type="button"
                      disabled={legibleHxdExtracting || fullExtracting}
                      onClick={() =>
                        void runLegibleHxdDecryption(
                          roleGroups.datExtractTargets.map((t) => ({ blob: t.blob, fileName: t.name }))
                        )
                      }
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Binary className="h-4 w-4" />
                      {legibleHxdExtracting
                        ? 'Descifrando textos…'
                        : 'Desencriptar Textos Legibles para HxD'}
                    </button>
                    <button
                      type="button"
                      disabled={fullExtracting}
                      onClick={() =>
                        void runFullDatExtraction(
                          roleGroups.datExtractTargets.map((t) => ({ blob: t.blob, fileName: t.name })),
                          'zip'
                        )
                      }
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-800 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Archive className="h-4 w-4" />
                      {fullExtracting
                        ? 'Extrayendo TODO…'
                        : `Extraer TODO (${roleGroups.datExtractTargets.map((t) => t.name).join(' + ')}) en .ZIP`}
                    </button>
                    <button
                      type="button"
                      disabled={fullExtracting}
                      onClick={() =>
                        void runFullDatExtraction(
                          roleGroups.datExtractTargets.map((t) => ({ blob: t.blob, fileName: t.name })),
                          'directory'
                        )
                      }
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <FolderInput className="h-4 w-4" />
                      Extraer TODO a Carpeta
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      type="button"
                      disabled={legibleHxdExtracting || fullExtracting}
                      onClick={() => legibleHxdInputRef.current?.click()}
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Binary className="h-4 w-4" />
                      {legibleHxdExtracting
                        ? 'Descifrando textos…'
                        : 'Desencriptar Textos Legibles para HxD (first.dat / RES.DAT)'}
                    </button>
                    <button
                      type="button"
                      disabled={fullExtracting}
                      onClick={() => datBatchInputRef.current?.click()}
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-800 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <LockOpen className="h-4 w-4" />
                      Seleccionar first.dat y/o RES.DAT para Extraer TODO (.ZIP)
                    </button>
                  </>
                )}
              </div>
            </div>

            {fullExtracting && fullExtractProgress && (
              <div className="mt-3 rounded-lg border border-blue-200 bg-blue-50/70 px-3 py-2 text-xs text-blue-800 dark:border-blue-900/50 dark:bg-blue-950/30 dark:text-blue-300 font-mono tabular-nums">
                {fullExtractProgress.phase} ({fullExtractProgress.done.toLocaleString('es-ES')} / {fullExtractProgress.total.toLocaleString('es-ES')})
              </div>
            )}

            {fullExtractError && (
              <div className="mt-3 rounded-lg border border-red-300 bg-red-50 px-3 py-2 text-xs text-red-800 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-300">
                {fullExtractError}
              </div>
            )}

            {fullExtractSummary && (
              <div className="mt-3 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-emerald-200 bg-emerald-50/70 px-3 py-2.5 text-xs text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/20 dark:text-emerald-200">
                <div>
                  <strong>Extracción completa:</strong> {fullExtractSummary.fileName} ·{' '}
                  <span className="font-mono tabular-nums">
                    {fullExtractSummary.decompressedBlocks} bloques descomprimidos · {fullExtractSummary.nestedExtracted} anidados · {fullExtractSummary.rawBlocksCopied} subarchivos · {fullExtractSummary.textStringsExtracted} textos Shift-JIS/UTF-8 ({formatBytes(fullExtractSummary.totalOutputBytes)})
                  </span>
                </div>
                {fullExtractSummary.zipBlob && (
                  <button
                    type="button"
                    onClick={() =>
                      downloadBlob(fullExtractSummary.zipBlob!, 'FIRST_Y_RES_DAT_TODO_DESENCRIPTADO.zip')
                    }
                    className="inline-flex items-center gap-1 font-semibold underline cursor-pointer"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Descargar .ZIP de nuevo
                  </button>
                )}
              </div>
            )}
          </section>

          {/* Translation Target Map (Objectives vs Typography vs Ignorable) */}
          {classifiedItems.length > 0 && (
            <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                    Mapa de Traducción y Objetivos PSP
                  </h3>
                  <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                    Prioriza dónde están los diálogos y textos (<span className="font-mono">RES.DAT</span>, <span className="font-mono">first.dat</span>, <span className="font-mono">DATA.BIN</span>, <span className="font-mono">EBOOT.BIN / BOOT.BIN</span>), revisa la fuente (<span className="font-mono">font.pgf</span>) u oculta audios/videos/rellenos.
                  </p>
                </div>

                <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={hideIgnoreNoText}
                    onChange={(e) => setHideIgnoreNoText(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  <EyeOff className="h-3.5 w-3.5 text-slate-500" />
                  Ocultar archivos sin texto (.awb, .pmf, .png, DUMMY.DAT)
                </label>
              </div>

              <div className="mt-4 grid grid-cols-1 gap-3 lg:grid-cols-3">
                {/* 1. Primary Text Targets */}
                <div
                  className={`rounded-xl border p-4 transition-colors ${
                    roleFilter === 'PRIMARY_TEXT'
                      ? 'border-emerald-600 bg-emerald-50/60 dark:border-emerald-500 dark:bg-emerald-950/20'
                      : 'border-slate-200 bg-slate-50/70 dark:border-slate-800 dark:bg-slate-950/50'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        setRoleFilter((prev) => (prev === 'PRIMARY_TEXT' ? 'ALL' : 'PRIMARY_TEXT'))
                      }
                      className="text-left text-xs font-semibold text-slate-900 hover:underline dark:text-white cursor-pointer"
                    >
                      1. Objetivos de Texto ({roleGroups.primaryTargets.length})
                    </button>
                    <FileText className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <p className="mt-1 text-[11px] text-slate-600 dark:text-slate-400">
                    RES.DAT (guiones/tablas), first.dat (menús iniciales), DATA.BIN (INSDIR), EBOOT.BIN/BOOT.BIN (sistema/objetos/error).
                  </p>
                  <div className="mt-3 space-y-1.5 max-h-40 overflow-y-auto">
                    {roleGroups.primaryTargets.slice(0, 6).map((target) => (
                      <div
                        key={target.id}
                        className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-[11px] dark:border-slate-800 dark:bg-slate-900"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="truncate font-mono font-semibold text-slate-900 dark:text-white" title={target.path}>
                            {target.name}
                          </div>
                          <div className="font-mono text-[10px] text-slate-500 tabular-nums">
                            {formatBytes(target.size)}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => void runTextAnalyzerOnBlob(target.blob, target.name)}
                            className="rounded bg-emerald-700 px-2 py-1 text-[10px] font-semibold text-white hover:bg-emerald-800 cursor-pointer"
                          >
                            Textos
                          </button>
                          <button
                            type="button"
                            onClick={() => void openInDecryptor(target)}
                            className="rounded border border-slate-300 px-2 py-1 text-[10px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                          >
                            Desempaquetar
                          </button>
                          {onInspectAssetBytes && target.size <= 16 * 1024 * 1024 && (
                            <button
                              type="button"
                              onClick={() => void openBlobInHxd(target.blob, target.path, 'shift_jis')}
                              className="rounded border border-slate-300 px-2 py-1 text-[10px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                              title="Abrir en HxD configurado en Shift-JIS"
                            >
                              HxD Shift-JIS
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 2. Fonts / Typography */}
                <div
                  className={`rounded-xl border p-4 transition-colors ${
                    roleFilter === 'FONT_TYPOGRAPHY'
                      ? 'border-blue-600 bg-blue-50/60 dark:border-blue-500 dark:bg-blue-950/20'
                      : 'border-slate-200 bg-slate-50/70 dark:border-slate-800 dark:bg-slate-950/50'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        setRoleFilter((prev) =>
                          prev === 'FONT_TYPOGRAPHY' ? 'ALL' : 'FONT_TYPOGRAPHY'
                        )
                      }
                      className="text-left text-xs font-semibold text-slate-900 hover:underline dark:text-white cursor-pointer"
                    >
                      2. Fuente y Tipografía ({roleGroups.fontTargets.length})
                    </button>
                    <Type className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                  </div>
                  <p className="mt-1 text-[11px] text-slate-600 dark:text-slate-400">
                    font.pgf y libfont.prx definen qué caracteres dibuja el motor. Verifica si soporta ñ y tildes (á, é, í, ó, ú) para español.
                  </p>
                  {roleGroups.pgfItem ? (
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => void openInDecryptor(roleGroups.pgfItem!)}
                        className="inline-flex min-h-[32px] items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-[11px] font-semibold text-white hover:bg-blue-700 cursor-pointer"
                      >
                        <Type className="h-3.5 w-3.5" />
                        Auditar {roleGroups.pgfItem.name} (ñ, tildes)
                      </button>
                    </div>
                  ) : (
                    <div className="mt-3 text-[11px] text-slate-500">
                      {roleGroups.fontTargets.length > 0
                        ? `${roleGroups.fontTargets.map((f) => f.name).join(', ')}`
                        : 'No se detectó font.pgf ni libfont.prx en este lote.'}
                    </div>
                  )}
                </div>

                {/* 3. Ignorable / Non-text */}
                <div
                  className={`rounded-xl border p-4 transition-colors ${
                    roleFilter === 'IGNORE_NO_TEXT'
                      ? 'border-amber-600 bg-amber-50/60 dark:border-amber-500 dark:bg-amber-950/20'
                      : 'border-slate-200 bg-slate-50/70 dark:border-slate-800 dark:bg-slate-950/50'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        setRoleFilter((prev) =>
                          prev === 'IGNORE_NO_TEXT' ? 'ALL' : 'IGNORE_NO_TEXT'
                        )
                      }
                      className="text-left text-xs font-semibold text-slate-900 hover:underline dark:text-white cursor-pointer"
                    >
                      3. Sin Texto / Ignorables ({roleGroups.ignoreTargets.length})
                    </button>
                    <EyeOff className="h-4 w-4 text-slate-500" />
                  </div>
                  <p className="mt-1 text-[11px] text-slate-600 dark:text-slate-400">
                    Contenedores de audio (.awb: bgm, voice, se, music, comment), videos (.pmf), imágenes XMB (.png) y relleno UMD (DUMMY.DAT).
                  </p>
                  <div className="mt-3 text-[11px] font-mono text-slate-500 tabular-nums">
                    Peso combinado:{' '}
                    {formatBytes(roleGroups.ignoreTargets.reduce((sum, f) => sum + f.size, 0))}
                  </div>
                </div>
              </div>
            </section>
          )}

          {/* 6 Category Filter Cards */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {(Object.keys(UNIVERSAL_CATEGORY_META) as UniversalMediaCategory[]).map((cat) => {
              const meta = UNIVERSAL_CATEGORY_META[cat];
              const active = categoryFilter === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategoryFilter((prev) => (prev === cat ? 'ALL' : cat))}
                  className={`rounded-xl border p-3.5 text-left transition-colors cursor-pointer ${
                    active
                      ? 'border-blue-600 bg-blue-50/70 dark:border-blue-500 dark:bg-blue-950/30'
                      : 'border-slate-200 bg-white hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:hover:bg-slate-800/70'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    {CATEGORY_ICON[cat]}
                    <span className="font-mono text-lg font-bold text-slate-900 tabular-nums dark:text-white">
                      {categoryCounts[cat]}
                    </span>
                  </div>
                  <div className="mt-2 text-xs font-semibold text-slate-900 dark:text-white">
                    {meta.shortLabel}
                  </div>
                  <div className="mt-0.5 line-clamp-2 text-[11px] text-slate-500 dark:text-slate-400">
                    {meta.description}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Identified Files Table */}
          <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-4 dark:border-slate-800">
              <div className="relative flex-1 min-w-[220px] max-w-md">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={identifierQuery}
                  onChange={(e) => setIdentifierQuery(e.target.value)}
                  placeholder="Filtrar por archivo, formato (RES.DAT, first.dat, .PGF, .AWB, ~PSP)..."
                  className="min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                {(categoryFilter !== 'ALL' || roleFilter !== 'ALL') && (
                  <button
                    type="button"
                    onClick={() => {
                      setCategoryFilter('ALL');
                      setRoleFilter('ALL');
                    }}
                    className="font-semibold text-blue-600 hover:underline dark:text-blue-400 cursor-pointer"
                  >
                    Ver todos los archivos
                  </button>
                )}
                <span className="font-mono tabular-nums">
                  {filteredClassified.length} archivos
                </span>
              </div>
            </div>

            {filteredClassified.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500 dark:text-slate-400">
                Carga una carpeta extraída de juego PSP (con <span className="font-mono">PSP_GAME/</span>, <span className="font-mono">INSDIR/</span>, <span className="font-mono">SYSDIR/</span>, <span className="font-mono">USRDIR/</span>, <span className="font-mono">font.pgf</span>, <span className="font-mono">UMD_DATA.BIN</span>) o arrastra archivos aquí.
              </div>
            ) : (
              <div className="max-h-[480px] overflow-auto">
                <table className="w-full border-collapse text-left text-xs">
                  <thead className="sticky top-0 z-10 border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    <tr>
                      <th className="px-4 py-2.5 font-semibold">Archivo / Ruta y Rol de Traducción</th>
                      <th className="px-4 py-2.5 font-semibold">Categoría</th>
                      <th className="px-4 py-2.5 font-semibold">Formato / Magic</th>
                      <th className="px-4 py-2.5 font-semibold">Estado / Compresión</th>
                      <th className="px-4 py-2.5 text-right font-semibold">Tamaño</th>
                      <th className="px-4 py-2.5 text-right font-semibold">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredClassified.slice(0, 350).map((item) => (
                      <tr key={item.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                        <td className="max-w-xs px-4 py-2.5">
                          <div className="truncate font-mono font-semibold text-slate-900 dark:text-slate-100" title={item.path}>
                            {item.path}
                          </div>
                          <div
                            className={`mt-0.5 text-[11px] ${
                              item.translationRole === 'PRIMARY_TEXT'
                                ? 'font-semibold text-emerald-700 dark:text-emerald-400'
                                : item.translationRole === 'FONT_TYPOGRAPHY'
                                ? 'font-semibold text-blue-700 dark:text-blue-400'
                                : 'text-slate-500 dark:text-slate-400'
                            }`}
                            title={item.translationAdvice}
                          >
                            {item.translationRoleLabel}
                          </div>
                        </td>
                        <td className="px-4 py-2.5 whitespace-nowrap">
                          <span className="inline-flex items-center gap-1.5 font-medium text-slate-800 dark:text-slate-200">
                            {CATEGORY_ICON[item.category]}
                            {UNIVERSAL_CATEGORY_META[item.category].shortLabel}
                          </span>
                        </td>
                        <td className="px-4 py-2.5">
                          <div className="font-mono font-semibold text-slate-900 dark:text-white">
                            {item.formatCode}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400">
                            {item.formatLabel}
                          </div>
                        </td>
                        <td className="px-4 py-2.5 text-[11px] text-slate-600 dark:text-slate-300">
                          <div>{item.compressionOrEncryption}</div>
                          <div className="font-mono text-[10px] text-slate-400">{item.magicHex}</div>
                        </td>
                        <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                          {formatBytes(item.size)}
                        </td>
                        <td className="px-4 py-2.5 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => void openInDecryptor(item)}
                              className="inline-flex min-h-[30px] items-center gap-1 rounded bg-slate-900 px-2.5 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
                            >
                              <LockOpen className="h-3 w-3" />
                              {item.formatCode === 'PGF0' ? 'Auditar' : 'Desencriptar'}
                            </button>
                            <button
                              type="button"
                              onClick={() => void runTextAnalyzerOnBlob(item.blob, item.name)}
                              className="inline-flex min-h-[30px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                            >
                              <FileText className="h-3 w-3" />
                              Textos
                            </button>
                            {(item.category === 'EXECUTABLE_CONTAINER' ||
                              item.category === 'AUDIO' ||
                              /\.(dat|bin|pck|awb|afs|cpk|prx)$/i.test(item.name)) && (
                              <button
                                type="button"
                                onClick={() => openInQuickBms(item.blob, item.name, item.path)}
                                className="inline-flex min-h-[30px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                                title="Generar script QuickBMS (.bms) analizando cabecera"
                              >
                                <FileCode2 className="h-3 w-3" />
                                QuickBMS
                              </button>
                            )}
                            {onInspectAssetBytes && item.size <= 16 * 1024 * 1024 && (
                              <button
                                type="button"
                                onClick={() => void openBlobInHxd(item.blob, item.path, 'shift_jis')}
                                className="inline-flex min-h-[30px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                                title="Abrir en HxD configurado en Shift-JIS"
                              >
                                <Binary className="h-3 w-3" />
                                HxD Shift-JIS
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => downloadBlob(item.blob, item.name)}
                              className="inline-flex min-h-[30px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                              title="Descargar archivo original"
                            >
                              <Download className="h-3 w-3" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </div>
      )}

      {/* ==================== TAB 2: UNIVERSAL DECRYPTOR / UNPACKER ==================== */}
      {subTab === 'decryptor' && (
        <div className="space-y-6">
          <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
                  Desencriptador y Desempaquetador Universal PSP (.DAT PRES/BLZ4/ZLIB · ~PSP · AFS2)
                </h2>
                <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  Desempaqueta <span className="font-mono">RES.DAT</span>, <span className="font-mono">first.dat</span> y <span className="font-mono">DATA.BIN</span> (motor Bandai Namco / Banpresto PSP) para dividir subarchivos en <span className="font-mono">.ZIP</span> o generar script <span className="font-mono">QuickBMS (.bms)</span>, descifra <span className="font-mono">EBOOT.BIN / BOOT.BIN / .PRX</span>, extrae pistas <span className="font-mono">.AWB</span> y audita <span className="font-mono">font.pgf</span>.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={datScanLimitMb}
                  onChange={(e) => setDatScanLimitMb(Number(e.target.value))}
                  aria-label="Límite de escaneo para contenedores .DAT/.BIN"
                  className="min-h-[38px] rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
                >
                  <option value={9999}>Escaneo .DAT: Archivo Completo (100%)</option>
                  <option value={64}>Escaneo .DAT: primeros 64 MB</option>
                  <option value={16}>Escaneo .DAT: primeros 16 MB</option>
                </select>
                <button
                  type="button"
                  disabled={legibleHxdExtracting}
                  onClick={() => legibleHxdInputRef.current?.click()}
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-indigo-600 dark:hover:bg-indigo-700 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Binary className="h-4 w-4" />
                  {legibleHxdExtracting ? 'Descifrando…' : 'Desencriptar Textos Legibles (HxD)'}
                </button>
                <button
                  type="button"
                  onClick={() => datBatchInputRef.current?.click()}
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-800 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Archive className="h-4 w-4" />
                  Extraer first.dat / RES.DAT (.ZIP)
                </button>
                <button
                  type="button"
                  onClick={() => decryptSingleInputRef.current?.click()}
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Upload className="h-4 w-4" />
                  Abrir Archivo
                </button>
              </div>
            </div>

            {selectedItem && (
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs dark:border-slate-800 dark:bg-slate-950">
                <div>
                  Archivo activo: <span className="font-mono font-semibold text-slate-900 dark:text-white">{selectedItem.path}</span>{' '}
                  <span className="font-mono text-slate-500">({formatBytes(selectedItem.size)})</span>
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    disabled={legibleHxdExtracting}
                    onClick={() =>
                      void runLegibleHxdDecryption([
                        { blob: selectedItem.blob, fileName: selectedItem.name },
                      ])
                    }
                    className="font-semibold text-indigo-700 hover:underline disabled:opacity-50 dark:text-indigo-400 cursor-pointer"
                  >
                    Desencriptar Textos Legibles para HxD
                  </button>
                  {onInspectAssetBytes && selectedItem.size <= 16 * 1024 * 1024 && (
                    <button
                      type="button"
                      onClick={() => void openBlobInHxd(selectedItem.blob, selectedItem.path, 'shift_jis')}
                      className="font-semibold text-slate-700 hover:underline dark:text-slate-200 cursor-pointer"
                    >
                      Abrir original en HxD (Shift-JIS)
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => openInQuickBms(selectedItem.blob, selectedItem.name, selectedItem.path)}
                    className="font-semibold text-emerald-700 hover:underline dark:text-emerald-400 cursor-pointer"
                  >
                    Generar Script QuickBMS (.bms)
                  </button>
                  <button
                    type="button"
                    onClick={() => void openInDecryptor(selectedItem, datScanLimitMb)}
                    className="font-semibold text-blue-600 hover:underline dark:text-blue-400 cursor-pointer"
                  >
                    Re-escanear con límite actual ({datScanLimitMb >= 9999 ? 'Completo' : `${datScanLimitMb} MB`})
                  </button>
                </div>
              </div>
            )}

            {legibleHxdExtracting && legibleHxdProgress && (
              <div className="mt-3 rounded-lg border border-indigo-200 bg-indigo-50/70 px-3 py-2 text-xs text-indigo-900 dark:border-indigo-900/50 dark:bg-indigo-950/30 dark:text-indigo-200 font-mono tabular-nums">
                {legibleHxdProgress.phase} ({legibleHxdProgress.done.toLocaleString('es-ES')} / {legibleHxdProgress.total.toLocaleString('es-ES')})
              </div>
            )}

            {legibleHxdError && (
              <div className="mt-3 rounded-lg border border-red-300 bg-red-50 px-3 py-2 text-xs text-red-800 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-300">
                {legibleHxdError}
              </div>
            )}

            {fullExtracting && fullExtractProgress && (
              <div className="mt-3 rounded-lg border border-blue-200 bg-blue-50/70 px-3 py-2 text-xs text-blue-800 dark:border-blue-900/50 dark:bg-blue-950/30 dark:text-blue-300 font-mono tabular-nums">
                {fullExtractProgress.phase} ({fullExtractProgress.done.toLocaleString('es-ES')} / {fullExtractProgress.total.toLocaleString('es-ES')})
              </div>
            )}

            {fullExtractError && (
              <div className="mt-3 rounded-lg border border-red-300 bg-red-50 px-3 py-2 text-xs text-red-800 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-300">
                {fullExtractError}
              </div>
            )}

            {fullExtractSummary && (
              <div className="mt-3 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-emerald-200 bg-emerald-50/70 px-3 py-2.5 text-xs text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/20 dark:text-emerald-200">
                <div>
                  <strong>Extracción completa:</strong> {fullExtractSummary.fileName} ·{' '}
                  <span className="font-mono tabular-nums">
                    {fullExtractSummary.decompressedBlocks} bloques descomprimidos · {fullExtractSummary.nestedExtracted} anidados · {fullExtractSummary.rawBlocksCopied} subarchivos · {fullExtractSummary.textStringsExtracted} textos Shift-JIS/UTF-8 ({formatBytes(fullExtractSummary.totalOutputBytes)})
                  </span>
                </div>
                {fullExtractSummary.zipBlob && (
                  <button
                    type="button"
                    onClick={() =>
                      downloadBlob(fullExtractSummary.zipBlob!, `${selectedItem?.name.replace(/\.[^.]+$/, '') ?? 'DAT'}_TODO_DESENCRIPTADO.zip`)
                    }
                    className="inline-flex items-center gap-1 font-semibold underline cursor-pointer"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Descargar .ZIP de nuevo
                  </button>
                )}
              </div>
            )}
          </section>

          {/* Legible Decrypted Text Blocks Ready for HxD Editing */}
          {legibleHxdResults.length > 0 && (
            <section className="space-y-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3 dark:border-slate-800">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                    Bloques Desencriptados con Textos Legibles para Editar en HxD (Shift-JIS / UTF-8)
                  </h3>
                  <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                    Cada archivo listado ya fue descifrado (XOR / BLZ4 / BLZ2 / ZLIB / PRES) y filtrado para mostrar solo los bloques que contienen diálogos, menús o texto editable directo en <span className="font-mono">HxD</span>.
                  </p>
                </div>

                <div className="relative min-w-[220px] max-w-xs flex-1">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={legibleHxdQuery}
                    onChange={(e) => setLegibleHxdQuery(e.target.value)}
                    placeholder="Buscar texto japonés, menú o bloque…"
                    className="min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 pl-8 pr-3 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                  />
                </div>
              </div>

              {legibleHxdResults.map((res, rIdx) => {
                const q = legibleHxdQuery.trim().toLowerCase();
                const filteredBlocks: LegibleTextBlockForHxd[] = !q
                  ? res.blocksWithText
                  : res.blocksWithText.filter(
                      (b) =>
                        b.blockLabel.toLowerCase().includes(q) ||
                        b.suggestedFileName.toLowerCase().includes(q) ||
                        b.previewLines.some((l) => l.text.toLowerCase().includes(q))
                    );

                return (
                  <div
                    key={`${res.fileName}-${rIdx}`}
                    className="overflow-hidden rounded-lg border border-slate-200 dark:border-slate-800"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 px-4 py-3 dark:bg-slate-950">
                      <div className="text-xs">
                        <div className="font-mono font-semibold text-slate-900 dark:text-white">
                          {res.fileName}{' '}
                          <span className="font-normal text-slate-500">
                            ({formatBytes(res.fileSize)})
                          </span>
                        </div>
                        <div className="mt-0.5 font-mono text-[11px] text-slate-600 tabular-nums dark:text-slate-400">
                          XOR:{' '}
                          {res.xorKeyDetected !== null
                            ? `0x${res.xorKeyDetected.toString(16).toUpperCase().padStart(2, '0')}`
                            : 'Ninguna (PRES/BLZ4 estándar)'}{' '}
                          · {res.blocksScanned} bloques analizados ·{' '}
                          <strong className="text-emerald-700 dark:text-emerald-400">
                            {res.blocksWithText.length} bloques con texto legible
                          </strong>{' '}
                          · {res.totalLegibleStrings.toLocaleString('es-ES')} cadenas
                        </div>
                      </div>

                      {res.blocksWithText.length > 0 && (
                        <button
                          type="button"
                          disabled={zippingLegibleIdx === rIdx}
                          onClick={() => void handleDownloadLegibleZip(res, rIdx)}
                          className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-emerald-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
                        >
                          <Archive className="h-3.5 w-3.5" />
                          {zippingLegibleIdx === rIdx
                            ? 'Empaquetando .ZIP…'
                            : 'Descargar .ZIP de Bloques para HxD'}
                        </button>
                      )}
                    </div>

                    {filteredBlocks.length === 0 ? (
                      <div className="p-4 text-xs text-slate-500 dark:text-slate-400">
                        {res.blocksWithText.length === 0
                          ? `No se encontraron bloques con cadenas legibles estándar dentro de ${res.fileName}. Puede usar cifrado por bloques propio o compresión custom; revisa en "4. Generador QuickBMS (.bms)" para inspeccionar su TOC.`
                          : 'Ningún bloque coincide con el filtro de búsqueda actual.'}
                      </div>
                    ) : (
                      <div className="max-h-[460px] overflow-auto">
                        <table className="w-full border-collapse text-left text-xs">
                          <thead className="sticky top-0 z-10 border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                            <tr>
                              <th className="px-4 py-2 font-semibold">Bloque Desencriptado</th>
                              <th className="px-4 py-2 font-semibold">HxD / Codif.</th>
                              <th className="px-4 py-2 font-semibold">Vista Previa de Textos Legibles</th>
                              <th className="px-4 py-2 text-right font-semibold">Acciones</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                            {filteredBlocks.slice(0, 200).map((blk) => (
                              <tr
                                key={blk.id}
                                className="align-top hover:bg-slate-50/70 dark:hover:bg-slate-800/40"
                              >
                                <td className="px-4 py-2.5">
                                  <div className="font-mono font-semibold text-slate-900 dark:text-white">
                                    {blk.blockLabel}
                                  </div>
                                  <div className="mt-0.5 font-mono text-[11px] text-slate-500 dark:text-slate-400">
                                    {blk.suggestedFileName} · {formatBytes(blk.bytes.length)}
                                  </div>
                                </td>
                                <td className="px-4 py-2.5 whitespace-nowrap font-mono tabular-nums">
                                  <div className="font-semibold text-blue-700 dark:text-blue-400">
                                    {blk.detectedEncoding === 'shift_jis' ? 'Shift-JIS' : 'UTF-8'}
                                  </div>
                                  <div className="text-[11px] text-slate-500">
                                    1º texto: {hex(blk.firstTextOffset, 6)}
                                  </div>
                                  <div className="text-[11px] text-emerald-700 dark:text-emerald-400">
                                    {blk.legibleStringCount} cadenas
                                  </div>
                                </td>
                                <td className="px-4 py-2.5 max-w-md">
                                  <ul className="space-y-1 font-mono text-[11px]">
                                    {blk.previewLines.slice(0, 3).map((line, lIdx) => (
                                      <li
                                        key={`${blk.id}-${lIdx}`}
                                        className="truncate text-slate-800 dark:text-slate-200"
                                        title={line.text}
                                      >
                                        <span className="text-slate-400">
                                          [{hex(line.offset, 6)}]
                                        </span>{' '}
                                        {line.text}
                                      </li>
                                    ))}
                                  </ul>
                                </td>
                                <td className="px-4 py-2.5 text-right whitespace-nowrap">
                                  <div className="inline-flex items-center gap-1.5">
                                    {onInspectAssetBytes && (
                                      <button
                                        type="button"
                                        onClick={() =>
                                          onInspectAssetBytes(
                                            blk.bytes,
                                            blk.suggestedFileName,
                                            blk.detectedEncoding,
                                            blk.firstTextOffset
                                          )
                                        }
                                        className="inline-flex min-h-[30px] items-center gap-1 rounded bg-blue-600 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
                                        title={`Abrir en HxD en offset ${hex(blk.firstTextOffset, 6)} con ${blk.detectedEncoding}`}
                                      >
                                        <Binary className="h-3 w-3" />
                                        Editar en HxD
                                      </button>
                                    )}
                                    <button
                                      type="button"
                                      onClick={() =>
                                        downloadBlob(
                                          new Blob([blk.bytes as unknown as BlobPart], {
                                            type: 'application/octet-stream',
                                          }),
                                          blk.suggestedFileName
                                        )
                                      }
                                      className="inline-flex min-h-[30px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
                                      title="Descargar archivo .BIN descifrado para HxD.exe"
                                    >
                                      <Download className="h-3 w-3" />
                                      .BIN
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() =>
                                        void runTextAnalyzerOnBlob(
                                          new Blob([blk.bytes as unknown as BlobPart]),
                                          blk.suggestedFileName,
                                          blk.detectedEncoding
                                        )
                                      }
                                      className="inline-flex min-h-[30px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
                                    >
                                      <FileText className="h-3 w-3" />
                                      Textos
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                );
              })}
            </section>
          )}

          {decrypting && (
            <div className="rounded-xl border border-slate-200 bg-white p-6 text-xs text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300">
              Desencriptando cabeceras, leyendo índices y escaneando flujos comprimidos...
            </div>
          )}

          {decryptError && (
            <div className="rounded-xl border border-red-300 bg-red-50 p-4 text-xs text-red-800 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-300">
              {decryptError}
            </div>
          )}

          {!decrypting && !decryptResult && (
            <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-xs text-slate-500 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400">
              Selecciona cualquier archivo desde <span className="font-semibold">1. Identificador</span> (como <span className="font-mono">RES.DAT</span>, <span className="font-mono">first.dat</span>, <span className="font-mono">EBOOT.BIN</span> o <span className="font-mono">font.pgf</span>) o pulsa <span className="font-semibold">Abrir Archivo para Desencriptar</span>.
            </div>
          )}

          {decryptResult && (
            <div className="space-y-6">
              {/* Summary & Key/Value details */}
              <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                      {decryptResult.summaryTitle}
                    </div>
                    <div className="mt-1 font-mono text-[11px] text-slate-500 dark:text-slate-400">
                      {decryptResult.filePath} · {formatBytes(decryptResult.fileSize)}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {decryptResult.decompressedBytes && decryptResult.decompressedName && (
                      <>
                        <button
                          type="button"
                          onClick={() =>
                            downloadBlob(
                              new Blob([decryptResult.decompressedBytes! as unknown as BlobPart], {
                                type: 'application/octet-stream',
                              }),
                              decryptResult.decompressedName!
                            )
                          }
                          className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-800 cursor-pointer"
                        >
                          <Download className="h-4 w-4" />
                          Descargar {decryptResult.decompressedName}
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            void runTextAnalyzerOnBlob(
                              new Blob([decryptResult.decompressedBytes! as unknown as BlobPart]),
                              decryptResult.decompressedName!
                            )
                          }
                          className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                        >
                          <FileText className="h-3.5 w-3.5" />
                          Analizar Textos ELF
                        </button>
                        {onInspectAssetBytes && (
                          <>
                            <button
                              type="button"
                              onClick={() =>
                                onInspectAssetBytes(
                                  decryptResult.decompressedBytes!,
                                  decryptResult.decompressedName!,
                                  'shift_jis'
                                )
                              }
                              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-slate-900 px-3 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
                            >
                              <Binary className="h-3.5 w-3.5" />
                              Abrir ELF en HxD (Shift-JIS)
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                onInspectAssetBytes(
                                  decryptResult.decompressedBytes!,
                                  decryptResult.decompressedName!,
                                  'utf-8'
                                )
                              }
                              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                            >
                              <Binary className="h-3.5 w-3.5" />
                              HxD (UTF-8)
                            </button>
                          </>
                        )}
                      </>
                    )}

                    {decryptResult.pmfInfo && selectedItem && (
                      <button
                        type="button"
                        onClick={() => {
                          const pmf = decryptResult.pmfInfo!;
                          const streamSize =
                            pmf.streamSize > 0
                              ? pmf.streamSize
                              : Math.max(0, selectedItem.size - pmf.streamOffset);
                          const slice = selectedItem.blob.slice(
                            pmf.streamOffset,
                            pmf.streamOffset + streamSize
                          );
                          downloadBlob(
                            slice,
                            selectedItem.name.replace(/\.pmf$/i, '.mps')
                          );
                        }}
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
                      >
                        <Download className="h-4 w-4" />
                        Extraer Stream MPEG/H.264 (.MPS)
                      </button>
                    )}

                    {selectedItem && (
                      <button
                        type="button"
                        onClick={() =>
                          void runTextAnalyzerOnBlob(selectedItem.blob, selectedItem.name)
                        }
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                      >
                        <FileText className="h-3.5 w-3.5" />
                        Analizar Textos
                      </button>
                    )}
                  </div>
                </div>

                {decryptResult.details.length > 0 && (
                  <dl className="mt-4 grid grid-cols-1 gap-2 border-t border-slate-100 pt-3 sm:grid-cols-2 lg:grid-cols-3 dark:border-slate-800">
                    {decryptResult.details.map((d) => (
                      <div key={d.label} className="rounded-lg border border-slate-100 p-2.5 text-xs dark:border-slate-800">
                        <dt className="text-[11px] text-slate-500 dark:text-slate-400">{d.label}</dt>
                        <dd className="mt-0.5 truncate font-mono font-semibold text-slate-900 dark:text-white" title={d.value}>
                          {d.value}
                        </dd>
                      </div>
                    ))}
                  </dl>
                )}

                {decryptResult.notes.length > 0 && (
                  <ul className="mt-3 space-y-1 text-xs text-slate-600 dark:text-slate-300">
                    {decryptResult.notes.map((n, idx) => (
                      <li key={idx}>• {n}</li>
                    ))}
                  </ul>
                )}

                {decryptResult.imageInfo?.previewUrl && (
                  <div className="mt-4 border-t border-slate-100 pt-4 dark:border-slate-800">
                    <div className="mb-2 text-xs font-semibold text-slate-900 dark:text-white">
                      Vista Previa Decodificada
                    </div>
                    <div className="inline-block rounded-lg border border-slate-200 bg-slate-100 p-2 dark:border-slate-700 dark:bg-slate-950">
                      <img
                        src={decryptResult.imageInfo.previewUrl}
                        alt={decryptResult.fileName}
                        className="max-h-64 w-auto object-contain"
                      />
                    </div>
                  </div>
                )}
              </section>

              {/* PGF Font Spanish Glyph Audit Grid */}
              {decryptResult.pgfInfo && (
                <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-3 dark:border-slate-800">
                    <div>
                      <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                        Auditoría de Caracteres Españoles en {decryptResult.fileName}
                      </h3>
                      <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                        {decryptResult.pgfInfo.spanishAuditSummary}
                      </p>
                    </div>
                    <span className="font-mono text-xs text-slate-500 tabular-nums">
                      Rango: U+{decryptResult.pgfInfo.firstGlyph.toString(16).toUpperCase().padStart(4, '0')} – U+{decryptResult.pgfInfo.lastGlyph.toString(16).toUpperCase().padStart(4, '0')}
                    </span>
                  </div>

                  <div className="mt-4 grid grid-cols-4 gap-2 sm:grid-cols-8">
                    {decryptResult.pgfInfo.spanishAudit.map((g) => (
                      <div
                        key={g.codePointHex}
                        className={`rounded-lg border p-2.5 text-center ${
                          g.supported === true
                            ? 'border-emerald-200 bg-emerald-50/70 dark:border-emerald-900/50 dark:bg-emerald-950/20'
                            : g.supported === false
                            ? 'border-red-200 bg-red-50/70 dark:border-red-900/50 dark:bg-red-950/20'
                            : 'border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-950'
                        }`}
                      >
                        <div className="text-lg font-bold text-slate-900 dark:text-white">
                          {g.char}
                        </div>
                        <div className="font-mono text-[10px] text-slate-500">
                          {g.codePointHex}
                        </div>
                        <div
                          className={`mt-1 text-[10px] font-semibold ${
                            g.supported === true
                              ? 'text-emerald-700 dark:text-emerald-400'
                              : g.supported === false
                              ? 'text-red-700 dark:text-red-400'
                              : 'text-slate-500'
                          }`}
                        >
                          {g.supported === true
                            ? 'Presente'
                            : g.supported === false
                            ? 'Falta'
                            : 'Según tabla'}
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* AWB (AFS2) Track Extractor Table */}
              {decryptResult.awbTracks && decryptResult.awbTracks.length > 0 && (
                <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-4 dark:border-slate-800">
                    <div className="relative flex-1 min-w-[200px] max-w-md">
                      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        value={awbTrackQuery}
                        onChange={(e) => setAwbTrackQuery(e.target.value)}
                        placeholder="Filtrar pista por Cue ID, índice o códec (HCA, ADX, AT3)..."
                        className="min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                      />
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-xs text-slate-500 tabular-nums">
                        {filteredAwbTracks.length} pistas
                      </span>
                      <button
                        type="button"
                        disabled={zippingAwb}
                        onClick={() =>
                          void handleExportAwbZip(filteredAwbTracks, decryptResult.fileName)
                        }
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-blue-600 cursor-pointer"
                      >
                        <Archive className="h-3.5 w-3.5" />
                        {zippingAwb
                          ? `Empaquetando (${awbZipProgress?.done ?? 0}/${awbZipProgress?.total ?? 0})…`
                          : `Extraer hasta 500 pistas (.ZIP)`}
                      </button>
                    </div>
                  </div>

                  <div className="max-h-[420px] overflow-auto">
                    <table className="w-full border-collapse text-left text-xs">
                      <thead className="sticky top-0 z-10 border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                        <tr>
                          <th className="px-4 py-2 font-semibold">#</th>
                          <th className="px-4 py-2 font-semibold">Cue ID</th>
                          <th className="px-4 py-2 font-semibold">Offset AWB</th>
                          <th className="px-4 py-2 font-semibold">Códec / Formato</th>
                          <th className="px-4 py-2 text-right font-semibold">Tamaño</th>
                          <th className="px-4 py-2 text-right font-semibold">Acción</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {filteredAwbTracks.slice(0, 300).map((t) => (
                          <tr key={t.index} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                            <td className="px-4 py-2 font-mono text-slate-400 tabular-nums">
                              {t.index}
                            </td>
                            <td className="px-4 py-2 font-mono font-semibold text-slate-900 tabular-nums dark:text-white">
                              {t.cueId}
                            </td>
                            <td className="px-4 py-2 font-mono tabular-nums text-slate-600 dark:text-slate-400">
                              {hex(t.offset)}
                            </td>
                            <td className="px-4 py-2">
                              <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                                {t.codecExt}
                              </span>{' '}
                              <span className="text-[11px] text-slate-500">{t.codecLabel}</span>
                            </td>
                            <td className="px-4 py-2 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                              {formatBytes(t.size)}
                            </td>
                            <td className="px-4 py-2 text-right">
                              <button
                                type="button"
                                onClick={() =>
                                  selectedItem &&
                                  downloadBlob(
                                    extractAwbTrackBlob(selectedItem.blob, t),
                                    `track_${String(t.index).padStart(4, '0')}_cue_${t.cueId}${t.codecExt}`
                                  )
                                }
                                className="inline-flex min-h-[28px] items-center gap-1 rounded bg-slate-900 px-2.5 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
                              >
                                <Download className="h-3 w-3" />
                                Extraer
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </section>
              )}

              {/* DAT Container Signatures & PRES/BLZ4/ZLIB/GZIP Splitter */}
              {decryptResult.detectedKind === 'DAT_CONTAINER' && (
                <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-4 dark:border-slate-800">
                    <div>
                      <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                        Subarchivos y Bloques Internos (.DAT / PRES / BLZ4 / ZLIB / GZIP)
                      </h3>
                      <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                        Divide y extrae en .ZIP los bloques detectados dentro del navegador, descomprime flujos <span className="font-mono">BLZ4/ZLIB</span> uno a uno, o descarga un script <span className="font-mono">QuickBMS</span> para Bandai Namco / Banpresto PSP.
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          if (selectedItem) {
                            openInQuickBms(selectedItem.blob, selectedItem.name, selectedItem.path);
                          } else {
                            const script = generateBandaiNamcoQuickBmsScript(decryptResult.fileName);
                            downloadBlob(
                              new Blob([script], { type: 'text/plain;charset=utf-8' }),
                              'bandai_namco_psp_dat.bms'
                            );
                          }
                        }}
                        className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
                      >
                        <FileCode2 className="h-3.5 w-3.5" />
                        Personalizar QuickBMS (.bms)
                      </button>

                      {selectedItem && (
                        <>
                          <button
                            type="button"
                            disabled={fullExtracting}
                            onClick={() =>
                              void runFullDatExtraction(
                                [{ blob: selectedItem.blob, fileName: selectedItem.name }],
                                'directory'
                              )
                            }
                            className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
                          >
                            <FolderInput className="h-3.5 w-3.5" />
                            Extraer TODO a Carpeta
                          </button>

                          <button
                            type="button"
                            disabled={fullExtracting || zippingDat}
                            onClick={() =>
                              void runFullDatExtraction(
                                [{ blob: selectedItem.blob, fileName: selectedItem.name }],
                                'zip'
                              )
                            }
                            className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 disabled:opacity-50 cursor-pointer"
                          >
                            <Archive className="h-3.5 w-3.5" />
                            {fullExtracting
                              ? 'Extrayendo TODO…'
                              : `Extraer TODO el Contenido (.ZIP Completo)`}
                          </button>
                        </>
                      )}

                      {decryptResult.datHits && decryptResult.datHits.length > 0 && (
                        <button
                          type="button"
                          disabled={zippingDat || fullExtracting}
                          onClick={() =>
                            void handleExportDatZip(decryptResult.datHits!, decryptResult.fileName)
                          }
                          className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-blue-600 cursor-pointer"
                        >
                          <Archive className="h-3.5 w-3.5" />
                          {zippingDat
                            ? `Empaquetando (${datZipProgress?.done ?? 0}/${datZipProgress?.total ?? 0})…`
                            : `Extraer ${decryptResult.datHits.length} bloques listados`}
                        </button>
                      )}
                    </div>
                  </div>

                  {!decryptResult.datHits || decryptResult.datHits.length === 0 ? (
                    <div className="p-6 text-xs text-slate-500 dark:text-slate-400">
                      No se detectaron firmas estándar en el rango actual. Usa <span className="font-semibold">Extraer TODO el Contenido (.ZIP Completo)</span> arriba para volcar todo el contenedor junto con las cadenas <span className="font-mono">Shift-JIS / UTF-8</span> detectadas.
                    </div>
                  ) : (
                    <div className="max-h-[440px] overflow-auto">
                      <table className="w-full border-collapse text-left text-xs">
                        <thead className="sticky top-0 z-10 border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                          <tr>
                            <th className="px-4 py-2 font-semibold">#</th>
                            <th className="px-4 py-2 font-semibold">Offset</th>
                            <th className="px-4 py-2 font-semibold">Firma / Subarchivo</th>
                            <th className="px-4 py-2 font-semibold">Categoría</th>
                            <th className="px-4 py-2 text-right font-semibold">Tamaño est.</th>
                            <th className="px-4 py-2 text-right font-semibold">Acciones</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                          {decryptResult.datHits.slice(0, 500).map((hit) => {
                            const dec = decompressedHitMap[hit.offset];
                            return (
                              <tr key={`${hit.offset}-${hit.signature}`} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                                <td className="px-4 py-2 font-mono text-slate-400 tabular-nums">
                                  {hit.index}
                                </td>
                                <td className="px-4 py-2 font-mono tabular-nums text-blue-600 dark:text-blue-400">
                                  {hex(hit.offset)}
                                </td>
                                <td className="px-4 py-2">
                                  <div className="font-mono font-semibold text-slate-900 dark:text-white">
                                    {hit.suggestedName ? `${hit.signature} · ${hit.suggestedName}` : hit.signature}
                                  </div>
                                  <div className="text-[11px] text-slate-500 dark:text-slate-400">
                                    {dec ? `Descomprimido: ${dec.innerFormat} (${formatBytes(dec.bytes.length)})` : hit.label}
                                  </div>
                                </td>
                                <td className="px-4 py-2 whitespace-nowrap text-slate-700 dark:text-slate-300">
                                  {UNIVERSAL_CATEGORY_META[hit.category].shortLabel}
                                </td>
                                <td className="px-4 py-2 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                                  {hit.estimatedSize !== null ? formatBytes(hit.estimatedSize) : '—'}
                                </td>
                                <td className="px-4 py-2 text-right whitespace-nowrap">
                                  <div className="inline-flex items-center gap-1">
                                    {hit.canDecompress && !dec && (
                                      <button
                                        type="button"
                                        disabled={decompressingOffset === hit.offset}
                                        onClick={() => void handleDecompressDatHit(hit)}
                                        className="inline-flex min-h-[28px] items-center gap-1 rounded bg-emerald-700 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-emerald-800 disabled:opacity-50 cursor-pointer"
                                      >
                                        <Sparkles className="h-3 w-3" />
                                        {decompressingOffset === hit.offset ? 'Descomprimiendo…' : 'Descomprimir'}
                                      </button>
                                    )}
                                    {dec && (
                                      <>
                                        <button
                                          type="button"
                                          onClick={() =>
                                            downloadBlob(
                                              new Blob([dec.bytes as unknown as BlobPart], {
                                                type: 'application/octet-stream',
                                              }),
                                              `descomprimido_${hex(hit.offset)}${dec.suggestedExt}`
                                            )
                                          }
                                          className="inline-flex min-h-[28px] items-center gap-1 rounded bg-emerald-700 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-emerald-800 cursor-pointer"
                                        >
                                          <Download className="h-3 w-3" />
                                          Guardar {dec.suggestedExt}
                                        </button>
                                        <button
                                          type="button"
                                          onClick={() =>
                                            void runTextAnalyzerOnBlob(
                                              new Blob([dec.bytes as unknown as BlobPart]),
                                              `${selectedItem?.name ?? 'chunk'}_${hex(hit.offset)}${dec.suggestedExt}`
                                            )
                                          }
                                          className="inline-flex min-h-[28px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                                        >
                                          <FileText className="h-3 w-3" />
                                          Textos
                                        </button>
                                        {onInspectAssetBytes && (
                                          <button
                                            type="button"
                                            onClick={() =>
                                              onInspectAssetBytes(
                                                dec.bytes,
                                                `${selectedItem?.name ?? 'chunk'}_${hex(hit.offset)}${dec.suggestedExt}`,
                                                'shift_jis'
                                              )
                                            }
                                            className="inline-flex min-h-[28px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                                          >
                                            <Binary className="h-3 w-3" />
                                            HxD Shift-JIS
                                          </button>
                                        )}
                                      </>
                                    )}
                                    {selectedItem && hit.estimatedSize !== null && (
                                      <button
                                        type="button"
                                        onClick={() =>
                                          downloadBlob(
                                            selectedItem.blob.slice(
                                              hit.offset,
                                              Math.min(selectedItem.size, hit.offset + hit.estimatedSize!)
                                            ),
                                            `${selectedItem.name}_${hex(hit.offset)}${hit.suggestedExt}`
                                          )
                                        }
                                        className="inline-flex min-h-[28px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                                      >
                                        <Download className="h-3 w-3" />
                                        Extraer
                                      </button>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </section>
              )}
            </div>
          )}
        </div>
      )}

      {/* ==================== TAB 3: UNIVERSAL TEXT ANALYZER ==================== */}
      {subTab === 'text_analyzer' && (
        <div className="space-y-6">
          <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
                  Analizador Profundo de Textos PSP (Shift-JIS · UTF-8 · Descompresión Automática BLZ4/ZLIB/GZIP)
                </h2>
                <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  Detecta diálogos, menús UI, textos de guardado/objetos/error y rutas incluso dentro de bloques comprimidos de <span className="font-mono">RES.DAT</span>, <span className="font-mono">first.dat</span>, <span className="font-mono">DATA.BIN</span> y <span className="font-mono">EBOOT.BIN/BOOT.BIN</span>.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => textSingleInputRef.current?.click()}
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Upload className="h-4 w-4" />
                  Analizar Archivo Local
                </button>
                {onInspectAssetBytes && textTargetBlob && textTargetName && textTargetBlob.size <= 16 * 1024 * 1024 && (
                  <button
                    type="button"
                    onClick={() =>
                      void openBlobInHxd(
                        textTargetBlob,
                        textTargetName,
                        textEncoding === 'utf-8' ? 'utf-8' : 'shift_jis'
                      )
                    }
                    className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-slate-700 cursor-pointer"
                  >
                    <Binary className="h-3.5 w-3.5" />
                    Abrir en HxD ({textEncoding === 'utf-8' ? 'UTF-8' : 'Shift-JIS'})
                  </button>
                )}
                {analysis && analysis.rawBytes.length > 0 && (
                  <button
                    type="button"
                    onClick={() =>
                      void runTextAnalyzerOnBlob(
                        new Blob([analysis.rawBytes as unknown as BlobPart]),
                        analysis.targetBinaryPath
                      )
                    }
                    className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    Analizar {analysis.targetBinaryPath.split('/').pop()} Actual
                  </button>
                )}
              </div>
            </div>

            {/* Quick Switcher across detected Primary Text Targets */}
            {roleGroups.primaryTargets.length > 0 && (
              <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                  Objetivos detectados:
                </span>
                {roleGroups.primaryTargets.slice(0, 8).map((target) => {
                  const active = textTargetName === target.name;
                  return (
                    <button
                      key={target.id}
                      type="button"
                      onClick={() => void runTextAnalyzerOnBlob(target.blob, target.name)}
                      className={`inline-flex min-h-[30px] items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11px] font-mono transition-colors cursor-pointer ${
                        active
                          ? 'border-blue-600 bg-blue-50 font-semibold text-blue-700 dark:border-blue-500 dark:bg-blue-950/30 dark:text-blue-300'
                          : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300'
                      }`}
                    >
                      {target.name} ({formatBytes(target.size)})
                    </button>
                  );
                })}
              </div>
            )}

            <div className="mt-4 grid grid-cols-1 gap-3 border-t border-slate-100 pt-4 sm:grid-cols-4 dark:border-slate-800">
              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                  Codificación de lectura
                </label>
                <select
                  value={textEncoding}
                  onChange={(e) => {
                    const next = e.target.value as TextEncodingMode | 'AUTO_MULTI';
                    setTextEncoding(next);
                    if (textTargetBlob && textTargetName) {
                      void runTextAnalyzerOnBlob(textTargetBlob, textTargetName, next);
                    }
                  }}
                  className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                >
                  <option value="AUTO_MULTI">Auto (Shift-JIS + UTF-8 + UTF-16LE)</option>
                  <option value="shift_jis">Shift-JIS (Japonés PSP)</option>
                  <option value="utf-8">UTF-8 / ASCII</option>
                  <option value="windows-1252">Windows-1252 (Español / Europa)</option>
                  <option value="utf-16le">UTF-16LE</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                  Longitud mínima
                </label>
                <select
                  value={textMinLen}
                  onChange={(e) => {
                    const next = Number(e.target.value);
                    setTextMinLen(next);
                    if (textTargetBlob && textTargetName) {
                      void runTextAnalyzerOnBlob(textTargetBlob, textTargetName, undefined, next);
                    }
                  }}
                  className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                >
                  <option value={3}>3 caracteres</option>
                  <option value={4}>4 caracteres</option>
                  <option value={6}>6 caracteres</option>
                  <option value={10}>10+ caracteres (frases)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                  Rango de escaneo
                </label>
                <select
                  value={textMaxMb}
                  onChange={(e) => {
                    const next = Number(e.target.value);
                    setTextMaxMb(next);
                    if (textTargetBlob && textTargetName) {
                      void runTextAnalyzerOnBlob(textTargetBlob, textTargetName, undefined, undefined, next);
                    }
                  }}
                  className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                >
                  <option value={8}>Primeros 8 MB</option>
                  <option value={16}>Primeros 16 MB</option>
                  <option value={64}>Primeros 64 MB</option>
                  <option value={9999}>Archivo Completo (streaming)</option>
                </select>
              </div>

              <div className="flex items-end gap-1.5">
                {textSummary && (
                  <>
                    <button
                      type="button"
                      onClick={() =>
                        downloadBlob(
                          new Blob([exportTextAnalysis(textSummary, 'TXT')], { type: 'text/plain;charset=utf-8' }),
                          `${textSummary.fileName}_TEXTOS.txt`
                        )
                      }
                      className="inline-flex min-h-[36px] flex-1 items-center justify-center rounded-lg border border-slate-300 px-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                    >
                      .TXT
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        downloadBlob(
                          new Blob([exportTextAnalysis(textSummary, 'CSV')], { type: 'text/csv;charset=utf-8' }),
                          `${textSummary.fileName}_TEXTOS.csv`
                        )
                      }
                      className="inline-flex min-h-[36px] flex-1 items-center justify-center rounded-lg border border-slate-300 px-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                    >
                      .CSV
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        downloadBlob(
                          new Blob([exportTextAnalysis(textSummary, 'JSON')], { type: 'application/json;charset=utf-8' }),
                          `${textSummary.fileName}_TEXTOS.json`
                        )
                      }
                      className="inline-flex min-h-[36px] flex-1 items-center justify-center rounded-lg border border-slate-300 px-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                    >
                      .JSON
                    </button>
                  </>
                )}
              </div>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-5 border-t border-slate-100 pt-3 dark:border-slate-800">
              <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeCompressedBlocks}
                  onChange={(e) => {
                    const next = e.target.checked;
                    setIncludeCompressedBlocks(next);
                    if (textTargetBlob && textTargetName) {
                      void runTextAnalyzerOnBlob(
                        textTargetBlob,
                        textTargetName,
                        undefined,
                        undefined,
                        undefined,
                        next
                      );
                    }
                  }}
                  className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                Descomprimir bloques ZLIB / GZIP / BLZ4 automáticamente (recomendado para RES.DAT, first.dat, DATA.BIN)
              </label>

              <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={onlyLegibleText}
                  onChange={(e) => setOnlyLegibleText(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                Ocultar ruido binario (mostrar solo cadenas claramente legibles)
              </label>
            </div>
          </section>

          {analyzingText && textScanProgress && (
            <div className="rounded-xl border border-slate-200 bg-white p-5 text-xs text-blue-700 dark:border-slate-800 dark:bg-slate-900 dark:text-blue-300 font-mono tabular-nums">
              Analizando cadenas y descomprimiendo bloques: {formatBytes(textScanProgress.scanned)} / {formatBytes(textScanProgress.total)}...
            </div>
          )}

          {textError && (
            <div className="rounded-xl border border-red-300 bg-red-50 p-4 text-xs text-red-800 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-300">
              {textError}
            </div>
          )}

          {!analyzingText && !textSummary && (
            <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-xs text-slate-500 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400">
              Pulsa <span className="font-semibold">Analizar Archivo Local</span> o selecciona <span className="font-mono">RES.DAT</span>, <span className="font-mono">first.dat</span>, <span className="font-mono">DATA.BIN</span> o <span className="font-mono">EBOOT.BIN</span> arriba.
            </div>
          )}

          {textSummary && (
            <div className="space-y-4">
              {/* Encoding & Compressed Blocks Summary Strip */}
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 text-xs dark:border-slate-800 dark:bg-slate-900">
                <div className="flex flex-wrap items-center gap-3 text-slate-600 dark:text-slate-300">
                  <span>
                    Codificación dominante:{' '}
                    <strong className="font-mono text-slate-900 dark:text-white">
                      {PRIMARY_ENCODING_LABEL[textSummary.detectedPrimaryEncoding]}
                    </strong>
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">
                    Bloques descomprimidos: {textSummary.compressedBlocksDecompressed} / {textSummary.compressedBlocksFound}
                  </span>
                </div>
                <div className="font-mono text-[11px] text-slate-500 tabular-nums">
                  Escaneado: {formatBytes(textSummary.scannedBytes)} de {formatBytes(textSummary.fileSize)}
                </div>
              </div>

              {/* 5 Category Stats Strip */}
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
                {(Object.keys(TEXT_CATEGORY_LABEL) as TextStringCategory[]).map((cat) => {
                  const active = textCategoryFilter === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setTextCategoryFilter((prev) => (prev === cat ? 'ALL' : cat))}
                      className={`rounded-xl border p-3.5 text-left transition-colors cursor-pointer ${
                        active
                          ? 'border-blue-600 bg-blue-50/70 dark:border-blue-500 dark:bg-blue-950/30'
                          : 'border-slate-200 bg-white hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900'
                      }`}
                    >
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        {TEXT_CATEGORY_LABEL[cat]}
                      </div>
                      <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums dark:text-white">
                        {textSummary.categoryCounts[cat].toLocaleString('es-ES')}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Strings Table */}
              <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-4 dark:border-slate-800">
                  <div className="relative flex-1 min-w-[200px] max-w-md">
                    <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={textSearchQuery}
                      onChange={(e) => setTextSearchQuery(e.target.value)}
                      placeholder="Buscar texto, dirección hex o bloque (ZLIB, BLZ4, Memory Stick)..."
                      className="min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                    />
                  </div>
                  <div className="flex flex-wrap items-center gap-3 font-mono text-xs text-slate-500 tabular-nums">
                    <span>
                      Archivo: <strong className="text-slate-900 dark:text-white">{textSummary.fileName}</strong>
                    </span>
                    <span>ES: {textSummary.languageCounts.ES}</span>
                    <span>EN: {textSummary.languageCounts.EN}</span>
                    <span>JA: {textSummary.languageCounts.JA}</span>
                    <span>{filteredTextEntries.length} cadenas</span>
                  </div>
                </div>

                <div className="max-h-[460px] overflow-auto">
                  <table className="w-full border-collapse text-left text-xs">
                    <thead className="sticky top-0 z-10 border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                      <tr>
                        <th className="px-4 py-2 font-semibold">#</th>
                        <th className="px-4 py-2 font-semibold">Offset</th>
                        <th className="px-4 py-2 font-semibold">Origen</th>
                        <th className="px-4 py-2 font-semibold">Cód. / Idioma</th>
                        <th className="px-4 py-2 font-semibold">Categoría</th>
                        <th className="px-4 py-2 font-semibold">Cadena de Texto Detectada</th>
                        <th className="px-4 py-2 text-right font-semibold">Bytes</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {filteredTextEntries.slice(0, 500).map((entry) => (
                        <tr key={entry.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                          <td className="px-4 py-2 font-mono text-slate-400 tabular-nums">
                            {entry.id}
                          </td>
                          <td className="px-4 py-2 font-mono tabular-nums">
                            {onJumpToHex && analysis && textSummary.fileName === analysis.targetBinaryPath ? (
                              <button
                                type="button"
                                onClick={() => onJumpToHex(entry.offset)}
                                className="text-blue-600 hover:underline dark:text-blue-400 cursor-pointer"
                              >
                                {hex(entry.offset)}
                              </button>
                            ) : (
                              <span className="text-slate-600 dark:text-slate-400">{hex(entry.offset)}</span>
                            )}
                          </td>
                          <td className="px-4 py-2 font-mono text-[11px] whitespace-nowrap text-slate-600 dark:text-slate-400">
                            {entry.sourceBlock}
                          </td>
                          <td className="px-4 py-2 font-mono text-[11px] whitespace-nowrap text-slate-600 dark:text-slate-300">
                            {entry.encoding} · {entry.languageHint}
                          </td>
                          <td className="px-4 py-2 whitespace-nowrap text-[11px] text-slate-600 dark:text-slate-300">
                            {TEXT_CATEGORY_LABEL[entry.category]}
                          </td>
                          <td className="max-w-xl break-words px-4 py-2 font-mono text-slate-900 dark:text-slate-100">
                            {entry.text}
                          </td>
                          <td className="px-4 py-2 text-right font-mono tabular-nums text-slate-600 dark:text-slate-400">
                            {entry.byteLength}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {filteredTextEntries.length > 500 && (
                    <div className="border-t border-slate-200 bg-slate-50 px-4 py-2 text-[11px] text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                      Mostrando las primeras 500 de {filteredTextEntries.length} cadenas. Exporta en .TXT / .CSV / .JSON para consultar todas.
                    </div>
                  )}
                </div>
              </section>
            </div>
          )}
        </div>
      )}

      {/* ==================== TAB 4: QUICKBMS SCRIPT GENERATOR ==================== */}
      {subTab === 'quickbms' && (
        <QuickBmsPanel
          classifiedItems={classifiedItems}
          externalTarget={quickBmsTarget}
          onOpenInDecryptor={(blob, fileName, path) =>
            void handleOpenFromQuickBmsInDecryptor(blob, fileName, path)
          }
        />
      )}

      {/* ==================== TAB 5: OREIMO TRANSLATION PATCH GENERATOR ==================== */}
      {subTab === 'oreimo_patch' && (
        <OreimoPatchPanel
          classifiedItems={classifiedItems}
          analysis={analysis}
          onReplaceClassifiedItems={(items, banner) => {
            setClassifiedItems(items);
            setSourceBanner(banner);
          }}
          onSendPatchedToIsoPacker={onSendPatchedToIsoPacker}
        />
      )}
    </div>
  );
};
