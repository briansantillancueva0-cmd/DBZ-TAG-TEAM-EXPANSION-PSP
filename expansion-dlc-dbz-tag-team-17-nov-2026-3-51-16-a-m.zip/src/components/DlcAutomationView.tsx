import React, { useMemo, useState } from 'react';
import { Check, Copy, Download } from 'lucide-react';
import { buildIsoExpanderPythonScript } from '../lib/isoExpander';
import { buildPck1PythonUnpackerScript } from '../lib/pck1Parser';
import { buildSequentialDlcPythonScript } from '../lib/pythonDlcGenerator';
import { buildObjOptimizerPythonScript } from '../lib/ramExpander';

type AutomationMode = 'dlc_seq' | 'pck1_unpack' | 'iso_expand' | 'obj_opt';

function downloadTextFile(content: string, filename: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export const DlcAutomationView: React.FC = () => {
  const [mode, setMode] = useState<AutomationMode>('dlc_seq');
  const [charStart, setCharStart] = useState(77);
  const [charEnd, setCharEnd] = useState(256);
  const [mapStart, setMapStart] = useState(11);
  const [mapEnd, setMapEnd] = useState(46);
  const [alignFileTo2048, setAlignFileTo2048] = useState(true);
  const [alignSubBlocksTo2048, setAlignSubBlocksTo2048] = useState(false);
  const [createMissingStubs, setCreateMissingStubs] = useState(false);
  const [copiedPython, setCopiedPython] = useState(false);

  const dlcScript = useMemo(
    () =>
      buildSequentialDlcPythonScript({
        charStart,
        charEnd,
        mapStart,
        mapEnd,
        alignFileTo2048,
        alignSubBlocksTo2048,
        createMissingStubs,
      }),
    [charStart, charEnd, mapStart, mapEnd, alignFileTo2048, alignSubBlocksTo2048, createMissingStubs]
  );

  const pck1Script = useMemo(() => buildPck1PythonUnpackerScript(), []);
  const isoScript = useMemo(() => buildIsoExpanderPythonScript(), []);
  const objOptScript = useMemo(() => buildObjOptimizerPythonScript(), []);

  const activeScript =
    mode === 'dlc_seq'
      ? dlcScript
      : mode === 'pck1_unpack'
      ? pck1Script
      : mode === 'iso_expand'
      ? isoScript
      : objOptScript;
  const activeFilename =
    mode === 'dlc_seq'
      ? 'generar_dlc_secuencial_iso.py'
      : mode === 'pck1_unpack'
      ? 'descomprimir_pck1_subcarpetas.py'
      : mode === 'iso_expand'
      ? 'expandir_iso_subcarpetas.py'
      : 'optimizar_obj_psp.py';

  const charCount = Math.max(0, Math.min(256, charEnd) - Math.max(0, charStart) + 1);
  const mapCount = Math.max(0, Math.min(99, mapEnd) - Math.max(0, mapStart) + 1);

  const handleCopyPython = async () => {
    try {
      await navigator.clipboard.writeText(activeScript);
      setCopiedPython(true);
      setTimeout(() => setCopiedPython(false), 1500);
    } catch {
      // Ignore clipboard failures
    }
  };

  return (
    <div className="space-y-6">
      {/* Mode Switcher */}
      <div className="inline-flex flex-wrap items-center gap-1 rounded-lg bg-slate-200/70 p-1 dark:bg-slate-800">
        <button
          type="button"
          onClick={() => setMode('dlc_seq')}
          className={`min-h-[38px] rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            mode === 'dlc_seq'
              ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
              : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
          }`}
        >
          Generador DLC Secuencial (2048 B ISO)
        </button>
        <button
          type="button"
          onClick={() => setMode('pck1_unpack')}
          className={`min-h-[38px] rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            mode === 'pck1_unpack'
              ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
              : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
          }`}
        >
          Descomprimidor PCK1 en Subcarpetas (.py)
        </button>
        <button
          type="button"
          onClick={() => setMode('iso_expand')}
          className={`min-h-[38px] rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            mode === 'iso_expand'
              ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
              : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
          }`}
        >
          Expansor ISO 9660 + MOD/DLC (.py)
        </button>
        <button
          type="button"
          onClick={() => setMode('obj_opt')}
          className={`min-h-[38px] rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            mode === 'obj_opt'
              ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
              : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
          }`}
        >
          Optimizador .OBJ PSP (&lt;8 MB RAM)
        </button>
      </div>

      {/* Header + Actions */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-3xl">
            <h2 className="text-xl font-semibold text-slate-900 dark:text-white [text-wrap:balance]">
              {mode === 'dlc_seq'
                ? 'Automatización DLC · Generador Python (CHARxxx.BIN y MAPSxx.BIN)'
                : mode === 'pck1_unpack'
                ? 'Descomprimidor Recursivo Python de PCK1 / PACKFILE.BIN en Subcarpetas'
                : mode === 'iso_expand'
                ? 'Expansor ISO 9660 Streaming para Carpeta /PSP_GAME/MOD/DLC/'
                : 'Optimizador de Modelos .OBJ para PSP (< 8 MB por luchador)'}
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
              {mode === 'dlc_seq' ? (
                <>
                  Script Python listo para copiar y pegar que automatiza la generación individual de <span className="font-mono">CHAR077.BIN</span>–<span className="font-mono">CHAR256.BIN</span> y <span className="font-mono">MAPS11.BIN</span>–<span className="font-mono">MAPS46.BIN</span> en <span className="font-mono">PSP_GAME/MOD/DLC/</span>, aplicando alineación a <span className="font-mono">16 bytes (0x10)</span> y relleno exacto a sectores ISO 9660 de <span className="font-mono">2048 bytes (0x800)</span>.
                </>
              ) : mode === 'pck1_unpack' ? (
                <>
                  Extrae tablas <span className="font-mono">PCK1</span> y bloques <span className="font-mono">Zlib</span> en subcarpetas por categoría: <span className="font-mono">Personajes/</span>, <span className="font-mono">Mapas/</span>, <span className="font-mono">Minimapas/</span>, <span className="font-mono">Modelos_OBJ/</span>, <span className="font-mono">Musica_AT3/</span> e <span className="font-mono">Imagenes/</span>.
                </>
              ) : mode === 'iso_expand' ? (
                <>
                  Fusiona una carpeta local con subcarpetas (<span className="font-mono">PSP_GAME/MOD/DLC/PERSONAJES</span>, <span className="font-mono">CASILLAS_ROSTER</span>, <span className="font-mono">BARRA_DE_VIDA</span>, <span className="font-mono">LOBBY</span>, <span className="font-mono">MUSICA_AT3</span>, <span className="font-mono">OBJ</span>, <span className="font-mono">VIDEOS_PMF</span>) dentro de una <span className="font-mono">.ISO</span> UMD completa recalculando PVD, tablas L/M y permisos <span className="font-mono">0x02 / 0x00</span>.
                </>
              ) : (
                <>
                  Audita vértices, caras y texturas de tus archivos <span className="font-mono">.OBJ</span> antes de convertirlos a <span className="font-mono">.GMO</span>, reduciendo mallas pesadas para mantener cada luchador por debajo de 8 MB en batallas Tag Team 2vs2.
                </>
              )}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => void handleCopyPython()}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              {copiedPython ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
              {copiedPython ? 'Copiado' : 'Copiar script Python'}
            </button>
            <button
              type="button"
              onClick={() => downloadTextFile(activeScript, activeFilename)}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              Descargar .PY
            </button>
          </div>
        </div>

        {mode === 'dlc_seq' && (
          <>
            <div className="mt-6 grid grid-cols-1 gap-4 border-t border-slate-100 pt-5 sm:grid-cols-2 lg:grid-cols-4 dark:border-slate-800">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                  Personaje inicial (CHARxxx)
                </label>
                <input
                  type="number"
                  min={0}
                  max={255}
                  value={charStart}
                  onChange={(e) => setCharStart(Math.max(0, Math.min(255, Number(e.target.value) || 0)))}
                  className="mt-1.5 min-h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-sm text-slate-900 tabular-nums focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                  Personaje final ({charCount} slots)
                </label>
                <input
                  type="number"
                  min={charStart}
                  max={256}
                  value={charEnd}
                  onChange={(e) => setCharEnd(Math.max(charStart, Math.min(256, Number(e.target.value) || charStart)))}
                  className="mt-1.5 min-h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-sm text-slate-900 tabular-nums focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                  Mapa inicial (MAPSxx)
                </label>
                <input
                  type="number"
                  min={0}
                  max={99}
                  value={mapStart}
                  onChange={(e) => setMapStart(Math.max(0, Math.min(99, Number(e.target.value) || 0)))}
                  className="mt-1.5 min-h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-sm text-slate-900 tabular-nums focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                  Mapa final ({mapCount} slots)
                </label>
                <input
                  type="number"
                  min={mapStart}
                  max={99}
                  value={mapEnd}
                  onChange={(e) => setMapEnd(Math.max(mapStart, Math.min(99, Number(e.target.value) || mapStart)))}
                  className="mt-1.5 min-h-[42px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-sm text-slate-900 tabular-nums focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>
            </div>

            <div className="mt-4 flex flex-wrap gap-6 border-t border-slate-100 pt-4 text-xs dark:border-slate-800">
              <label className="inline-flex min-h-[40px] items-center gap-2 text-slate-700 dark:text-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={alignFileTo2048}
                  onChange={(e) => setAlignFileTo2048(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <span>Alinear tamaño final de cada .BIN a sectores ISO de 2048 B</span>
              </label>

              <label className="inline-flex min-h-[40px] items-center gap-2 text-slate-700 dark:text-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={alignSubBlocksTo2048}
                  onChange={(e) => setAlignSubBlocksTo2048(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <span>Alinear también cabecera y cada traje/mapa interno a 2048 B</span>
              </label>

              <label className="inline-flex min-h-[40px] items-center gap-2 text-slate-700 dark:text-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={createMissingStubs}
                  onChange={(e) => setCreateMissingStubs(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
                <span>Crear archivos stub alineados si falta alguna carpeta</span>
              </label>
            </div>
          </>
        )}
      </section>

      {/* Copy-pasteable Python Script Viewer */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
          <span>
            <span className="font-mono font-semibold text-slate-900 dark:text-white">
              {activeFilename}
            </span>
            <span aria-hidden="true"> · </span>
            <span>Python 3.10+ (solo librería estándar, sin dependencias externas)</span>
          </span>
          <span className="font-mono text-[11px]">
            {mode === 'dlc_seq'
              ? `python3 ${activeFilename} --src ./dlc_source --out ./PSP_GAME/MOD/DLC`
              : mode === 'pck1_unpack'
              ? `python3 ${activeFilename} PACKFILE.BIN --out ./PCK1_EXTRAIDO`
              : mode === 'iso_expand'
              ? `python3 ${activeFilename} BASE.ISO ./MOD_CARPETA --out ./PSP_MOD_EXPANDIDA.ISO`
              : `python3 ${activeFilename} ./MOD/DLC/OBJ --max-tris 6500`}
          </span>
        </div>

        <pre className="mt-3 max-h-[540px] overflow-auto rounded-xl border border-slate-200 bg-slate-950 p-4 font-mono text-xs leading-relaxed text-slate-100 dark:border-slate-800">
          {activeScript}
        </pre>
      </section>
    </div>
  );
};
