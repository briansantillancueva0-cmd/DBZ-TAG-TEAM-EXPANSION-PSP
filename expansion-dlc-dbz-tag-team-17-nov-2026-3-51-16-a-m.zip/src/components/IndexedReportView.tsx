import React, { useMemo, useState } from 'react';
import { Check, Copy, Download, FileText, Printer } from 'lucide-react';
import { buildGameAssetReport } from '../lib/assetClassifier';
import { scanMipsIdLimits, validateIsoLbaAlignment, verifyDisc0Paths } from '../lib/dlcVerifier';
import { buildIndexedReport } from '../lib/reportGenerator';
import type { EbootAnalysis } from '../lib/types';

interface IndexedReportViewProps {
  analysis: EbootAnalysis;
  onJumpToHex: (offset: number) => void;
}

function hex(val: number | null, width = 8): string {
  if (val === null || Number.isNaN(val)) return 'N/A';
  return `0x${(val >>> 0).toString(16).toUpperCase().padStart(width, '0')}`;
}

function downloadFile(content: string, filename: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export const IndexedReportView: React.FC<IndexedReportViewProps> = ({ analysis, onJumpToHex }) => {
  const report = useMemo(() => buildIndexedReport(analysis), [analysis]);
  const assetReport = useMemo(() => buildGameAssetReport(analysis), [analysis]);
  const disc0Checks = useMemo(() => verifyDisc0Paths(analysis), [analysis]);
  const isoAlignment = useMemo(
    () => (analysis.isoInfo ? validateIsoLbaAlignment(analysis.isoInfo) : null),
    [analysis.isoInfo]
  );
  const mipsLimits = useMemo(() => scanMipsIdLimits(analysis), [analysis]);
  const dlcIsoFiles = useMemo(
    () =>
      analysis.isoInfo?.files.filter(
        (f) => !f.isDirectory && f.path.toUpperCase().startsWith('/PSP_GAME/DLC/')
      ) ?? [],
    [analysis.isoInfo]
  );
  const [viewMode, setViewMode] = useState<'structured' | 'plain'>('structured');
  const [copied, setCopied] = useState(false);

  const safeSlug = (analysis.sfoInfo?.discId || analysis.sourceName)
    .replace(/[^a-zA-Z0-9_-]+/g, '_')
    .slice(0, 36);

  const handleCopyReport = async () => {
    try {
      await navigator.clipboard.writeText(report.plainText);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      // Ignore clipboard failures
    }
  };

  return (
    <div className="space-y-6">
      {/* Export & View Toolbar */}
      <div className="no-print flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
          <button
            type="button"
            onClick={() => setViewMode('structured')}
            className={`min-h-[36px] rounded-md px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              viewMode === 'structured'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
            }`}
          >
            Vista Indexada
          </button>
          <button
            type="button"
            onClick={() => setViewMode('plain')}
            className={`min-h-[36px] rounded-md px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              viewMode === 'plain'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
            }`}
          >
            Texto Plano (.TXT)
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleCopyReport}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
            {copied ? 'Copiado' : 'Copiar'}
          </button>
          <button
            type="button"
            onClick={() => downloadFile(report.plainText, `INFORME_${safeSlug}.txt`, 'text/plain;charset=utf-8')}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            .TXT
          </button>
          <button
            type="button"
            onClick={() => downloadFile(report.markdown, `INFORME_${safeSlug}.md`, 'text/markdown;charset=utf-8')}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <FileText className="h-3.5 w-3.5" />
            .MD
          </button>
          <button
            type="button"
            onClick={() => downloadFile(report.csv, `DIRECCIONES_${safeSlug}.csv`, 'text/csv;charset=utf-8')}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            .CSV
          </button>
          <button
            type="button"
            onClick={() => downloadFile(report.json, `INFORME_${safeSlug}.json`, 'application/json;charset=utf-8')}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            .JSON
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Printer className="h-3.5 w-3.5" />
            Imprimir / PDF
          </button>
        </div>
      </div>

      {viewMode === 'plain' ? (
        <pre className="overflow-x-auto rounded-xl border border-slate-200 bg-white p-5 font-mono text-xs leading-6 text-slate-800 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200">
          {report.plainText}
        </pre>
      ) : (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Index / Table of Contents Rail */}
          <aside className="no-print lg:col-span-4 xl:col-span-3">
            <div className="sticky top-20 rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Índice del Informe
              </h3>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Generado: {report.generatedAt}
              </p>
              <nav className="mt-4 space-y-1">
                {report.toc.map((entry) => (
                  <a
                    key={entry.id}
                    href={`#${entry.id}`}
                    className="flex items-baseline justify-between gap-2 rounded-lg px-2.5 py-2 text-xs text-slate-700 transition-colors hover:bg-slate-100 hover:text-slate-950 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white"
                  >
                    <span className="truncate font-medium">
                      <span className="font-mono text-blue-600 dark:text-blue-400">{entry.code}</span>{' '}
                      {entry.title}
                    </span>
                    <span className="shrink-0 font-mono text-[11px] text-slate-400 tabular-nums">
                      {entry.countLabel}
                    </span>
                  </a>
                ))}
              </nav>
            </div>
          </aside>

          {/* Report Sections */}
          <div className="space-y-6 lg:col-span-8 xl:col-span-9">
            {/* 1.0 Resumen */}
            <section id="sec-1" className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <div className="text-xs font-mono text-blue-600 dark:text-blue-400">Sección 1.0</div>
              <h3 className="mt-1 text-lg font-semibold text-slate-900 dark:text-white">
                Resumen Ejecutivo y Propósito del Binario
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                El binario <span className="font-mono text-slate-900 dark:text-white">{analysis.targetBinaryPath}</span> actúa como ejecutable principal de arranque en la PSP. Su función es inicializar los controladores de pantalla, entradas y sistema de archivos, enlazar los módulos del sistema mediante stubs NID y cargar los recursos del juego en memoria RAM.
              </p>
              <dl className="mt-4 grid grid-cols-1 gap-3 border-t border-slate-100 pt-4 text-xs sm:grid-cols-3 dark:border-slate-800">
                <div>
                  <dt className="text-slate-500">Formato detectado</dt>
                  <dd className="mt-0.5 font-semibold text-slate-900 dark:text-white">{analysis.formatLabel}</dd>
                </div>
                <div>
                  <dt className="text-slate-500">Tamaño del ejecutable</dt>
                  <dd className="mt-0.5 font-mono font-semibold text-slate-900 tabular-nums dark:text-white">
                    {analysis.fileSize.toLocaleString('es-ES')} bytes
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500">Entry Point (CPU MIPS)</dt>
                  <dd className="mt-0.5 font-mono font-semibold text-blue-600 tabular-nums dark:text-blue-400">
                    {analysis.elfHeader
                      ? hex(analysis.elfHeader.entryPoint)
                      : analysis.pspHeader
                      ? hex(analysis.pspHeader.bootEntry)
                      : 'N/A'}
                  </dd>
                </div>
              </dl>
              <ul className="mt-4 space-y-1.5 border-t border-slate-100 pt-4 text-xs text-slate-600 dark:border-slate-800 dark:text-slate-300">
                {analysis.analyzedNotes.map((note, idx) => (
                  <li key={idx}>• {note}</li>
                ))}
              </ul>
            </section>

            {/* 2.0 ISO & SFO */}
            <section id="sec-2" className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <div className="text-xs font-mono text-blue-600 dark:text-blue-400">Sección 2.0</div>
              <h3 className="mt-1 text-lg font-semibold text-slate-900 dark:text-white">
                Metadatos de ISO 9660 y PARAM.SFO
              </h3>
              {analysis.sfoInfo || analysis.isoInfo ? (
                <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 text-xs">
                  {analysis.sfoInfo && (
                    <dl className="space-y-2 border-t border-slate-100 pt-3 dark:border-slate-800">
                      <div className="flex justify-between gap-2">
                        <dt className="text-slate-500">Título (TITLE)</dt>
                        <dd className="font-semibold text-slate-900 dark:text-white">{analysis.sfoInfo.title}</dd>
                      </div>
                      <div className="flex justify-between gap-2">
                        <dt className="text-slate-500">ID Disco (DISC_ID)</dt>
                        <dd className="font-mono text-slate-900 dark:text-white">{analysis.sfoInfo.discId}</dd>
                      </div>
                      <div className="flex justify-between gap-2">
                        <dt className="text-slate-500">Firmware PSP</dt>
                        <dd className="font-mono text-slate-900 dark:text-white">{analysis.sfoInfo.pspSystemVer}</dd>
                      </div>
                      <div className="flex justify-between gap-2">
                        <dt className="text-slate-500">Categoría</dt>
                        <dd className="text-slate-900 dark:text-white">{analysis.sfoInfo.categoryLabel}</dd>
                      </div>
                    </dl>
                  )}
                  {analysis.isoInfo && (
                    <dl className="space-y-2 border-t border-slate-100 pt-3 dark:border-slate-800">
                      <div className="flex justify-between gap-2">
                        <dt className="text-slate-500">Etiqueta Volumen</dt>
                        <dd className="font-mono text-slate-900 dark:text-white">{analysis.isoInfo.volume.volumeId}</dd>
                      </div>
                      <div className="flex justify-between gap-2">
                        <dt className="text-slate-500">Publicador</dt>
                        <dd className="text-slate-900 dark:text-white">{analysis.isoInfo.volume.publisher}</dd>
                      </div>
                      <div className="flex justify-between gap-2">
                        <dt className="text-slate-500">Fecha Creación</dt>
                        <dd className="font-mono text-slate-900 dark:text-white">{analysis.isoInfo.volume.creationDate}</dd>
                      </div>
                      <div className="flex justify-between gap-2">
                        <dt className="text-slate-500">Contenido ISO</dt>
                        <dd className="font-mono text-slate-900 tabular-nums dark:text-white">
                          {analysis.isoInfo.totalFiles} archivos · {analysis.isoInfo.totalDirs} carpetas
                        </dd>
                      </div>
                    </dl>
                  )}
                </div>
              ) : (
                <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
                  Se analizó el binario directamente sin imagen ISO contenedora ni PARAM.SFO adjunto.
                </p>
              )}
            </section>

            {/* 3.0 Cabecera y sceModuleInfo */}
            <section id="sec-3" className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <div className="text-xs font-mono text-blue-600 dark:text-blue-400">Sección 3.0</div>
              <h3 className="mt-1 text-lg font-semibold text-slate-900 dark:text-white">
                Cabecera Binaria y Estructura sceModuleInfo
              </h3>
              {analysis.pspHeader && (
                <dl className="mt-4 grid grid-cols-1 gap-3 border-t border-slate-100 pt-4 text-xs sm:grid-cols-2 dark:border-slate-800">
                  <div>
                    <dt className="text-slate-500">Nombre interno (~PSP)</dt>
                    <dd className="font-mono font-semibold text-slate-900 dark:text-white">{analysis.pspHeader.modName}</dd>
                  </div>
                  <div>
                    <dt className="text-slate-500">Devkit SDK</dt>
                    <dd className="font-mono text-slate-900 dark:text-white">{analysis.pspHeader.devkitVersionLabel}</dd>
                  </div>
                  <div>
                    <dt className="text-slate-500">Atributos</dt>
                    <dd className="text-slate-900 dark:text-white">{analysis.pspHeader.modAttrLabels.join(' · ')}</dd>
                  </div>
                  <div>
                    <dt className="text-slate-500">Estado contenedor</dt>
                    <dd className="text-slate-900 dark:text-white">{analysis.pspHeader.compAttrLabels.join(' · ')}</dd>
                  </div>
                </dl>
              )}
              {analysis.moduleInfo && (
                <dl className="mt-4 grid grid-cols-1 gap-3 border-t border-slate-100 pt-4 text-xs sm:grid-cols-3 dark:border-slate-800">
                  <div>
                    <dt className="text-slate-500">Módulo (sceModuleInfo)</dt>
                    <dd className="font-mono font-semibold text-slate-900 dark:text-white">
                      {analysis.moduleInfo.name} v{analysis.moduleInfo.versionMajor}.{analysis.moduleInfo.versionMinor}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-slate-500">Offset / RAM</dt>
                    <dd className="font-mono text-blue-600 tabular-nums dark:text-blue-400">
                      {hex(analysis.moduleInfo.fileOffset, 6)} / {hex(analysis.moduleInfo.ramAddress)}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-slate-500">Puntero Global ($gp)</dt>
                    <dd className="font-mono text-slate-900 tabular-nums dark:text-white">
                      {hex(analysis.moduleInfo.gpValue)}
                    </dd>
                  </div>
                </dl>
              )}
              {!analysis.pspHeader && !analysis.moduleInfo && (
                <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
                  No se detectó cabecera ~PSP ni bloque sceModuleInfo en las posiciones estándar.
                </p>
              )}
            </section>

            {/* 4.0 Mapa de Memoria */}
            <section id="sec-4" className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <div className="text-xs font-mono text-blue-600 dark:text-blue-400">Sección 4.0</div>
              <h3 className="mt-1 text-lg font-semibold text-slate-900 dark:text-white">
                Mapa de Memoria: Segmentos y Secciones ELF32
              </h3>
              {analysis.sections.length > 0 ? (
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full border-collapse text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-800">
                        <th className="py-2 pr-3 font-semibold">Sección</th>
                        <th className="py-2 px-3 font-semibold">Offset</th>
                        <th className="py-2 px-3 font-semibold">RAM Virtual</th>
                        <th className="py-2 px-3 font-semibold">Perm</th>
                        <th className="py-2 px-3 font-semibold">Tamaño</th>
                        <th className="py-2 pl-3 font-semibold">Función en PSP</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {analysis.sections.map((sec) => (
                        <tr key={sec.index}>
                          <td className="py-2 pr-3 font-mono font-semibold text-slate-900 dark:text-white">
                            {sec.name}
                          </td>
                          <td className="py-2 px-3 font-mono tabular-nums">
                            {sec.offset > 0 ? (
                              <button
                                type="button"
                                onClick={() => onJumpToHex(sec.offset)}
                                className="text-blue-600 underline-offset-2 hover:underline dark:text-blue-400 cursor-pointer"
                              >
                                {hex(sec.offset, 6)}
                              </button>
                            ) : (
                              '—'
                            )}
                          </td>
                          <td className="py-2 px-3 font-mono tabular-nums text-slate-800 dark:text-slate-200">
                            {sec.vaddr > 0 ? hex(sec.vaddr) : '—'}
                          </td>
                          <td className="py-2 px-3 font-mono text-slate-500">{sec.flagsText}</td>
                          <td className="py-2 px-3 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                            {sec.size.toLocaleString('es-ES')} B
                          </td>
                          <td className="py-2 pl-3 text-slate-600 dark:text-slate-400">{sec.purpose}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
                  No hay secciones ELF descifradas expuestas para mapear.
                </p>
              )}
            </section>

            {/* 5.0 Librerías */}
            <section id="sec-5" className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <div className="text-xs font-mono text-blue-600 dark:text-blue-400">Sección 5.0</div>
              <h3 className="mt-1 text-lg font-semibold text-slate-900 dark:text-white">
                Librerías y Funciones del Sistema PSP (NIDs)
              </h3>
              {analysis.libraries.length > 0 ? (
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full border-collapse text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-800">
                        <th className="py-2 pr-3 font-semibold">Librería</th>
                        <th className="py-2 px-3 font-semibold">NIDs</th>
                        <th className="py-2 px-3 font-semibold">Stub RAM</th>
                        <th className="py-2 pl-3 font-semibold">Qué controla</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {analysis.libraries.map((lib, idx) => (
                        <tr key={`${lib.name}-${idx}`}>
                          <td className="py-2 pr-3 font-mono font-semibold text-slate-900 dark:text-white">
                            {lib.name}
                          </td>
                          <td className="py-2 px-3 font-mono tabular-nums">{lib.nidCount}</td>
                          <td className="py-2 px-3 font-mono tabular-nums text-blue-600 dark:text-blue-400">
                            {hex(lib.stubAddr)}
                          </td>
                          <td className="py-2 pl-3 text-slate-600 dark:text-slate-300">{lib.purpose}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
                  Sin tablas .lib.stub expuestas en este binario.
                </p>
              )}
            </section>

            {/* 6.0 Índice de Direcciones Clave */}
            <section id="sec-6" className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <div className="text-xs font-mono text-blue-600 dark:text-blue-400">Sección 6.0</div>
              <h3 className="mt-1 text-lg font-semibold text-slate-900 dark:text-white">
                Índice de Direcciones Clave, Subrutinas y Cadenas ({analysis.addresses.length})
              </h3>
              <div className="mt-4 overflow-x-auto">
                <table className="w-full border-collapse text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-800">
                      <th className="py-2 pr-2 font-semibold">#</th>
                      <th className="py-2 px-2 font-semibold">Offset</th>
                      <th className="py-2 px-2 font-semibold">RAM</th>
                      <th className="py-2 px-2 font-semibold">Categoría</th>
                      <th className="py-2 pl-2 font-semibold">Hallazgo</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {analysis.addresses.slice(0, 80).map((item) => (
                      <tr key={`${item.index}-${item.label}`}>
                        <td className="py-2 pr-2 font-mono text-slate-400 tabular-nums">
                          {String(item.index).padStart(3, '0')}
                        </td>
                        <td className="py-2 px-2 font-mono tabular-nums">
                          {item.fileOffset !== null ? (
                            <button
                              type="button"
                              onClick={() => onJumpToHex(item.fileOffset!)}
                              className="text-blue-600 hover:underline dark:text-blue-400 cursor-pointer"
                            >
                              {hex(item.fileOffset, 6)}
                            </button>
                          ) : (
                            '—'
                          )}
                        </td>
                        <td className="py-2 px-2 font-mono tabular-nums text-slate-800 dark:text-slate-200">
                          {hex(item.ramAddress)}
                        </td>
                        <td className="py-2 px-2 whitespace-nowrap text-slate-600 dark:text-slate-400">
                          {item.categoryLabel}
                        </td>
                        <td className="max-w-md truncate py-2 pl-2 font-mono text-slate-900 dark:text-slate-100">
                          {item.label}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {analysis.addresses.length > 80 && (
                <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">
                  Mostrando los primeros 80 hallazgos indexados en vista HTML. Descarga .TXT, .MD o .CSV arriba para obtener las {analysis.addresses.length} direcciones completas.
                </p>
              )}
            </section>

            {/* 7.0 Árbol ISO */}
            <section id="sec-7" className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <div className="text-xs font-mono text-blue-600 dark:text-blue-400">Sección 7.0</div>
              <h3 className="mt-1 text-lg font-semibold text-slate-900 dark:text-white">
                Árbol de Contenidos del Disco ISO
              </h3>
              {analysis.isoInfo ? (
                <div className="mt-4 max-h-80 overflow-y-auto overflow-x-auto">
                  <table className="w-full border-collapse text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-800">
                        <th className="py-2 pr-3 font-semibold">Ruta ISO 9660</th>
                        <th className="py-2 px-3 font-semibold">LBA</th>
                        <th className="py-2 px-3 font-semibold">Offset ISO</th>
                        <th className="py-2 pl-3 text-right font-semibold">Tamaño</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {analysis.isoInfo.files.slice(0, 150).map((f) => (
                        <tr key={`${f.lba}-${f.path}`}>
                          <td className="py-1.5 pr-3 font-mono text-slate-800 dark:text-slate-200">
                            {f.isDirectory ? `${f.path}/` : f.path}
                          </td>
                          <td className="py-1.5 px-3 font-mono tabular-nums text-slate-500">{f.lba}</td>
                          <td className="py-1.5 px-3 font-mono tabular-nums text-slate-500">
                            {hex(f.byteOffset, 8)}
                          </td>
                          <td className="py-1.5 pl-3 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                            {f.isDirectory ? 'DIR' : `${f.size.toLocaleString('es-ES')} B`}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
                  No se cargó una imagen ISO completa para listar su árbol de directorios.
                </p>
              )}
            </section>

            {/* 8.0 Personajes, Mapas, Texturas, Música y Minimapas */}
            <section id="sec-8" className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <div className="text-xs font-mono text-blue-600 dark:text-blue-400">Sección 8.0</div>
              <h3 className="mt-1 text-lg font-semibold text-slate-900 dark:text-white">
                Personajes, Mapas, Texturas, Música y Minimapas ({assetReport.totalCount} activos)
              </h3>
              <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5 text-xs">
                {assetReport.summaries.map((sum) => (
                  <div
                    key={sum.category}
                    className="rounded-lg border border-slate-200 p-3 dark:border-slate-800"
                  >
                    <div className="font-semibold text-slate-900 dark:text-white">{sum.label}</div>
                    <div className="mt-1 font-mono text-lg font-bold text-blue-600 tabular-nums dark:text-blue-400">
                      {sum.count}
                    </div>
                    <div className="mt-0.5 font-mono text-[11px] text-slate-500 tabular-nums">
                      {sum.isoFileCount} ISO · {sum.ebootRefCount} EBOOT
                    </div>
                  </div>
                ))}
              </div>
              {assetReport.items.length > 0 && (
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full border-collapse text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-800">
                        <th className="py-2 pr-2 font-semibold">#</th>
                        <th className="py-2 px-2 font-semibold">Categoría</th>
                        <th className="py-2 px-2 font-semibold">Origen</th>
                        <th className="py-2 px-2 font-semibold">Recurso / Ruta</th>
                        <th className="py-2 pl-2 text-right font-semibold">Tamaño</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {assetReport.items.slice(0, 80).map((item) => (
                        <tr key={`${item.index}-${item.pathOrSymbol}`}>
                          <td className="py-1.5 pr-2 font-mono text-slate-400 tabular-nums">
                            {String(item.index).padStart(3, '0')}
                          </td>
                          <td className="py-1.5 px-2 whitespace-nowrap text-slate-700 dark:text-slate-300">
                            {item.categoryLabel}
                          </td>
                          <td className="py-1.5 px-2 font-mono text-[11px] text-slate-500">
                            {item.source === 'ISO_FILE' ? 'ISO' : 'EBOOT'}
                          </td>
                          <td className="max-w-md truncate py-1.5 px-2 font-mono text-slate-900 dark:text-slate-100">
                            {item.pathOrSymbol}
                          </td>
                          <td className="py-1.5 pl-2 text-right font-mono tabular-nums text-slate-600 dark:text-slate-400">
                            {item.sizeBytes !== null ? `${item.sizeBytes.toLocaleString('es-ES')} B` : 'Ref'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>

            {/* 9.0 Auditoría DLC, Rutas disc0:/, LBA ISO y Límites MIPS */}
            <section id="sec-9" className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <div className="text-xs font-mono text-blue-600 dark:text-blue-400">Sección 9.0</div>
              <h3 className="mt-1 text-lg font-semibold text-slate-900 dark:text-white">
                Auditoría DLC, Rutas disc0:/, Sectores LBA y Límites MIPS
              </h3>

              <dl className="mt-4 grid grid-cols-1 gap-3 border-t border-slate-100 pt-4 text-xs sm:grid-cols-4 dark:border-slate-800">
                <div>
                  <dt className="text-slate-500">Alineación ISO (PVD)</dt>
                  <dd className="mt-0.5 font-mono font-semibold text-slate-900 dark:text-white">
                    {isoAlignment
                      ? `${isoAlignment.logicalBlockSize} B · ${isoAlignment.isSizeMultipleOf2048 ? 'Múltiplo OK' : 'Revisar'}`
                      : 'Sin ISO'}
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500">Rutas disc0:/ y ms0:/</dt>
                  <dd className="mt-0.5 font-mono font-semibold text-slate-900 tabular-nums dark:text-white">
                    {disc0Checks.length} ({disc0Checks.filter((d) => d.nullTerminated).length} con 0x00)
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500">Límites MIPS (.text)</dt>
                  <dd className="mt-0.5 font-mono font-semibold text-slate-900 tabular-nums dark:text-white">
                    {mipsLimits.length} candidatos sltiu
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500">Archivos PSP_GAME/DLC/</dt>
                  <dd className="mt-0.5 font-mono font-semibold text-slate-900 tabular-nums dark:text-white">
                    {dlcIsoFiles.length} archivos
                  </dd>
                </div>
              </dl>

              {disc0Checks.length > 0 && (
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full border-collapse text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-800">
                        <th className="py-2 pr-2 font-semibold">Tipo</th>
                        <th className="py-2 px-2 font-semibold">Offset</th>
                        <th className="py-2 px-2 font-semibold">RAM</th>
                        <th className="py-2 px-2 font-semibold">0x00</th>
                        <th className="py-2 pl-2 font-semibold">Ruta en EBOOT.BIN</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {disc0Checks.slice(0, 40).map((d) => (
                        <tr key={`${d.index}-${d.fileOffset}`}>
                          <td className="py-1.5 pr-2 font-mono text-[11px] text-slate-500">{d.kind}</td>
                          <td className="py-1.5 px-2 font-mono tabular-nums">
                            <button
                              type="button"
                              onClick={() => onJumpToHex(d.fileOffset)}
                              className="text-blue-600 hover:underline dark:text-blue-400 cursor-pointer"
                            >
                              {hex(d.fileOffset, 6)}
                            </button>
                          </td>
                          <td className="py-1.5 px-2 font-mono tabular-nums text-slate-800 dark:text-slate-200">
                            {hex(d.ramAddress)}
                          </td>
                          <td className="py-1.5 px-2 font-mono">
                            <span className={d.nullTerminated ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}>
                              {d.nullTerminated ? 'OK' : 'FALTA'}
                            </span>
                          </td>
                          <td className="max-w-md truncate py-1.5 pl-2 font-mono text-slate-900 dark:text-slate-100">
                            {d.path}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {mipsLimits.length > 0 && (
                <div className="mt-4 overflow-x-auto border-t border-slate-100 pt-4 dark:border-slate-800">
                  <div className="mb-2 text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Instrucciones MIPS de límite detectadas en .text
                  </div>
                  <table className="w-full border-collapse text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-800">
                        <th className="py-1.5 pr-2 font-semibold">Rol</th>
                        <th className="py-1.5 px-2 font-semibold">Offset</th>
                        <th className="py-1.5 px-2 font-semibold">RAM</th>
                        <th className="py-1.5 px-2 font-semibold">Instrucción</th>
                        <th className="py-1.5 pl-2 font-semibold">Sugerencia</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {mipsLimits.slice(0, 40).map((m) => (
                        <tr key={`${m.index}-${m.fileOffset}`}>
                          <td className="py-1.5 pr-2 font-mono text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                            {m.likelyRole}
                          </td>
                          <td className="py-1.5 px-2 font-mono tabular-nums">
                            <button
                              type="button"
                              onClick={() => onJumpToHex(m.fileOffset)}
                              className="text-blue-600 hover:underline dark:text-blue-400 cursor-pointer"
                            >
                              {hex(m.fileOffset, 6)}
                            </button>
                          </td>
                          <td className="py-1.5 px-2 font-mono tabular-nums text-slate-800 dark:text-slate-200">
                            {hex(m.ramAddress)}
                          </td>
                          <td className="py-1.5 px-2 font-mono text-slate-900 dark:text-white">{m.mnemonic}</td>
                          <td className="py-1.5 pl-2 text-slate-600 dark:text-slate-400">{m.suggestion}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          </div>
        </div>
      )}
    </div>
  );
};
