import React, { useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Code2,
  Copy,
  Download,
  FileJson,
  MemoryStick,
  RefreshCw,
  Upload,
  Wand2,
} from 'lucide-react';
import {
  buildGameEngineCompatibleJson,
  generateRosterMappingScript,
  type RosterScriptGeneratorOptions,
  type RosterScriptTarget,
} from '../lib/dbzScriptGenerator';
import {
  buildDefaultDbzRoster256Json,
  computeDbzRosterRamEstimate,
  parseAndValidateDbzRosterJson,
  type DbzCharacterJsonEntry,
  type DbzRamBalanceConfig,
  type DbzRamLoadStrategy,
  type DbzRoster256JsonManifest,
  type DbzSlotMemoryPriority,
} from '../lib/dbzTagTeamExpander';

interface DbzCharacterJsonMapperProps {
  gameId: string;
  charCount: number;
  manifest: DbzRoster256JsonManifest;
  onChangeManifest: (next: DbzRoster256JsonManifest) => void;
}

function downloadText(content: string, filename: string) {
  const blob = new Blob([content], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export const DbzCharacterJsonMapper: React.FC<DbzCharacterJsonMapperProps> = ({
  gameId,
  charCount,
  manifest,
  onChangeManifest,
}) => {
  const [rawJson, setRawJson] = useState<string>(() => JSON.stringify(manifest, null, 2));
  const [selectedSlotId, setSelectedSlotId] = useState<number>(1);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [priorityFilter, setPriorityFilter] = useState<'ALL' | DbzSlotMemoryPriority>('ALL');
  const [pageIdx, setPageIdx] = useState<number>(0);
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);
  const jsonFileInputRef = useRef<HTMLInputElement | null>(null);

  const [scriptOpts, setScriptOpts] = useState<RosterScriptGeneratorOptions>({
    target: 'PYTHON',
    baseIndexMode: '0x00_BASED',
    dlcBasePath: 'disc0:/PSP_GAME/DLC',
    includeCanonicalNamesOnly: false,
    customSlotPrefix: 'CHAR',
  });
  const [scriptFeedback, setScriptFeedback] = useState<string | null>(null);

  const generatedScript = useMemo(
    () => generateRosterMappingScript(manifest, scriptOpts),
    [manifest, scriptOpts]
  );

  const generatedEngineJsonText = useMemo(
    () => JSON.stringify(buildGameEngineCompatibleJson(manifest, scriptOpts), null, 2),
    [manifest, scriptOpts]
  );

  const handleBatchApplyPathsFromScript = () => {
    const cleanBase = scriptOpts.dlcBasePath.replace(/\/+$/, '');
    const prefix = (scriptOpts.customSlotPrefix || 'CHAR').trim();
    const updatedChars = manifest.characters.map((ch, idx) => {
      const idNum = scriptOpts.baseIndexMode === '0x00_BASED' ? idx : idx + 1;
      const hexStr = `0x${idNum.toString(16).toUpperCase().padStart(2, '0')}`;
      const pad3 = String(idNum).padStart(3, '0');
      return {
        ...ch,
        hexId: hexStr,
        codeName: `${prefix}${pad3}`,
        modelBinPath: `${cleanBase}/PERSONAJES/${prefix}${pad3}.BIN`,
        gimPortraitPath: `${cleanBase}/CHIBIS/CHIBI${pad3}.GIM`,
        pmfSpecialPath: `${cleanBase}/VIDEOS/ULT_${pad3}.PMF`,
      };
    });
    syncManifestToJson({ ...manifest, characters: updatedChars });
    setScriptFeedback(
      `Regla masiva aplicada a ${updatedChars.length} IDs (${scriptOpts.baseIndexMode === '0x00_BASED' ? '0x00–0xFF' : '0x01–0x100'}) bajo ${cleanBase}.`
    );
  };

  const validation = useMemo(() => parseAndValidateDbzRosterJson(rawJson), [rawJson]);

  const ramStats = useMemo(
    () => computeDbzRosterRamEstimate(manifest.ramBalance, manifest.characters),
    [manifest]
  );

  const syncManifestToJson = (next: DbzRoster256JsonManifest) => {
    onChangeManifest(next);
    setRawJson(JSON.stringify(next, null, 2));
  };

  const handleReset256 = (ramMb: 64 | 128 | 256 = manifest.ramBalance.targetRamMb) => {
    const fresh = buildDefaultDbzRoster256Json(gameId, charCount, ramMb);
    syncManifestToJson(fresh);
    setSelectedSlotId(1);
    setPageIdx(0);
    setCopyFeedback(`Estructura JSON regenerada para ${fresh.totalSlots} personajes y perfil ${ramMb} MB.`);
  };

  const handleUpdateRamBalance = <K extends keyof DbzRamBalanceConfig>(
    key: K,
    value: DbzRamBalanceConfig[K]
  ) => {
    const next: DbzRoster256JsonManifest = {
      ...manifest,
      ramBalance: {
        ...manifest.ramBalance,
        [key]: value,
      },
    };
    syncManifestToJson(next);
  };

  const selectedEntry: DbzCharacterJsonEntry = useMemo(() => {
    return (
      manifest.characters.find((c) => c.id === selectedSlotId) ??
      manifest.characters[0] ?? {
        id: 1,
        hexId: '0x001',
        codeName: 'CHAR001',
        displayName: 'Goku #001',
        modelBinPath: 'disc0:/PSP_GAME/DLC/PERSONAJES/CHAR001.BIN',
        gimPortraitPath: 'disc0:/PSP_GAME/DLC/CHIBIS/CHIBI001.GIM',
        pmfSpecialPath: 'disc0:/PSP_GAME/DLC/VIDEOS/ULT_001.PMF',
        ramWeightMb: 6.2,
        priority: 'CORE',
        costumes: 8,
      }
    );
  }, [manifest.characters, selectedSlotId]);

  const handleUpdateCharacterField = <K extends keyof DbzCharacterJsonEntry>(
    field: K,
    value: DbzCharacterJsonEntry[K]
  ) => {
    const updatedChars = manifest.characters.map((c) => {
      if (c.id !== selectedEntry.id) return c;
      const nextItem = { ...c, [field]: value };
      if (field === 'id') {
        const numId = Math.max(1, Math.min(256, Number(value) || 1));
        nextItem.id = numId;
        nextItem.hexId = `0x${numId.toString(16).toUpperCase().padStart(3, '0')}`;
      }
      return nextItem;
    });
    const nextManifest: DbzRoster256JsonManifest = {
      ...manifest,
      characters: updatedChars,
    };
    syncManifestToJson(nextManifest);
    if (field === 'id') {
      setSelectedSlotId(Math.max(1, Math.min(256, Number(value) || 1)));
    }
  };

  const filteredChars = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    return manifest.characters.filter((c) => {
      if (priorityFilter !== 'ALL' && c.priority !== priorityFilter) return false;
      if (!q) return true;
      return (
        String(c.id).includes(q) ||
        c.hexId.toLowerCase().includes(q) ||
        c.codeName.toLowerCase().includes(q) ||
        c.displayName.toLowerCase().includes(q) ||
        c.pmfSpecialPath.toLowerCase().includes(q) ||
        c.gimPortraitPath.toLowerCase().includes(q)
      );
    });
  }, [manifest.characters, searchTerm, priorityFilter]);

  const PAGE_SIZE = 32;
  const totalPages = Math.max(1, Math.ceil(filteredChars.length / PAGE_SIZE));
  const clampedPage = Math.min(pageIdx, totalPages - 1);
  const pageItems = filteredChars.slice(clampedPage * PAGE_SIZE, (clampedPage + 1) * PAGE_SIZE);

  const handleApplyRawJson = () => {
    const res = parseAndValidateDbzRosterJson(rawJson);
    if (res.manifest) {
      onChangeManifest(res.manifest);
      setCopyFeedback(
        res.valid
          ? `JSON aplicado: ${res.manifest.characters.length} personajes válidos (${res.estimatedPeakRamMb} MB pico).`
          : `JSON aplicado con advertencias de validación (${res.errors.length}).`
      );
    }
  };

  const handleImportJsonFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    e.target.value = '';
    setRawJson(text);
    const res = parseAndValidateDbzRosterJson(text);
    if (res.manifest) {
      onChangeManifest(res.manifest);
      setCopyFeedback(`Archivo ${file.name} cargado (${res.manifest.characters.length} slots).`);
    } else {
      setCopyFeedback(`Error al analizar ${file.name}: revisa la sintaxis JSON.`);
    }
  };

  const handleCopyJson = async () => {
    try {
      await navigator.clipboard.writeText(rawJson);
      setCopyFeedback('JSON de 256 personajes copiado al portapapeles.');
    } catch {
      setCopyFeedback('No se pudo copiar automáticamente; usa el botón Descargar .JSON.');
    }
  };

  return (
    <div className="space-y-6">
      <input
        ref={jsonFileInputRef}
        type="file"
        accept=".json,application/json"
        onChange={(e) => void handleImportJsonFile(e)}
        className="hidden"
      />

      {/* RAM Balancing & Schema Header */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
          <div>
            <h3 className="flex items-center gap-2 text-base font-bold text-slate-900 dark:text-white">
              <FileJson className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              Mapeo JSON de 256 Personajes (.PMF / .GIM) y Balanceo de RAM
            </h3>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-300">
              Define la estructura JSON oficial para los {manifest.characters.length} slots: asigna <span className="font-mono">ID</span> único, modelo <span className="font-mono">.BIN/.GMO</span>, textura chibi <span className="font-mono">.GIM</span>, cinemática/ultimate <span className="font-mono">.PMF</span> y reglas de balanceo de RAM.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => handleReset256(manifest.ramBalance.targetRamMb)}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              Regenerar 256 Slots
            </button>
            <button
              type="button"
              onClick={() => jsonFileInputRef.current?.click()}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
            >
              <Upload className="h-3.5 w-3.5" />
              Importar .JSON
            </button>
            <button
              type="button"
              onClick={() => downloadText(rawJson, `${manifest.gameId}_ROSTER_MAP_256.json`)}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              Exportar ROSTER_MAP_256.json
            </button>
          </div>
        </div>

        {/* RAM Balancing Parameters Grid */}
        <div className="mt-4">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h4 className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-slate-700 dark:text-slate-300">
              <MemoryStick className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              Configuración de Balanceo de RAM (ramBalance)
            </h4>
            <div className="font-mono text-xs font-semibold tabular-nums">
              Pico Estimado:{' '}
              <span className={ramStats.fitsTargetRam ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}>
                {ramStats.estimatedPeakRamMb} MB / {ramStats.userRamCeilingMb} MB libres
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 text-xs">
            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                RAM Objetivo (MB)
              </label>
              <select
                value={manifest.ramBalance.targetRamMb}
                onChange={(e) =>
                  handleUpdateRamBalance('targetRamMb', Number(e.target.value) as 64 | 128 | 256)
                }
                className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                <option value={256}>256 MB (Mod PPSSPP 0x18000000)</option>
                <option value={128}>128 MB (Extendida)</option>
                <option value={64}>64 MB (PSP-2000/3000 Slim)</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                Estrategia de Carga
              </label>
              <select
                value={manifest.ramBalance.loadStrategy}
                onChange={(e) =>
                  handleUpdateRamBalance('loadStrategy', e.target.value as DbzRamLoadStrategy)
                }
                className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                <option value="STREAMING_ON_DEMAND">STREAMING_ON_DEMAND (Bajo RAM)</option>
                <option value="HYBRID_CACHE">HYBRID_CACHE (Balanceado)</option>
                <option value="PRELOAD_FIGHTERS">PRELOAD_FIGHTERS (256 MB Rápido)</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                Tope MB / Luchador
              </label>
              <input
                type="number"
                step="0.5"
                min={2}
                max={32}
                value={manifest.ramBalance.fighterRamCapMb}
                onChange={(e) =>
                  handleUpdateRamBalance('fighterRamCapMb', Number(e.target.value) || 8.5)
                }
                className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-slate-900 tabular-nums dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                Buffer Video .PMF (KB)
              </label>
              <input
                type="number"
                step="128"
                min={128}
                max={8192}
                value={manifest.ramBalance.pmfStreamBufferKb}
                onChange={(e) =>
                  handleUpdateRamBalance('pmfStreamBufferKb', Number(e.target.value) || 2048)
                }
                className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-slate-900 tabular-nums dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                Caché Chibis .GIM (MB)
              </label>
              <input
                type="number"
                step="1"
                min={1}
                max={64}
                value={manifest.ramBalance.chibiGimCacheMb}
                onChange={(e) =>
                  handleUpdateRamBalance('chibiGimCacheMb', Number(e.target.value) || 14)
                }
                className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-slate-900 tabular-nums dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                VRAM Texturas .GIM (MB)
              </label>
              <input
                type="number"
                step="2"
                min={4}
                max={128}
                value={manifest.ramBalance.vramTextureBudgetMb}
                onChange={(e) =>
                  handleUpdateRamBalance('vramTextureBudgetMb', Number(e.target.value) || 32)
                }
                className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-slate-900 tabular-nums dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                Luchadores Activos Tag
              </label>
              <select
                value={manifest.ramBalance.maxActiveFightersInRam}
                onChange={(e) =>
                  handleUpdateRamBalance('maxActiveFightersInRam', Number(e.target.value) === 2 ? 2 : 4)
                }
                className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                <option value={4}>4 Luchadores (2 vs 2 Tag)</option>
                <option value={2}>2 Luchadores (1 vs 1)</option>
              </select>
            </div>

            <div className="flex items-end pb-1">
              <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={manifest.ramBalance.unloadUnusedCostumes}
                  onChange={(e) => handleUpdateRamBalance('unloadUnusedCostumes', e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 accent-blue-600"
                />
                Liberar trajes inactivos
              </label>
            </div>
          </div>
        </div>
      </section>

      {/* Two-column workspace: Left = 256 Slots Selector + Field Editor; Right = Live JSON Schema */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <section className="lg:col-span-7 space-y-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          {/* Quick Editor for Selected Character Slot */}
          <div className="rounded-xl border border-blue-200 bg-blue-50/40 p-4 dark:border-blue-900/50 dark:bg-blue-950/20">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-blue-200/60 pb-2.5 dark:border-blue-900/40">
              <div className="text-sm font-bold text-slate-900 dark:text-white">
                Editor del Personaje #{String(selectedEntry.id).padStart(3, '0')} ({selectedEntry.hexId})
              </div>
              <span className="font-mono text-xs text-blue-700 dark:text-blue-300">
                {selectedEntry.codeName}
              </span>
            </div>

            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3 text-xs">
              <div>
                <label className="block font-medium text-slate-600 dark:text-slate-400">
                  ID Numérico (1–256)
                </label>
                <input
                  type="number"
                  min={1}
                  max={256}
                  value={selectedEntry.id}
                  onChange={(e) => handleUpdateCharacterField('id', Number(e.target.value) || 1)}
                  className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-600 dark:text-slate-400">
                  Código Interno
                </label>
                <input
                  type="text"
                  value={selectedEntry.codeName}
                  onChange={(e) => handleUpdateCharacterField('codeName', e.target.value)}
                  className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-600 dark:text-slate-400">
                  Nombre en Lobby 256
                </label>
                <input
                  type="text"
                  value={selectedEntry.displayName}
                  onChange={(e) => handleUpdateCharacterField('displayName', e.target.value)}
                  className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block font-medium text-slate-600 dark:text-slate-400">
                  Ruta Archivo Modelo / Paquete (.BIN / .GMO)
                </label>
                <input
                  type="text"
                  value={selectedEntry.modelBinPath}
                  onChange={(e) => handleUpdateCharacterField('modelBinPath', e.target.value)}
                  className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block font-medium text-slate-600 dark:text-slate-400">
                  Ruta Chibi / Textura Retrato (.GIM)
                </label>
                <input
                  type="text"
                  value={selectedEntry.gimPortraitPath}
                  onChange={(e) => handleUpdateCharacterField('gimPortraitPath', e.target.value)}
                  className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block font-medium text-slate-600 dark:text-slate-400">
                  Ruta Cinemática / Técnica Ultimate (.PMF)
                </label>
                <input
                  type="text"
                  value={selectedEntry.pmfSpecialPath}
                  onChange={(e) => handleUpdateCharacterField('pmfSpecialPath', e.target.value)}
                  className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-600 dark:text-slate-400">
                  Peso RAM (MB)
                </label>
                <input
                  type="number"
                  step="0.2"
                  min={1}
                  max={32}
                  value={selectedEntry.ramWeightMb}
                  onChange={(e) =>
                    handleUpdateCharacterField('ramWeightMb', Number(e.target.value) || 6.0)
                  }
                  className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-slate-900 tabular-nums dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-600 dark:text-slate-400">
                  Prioridad de Memoria
                </label>
                <select
                  value={selectedEntry.priority}
                  onChange={(e) =>
                    handleUpdateCharacterField('priority', e.target.value as DbzSlotMemoryPriority)
                  }
                  className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                >
                  <option value="CORE">CORE (Residente)</option>
                  <option value="DLC_HIGH">DLC_HIGH (Caché Rápida)</option>
                  <option value="STREAM_LAZY">STREAM_LAZY (Bajo Demanda)</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-600 dark:text-slate-400">
                  Trajes / Colores
                </label>
                <input
                  type="number"
                  min={1}
                  max={8}
                  value={selectedEntry.costumes}
                  onChange={(e) =>
                    handleUpdateCharacterField('costumes', Math.max(1, Math.min(8, Number(e.target.value) || 8)))
                  }
                  className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-slate-900 tabular-nums dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>
            </div>
          </div>

          {/* Search & Mini-grid of the 256 character slots */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setPageIdx(0);
              }}
              placeholder="Buscar ID, nombre, .PMF o .GIM..."
              className="min-h-[34px] flex-1 min-w-[180px] rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
            <select
              value={priorityFilter}
              onChange={(e) => {
                setPriorityFilter(e.target.value as 'ALL' | DbzSlotMemoryPriority);
                setPageIdx(0);
              }}
              className="min-h-[34px] rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="ALL">Todos ({manifest.characters.length})</option>
              <option value="CORE">CORE</option>
              <option value="DLC_HIGH">DLC_HIGH</option>
              <option value="STREAM_LAZY">STREAM_LAZY</option>
            </select>
          </div>

          {/* Interactive Mini-Slots Grid (32 per page = 8 pages for 256 chars) */}
          <div className="grid grid-cols-4 gap-1.5 sm:grid-cols-8">
            {pageItems.map((c) => {
              const active = c.id === selectedEntry.id;
              return (
                <button
                  key={`${c.id}-${c.codeName}`}
                  type="button"
                  onClick={() => setSelectedSlotId(c.id)}
                  title={`#${c.id} ${c.displayName}\nGIM: ${c.gimPortraitPath}\nPMF: ${c.pmfSpecialPath}\nRAM: ${c.ramWeightMb} MB`}
                  className={`rounded-lg border px-2 py-1.5 text-left transition-colors cursor-pointer ${
                    active
                      ? 'border-blue-600 bg-blue-600 text-white'
                      : 'border-slate-200 bg-slate-50 text-slate-800 hover:border-blue-400 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between font-mono text-[10px] font-bold">
                    <span>#{String(c.id).padStart(3, '0')}</span>
                    <span className={active ? 'text-blue-100' : 'text-slate-400'}>{c.ramWeightMb}M</span>
                  </div>
                  <div className="truncate text-[10px] font-medium">{c.displayName}</div>
                </button>
              );
            })}
          </div>

          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>
              Mostrando {pageItems.length} de {filteredChars.length} slots (Página {clampedPage + 1}/{totalPages})
            </span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                disabled={clampedPage === 0}
                onClick={() => setPageIdx((p) => Math.max(0, p - 1))}
                className="rounded border border-slate-200 px-2.5 py-1 disabled:opacity-40 dark:border-slate-700 cursor-pointer"
              >
                Anterior
              </button>
              <button
                type="button"
                disabled={clampedPage >= totalPages - 1}
                onClick={() => setPageIdx((p) => Math.min(totalPages - 1, p + 1))}
                className="rounded border border-slate-200 px-2.5 py-1 disabled:opacity-40 dark:border-slate-700 cursor-pointer"
              >
                Siguiente
              </button>
            </div>
          </div>
        </section>

        {/* Right Column: Live Raw JSON Editor & Schema Validation */}
        <section className="lg:col-span-5 flex flex-col justify-between space-y-3 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              Editor JSON Directo (`ROSTER_MAP_256.json`)
            </h4>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => void handleCopyJson()}
                className="inline-flex items-center gap-1 rounded border border-slate-300 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
              >
                <Copy className="h-3 w-3" />
                Copiar
              </button>
              <button
                type="button"
                onClick={handleApplyRawJson}
                className="inline-flex items-center gap-1 rounded bg-blue-600 px-3 py-1 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
              >
                Aplicar JSON
              </button>
            </div>
          </div>

          {copyFeedback && (
            <div className="rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-xs text-blue-900 dark:border-blue-900/50 dark:bg-blue-950/30 dark:text-blue-200">
              {copyFeedback}
            </div>
          )}

          <div
            className={`rounded-lg border px-3 py-2 text-xs ${
              validation.valid
                ? 'border-emerald-200 bg-emerald-50/70 text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-200'
                : 'border-amber-300 bg-amber-50 text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-200'
            }`}
          >
            {validation.valid ? (
              <div className="flex items-center gap-2 font-medium">
                <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
                Esquema válido: {validation.manifest?.characters.length} slots · Pico RAM {validation.estimatedPeakRamMb} MB
              </div>
            ) : (
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 font-semibold">
                  <AlertTriangle className="h-4 w-4 shrink-0" />
                  Observaciones de esquema ({validation.errors.length}):
                </div>
                <ul className="list-disc pl-4 space-y-0.5 text-[11px]">
                  {validation.errors.map((err, i) => (
                    <li key={i}>{err}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <textarea
            value={rawJson}
            onChange={(e) => setRawJson(e.target.value)}
            spellCheck={false}
            rows={20}
            aria-label="Estructura JSON de 256 personajes"
            className="w-full flex-1 rounded-lg border border-slate-200 bg-slate-950 p-3 font-mono text-[11px] leading-relaxed text-emerald-200 focus:border-blue-500 focus:outline-none dark:border-slate-800"
          />
        </section>
      </div>

      {/* 256-ID Script Generator & Game Engine JSON Exporter */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
          <div>
            <h4 className="flex items-center gap-2 text-base font-bold text-slate-900 dark:text-white">
              <Code2 className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              Generador de Scripts para Mapear los 256 IDs + Exportador <span className="font-mono">.json</span> Motor del Juego
            </h4>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-300">
              Genera scripts automatizados (<span className="font-mono">Python 3</span>, <span className="font-mono">Header C/C++</span>, <span className="font-mono">MIPS ARMIPS</span> o <span className="font-mono">CWCheat INI</span>) con los {manifest.characters.length} IDs y exporta la tabla oficial en formato <span className="font-mono">DBZ_TT_ENGINE_ROSTER_V2.json</span> compatible con el motor del juego.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleBatchApplyPathsFromScript}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-blue-600 bg-white px-3 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-50 dark:border-blue-500 dark:bg-slate-900 dark:text-blue-300 cursor-pointer"
            >
              <Wand2 className="h-3.5 w-3.5" />
              Aplicar Regla Masiva a 256 IDs
            </button>
            <button
              type="button"
              onClick={() =>
                downloadText(generatedEngineJsonText, `${manifest.gameId}_ENGINE_256_MAP.json`)
              }
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 cursor-pointer"
            >
              <FileJson className="h-3.5 w-3.5" />
              Exportar .json Motor del Juego
            </button>
            <button
              type="button"
              onClick={() => downloadText(generatedScript.content, generatedScript.filename)}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              Descargar {generatedScript.filename}
            </button>
          </div>
        </div>

        {/* Script Options Grid */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5 text-xs">
          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-400">
              Formato de Script
            </label>
            <select
              value={scriptOpts.target}
              onChange={(e) =>
                setScriptOpts((prev) => ({
                  ...prev,
                  target: e.target.value as RosterScriptTarget,
                }))
              }
              className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="PYTHON">Python 3 (.py)</option>
              <option value="C_HEADER">Tabla C / PSP SDK (.h)</option>
              <option value="MIPS_ARMIPS">MIPS Assembly ARMIPS (.asm)</option>
              <option value="CWCHEAT_INI">PPSSPP CWCheat (.ini)</option>
            </select>
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-400">
              Indexación de IDs
            </label>
            <select
              value={scriptOpts.baseIndexMode}
              onChange={(e) =>
                setScriptOpts((prev) => ({
                  ...prev,
                  baseIndexMode: e.target.value as '0x00_BASED' | '0x01_BASED',
                }))
              }
              className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="0x00_BASED">0x00 – 0xFF (Índice Real PSP)</option>
              <option value="0x01_BASED">0x01 – 0x100 (Slot 1 a 256)</option>
            </select>
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-400">
              Prefijo Carpeta DLC
            </label>
            <input
              type="text"
              value={scriptOpts.dlcBasePath}
              onChange={(e) =>
                setScriptOpts((prev) => ({ ...prev, dlcBasePath: e.target.value }))
              }
              className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-400">
              Prefijo Código Slot
            </label>
            <input
              type="text"
              value={scriptOpts.customSlotPrefix}
              onChange={(e) =>
                setScriptOpts((prev) => ({ ...prev, customSlotPrefix: e.target.value }))
              }
              className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div className="flex items-end pb-1">
            <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={scriptOpts.includeCanonicalNamesOnly}
                onChange={(e) =>
                  setScriptOpts((prev) => ({
                    ...prev,
                    includeCanonicalNamesOnly: e.target.checked,
                  }))
                }
                className="h-4 w-4 rounded border-slate-300 accent-blue-600"
              />
              Solo 71 base (0x00–0x46)
            </label>
          </div>
        </div>

        {scriptFeedback && (
          <div className="rounded-lg border border-emerald-200 bg-emerald-50/70 px-3 py-2 text-xs text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-200">
            {scriptFeedback}
          </div>
        )}

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <div>
            <div className="mb-1.5 flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
              <span>Vista Previa Script ({generatedScript.filename})</span>
              <button
                type="button"
                onClick={async () => {
                  try {
                    await navigator.clipboard.writeText(generatedScript.content);
                    setScriptFeedback(`Script ${generatedScript.filename} copiado al portapapeles.`);
                  } catch {
                    setScriptFeedback('Usa Descargar para guardar el archivo.');
                  }
                }}
                className="inline-flex items-center gap-1 rounded border border-slate-300 px-2 py-0.5 text-[11px] hover:bg-slate-50 dark:border-slate-700 cursor-pointer"
              >
                <Copy className="h-3 w-3" />
                Copiar Script
              </button>
            </div>
            <pre className="h-64 overflow-auto rounded-lg border border-slate-200 bg-slate-950 p-3 font-mono text-[11px] leading-relaxed text-sky-200 dark:border-slate-800">
              {generatedScript.content}
            </pre>
          </div>

          <div>
            <div className="mb-1.5 flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
              <span>JSON Compatible con Motor del Juego ({manifest.gameId}_ENGINE_256_MAP.json)</span>
              <button
                type="button"
                onClick={async () => {
                  try {
                    await navigator.clipboard.writeText(generatedEngineJsonText);
                    setScriptFeedback('JSON del motor del juego copiado al portapapeles.');
                  } catch {
                    setScriptFeedback('Usa Exportar .json Motor del Juego para descargarlo.');
                  }
                }}
                className="inline-flex items-center gap-1 rounded border border-slate-300 px-2 py-0.5 text-[11px] hover:bg-slate-50 dark:border-slate-700 cursor-pointer"
              >
                <Copy className="h-3 w-3" />
                Copiar JSON Motor
              </button>
            </div>
            <pre className="h-64 overflow-auto rounded-lg border border-slate-200 bg-slate-950 p-3 font-mono text-[11px] leading-relaxed text-emerald-200 dark:border-slate-800">
              {generatedEngineJsonText}
            </pre>
          </div>
        </div>
      </section>
    </div>
  );
};
