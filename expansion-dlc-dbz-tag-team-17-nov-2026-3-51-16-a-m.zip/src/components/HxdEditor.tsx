import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowRight,
  Download,
  Languages,
  RefreshCw,
  RotateCcw,
  Search,
  Table2,
  Undo2,
  Upload,
} from 'lucide-react';
import {
  decodeByteCell,
  decodeSlicePreview,
  encodeTextToBytes,
  extractMultilingualStrings,
  parseCodeTable,
  PRESET_TBL_CONTROL,
  PRESET_TBL_ESPANOL,
  PRESET_TBL_SHIFTJIS,
  type TextEncodingMode,
} from '../lib/codeTable';
import type { EbootAnalysis } from '../lib/types';

interface HxdEditorProps {
  analysis: EbootAnalysis;
  initialOffset: number | null;
  initialEncoding?: TextEncodingMode | null;
  onApplyModifiedBytes: (newBytes: Uint8Array) => void;
}

interface EditHistoryEntry {
  offset: number;
  prevValue: number;
  newValue: number;
}

const ROWS_PER_PAGE = 24;
const BYTES_PER_ROW = 16;
const PAGE_BYTES = ROWS_PER_PAGE * BYTES_PER_ROW;

function toHex(num: number, pad = 2): string {
  return (num >>> 0).toString(16).toUpperCase().padStart(pad, '0');
}

function mapOffsetToRam(offset: number, analysis: EbootAnalysis): number {
  for (const sec of analysis.sections) {
    if (sec.size > 0 && sec.offset > 0 && offset >= sec.offset && offset < sec.offset + sec.size) {
      const base = sec.vaddr > 0 ? sec.vaddr : analysis.baseRamAddress + sec.offset;
      return base + (offset - sec.offset);
    }
  }
  for (const seg of analysis.segments) {
    if (seg.filesz > 0 && offset >= seg.offset && offset < seg.offset + seg.filesz) {
      return seg.vaddr + (offset - seg.offset);
    }
  }
  return analysis.baseRamAddress + offset;
}

function mapRamToOffset(ram: number, analysis: EbootAnalysis): number | null {
  for (const seg of analysis.segments) {
    if (seg.filesz > 0 && ram >= seg.vaddr && ram < seg.vaddr + seg.filesz) {
      return seg.offset + (ram - seg.vaddr);
    }
  }
  for (const sec of analysis.sections) {
    if (sec.size > 0 && sec.vaddr > 0 && ram >= sec.vaddr && ram < sec.vaddr + sec.size) {
      return sec.offset + (ram - sec.vaddr);
    }
  }
  if (ram >= analysis.baseRamAddress) {
    const candidate = ram - analysis.baseRamAddress;
    if (candidate >= 0 && candidate < analysis.rawBytes.length) return candidate;
  }
  return null;
}

export const HxdEditor: React.FC<HxdEditorProps> = ({
  analysis,
  initialOffset,
  initialEncoding,
  onApplyModifiedBytes,
}) => {
  const [buffer, setBuffer] = useState<Uint8Array>(() => new Uint8Array(analysis.rawBytes));
  const [modifiedOffsets, setModifiedOffsets] = useState<Set<number>>(new Set());
  const [history, setHistory] = useState<EditHistoryEntry[]>([]);
  const [selectedOffset, setSelectedOffset] = useState<number>(initialOffset ?? 0);
  const [pageStart, setPageStart] = useState<number>(() => {
    const target = initialOffset ?? 0;
    return Math.floor(target / PAGE_BYTES) * PAGE_BYTES;
  });
  const [pendingNibble, setPendingNibble] = useState<string | null>(null);
  const [editMode, setEditMode] = useState<'hex' | 'ascii'>('hex');

  // Multilingual & Code Table (.TBL) state
  const [encoding, setEncoding] = useState<TextEncodingMode>(initialEncoding ?? 'windows-1252');
  const [showTableBox, setShowTableBox] = useState<boolean>(true);
  const [tblRawText, setTblRawText] = useState<string>(PRESET_TBL_ESPANOL);
  const [applyTableOverlay, setApplyTableOverlay] = useState<boolean>(false);
  const [nullPadPatch, setNullPadPatch] = useState<boolean>(true);
  const [showExtractedTexts, setShowExtractedTexts] = useState<boolean>(false);
  const [textScanFilter, setTextScanFilter] = useState<string>('');

  const [gotoInput, setGotoInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchMode, setSearchMode] = useState<'text' | 'hex'>('text');
  const [patchText, setPatchText] = useState('');
  const [statusNote, setStatusNote] = useState<string | null>(null);

  const tblFileInputRef = useRef<HTMLInputElement | null>(null);

  const parsedTable = useMemo(() => parseCodeTable(tblRawText), [tblRawText]);

  useEffect(() => {
    if (initialEncoding) {
      setEncoding(initialEncoding);
      if ((initialEncoding === 'shift_jis' || initialEncoding === 'utf-8') && (initialOffset ?? 0) > 0) {
        setShowExtractedTexts(true);
      }
      setStatusNote(
        `Codificación activa en HxD: ${initialEncoding === 'shift_jis' ? 'Shift-JIS (Japonés PSP)' : initialEncoding.toUpperCase()}.`
      );
    }
  }, [initialEncoding, initialOffset]);

  useEffect(() => {
    setBuffer(new Uint8Array(analysis.rawBytes));
    setModifiedOffsets(new Set());
    setHistory([]);
    const startOff = initialOffset ?? 0;
    setSelectedOffset(Math.min(startOff, Math.max(0, analysis.rawBytes.length - 1)));
    setPageStart(Math.floor(startOff / PAGE_BYTES) * PAGE_BYTES);
    setPendingNibble(null);
  }, [analysis.rawBytes, analysis.targetBinaryPath]);

  useEffect(() => {
    if (initialOffset !== null && initialOffset >= 0 && initialOffset < buffer.length) {
      setSelectedOffset(initialOffset);
      setPageStart(Math.floor(initialOffset / PAGE_BYTES) * PAGE_BYTES);
      setPendingNibble(null);
    }
  }, [initialOffset, buffer.length]);

  const jumpToOffset = (off: number) => {
    const clamped = Math.max(0, Math.min(buffer.length - 1, off));
    setSelectedOffset(clamped);
    setPageStart(Math.floor(clamped / PAGE_BYTES) * PAGE_BYTES);
    setPendingNibble(null);
  };

  const writeByte = (offset: number, newVal: number) => {
    if (offset < 0 || offset >= buffer.length) return;
    const prev = buffer[offset];
    if (prev === newVal) return;

    const next = new Uint8Array(buffer);
    next[offset] = newVal & 0xff;
    setBuffer(next);

    const nextMod = new Set(modifiedOffsets);
    nextMod.add(offset);
    setModifiedOffsets(nextMod);

    setHistory((h) => [...h, { offset, prevValue: prev, newValue: newVal & 0xff }]);
  };

  const handleHexKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (
      e.target instanceof HTMLInputElement ||
      e.target instanceof HTMLTextAreaElement ||
      e.target instanceof HTMLSelectElement
    ) {
      return;
    }
    if (buffer.length === 0) return;

    if (e.key === 'ArrowRight') {
      e.preventDefault();
      jumpToOffset(selectedOffset + 1);
      return;
    }
    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      jumpToOffset(selectedOffset - 1);
      return;
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      jumpToOffset(selectedOffset + BYTES_PER_ROW);
      return;
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      jumpToOffset(selectedOffset - BYTES_PER_ROW);
      return;
    }

    if (editMode === 'hex') {
      const ch = e.key.toUpperCase();
      if (/^[0-9A-F]$/.test(ch)) {
        e.preventDefault();
        if (pendingNibble === null) {
          setPendingNibble(ch);
        } else {
          const val = parseInt(pendingNibble + ch, 16);
          writeByte(selectedOffset, val);
          setPendingNibble(null);
          if (selectedOffset + 1 < buffer.length) {
            jumpToOffset(selectedOffset + 1);
          }
        }
      } else if (e.key === 'Escape') {
        setPendingNibble(null);
      }
    } else if (editMode === 'ascii') {
      if (e.key.length === 1) {
        const { bytes } = encodeTextToBytes(e.key, encoding, parsedTable, applyTableOverlay);
        if (bytes.length > 0) {
          e.preventDefault();
          const next = new Uint8Array(buffer);
          const nextMod = new Set(modifiedOffsets);
          const added: EditHistoryEntry[] = [];
          for (let i = 0; i < bytes.length && selectedOffset + i < next.length; i++) {
            const off = selectedOffset + i;
            if (next[off] !== bytes[i]) {
              added.push({ offset: off, prevValue: next[off], newValue: bytes[i] });
              next[off] = bytes[i];
              nextMod.add(off);
            }
          }
          setBuffer(next);
          setModifiedOffsets(nextMod);
          setHistory((h) => [...h, ...added]);
          if (selectedOffset + bytes.length < buffer.length) {
            jumpToOffset(selectedOffset + bytes.length);
          }
        }
      }
    }
  };

  const handleUndo = () => {
    if (history.length === 0) return;
    const last = history[history.length - 1];
    const next = new Uint8Array(buffer);
    next[last.offset] = last.prevValue;
    setBuffer(next);
    setHistory(history.slice(0, -1));
    jumpToOffset(last.offset);
    setStatusNote(`Deshecho cambio en offset 0x${toHex(last.offset, 6)}.`);
  };

  const handleRevertAll = () => {
    setBuffer(new Uint8Array(analysis.rawBytes));
    setModifiedOffsets(new Set());
    setHistory([]);
    setPendingNibble(null);
    setStatusNote('Todos los cambios locales fueron revertidos.');
  };

  const handleGoto = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = gotoInput.trim().replace(/^0x/i, '');
    const parsed = parseInt(clean, 16);
    if (Number.isNaN(parsed)) {
      setStatusNote('Ingresa una dirección hexadecimal válida (ej. 100 o 0x08804100).');
      return;
    }
    if (parsed >= 0 && parsed < buffer.length) {
      jumpToOffset(parsed);
      setStatusNote(`Saltado a offset de archivo 0x${toHex(parsed, 6)}.`);
      return;
    }
    const mapped = mapRamToOffset(parsed, analysis);
    if (mapped !== null && mapped < buffer.length) {
      jumpToOffset(mapped);
      setStatusNote(`RAM 0x${toHex(parsed, 8)} mapeada a offset 0x${toHex(mapped, 6)}.`);
      return;
    }
    setStatusNote('La dirección indicada está fuera de los límites del binario.');
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim() || buffer.length === 0) return;

    let pattern: number[] = [];
    if (searchMode === 'hex') {
      const tokens = searchQuery.trim().split(/\s+/);
      for (const t of tokens) {
        const clean = t.replace(/^0x/i, '');
        if (!/^[0-9a-fA-F]{1,2}$/.test(clean)) {
          setStatusNote('Formato hexadecimal inválido. Usa bytes separados por espacios (ej. 7F 45 4C 46).');
          return;
        }
        pattern.push(parseInt(clean, 16));
      }
    } else {
      const encoded = encodeTextToBytes(searchQuery, encoding, parsedTable, applyTableOverlay);
      pattern = Array.from(encoded.bytes);
    }

    if (pattern.length === 0) return;

    const startSearch = selectedOffset + 1;
    let found = -1;
    for (let i = startSearch; i <= buffer.length - pattern.length; i++) {
      let match = true;
      for (let j = 0; j < pattern.length; j++) {
        if (buffer[i + j] !== pattern[j]) {
          match = false;
          break;
        }
      }
      if (match) {
        found = i;
        break;
      }
    }

    if (found === -1 && startSearch > 0) {
      for (let i = 0; i < Math.min(startSearch, buffer.length - pattern.length + 1); i++) {
        let match = true;
        for (let j = 0; j < pattern.length; j++) {
          if (buffer[i + j] !== pattern[j]) {
            match = false;
            break;
          }
        }
        if (match) {
          found = i;
          break;
        }
      }
    }

    if (found !== -1) {
      jumpToOffset(found);
      setStatusNote(`Coincidencia encontrada en 0x${toHex(found, 6)} (${pattern.length} bytes).`);
    } else {
      setStatusNote('No se encontraron coincidencias con la codificación/tabla activa.');
    }
  };

  const patchPreview = useMemo(() => {
    if (!patchText) return null;
    return encodeTextToBytes(patchText, encoding, parsedTable, applyTableOverlay);
  }, [patchText, encoding, parsedTable, applyTableOverlay]);

  const handlePatchText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patchText || !patchPreview) return;

    const bytes = patchPreview.bytes;
    const next = new Uint8Array(buffer);
    const nextMod = new Set(modifiedOffsets);
    const newHist: EditHistoryEntry[] = [];

    let written = 0;
    for (let i = 0; i < bytes.length && selectedOffset + i < next.length; i++) {
      const off = selectedOffset + i;
      if (next[off] !== bytes[i]) {
        newHist.push({ offset: off, prevValue: next[off], newValue: bytes[i] });
        next[off] = bytes[i];
        nextMod.add(off);
      }
      written++;
    }

    if (nullPadPatch && selectedOffset + written < next.length) {
      const nullOff = selectedOffset + written;
      if (next[nullOff] !== 0) {
        newHist.push({ offset: nullOff, prevValue: next[nullOff], newValue: 0 });
        next[nullOff] = 0;
        nextMod.add(nullOff);
      }
    }

    setBuffer(next);
    setModifiedOffsets(nextMod);
    setHistory((h) => [...h, ...newHist]);
    setStatusNote(
      `Escritos ${written} bytes (${encoding}) desde 0x${toHex(selectedOffset, 6)}${
        patchPreview.unmappedChars.length > 0
          ? ` · Caracteres sin mapeo reemplazados por '?': ${patchPreview.unmappedChars.join('')}`
          : ''
      }.`
    );
    setPatchText('');
  };

  const handleLoadTblFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    setTblRawText(text);
    setApplyTableOverlay(true);
    setEncoding('custom_tbl');
    setStatusNote(`Tabla de códigos "${file.name}" cargada y aplicada.`);
    e.target.value = '';
  };

  const handleDownloadPatched = () => {
    const safeBytes = new Uint8Array(buffer);
    const blob = new Blob([safeBytes.buffer], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const baseName = analysis.targetBinaryPath.split('/').pop() || 'EBOOT_MOD.BIN';
    a.href = url;
    a.download = modifiedOffsets.size > 0 ? `MOD_${baseName}` : baseName;
    a.click();
    URL.revokeObjectURL(url);
  };

  const extractedStrings = useMemo(() => {
    if (!showExtractedTexts) return [];
    const list = extractMultilingualStrings(buffer, encoding, parsedTable, applyTableOverlay, 4);
    const q = textScanFilter.trim().toLowerCase();
    if (!q) return list;
    return list.filter((item) => item.text.toLowerCase().includes(q));
  }, [showExtractedTexts, buffer, encoding, parsedTable, applyTableOverlay, textScanFilter]);

  const inspector = useMemo(() => {
    if (buffer.length === 0 || selectedOffset >= buffer.length) return null;
    const u8 = buffer[selectedOffset];
    const i8 = u8 > 127 ? u8 - 256 : u8;
    const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
    const can16 = selectedOffset + 2 <= buffer.length;
    const can32 = selectedOffset + 4 <= buffer.length;
    const decodedPreview = decodeSlicePreview(
      buffer,
      selectedOffset,
      32,
      encoding,
      parsedTable,
      applyTableOverlay
    );
    return {
      offsetHex: `0x${toHex(selectedOffset, 6)}`,
      ramHex: `0x${toHex(mapOffsetToRam(selectedOffset, analysis), 8)}`,
      u8,
      i8,
      u16: can16 ? view.getUint16(selectedOffset, true) : null,
      i16: can16 ? view.getInt16(selectedOffset, true) : null,
      u32: can32 ? view.getUint32(selectedOffset, true) : null,
      i32: can32 ? view.getInt32(selectedOffset, true) : null,
      f32: can32 ? view.getFloat32(selectedOffset, true) : null,
      bin: u8.toString(2).padStart(8, '0'),
      decodedPreview,
    };
  }, [buffer, selectedOffset, analysis, encoding, parsedTable, applyTableOverlay]);

  const rows = useMemo(() => {
    const out: number[] = [];
    const end = Math.min(buffer.length, pageStart + PAGE_BYTES);
    for (let off = pageStart; off < end; off += BYTES_PER_ROW) {
      out.push(off);
    }
    return out;
  }, [buffer.length, pageStart]);

  const totalPages = Math.max(1, Math.ceil(buffer.length / PAGE_BYTES));
  const currentPage = Math.floor(pageStart / PAGE_BYTES) + 1;

  return (
    <div className="space-y-4">
      <input
        ref={tblFileInputRef}
        type="file"
        accept=".tbl,.txt"
        onChange={handleLoadTblFile}
        className="hidden"
      />

      {/* Top HxD Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
            <button
              type="button"
              onClick={() => {
                setEditMode('hex');
                setPendingNibble(null);
              }}
              className={`min-h-[36px] rounded-md px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                editMode === 'hex'
                  ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
              }`}
            >
              Modo Hex
            </button>
            <button
              type="button"
              onClick={() => {
                setEditMode('ascii');
                setPendingNibble(null);
              }}
              className={`min-h-[36px] rounded-md px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                editMode === 'ascii'
                  ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
              }`}
            >
              Modo Texto
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <Languages className="h-4 w-4 text-slate-400" />
            <select
              value={encoding}
              onChange={(e) => setEncoding(e.target.value as TextEncodingMode)}
              aria-label="Idioma y codificación de texto"
              className="min-h-[36px] rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs font-medium text-slate-800 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="windows-1252">Español / Occidental (Win-1252)</option>
              <option value="utf-8">Multi-idioma (UTF-8)</option>
              <option value="shift_jis">Japonés PSP (Shift-JIS)</option>
              <option value="utf-16le">Unicode (UTF-16LE)</option>
              <option value="custom_tbl">Tabla de Códigos (.TBL)</option>
            </select>
          </div>

          <button
            type="button"
            onClick={() => setShowTableBox((s) => !s)}
            className={`inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              showTableBox
                ? 'border-blue-600 bg-blue-50 text-blue-700 dark:border-blue-500 dark:bg-blue-950/40 dark:text-blue-300'
                : 'border-slate-300 text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            <Table2 className="h-3.5 w-3.5" />
            Tabla de Códigos ({parsedTable.entryCount})
          </button>

          <button
            type="button"
            onClick={() => setShowExtractedTexts((s) => !s)}
            className={`inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              showExtractedTexts
                ? 'border-blue-600 bg-blue-50 text-blue-700 dark:border-blue-500 dark:bg-blue-950/40 dark:text-blue-300'
                : 'border-slate-300 text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800'
            }`}
          >
            Extraer Textos
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            {modifiedOffsets.size} B editados
          </span>
          <button
            type="button"
            onClick={handleUndo}
            disabled={history.length === 0}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Undo2 className="h-3.5 w-3.5" />
            Deshacer
          </button>
          <button
            type="button"
            onClick={handleRevertAll}
            disabled={modifiedOffsets.size === 0}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Revertir
          </button>
          <button
            type="button"
            onClick={() => {
              onApplyModifiedBytes(new Uint8Array(buffer));
              setStatusNote('Análisis e informe indexado actualizados con los bytes editados.');
            }}
            disabled={modifiedOffsets.size === 0}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-blue-600 px-3 py-1.5 text-xs font-medium text-blue-600 hover:bg-blue-50 disabled:opacity-40 dark:border-blue-500 dark:text-blue-400 dark:hover:bg-blue-950/40 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Re-analizar
          </button>
          <button
            type="button"
            onClick={handleDownloadPatched}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            Guardar .BIN
          </button>
        </div>
      </div>

      {/* Casilla para Tabla de Códigos (.TBL) */}
      {showTableBox && (
        <section className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Casilla de Tabla de Códigos (.TBL) para Español y Otros Idiomas
              </h3>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                Pega o carga un archivo <span className="font-mono">.tbl</span> (<span className="font-mono">HEX=Carácter</span>) para decodificar la columna de texto de HxD, buscar palabras o traducir diálogos.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => tblFileInputRef.current?.click()}
                className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-blue-600 px-3 text-xs font-semibold text-white hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Upload className="h-3.5 w-3.5" />
                Cargar archivo .TBL
              </button>
              <button
                type="button"
                onClick={() => {
                  setTblRawText(PRESET_TBL_ESPANOL);
                  setApplyTableOverlay(true);
                  setStatusNote('Cargado preset Español (á, é, í, ó, ú, ñ, ¿, ¡).');
                }}
                className="min-h-[36px] rounded-lg border border-slate-300 px-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
              >
                Preset Español
              </button>
              <button
                type="button"
                onClick={() => {
                  setTblRawText(PRESET_TBL_SHIFTJIS);
                  setApplyTableOverlay(true);
                  setEncoding('shift_jis');
                  setStatusNote('Cargado preset Japonés Shift-JIS.');
                }}
                className="min-h-[36px] rounded-lg border border-slate-300 px-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
              >
                Preset Shift-JIS
              </button>
              <button
                type="button"
                onClick={() => {
                  setTblRawText(PRESET_TBL_CONTROL);
                  setApplyTableOverlay(true);
                }}
                className="min-h-[36px] rounded-lg border border-slate-300 px-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
              >
                Plantilla Control
              </button>
              <button
                type="button"
                onClick={() => setTblRawText('')}
                className="min-h-[36px] rounded-lg border border-slate-300 px-2.5 text-xs font-medium text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-400 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
              >
                Vaciar
              </button>
            </div>
          </div>

          <div className="mt-3 grid grid-cols-1 gap-3 lg:grid-cols-12">
            <div className="lg:col-span-8">
              <textarea
                value={tblRawText}
                onChange={(e) => setTblRawText(e.target.value)}
                rows={5}
                spellCheck={false}
                placeholder="Ejemplo:&#10;E1=á&#10;E9=é&#10;ED=í&#10;F1=ñ&#10;F3=ó&#10;FA=ú&#10;00=<FIN>&#10;82A0=あ"
                className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div className="lg:col-span-4 flex flex-col justify-between rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs dark:border-slate-800 dark:bg-slate-950/60">
              <div className="space-y-2">
                <label className="flex items-center gap-2 font-medium text-slate-800 dark:text-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={applyTableOverlay}
                    onChange={(e) => setApplyTableOverlay(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-300 accent-blue-600"
                  />
                  Aplicar tabla .TBL en columna HxD
                </label>
                <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
                  Reglas activas: <strong className="font-mono text-slate-800 dark:text-slate-200">{parsedTable.entryCount}</strong> · Longitud máx: <strong className="font-mono">{parsedTable.maxHexBytes} B</strong>.
                </p>
                <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
                  Si el juego usa tildes en español personalizadas (ej. <span className="font-mono">80=á</span>, <span className="font-mono">85=ñ</span>), escribe aquí las parejas para ver y editar el texto directamente.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  const blob = new Blob([tblRawText], { type: 'text/plain;charset=utf-8' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'tabla_codigos.tbl';
                  a.click();
                  URL.revokeObjectURL(url);
                }}
                className="mt-3 inline-flex min-h-[36px] items-center justify-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                Guardar .TBL
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Multi-language String Extractor Panel */}
      {showExtractedTexts && (
        <section className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Textos Detectados ({encoding === 'custom_tbl' ? 'Tabla .TBL' : encoding})
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Haz clic en cualquier texto para saltar a su offset en HxD y editarlo.
              </p>
            </div>
            <input
              type="text"
              value={textScanFilter}
              onChange={(e) => setTextScanFilter(e.target.value)}
              placeholder="Filtrar texto (ej. Misión, disc0, ステージ)..."
              className="min-h-[38px] w-full max-w-xs rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>
          <div className="mt-3 max-h-56 overflow-y-auto divide-y divide-slate-100 rounded-lg border border-slate-100 dark:divide-slate-800 dark:border-slate-800">
            {extractedStrings.length === 0 ? (
              <div className="p-4 text-xs text-slate-500">No se encontraron cadenas legibles con la codificación seleccionada.</div>
            ) : (
              extractedStrings.map((item) => (
                <button
                  key={`${item.offset}-${item.lengthBytes}`}
                  type="button"
                  onClick={() => jumpToOffset(item.offset)}
                  className="flex w-full items-center justify-between gap-3 px-3 py-2 text-left text-xs hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer"
                >
                  <span className="truncate font-mono text-slate-900 dark:text-slate-100">{item.text}</span>
                  <span className="shrink-0 font-mono text-[11px] text-blue-600 tabular-nums dark:text-blue-400">
                    0x{toHex(item.offset, 6)} ({item.lengthBytes} B)
                  </span>
                </button>
              ))
            )}
          </div>
        </section>
      )}

      {/* Go To, Search & Multilingual Text Patch Controls */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <form onSubmit={handleGoto} className="flex gap-2 rounded-xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900">
          <input
            type="text"
            value={gotoInput}
            onChange={(e) => setGotoInput(e.target.value)}
            placeholder="Ir a Offset o RAM (ej. 0x100 o 0x08804100)"
            className="min-w-0 flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          />
          <button
            type="submit"
            className="inline-flex min-h-[40px] items-center gap-1 rounded-lg bg-slate-900 px-3 text-xs font-medium text-white hover:bg-slate-800 dark:bg-slate-700 dark:hover:bg-slate-600 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Ir
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </form>

        <form onSubmit={handleSearch} className="flex gap-2 rounded-xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900">
          <select
            value={searchMode}
            onChange={(e) => setSearchMode(e.target.value as 'text' | 'hex')}
            aria-label="Tipo de búsqueda"
            className="rounded-lg border border-slate-200 bg-slate-50 px-2 py-2 text-xs font-medium text-slate-700 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
          >
            <option value="text">Idioma/TBL</option>
            <option value="hex">Hex</option>
          </select>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={searchMode === 'hex' ? 'Ej: 7F 45 4C 46' : 'Ej: Misión, ステージ, disc0:'}
            className="min-w-0 flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          />
          <button
            type="submit"
            className="inline-flex min-h-[40px] items-center gap-1 rounded-lg bg-blue-600 px-3 text-xs font-medium text-white hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Search className="h-3.5 w-3.5" />
            Buscar
          </button>
        </form>

        <form onSubmit={handlePatchText} className="space-y-1.5 rounded-xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex gap-2">
            <input
              type="text"
              value={patchText}
              onChange={(e) => setPatchText(e.target.value)}
              placeholder={`Escribir en 0x${toHex(selectedOffset, 6)} (Español / TBL)`}
              className="min-w-0 flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
            <button
              type="submit"
              className="inline-flex min-h-[40px] items-center gap-1 rounded-lg border border-slate-300 px-3 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              Escribir
            </button>
          </div>
          <div className="flex items-center justify-between gap-2 text-[11px] text-slate-500 dark:text-slate-400">
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={nullPadPatch}
                onChange={(e) => setNullPadPatch(e.target.checked)}
                className="h-3.5 w-3.5 accent-blue-600"
              />
              Añadir byte 0x00 al final
            </label>
            {patchPreview && (
              <span className="truncate font-mono">
                {patchPreview.bytes.length} B:{' '}
                {Array.from(patchPreview.bytes.slice(0, 8))
                  .map((b) => toHex(b, 2))
                  .join(' ')}
                {patchPreview.bytes.length > 8 ? '…' : ''}
              </span>
            )}
          </div>
        </form>
      </div>

      {statusNote && (
        <p className="text-xs font-medium text-blue-700 dark:text-blue-400">{statusNote}</p>
      )}

      {/* Main HxD Grid + Data Inspector */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-12">
        {/* Hex Matrix */}
        <div
          tabIndex={0}
          onKeyDown={handleHexKeyDown}
          className="xl:col-span-9 overflow-x-auto rounded-xl border border-slate-200 bg-white p-4 outline-none focus-visible:ring-2 focus-visible:ring-blue-500 dark:border-slate-800 dark:bg-slate-900"
        >
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2 dark:border-slate-800">
            <div className="text-xs text-slate-500 dark:text-slate-400">
              Haz clic en un byte y escribe ({editMode === 'hex' ? 'Hex 0-9 A-F' : `Texto ${encoding}`}) · Decodificación activa: <span className="font-mono font-semibold text-slate-700 dark:text-slate-200">{applyTableOverlay ? 'Tabla .TBL' : encoding}</span>
            </div>
            <div className="flex items-center gap-2 text-xs tabular-nums">
              <button
                type="button"
                disabled={pageStart === 0}
                onClick={() => setPageStart(Math.max(0, pageStart - PAGE_BYTES))}
                className="min-h-[34px] rounded border border-slate-200 px-2.5 text-slate-700 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
              >
                Anterior
              </button>
              <span className="font-mono text-slate-600 dark:text-slate-300">
                Pág {currentPage} / {totalPages}
              </span>
              <button
                type="button"
                disabled={pageStart + PAGE_BYTES >= buffer.length}
                onClick={() => setPageStart(pageStart + PAGE_BYTES)}
                className="min-h-[34px] rounded border border-slate-200 px-2.5 text-slate-700 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
              >
                Siguiente
              </button>
            </div>
          </div>

          <div className="min-w-[700px] font-mono text-[12px] leading-6 select-none tabular-nums">
            <div className="grid grid-cols-[84px_1fr_176px] gap-4 border-b border-slate-100 pb-1 text-[11px] font-semibold text-slate-400 dark:border-slate-800">
              <span>Offset(h)</span>
              <div className="grid grid-cols-16 gap-1 text-center">
                {Array.from({ length: 16 }, (_, i) => (
                  <span key={i}>{toHex(i, 2)}</span>
                ))}
              </div>
              <span>Texto ({applyTableOverlay ? '.TBL' : encoding})</span>
            </div>

            <div className="divide-y divide-slate-50 dark:divide-slate-800/60">
              {rows.map((rowOffset) => (
                <div
                  key={rowOffset}
                  className="grid grid-cols-[84px_1fr_176px] items-center gap-4 py-0.5 hover:bg-slate-50/70 dark:hover:bg-slate-800/40"
                >
                  <span className="text-slate-400 dark:text-slate-500">
                    {toHex(rowOffset, 8)}
                  </span>

                  <div className="grid grid-cols-16 gap-1 text-center">
                    {Array.from({ length: 16 }, (_, col) => {
                      const off = rowOffset + col;
                      if (off >= buffer.length) {
                        return <span key={col} className="text-slate-200 dark:text-slate-800">..</span>;
                      }
                      const b = buffer[off];
                      const isSelected = off === selectedOffset;
                      const isModified = modifiedOffsets.has(off);
                      const display =
                        isSelected && pendingNibble !== null
                          ? `${pendingNibble}_`
                          : toHex(b, 2);

                      return (
                        <button
                          key={col}
                          type="button"
                          onClick={() => {
                            setSelectedOffset(off);
                            setPendingNibble(null);
                          }}
                          className={`rounded px-0.5 py-0.5 transition-colors cursor-pointer ${
                            isSelected
                              ? 'bg-blue-600 font-semibold text-white'
                              : isModified
                              ? 'bg-amber-100 font-semibold text-amber-800 dark:bg-amber-900/50 dark:text-amber-300'
                              : b === 0
                              ? 'text-slate-300 dark:text-slate-600'
                              : 'text-slate-800 hover:bg-slate-200/70 dark:text-slate-200 dark:hover:bg-slate-700'
                          }`}
                        >
                          {display}
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex tracking-tight">
                    {Array.from({ length: 16 }, (_, col) => {
                      const off = rowOffset + col;
                      if (off >= buffer.length) return <span key={col}> </span>;
                      const cell = decodeByteCell(buffer, off, encoding, parsedTable, applyTableOverlay);
                      const isSelected = off === selectedOffset;
                      const isModified = modifiedOffsets.has(off);

                      return (
                        <button
                          key={col}
                          type="button"
                          onClick={() => {
                            setSelectedOffset(off);
                            setEditMode('ascii');
                            setPendingNibble(null);
                          }}
                          title={cell.text}
                          className={`w-[11px] overflow-hidden text-center cursor-pointer ${
                            isSelected
                              ? 'bg-blue-600 text-white'
                              : isModified
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300'
                              : cell.isPrintable
                              ? 'text-slate-800 dark:text-slate-200'
                              : 'text-slate-300 dark:text-slate-600'
                          }`}
                        >
                          {cell.text}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* HxD Data Inspector */}
        <aside className="xl:col-span-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
            Inspector de Datos HxD
          </h3>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Interpretación Little-Endian y texto desde el cursor.
          </p>

          {inspector ? (
            <>
              <dl className="mt-4 divide-y divide-slate-100 font-mono text-xs tabular-nums dark:divide-slate-800">
                <div className="flex justify-between py-2">
                  <dt className="text-slate-500">Offset Archivo</dt>
                  <dd className="font-semibold text-slate-900 dark:text-white">{inspector.offsetHex}</dd>
                </div>
                <div className="flex justify-between py-2">
                  <dt className="text-slate-500">RAM PSP</dt>
                  <dd className="font-semibold text-blue-600 dark:text-blue-400">{inspector.ramHex}</dd>
                </div>
                <div className="flex justify-between py-2">
                  <dt className="text-slate-500">Binario (8b)</dt>
                  <dd className="text-slate-800 dark:text-slate-200">{inspector.bin}</dd>
                </div>
                <div className="flex justify-between py-2">
                  <dt className="text-slate-500">UInt8 / Int8</dt>
                  <dd className="text-slate-800 dark:text-slate-200">
                    {inspector.u8} / {inspector.i8}
                  </dd>
                </div>
                <div className="flex justify-between py-2">
                  <dt className="text-slate-500">UInt16 LE</dt>
                  <dd className="text-slate-800 dark:text-slate-200">
                    {inspector.u16 !== null ? `${inspector.u16} (0x${toHex(inspector.u16, 4)})` : 'N/A'}
                  </dd>
                </div>
                <div className="flex justify-between py-2">
                  <dt className="text-slate-500">UInt32 LE</dt>
                  <dd className="text-slate-800 dark:text-slate-200">
                    {inspector.u32 !== null ? `0x${toHex(inspector.u32, 8)}` : 'N/A'}
                  </dd>
                </div>
                <div className="flex justify-between py-2">
                  <dt className="text-slate-500">Int32 LE</dt>
                  <dd className="text-slate-800 dark:text-slate-200">
                    {inspector.i32 !== null ? inspector.i32 : 'N/A'}
                  </dd>
                </div>
                <div className="flex justify-between py-2">
                  <dt className="text-slate-500">Float32 LE</dt>
                  <dd className="text-slate-800 dark:text-slate-200">
                    {inspector.f32 !== null && Number.isFinite(inspector.f32)
                      ? inspector.f32.toPrecision(5)
                      : 'N/A'}
                  </dd>
                </div>
              </dl>

              <div className="mt-4 border-t border-slate-100 pt-3 dark:border-slate-800">
                <div className="text-[11px] font-semibold text-slate-500">
                  Texto decodificado ({applyTableOverlay ? '.TBL' : encoding})
                </div>
                <div className="mt-1.5 break-all rounded-lg bg-slate-50 p-2.5 font-mono text-xs text-slate-900 dark:bg-slate-950 dark:text-slate-100">
                  {inspector.decodedPreview || '(vacío)'}
                </div>
              </div>
            </>
          ) : (
            <p className="mt-4 text-xs text-slate-500">Sin bytes cargados.</p>
          )}
        </aside>
      </div>
    </div>
  );
};
