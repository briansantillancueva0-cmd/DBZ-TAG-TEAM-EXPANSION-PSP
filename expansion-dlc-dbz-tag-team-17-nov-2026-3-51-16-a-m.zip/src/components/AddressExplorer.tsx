import React, { useMemo, useState } from 'react';
import { Binary, Check, Copy, Search } from 'lucide-react';
import type { AddressCategory, AddressEntry } from '../lib/types';

interface AddressExplorerProps {
  addresses: AddressEntry[];
  onInspectHex: (offset: number) => void;
}

type FilterKey = 'ALL' | 'CORE' | 'SECTIONS' | 'LIBS' | 'MIPS' | 'STRINGS';

function formatHex(val: number | null, width = 8): string {
  if (val === null || Number.isNaN(val)) return '—';
  return `0x${(val >>> 0).toString(16).toUpperCase().padStart(width, '0')}`;
}

function matchesFilter(cat: AddressCategory, filter: FilterKey): boolean {
  switch (filter) {
    case 'ALL':
      return true;
    case 'CORE':
      return cat === 'ENTRY_POINT' || cat === 'MODULE_INFO' || cat === 'SEGMENT';
    case 'SECTIONS':
      return cat === 'SECTION';
    case 'LIBS':
      return cat === 'LIBRARY_STUB';
    case 'MIPS':
      return cat === 'MIPS_JAL' || cat === 'MIPS_PTR';
    case 'STRINGS':
      return cat === 'STRING_PATH' || cat === 'STRING_SCE' || cat === 'STRING_DEBUG';
  }
}

export const AddressExplorer: React.FC<AddressExplorerProps> = ({ addresses, onInspectHex }) => {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<FilterKey>('ALL');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return addresses.filter((item) => {
      if (!matchesFilter(item.category, filter)) return false;
      if (!q) return true;
      const ramStr = formatHex(item.ramAddress, 8).toLowerCase();
      const offStr = formatHex(item.fileOffset, 6).toLowerCase();
      return (
        item.label.toLowerCase().includes(q) ||
        item.categoryLabel.toLowerCase().includes(q) ||
        item.sectionName.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        ramStr.includes(q) ||
        offStr.includes(q)
      );
    });
  }, [addresses, filter, query]);

  const copyAddr = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1400);
    } catch {
      // Ignore clipboard failures in restricted contexts
    }
  };

  const tabs: Array<{ key: FilterKey; label: string }> = [
    { key: 'ALL', label: 'Todas' },
    { key: 'CORE', label: 'Entry y Segmentos' },
    { key: 'SECTIONS', label: 'Secciones' },
    { key: 'LIBS', label: 'Librerías PSP' },
    { key: 'MIPS', label: 'MIPS JAL / Punteros' },
    { key: 'STRINGS', label: 'Rutas y Cadenas' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 lg:flex-row lg:items-center lg:justify-between">
        <div className="relative flex-1 max-w-xl">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar dirección RAM (0x0880...), offset, ruta disc0:/, librería sce..."
            className="min-h-[44px] w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-sm text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          />
        </div>

        <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => setFilter(tab.key)}
              className={`min-h-[36px] rounded-md px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                filter === tab.key
                  ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
          <span className="tabular-nums">
            Mostrando {Math.min(filtered.length, 300)} de {filtered.length} direcciones encontradas
          </span>
          <span>Haz clic en HxD para editar ese offset</span>
        </div>

        {filtered.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500 dark:text-slate-400">
            No hay direcciones que coincidan con el filtro actual.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                  <th className="px-4 py-2.5 font-semibold">#</th>
                  <th className="px-4 py-2.5 font-semibold">Tipo</th>
                  <th className="px-4 py-2.5 font-semibold">Offset Archivo</th>
                  <th className="px-4 py-2.5 font-semibold">Dirección RAM</th>
                  <th className="px-4 py-2.5 font-semibold">Sección</th>
                  <th className="px-4 py-2.5 font-semibold">Etiqueta / Contenido</th>
                  <th className="px-4 py-2.5 text-right font-semibold">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.slice(0, 300).map((item) => {
                  const ramText = formatHex(item.ramAddress, 8);
                  const offText = formatHex(item.fileOffset, 6);
                  const copyKey = `${item.index}-ram`;

                  return (
                    <tr
                      key={`${item.index}-${item.label}`}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40"
                    >
                      <td className="px-4 py-2.5 font-mono text-slate-400 tabular-nums">
                        {String(item.index).padStart(3, '0')}
                      </td>
                      <td className="px-4 py-2.5 whitespace-nowrap text-slate-700 dark:text-slate-300">
                        {item.categoryLabel}
                      </td>
                      <td className="px-4 py-2.5 font-mono text-slate-800 tabular-nums dark:text-slate-200">
                        {offText}
                      </td>
                      <td className="px-4 py-2.5 font-mono font-semibold text-blue-600 tabular-nums dark:text-blue-400">
                        {ramText}
                      </td>
                      <td className="px-4 py-2.5 font-mono text-slate-500 dark:text-slate-400">
                        {item.sectionName}
                      </td>
                      <td className="max-w-md px-4 py-2.5">
                        <div className="truncate font-mono text-slate-900 dark:text-slate-100" title={item.label}>
                          {item.label}
                        </div>
                        <div className="truncate text-[11px] text-slate-500 dark:text-slate-400">
                          {item.description}
                        </div>
                      </td>
                      <td className="px-4 py-2.5 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          {item.ramAddress !== null && (
                            <button
                              type="button"
                              onClick={() => copyAddr(ramText, copyKey)}
                              className="inline-flex min-h-[32px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
                              title="Copiar dirección RAM"
                            >
                              {copiedId === copyKey ? (
                                <Check className="h-3 w-3 text-emerald-600" />
                              ) : (
                                <Copy className="h-3 w-3" />
                              )}
                              RAM
                            </button>
                          )}
                          {item.fileOffset !== null && (
                            <button
                              type="button"
                              onClick={() => onInspectHex(item.fileOffset!)}
                              className="inline-flex min-h-[32px] items-center gap-1 rounded bg-slate-900 px-2.5 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
                              title="Abrir este offset en el editor HxD"
                            >
                              <Binary className="h-3 w-3" />
                              HxD
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
