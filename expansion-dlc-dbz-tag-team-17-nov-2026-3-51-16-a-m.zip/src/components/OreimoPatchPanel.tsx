import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Archive,
  CheckCircle2,
  Download,
  FileDiff,
  FolderInput,
  HardDrive,
  Languages,
  Search,
  Sparkles,
  Upload,
} from 'lucide-react';
import { encodeTextToBytes } from '../lib/codeTable';
import {
  auditOreimoWorkspace,
  buildIpsPatch,
  buildOreimoTranslationPatchBundle,
  buildPpf3Patch,
  diffBlobsToChunks,
  exportOreimoSlotsCsv,
  extractOreimoPatchSlots,
  normalizeTargetIsoPath,
  parseOreimoSlotsCsv,
  suggestOreimoSpanishTranslation,
  type OreimoPatchBundleOutput,
  type OreimoPatchSlot,
  type OreimoWorkspaceAudit,
} from '../lib/oreimoPatcher';
import { stripAccentsToAscii } from '../lib/textTranslator';
import type { EbootAnalysis } from '../lib/types';
import {
  scanUniversalItems,
  type UniversalClassifiedItem,
  type UniversalSourceItem,
} from '../lib/universalInspector';

interface OreimoPatchPanelProps {
  classifiedItems: UniversalClassifiedItem[];
  analysis: EbootAnalysis | null;
  onReplaceClassifiedItems?: (items: UniversalClassifiedItem[], banner: string) => void;
  onSendPatchedToIsoPacker?: (files: Array<{ file: File; relativePath: string }>) => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes.toLocaleString('es-ES')} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function hex(val: number, width = 8): string {
  return `0x${(val >>> 0).toString(16).toUpperCase().padStart(width, '0')}`;
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

const STATUS_LABEL: Record<'READY' | 'KIRK_LOCKED' | 'GLYPH_WARN' | 'MISSING', string> = {
  READY: 'Listo para parchear',
  KIRK_LOCKED: 'Cifrado Kirk (~PSP)',
  GLYPH_WARN: 'Sin glifos ñ/tildes',
  MISSING: 'No cargado',
};

export const OreimoPatchPanel: React.FC<OreimoPatchPanelProps> = ({
  classifiedItems,
  analysis,
  onReplaceClassifiedItems,
  onSendPatchedToIsoPacker,
}) => {
  const folderInputRef = useRef<HTMLInputElement | null>(null);
  const filesInputRef = useRef<HTMLInputElement | null>(null);
  const csvInputRef = useRef<HTMLInputElement | null>(null);
  const diffOrigInputRef = useRef<HTMLInputElement | null>(null);
  const diffModInputRef = useRef<HTMLInputElement | null>(null);

  const [localItems, setLocalItems] = useState<UniversalClassifiedItem[]>([]);
  const activeItems = classifiedItems.length > 0 ? classifiedItems : localItems;

  const [loadingFolder, setLoadingFolder] = useState(false);
  const [audit, setAudit] = useState<OreimoWorkspaceAudit | null>(null);

  // Script extraction & editing
  const [extractingSlots, setExtractingSlots] = useState(false);
  const [slots, setSlots] = useState<OreimoPatchSlot[]>([]);
  const [slotFileFilter, setSlotFileFilter] = useState<string>('ALL');
  const [onlyEdited, setOnlyEdited] = useState(false);
  const [slotQuery, setSlotQuery] = useState('');

  // Patch configuration
  const [patchTitle, setPatchTitle] = useState('Oreimo Portable [ESP v1.0]');
  const [sfoTitleOverride, setSfoTitleOverride] = useState('Oreimo Portable [ESP]');
  const [autoAsciiAccents, setAutoAsciiAccents] = useState(true);
  const [includePresCompressed, setIncludePresCompressed] = useState(true);

  // Patch generation output
  const [buildingPatch, setBuildingPatch] = useState(false);
  const [buildPhase, setBuildPhase] = useState<string | null>(null);
  const [patchError, setPatchError] = useState<string | null>(null);
  const [bundleOutput, setBundleOutput] = useState<OreimoPatchBundleOutput | null>(null);
  const [statusNote, setStatusNote] = useState<string | null>(null);

  // Binary 2-file Diff -> PPF/IPS
  const [diffOrigFile, setDiffOrigFile] = useState<File | null>(null);
  const [diffModFile, setDiffModFile] = useState<File | null>(null);
  const [diffRunning, setDiffRunning] = useState(false);
  const [diffResult, setDiffResult] = useState<{
    fileName: string;
    chunkCount: number;
    bytesChanged: number;
    ppfBlob: Blob;
    ipsBlob: Blob | null;
  } | null>(null);

  // Audit active workspace whenever items change
  useEffect(() => {
    if (activeItems.length === 0) {
      setAudit(null);
      return;
    }
    let cancelled = false;
    void auditOreimoWorkspace(activeItems, analysis?.isoInfo).then((res) => {
      if (cancelled) return;
      setAudit(res);
      if (res.fontSupportsSpanish === true) {
        setAutoAsciiAccents(false);
      } else if (res.fontSupportsSpanish === false) {
        setAutoAsciiAccents(true);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [activeItems, analysis?.isoInfo]);

  const handleLoadFolder = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (!list || list.length === 0) return;
    setLoadingFolder(true);
    setPatchError(null);
    try {
      const sources: UniversalSourceItem[] = Array.from(list).map((file, idx) => ({
        id: `oreimo-fld-${idx}-${file.name}`,
        name: file.name,
        path: `/${(file.webkitRelativePath || file.name).replace(/^\/+/, '')}`,
        size: file.size,
        origin: 'FOLDER',
        blob: file,
      }));
      const classified = await scanUniversalItems(sources);
      setLocalItems(classified);
      onReplaceClassifiedItems?.(
        classified,
        `Carpeta Oreimo cargada (${classified.length} archivos listos para parcheo)`
      );
      setStatusNote(`Cargados ${classified.length} archivos desde carpeta local.`);
    } finally {
      setLoadingFolder(false);
      e.target.value = '';
    }
  };

  const handleLoadFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (!list || list.length === 0) return;
    setLoadingFolder(true);
    setPatchError(null);
    try {
      const sources: UniversalSourceItem[] = Array.from(list).map((file, idx) => ({
        id: `oreimo-file-${idx}-${file.name}-${Date.now()}`,
        name: file.name,
        path: `/${file.name}`,
        size: file.size,
        origin: 'FILE',
        blob: file,
      }));
      const classified = await scanUniversalItems(sources);
      const mergedMap = new Map<string, UniversalClassifiedItem>(
        activeItems.map((it) => [it.path.toUpperCase(), it])
      );
      for (const c of classified) {
        mergedMap.set(c.path.toUpperCase(), c);
      }
      const next = Array.from(mergedMap.values());
      setLocalItems(next);
      onReplaceClassifiedItems?.(
        next,
        `Archivos añadidos al proyecto (${next.length} elementos en total)`
      );
      setStatusNote(`Añadidos ${classified.length} archivos al entorno de parcheo.`);
    } finally {
      setLoadingFolder(false);
      e.target.value = '';
    }
  };

  const handleExtractScript = async () => {
    if (activeItems.length === 0) return;
    setExtractingSlots(true);
    setPatchError(null);
    setBundleOutput(null);
    try {
      const extracted = await extractOreimoPatchSlots(activeItems, {
        maxDirectScanMb: 16,
        maxSlotsPerFile: 1200,
        includePresZlibBlocks: includePresCompressed,
      });
      setSlots(extracted);
      setStatusNote(
        `Extraídas ${extracted.length.toLocaleString('es-ES')} cadenas traducibles de los archivos del juego.`
      );
    } catch (err) {
      setPatchError(
        err instanceof Error ? err.message : 'Error al extraer textos del proyecto.'
      );
    } finally {
      setExtractingSlots(false);
    }
  };

  const handleApplyOreimoGlossary = () => {
    if (slots.length === 0) return;
    let translatedCount = 0;
    const next = slots.map((s) => {
      const suggestion = suggestOreimoSpanishTranslation(s.originalText);
      if (suggestion && suggestion !== s.originalText) {
        translatedCount++;
        return { ...s, translatedText: suggestion };
      }
      return s;
    });
    setSlots(next);
    setStatusNote(
      translatedCount > 0
        ? `Glosario Oreimo Portable aplicado: ${translatedCount} cadenas traducidas al español.`
        : 'Sin nuevas coincidencias exactas de glosario en las líneas cargadas; puedes editar manualmente o importar un guion .CSV.'
    );
  };

  const handleEditSlot = (id: string, nextVal: string) => {
    setSlots((prev) => prev.map((s) => (s.id === id ? { ...s, translatedText: nextVal } : s)));
  };

  const handleImportCsv = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const rows = parseOreimoSlotsCsv(await f.text());
    const lookup = new Map<string, string>();
    for (const r of rows) {
      lookup.set(`${r.fileName.toUpperCase()}@${r.offset}@${r.sourceBlock}`, r.translatedText);
    }
    let applied = 0;
    setSlots((prev) =>
      prev.map((s) => {
        const key = `${s.fileName.toUpperCase()}@${s.offset}@${s.sourceBlock}`;
        const hit = lookup.get(key);
        if (hit !== undefined && hit !== s.translatedText) {
          applied++;
          return { ...s, translatedText: hit };
        }
        return s;
      })
    );
    setStatusNote(`Importadas ${applied} líneas traducidas desde ${f.name}.`);
    e.target.value = '';
  };

  const handleBuildPatchBundle = async () => {
    if (activeItems.length === 0) return;
    setBuildingPatch(true);
    setPatchError(null);
    setBundleOutput(null);
    setBuildPhase('Calculando parches binarios y PPF 3.0…');
    try {
      const discId = audit?.discId || analysis?.sfoInfo?.discId || 'NPJH50421';
      const bundle = await buildOreimoTranslationPatchBundle({
        items: activeItems,
        slots,
        patchTitle,
        discId,
        newSfoTitle: sfoTitleOverride.trim() || undefined,
        autoAsciiAccents,
        isoInfo: analysis?.isoInfo,
        onProgress: (p) => setBuildPhase(p),
      });

      if (bundle.patchedFiles.length === 0) {
        setPatchError(
          'No hay cambios aplicados todavía. Usa "Auto-traducir Glosario Oreimo", edita al menos una cadena o define un título en PARAM.SFO.'
        );
      } else {
        setBundleOutput(bundle);
      }
    } catch (err) {
      setPatchError(
        err instanceof Error ? err.message : 'No se pudo construir el paquete de parche.'
      );
    } finally {
      setBuildingPatch(false);
      setBuildPhase(null);
    }
  };

  const handleSendToIsoPacker = () => {
    if (!bundleOutput || !onSendPatchedToIsoPacker) return;
    const patchedByPath = new Map<string, File>();
    for (const pf of bundleOutput.patchedFiles) {
      const cleanRel = pf.isoPath.replace(/^\/+/, '');
      patchedByPath.set(
        cleanRel.toUpperCase(),
        new File([pf.patchedBlob], pf.fileName, { type: 'application/octet-stream' })
      );
    }

    const combined: Array<{ file: File; relativePath: string }> = [];
    const seen = new Set<string>();

    // Include patched files first
    for (const pf of bundleOutput.patchedFiles) {
      const cleanRel = pf.isoPath.replace(/^\/+/, '');
      const f = patchedByPath.get(cleanRel.toUpperCase());
      if (f) {
        combined.push({ file: f, relativePath: cleanRel });
        seen.add(cleanRel.toUpperCase());
      }
    }

    // Carry over unmodified files from loaded project so the ISO structure stays complete
    for (const item of activeItems) {
      const rel = normalizeTargetIsoPath(item).replace(/^\/+/, '');
      if (seen.has(rel.toUpperCase())) continue;
      seen.add(rel.toUpperCase());
      combined.push({
        file: new File([item.blob], item.name, { type: 'application/octet-stream' }),
        relativePath: rel,
      });
    }

    onSendPatchedToIsoPacker(combined);
  };

  const handleRunManualBinaryDiff = async () => {
    if (!diffOrigFile || !diffModFile) return;
    setDiffRunning(true);
    setPatchError(null);
    try {
      const chunks = await diffBlobsToChunks(diffOrigFile, diffModFile);
      if (chunks.length === 0) {
        setPatchError('Los dos archivos seleccionados son idénticos byte a byte.');
        return;
      }
      const bytesChanged = chunks.reduce((acc, c) => acc + c.data.length, 0);
      const ppfBlob = buildPpf3Patch(chunks, `Oreimo Diff: ${diffOrigFile.name}`);
      const ipsBlob =
        Math.max(diffOrigFile.size, diffModFile.size) < 16 * 1024 * 1024
          ? buildIpsPatch(chunks)
          : null;
      setDiffResult({
        fileName: diffOrigFile.name,
        chunkCount: chunks.length,
        bytesChanged,
        ppfBlob,
        ipsBlob,
      });
    } catch (err) {
      setPatchError(err instanceof Error ? err.message : 'Error comparando los archivos.');
    } finally {
      setDiffRunning(false);
    }
  };

  const fileOptions = useMemo(() => {
    const names = Array.from(new Set(slots.map((s) => s.fileName)));
    return names;
  }, [slots]);

  const modifiedCount = useMemo(
    () => slots.filter((s) => s.translatedText !== s.originalText).length,
    [slots]
  );

  const filteredSlots = useMemo(() => {
    const q = slotQuery.trim().toLowerCase();
    return slots.filter((s) => {
      if (slotFileFilter !== 'ALL' && s.fileName !== slotFileFilter) return false;
      if (onlyEdited && s.translatedText === s.originalText) return false;
      if (!q) return true;
      return (
        s.originalText.toLowerCase().includes(q) ||
        s.translatedText.toLowerCase().includes(q) ||
        s.fileName.toLowerCase().includes(q) ||
        hex(s.offset).toLowerCase().includes(q)
      );
    });
  }, [slots, slotFileFilter, onlyEdited, slotQuery]);

  return (
    <div className="space-y-6">
      <input
        ref={folderInputRef}
        type="file"
        multiple
        onChange={(e) => void handleLoadFolder(e)}
        className="hidden"
        {...({ webkitdirectory: '', directory: '' } as Record<string, string>)}
      />
      <input
        ref={filesInputRef}
        type="file"
        multiple
        onChange={(e) => void handleLoadFiles(e)}
        className="hidden"
      />
      <input
        ref={csvInputRef}
        type="file"
        accept=".csv,.txt"
        onChange={(e) => void handleImportCsv(e)}
        className="hidden"
      />
      <input
        ref={diffOrigInputRef}
        type="file"
        onChange={(e) => {
          const f = e.target.files?.[0] ?? null;
          setDiffOrigFile(f);
          setDiffResult(null);
        }}
        className="hidden"
      />
      <input
        ref={diffModInputRef}
        type="file"
        onChange={(e) => {
          const f = e.target.files?.[0] ?? null;
          setDiffModFile(f);
          setDiffResult(null);
        }}
        className="hidden"
      />

      {/* Section 1: Workspace Loader & Oreimo Readiness Audit */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="max-w-2xl">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
              <Languages className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              Generador de Parche de Traducción al Español — Oreimo Portable (PSP)
            </h2>
            <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
              Extrae textos de <span className="font-mono">first.dat</span>, <span className="font-mono">RES.DAT</span>, <span className="font-mono">DATA.BIN</span> y <span className="font-mono">BOOT.BIN / EBOOT.BIN</span>, verifica glifos en <span className="font-mono">font.pgf</span>, traduce con glosario específico de Oreimo y compila parches <span className="font-mono">.PPF 3.0</span>, <span className="font-mono">.IPS</span>, script Python y archivos listos para reempaquetar en <span className="font-mono">.ISO</span>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={loadingFolder}
              onClick={() => folderInputRef.current?.click()}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <FolderInput className="h-4 w-4" />
              {loadingFolder ? 'Cargando…' : 'Cargar Carpeta del Juego'}
            </button>
            <button
              type="button"
              disabled={loadingFolder}
              onClick={() => filesInputRef.current?.click()}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Upload className="h-3.5 w-3.5" />
              Añadir Archivos (.dat, .bin, .sfo, .pgf)
            </button>
          </div>
        </div>

        {statusNote && (
          <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-700 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300">
            {statusNote}
          </div>
        )}

        {patchError && (
          <div className="mt-3 rounded-lg border border-red-300 bg-red-50 px-3 py-2 text-xs text-red-800 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-300">
            {patchError}
          </div>
        )}

        {/* Readiness Table */}
        {!audit ? (
          <div className="mt-4 rounded-lg border border-dashed border-slate-300 p-6 text-center text-xs text-slate-500 dark:border-slate-700 dark:text-slate-400">
            Carga tu carpeta extraída de Oreimo (<span className="font-mono">PSP_GAME/</span>, <span className="font-mono">first.dat</span>, <span className="font-mono">RES.DAT</span>, <span className="font-mono">DATA.BIN</span>, <span className="font-mono">font.pgf</span>) o una <span className="font-mono">.ISO</span> en la pestaña principal para comenzar el parcheo.
          </div>
        ) : (
          <div className="mt-4 overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
            <table className="w-full border-collapse text-left text-xs">
              <thead className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                <tr>
                  <th className="px-3.5 py-2 font-semibold">Archivo Objetivo</th>
                  <th className="px-3.5 py-2 font-semibold">Rol en Oreimo Portable</th>
                  <th className="px-3.5 py-2 font-semibold">Estado</th>
                  <th className="px-3.5 py-2 font-semibold">Detalle / Diagnóstico</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {audit.targets.map((row) => (
                  <tr key={row.role} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/30">
                    <td className="px-3.5 py-2 font-mono font-semibold text-slate-900 dark:text-white">
                      {row.expectedName}
                    </td>
                    <td className="px-3.5 py-2 text-slate-600 dark:text-slate-300">
                      {row.purpose}
                    </td>
                    <td
                      className={`px-3.5 py-2 font-semibold whitespace-nowrap ${
                        row.status === 'READY'
                          ? 'text-emerald-700 dark:text-emerald-400'
                          : row.status === 'MISSING'
                          ? 'text-slate-400'
                          : 'text-amber-700 dark:text-amber-400'
                      }`}
                    >
                      {STATUS_LABEL[row.status]}
                    </td>
                    <td className="px-3.5 py-2 font-mono text-[11px] text-slate-600 dark:text-slate-400">
                      {row.detail}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Section 2: Script Extractor, Glossary & Inline Editor */}
      {activeItems.length > 0 && (
        <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Extracción y Edición de Guion (Shift-JIS / UTF-8)
              </h3>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                Escanea textos parcheables respetando el límite exacto de bytes de cada puntero y añade tildes/ñ según soporte de <span className="font-mono">font.pgf</span>.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={extractingSlots}
                onClick={() => void handleExtractScript()}
                className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-blue-600 dark:hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Search className="h-3.5 w-3.5" />
                {extractingSlots ? 'Extrayendo Textos…' : 'Extraer Textos del Juego'}
              </button>

              {slots.length > 0 && (
                <>
                  <button
                    type="button"
                    onClick={handleApplyOreimoGlossary}
                    className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    Auto-traducir Glosario Oreimo (ES)
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      downloadBlob(
                        new Blob([exportOreimoSlotsCsv(slots)], {
                          type: 'text/csv;charset=utf-8',
                        }),
                        'GUION_OREIMO_ES.csv'
                      )
                    }
                    className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Exportar .CSV
                  </button>
                  <button
                    type="button"
                    onClick={() => csvInputRef.current?.click()}
                    className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Upload className="h-3.5 w-3.5" />
                    Importar .CSV
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Options row */}
          <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                Nombre del Parche
              </label>
              <input
                type="text"
                value={patchTitle}
                onChange={(e) => setPatchTitle(e.target.value)}
                className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                Título XMB en PARAM.SFO
              </label>
              <input
                type="text"
                value={sfoTitleOverride}
                onChange={(e) => setSfoTitleOverride(e.target.value)}
                placeholder="Oreimo Portable [ESP]"
                className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div className="flex items-end pb-1.5">
              <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoAsciiAccents}
                  onChange={(e) => setAutoAsciiAccents(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-blue-600"
                />
                Normalizar ñ/tildes a ASCII si font.pgf no las soporta
              </label>
            </div>

            <div className="flex items-end pb-1.5">
              <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includePresCompressed}
                  onChange={(e) => setIncludePresCompressed(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-blue-600"
                />
                Descomprimir bloques PRES/ZLIB en .DAT
              </label>
            </div>
          </div>

          {/* Slots Table */}
          {slots.length > 0 && (
            <div className="mt-4 space-y-3 border-t border-slate-100 pt-4 dark:border-slate-800">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2 flex-1">
                  <div className="relative min-w-[200px] max-w-sm flex-1">
                    <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={slotQuery}
                      onChange={(e) => setSlotQuery(e.target.value)}
                      placeholder="Buscar diálogo, personaje o dirección hex..."
                      className="min-h-[34px] w-full rounded-lg border border-slate-200 bg-slate-50 pl-8 pr-3 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                    />
                  </div>
                  <select
                    value={slotFileFilter}
                    onChange={(e) => setSlotFileFilter(e.target.value)}
                    aria-label="Filtrar por archivo"
                    className="min-h-[34px] rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-800 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
                  >
                    <option value="ALL">Todos los archivos ({slots.length})</option>
                    {fileOptions.map((fn) => (
                      <option key={fn} value={fn}>
                        {fn}
                      </option>
                    ))}
                  </select>
                  <label className="inline-flex items-center gap-1.5 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={onlyEdited}
                      onChange={(e) => setOnlyEdited(e.target.checked)}
                      className="h-4 w-4 rounded border-slate-300 text-blue-600"
                    />
                    Solo traducidos ({modifiedCount})
                  </label>
                </div>

                <button
                  type="button"
                  disabled={buildingPatch}
                  onClick={() => void handleBuildPatchBundle()}
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Archive className="h-4 w-4" />
                  {buildingPatch
                    ? buildPhase || 'Generando parche…'
                    : `Generar Parche de Traducción (${modifiedCount} líneas + SFO)`}
                </button>
              </div>

              <div className="max-h-[420px] overflow-auto rounded-lg border border-slate-200 dark:border-slate-800">
                <table className="w-full border-collapse text-left text-xs">
                  <thead className="sticky top-0 z-10 border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    <tr>
                      <th className="px-3 py-2 font-semibold">Archivo · Bloque</th>
                      <th className="px-3 py-2 font-semibold">Offset</th>
                      <th className="px-3 py-2 font-semibold">Texto Original</th>
                      <th className="px-3 py-2 font-semibold">Traducción al Español</th>
                      <th className="px-3 py-2 text-right font-semibold">Bytes</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredSlots.slice(0, 300).map((slot) => {
                      const effectiveText = autoAsciiAccents
                        ? stripAccentsToAscii(slot.translatedText)
                        : slot.translatedText;
                      const byteLen = encodeTextToBytes(effectiveText, slot.encoding, null, false)
                        .bytes.length;
                      const overBudget = byteLen > slot.maxByteCapacity;
                      const isEdited = slot.translatedText !== slot.originalText;

                      return (
                        <tr
                          key={slot.id}
                          className={
                            isEdited
                              ? 'bg-emerald-50/40 dark:bg-emerald-950/15'
                              : 'hover:bg-slate-50/70 dark:hover:bg-slate-800/30'
                          }
                        >
                          <td className="px-3 py-2 font-mono text-[11px] whitespace-nowrap">
                            <div className="font-semibold text-slate-900 dark:text-white">
                              {slot.fileName}
                            </div>
                            <div className="text-[10px] text-slate-500">
                              {slot.sourceBlock} · {slot.encoding}
                            </div>
                          </td>
                          <td className="px-3 py-2 font-mono text-[11px] tabular-nums text-blue-600 dark:text-blue-400">
                            {hex(slot.offset)}
                          </td>
                          <td className="max-w-xs break-words px-3 py-2 font-mono text-slate-800 dark:text-slate-200">
                            {slot.originalText}
                          </td>
                          <td className="min-w-[240px] px-3 py-1.5">
                            <input
                              type="text"
                              value={slot.translatedText}
                              onChange={(e) => handleEditSlot(slot.id, e.target.value)}
                              className="min-h-[32px] w-full rounded border border-slate-200 bg-white px-2 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                            />
                          </td>
                          <td
                            className={`px-3 py-2 text-right font-mono text-[11px] tabular-nums whitespace-nowrap ${
                              overBudget
                                ? 'font-semibold text-red-600 dark:text-red-400'
                                : 'text-slate-600 dark:text-slate-400'
                            }`}
                          >
                            {byteLen}/{slot.maxByteCapacity} B
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {slots.length === 0 && (
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
              <span>
                Pulsa <strong className="text-slate-800 dark:text-slate-200">Extraer Textos del Juego</strong> para editar líneas, o genera directamente un parche solo para el título de <span className="font-mono">PARAM.SFO</span>.
              </span>
              {audit?.targets.some((t) => t.role === 'PARAM_SFO' && t.item) && (
                <button
                  type="button"
                  disabled={buildingPatch}
                  onClick={() => void handleBuildPatchBundle()}
                  className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 cursor-pointer"
                >
                  Generar Parche PARAM.SFO ({sfoTitleOverride})
                </button>
              )}
            </div>
          )}
        </section>
      )}

      {/* Section 3: Generated Patch Outputs */}
      {bundleOutput && (
        <section className="rounded-xl border border-emerald-200 bg-white p-5 dark:border-emerald-900/60 dark:bg-slate-900">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4 dark:border-slate-800">
            <div>
              <div className="flex items-center gap-2 text-sm font-semibold text-emerald-700 dark:text-emerald-400">
                <CheckCircle2 className="h-4 w-4" />
                Parche de Traducción Generado: {bundleOutput.patchTitle}
              </div>
              <div className="mt-1 font-mono text-xs text-slate-600 tabular-nums dark:text-slate-400">
                Disc ID: {bundleOutput.discId} · {bundleOutput.patchedFiles.length} archivos parcheados · {bundleOutput.totalStringsPatched} traducciones · {formatBytes(bundleOutput.totalBytesModified)} modificados
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  downloadBlob(
                    bundleOutput.zipBlob,
                    `OREIMO_PARCHE_ESP_${bundleOutput.discId}.zip`
                  )
                }
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-emerald-700 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-800 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Download className="h-4 w-4" />
                Descargar Paquete Completo (.ZIP)
              </button>

              {bundleOutput.isoPpfBlob && (
                <button
                  type="button"
                  onClick={() =>
                    downloadBlob(
                      bundleOutput.isoPpfBlob!,
                      `OREIMO_ISO_COMPLETA_${bundleOutput.discId}.ppf`
                    )
                  }
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Download className="h-3.5 w-3.5" />
                  Parche ISO Completa (.PPF 3.0)
                </button>
              )}

              {onSendPatchedToIsoPacker && (
                <button
                  type="button"
                  onClick={handleSendToIsoPacker}
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <HardDrive className="h-4 w-4" />
                  Reempaquetar en .ISO PSP
                </button>
              )}
            </div>
          </div>

          <div className="mt-4 overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
            <table className="w-full border-collapse text-left text-xs">
              <thead className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                <tr>
                  <th className="px-3.5 py-2 font-semibold">Archivo / Ruta ISO</th>
                  <th className="px-3.5 py-2 text-right font-semibold">Traducciones</th>
                  <th className="px-3.5 py-2 text-right font-semibold">Bytes Modificados</th>
                  <th className="px-3.5 py-2 text-right font-semibold">Descargas Individuales</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {bundleOutput.patchedFiles.map((pf) => (
                  <tr key={pf.isoPath}>
                    <td className="px-3.5 py-2">
                      <div className="font-mono font-semibold text-slate-900 dark:text-white">
                        {pf.fileName}
                      </div>
                      <div className="font-mono text-[11px] text-slate-500">{pf.isoPath}</div>
                    </td>
                    <td className="px-3.5 py-2 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                      {pf.appliedStrings}
                    </td>
                    <td className="px-3.5 py-2 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                      {formatBytes(pf.bytesModified)}
                    </td>
                    <td className="px-3.5 py-2 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => downloadBlob(pf.ppfBlob, `${pf.fileName}.ppf`)}
                          className="rounded border border-slate-300 px-2.5 py-1 font-mono text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                        >
                          .PPF
                        </button>
                        {pf.ipsBlob && (
                          <button
                            type="button"
                            onClick={() => downloadBlob(pf.ipsBlob!, `${pf.fileName}.ips`)}
                            className="rounded border border-slate-300 px-2.5 py-1 font-mono text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                          >
                            .IPS
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => downloadBlob(pf.patchedBlob, pf.fileName)}
                          className="rounded bg-slate-900 px-2.5 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
                        >
                          Archivo Parcheado
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {bundleOutput.notes.length > 0 && (
            <ul className="mt-3 space-y-1 text-xs text-slate-600 dark:text-slate-400">
              {bundleOutput.notes.map((n, i) => (
                <li key={i}>• {n}</li>
              ))}
            </ul>
          )}
        </section>
      )}

      {/* Section 4: Standalone Binary Diff Patcher (Original vs Modified -> PPF3 + IPS) */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
              <FileDiff className="h-4 w-4 text-slate-600 dark:text-slate-300" />
              Comparador Binario: Generar Parche .PPF / .IPS desde Archivo Original vs Traducido
            </h3>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              Si ya editaste manualmente un archivo de Oreimo (<span className="font-mono">RES.DAT</span>, <span className="font-mono">first.dat</span>, <span className="font-mono">EBOOT.BIN</span> o una <span className="font-mono">.ISO</span> completa), selecciona el original y tu versión modificada para generar su parche distribuible.
            </p>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
          <button
            type="button"
            onClick={() => diffOrigInputRef.current?.click()}
            className="flex min-h-[42px] items-center justify-between rounded-lg border border-slate-300 bg-slate-50 px-3 text-left text-xs text-slate-800 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 cursor-pointer"
          >
            <span className="truncate font-mono">
              {diffOrigFile ? `Original: ${diffOrigFile.name}` : '1. Elegir Archivo Original'}
            </span>
            <Upload className="h-3.5 w-3.5 shrink-0 text-slate-400" />
          </button>

          <button
            type="button"
            onClick={() => diffModInputRef.current?.click()}
            className="flex min-h-[42px] items-center justify-between rounded-lg border border-slate-300 bg-slate-50 px-3 text-left text-xs text-slate-800 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 cursor-pointer"
          >
            <span className="truncate font-mono">
              {diffModFile ? `Traducido: ${diffModFile.name}` : '2. Elegir Archivo Modificado'}
            </span>
            <Upload className="h-3.5 w-3.5 shrink-0 text-slate-400" />
          </button>

          <button
            type="button"
            disabled={!diffOrigFile || !diffModFile || diffRunning}
            onClick={() => void handleRunManualBinaryDiff()}
            className="inline-flex min-h-[42px] items-center justify-center gap-1.5 rounded-lg bg-slate-900 px-4 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-40 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
          >
            <FileDiff className="h-4 w-4" />
            {diffRunning ? 'Comparando bytes…' : 'Comparar y Crear Parche .PPF/.IPS'}
          </button>
        </div>

        {diffResult && (
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-emerald-200 bg-emerald-50/70 px-3.5 py-2.5 text-xs text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/20 dark:text-emerald-200">
            <div className="font-mono tabular-nums">
              {diffResult.fileName}: {diffResult.chunkCount} bloques distintos ({formatBytes(diffResult.bytesChanged)} cambiados)
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  downloadBlob(
                    diffResult.ppfBlob,
                    `${diffResult.fileName.replace(/\.[^.]+$/, '')}_PARCHE.ppf`
                  )
                }
                className="inline-flex items-center gap-1 rounded bg-emerald-700 px-3 py-1 font-semibold text-white hover:bg-emerald-800 cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                Descargar .PPF 3.0
              </button>
              {diffResult.ipsBlob && (
                <button
                  type="button"
                  onClick={() =>
                    downloadBlob(
                      diffResult.ipsBlob!,
                      `${diffResult.fileName.replace(/\.[^.]+$/, '')}_PARCHE.ips`
                    )
                  }
                  className="inline-flex items-center gap-1 rounded border border-emerald-700 bg-white px-3 py-1 font-semibold text-emerald-800 hover:bg-emerald-50 dark:bg-slate-900 dark:text-emerald-300 cursor-pointer"
                >
                  <Download className="h-3.5 w-3.5" />
                  Descargar .IPS
                </button>
              )}
            </div>
          </div>
        )}
      </section>
    </div>
  );
};
