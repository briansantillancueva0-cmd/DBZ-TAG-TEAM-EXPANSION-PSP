import React, { useState } from 'react';
import { Check, Code2, Copy, Download, FileCode2, Layers } from 'lucide-react';
import { KOTLIN_PROJECT_FILES } from '../lib/kotlinTemplates';
import { DlcAutomationView } from './DlcAutomationView';

type GuideSubView = 'eboot' | 'kotlin' | 'python_dlc';

function downloadTextFile(content: string, filename: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export const GuideAndApkView: React.FC = () => {
  const [subView, setSubView] = useState<GuideSubView>('eboot');
  const [selectedFileIdx, setSelectedFileIdx] = useState(0);
  const [copiedKotlin, setCopiedKotlin] = useState(false);

  const activeFile = KOTLIN_PROJECT_FILES[selectedFileIdx];

  const handleCopyKotlin = async () => {
    try {
      await navigator.clipboard.writeText(activeFile.code);
      setCopiedKotlin(true);
      setTimeout(() => setCopiedKotlin(false), 1500);
    } catch {
      // Ignore clipboard failures
    }
  };

  return (
    <div className="space-y-6">
      {/* Guide Sub-View Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex flex-wrap items-center gap-1 rounded-lg bg-slate-200/70 p-1 dark:bg-slate-800">
          <button
            type="button"
            onClick={() => setSubView('eboot')}
            className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              subView === 'eboot'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
            }`}
          >
            <Layers className="h-3.5 w-3.5" />
            01. Arquitectura EBOOT.BIN
          </button>
          <button
            type="button"
            onClick={() => setSubView('kotlin')}
            className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              subView === 'kotlin'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
            }`}
          >
            <Code2 className="h-3.5 w-3.5" />
            02. Código Kotlin (APK)
          </button>
          <button
            type="button"
            onClick={() => setSubView('python_dlc')}
            className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              subView === 'python_dlc'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
            }`}
          >
            <FileCode2 className="h-3.5 w-3.5" />
            03. Script Python DLC Secuencial (2048 B ISO)
          </button>
        </div>
      </div>

      {/* View 1: Arquitectura EBOOT.BIN */}
      {subView === 'eboot' && (
        <section className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="text-xl font-semibold text-slate-900 dark:text-white">
            01. ¿Qué es EBOOT.BIN, para qué sirve y qué contiene?
          </h2>
          <p className="mt-3 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
            En toda imagen ISO de Sony PlayStation Portable (<span className="font-mono">PSP_GAME/SYSDIR/EBOOT.BIN</span>) o paquete homebrew (<span className="font-mono">PBP</span>), el archivo <span className="font-mono font-semibold text-slate-900 dark:text-white">EBOOT.BIN</span> es el ejecutable principal compilado para el procesador MIPS R4000/Allegrex de 32 bits. El firmware de la PSP lo carga en la memoria RAM principal (habitualmente desde la dirección base <span className="font-mono">0x08804000</span>) antes de transferirle el control de ejecución.
          </p>

          <div className="mt-6 grid grid-cols-1 gap-6 border-t border-slate-100 pt-6 md:grid-cols-2 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Para qué sirve analizarlo
              </h3>
              <ul className="mt-2 space-y-2 text-sm text-slate-600 dark:text-slate-300">
                <li>• Verificar la arquitectura, versión de SDK Sony y modo de ejecución (Usuario o Kernel).</li>
                <li>• Localizar la dirección exacta de inicio (<span className="font-mono">Entry Point</span>) y el mapa de memoria en RAM.</li>
                <li>• Identificar librerías del sistema (<span className="font-mono">sceDisplay</span>, <span className="font-mono">sceCtrl</span>, <span className="font-mono">sceIoFileMgr</span>, <span className="font-mono">sceGe</span>, <span className="font-mono">sceNet</span>) mediante stubs NID.</li>
                <li>• Encontrar rutas internas (<span className="font-mono">disc0:/PSP_GAME/USRDIR/...</span> y <span className="font-mono">disc0:/PSP_GAME/DLC/...</span>) y textos embebidos con su Offset exacto para traducción o edición en HxD.</li>
              </ul>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Qué contiene internamente
              </h3>
              <ul className="mt-2 space-y-2 text-sm text-slate-600 dark:text-slate-300">
                <li>• <span className="font-semibold text-slate-900 dark:text-white">Cabecera ~PSP o ELF32:</span> Identifica si el binario está sellado como PRX oficial (<span className="font-mono">~PSP</span>) o expuesto como ejecutable <span className="font-mono">\x7FELF</span>.</li>
                <li>• <span className="font-semibold text-slate-900 dark:text-white">sceModuleInfo:</span> Estructura con el nombre del módulo, puntero global <span className="font-mono">$gp</span> y límites de tablas NID.</li>
                <li>• <span className="font-semibold text-slate-900 dark:text-white">Secciones ELF:</span> <span className="font-mono">.text</span> (código máquina MIPS), <span className="font-mono">.rodata</span> (textos y rutas fijas), <span className="font-mono">.data</span> (variables) y <span className="font-mono">.bss</span> (reservas RAM).</li>
                <li>• <span className="font-semibold text-slate-900 dark:text-white">Punteros MIPS:</span> Llamadas <span className="font-mono">JAL</span> a subrutinas, pares <span className="font-mono">LUI + ADDIU</span> y límites <span className="font-mono">sltiu</span> de slots de personajes y mapas.</li>
              </ul>
            </div>
          </div>
        </section>
      )}

      {/* View 2: Código Kotlin (APK Android Studio) */}
      {subView === 'kotlin' && (
        <section className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="text-xl font-semibold text-slate-900 dark:text-white">
            02. Instalación en Android (PWA) y Código Fuente Kotlin (APK en Android Studio)
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
            Esta herramienta funciona sin conexión como aplicación Android instalable (PWA) usando el botón <span className="font-semibold text-slate-900 dark:text-white">Instalar App Android / PC</span>. Si deseas compilar un <span className="font-mono">.apk</span> nativo en Android Studio (incluyendo verificación <span className="font-mono">disc0:/</span>, LBA <span className="font-mono">2048 B</span>, límites MIPS y carpeta <span className="font-mono">PSP_GAME/DLC/</span>), aquí tienes los archivos listos para copiar o descargar:
          </p>

          <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
              {KOTLIN_PROJECT_FILES.map((file, idx) => (
                <button
                  key={file.filename}
                  type="button"
                  onClick={() => setSelectedFileIdx(idx)}
                  className={`min-h-[38px] rounded-md px-3 font-mono text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    selectedFileIdx === idx
                      ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
                  }`}
                >
                  {file.filename}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleCopyKotlin}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
              >
                {copiedKotlin ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                {copiedKotlin ? 'Copiado' : 'Copiar código'}
              </button>
              <button
                type="button"
                onClick={() => downloadTextFile(activeFile.code, activeFile.filename)}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                Descargar {activeFile.filename}
              </button>
            </div>
          </div>

          <div className="mt-3 text-xs text-slate-500 dark:text-slate-400">
            <span className="font-mono text-slate-700 dark:text-slate-300">{activeFile.path}</span>
            <span aria-hidden="true"> · </span>
            <span>{activeFile.description}</span>
          </div>

          <pre className="mt-3 max-h-[500px] overflow-auto rounded-xl border border-slate-200 bg-slate-950 p-4 font-mono text-xs leading-relaxed text-slate-100 dark:border-slate-800">
            {activeFile.code}
          </pre>
        </section>
      )}

      {/* View 3: Script Python DLC Secuencial */}
      {subView === 'python_dlc' && <DlcAutomationView />}
    </div>
  );
};
