import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  Code2,
  Copy,
  Download,
  FileCode2,
  LockOpen,
  RefreshCw,
  Upload,
} from 'lucide-react';
import {
  analyzeHeaderForQuickBms,
  buildQuickBmsScript,
  QUICKBMS_TEMPLATE_LABELS,
  type QuickBmsGenOptions,
  type QuickBmsHeaderProfile,
  type QuickBmsTemplateId,
} from '../lib/quickBmsGenerator';
import type { UniversalClassifiedItem } from '../lib/universalInspector';

interface QuickBmsTarget {
  blob: Blob;
  fileName: string;
  path?: string;
}

interface QuickBmsPanelProps {
  classifiedItems: UniversalClassifiedItem[];
  externalTarget?: QuickBmsTarget | null;
  onOpenInDecryptor?: (blob: Blob, fileName: string, path?: string) => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes.toLocaleString('es-ES')} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function toHexOffset(val: number): string {
  return `0x${(val >>> 0).toString(16).toUpperCase().padStart(2, '0')}`;
}

function sanitizeBmsDownloadName(fileName: string): string {
  const base = fileName
    .replace(/\.[^.]+$/, '')
    .replace(/[^a-zA-Z0-9_-]+/g, '_')
    .replace(/^_+|_+$/g, '');
  return `${base || 'psp_container'}_extract.bms`;
}

function downloadTextFile(content: string, filename: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

const DEFAULT_OPTIONS: QuickBmsGenOptions = {
  template: 'AUTO',
  endian: 'little',
  compression: 'auto',
  tocStartHex: '0x08',
  countOffsetHex: '0x04',
  entryStride: 8,
  includeSignatureCarver: true,
  xorKeyHex: '',
  outputPrefix: '',
};

export const QuickBmsPanel: React.FC<QuickBmsPanelProps> = ({
  classifiedItems,
  externalTarget,
  onOpenInDecryptor,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [activeTarget, setActiveTarget] = useState<QuickBmsTarget | null>(
    externalTarget ?? null
  );
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [profile, setProfile] = useState<QuickBmsHeaderProfile | null>(null);

  const [options, setOptions] = useState<QuickBmsGenOptions>(DEFAULT_OPTIONS);
  const [editedScript, setEditedScript] = useState<string>('');
  const [isManuallyEdited, setIsManuallyEdited] = useState(false);
  const [copied, setCopied] = useState(false);

  // Filter container/executable candidates from loaded ISO/Folder items
  const containerCandidates = useMemo(() => {
    return classifiedItems.filter((item) => {
      const lower = item.name.toLowerCase();
      return (
        item.category === 'EXECUTABLE_CONTAINER' ||
        item.category === 'AUDIO' ||
        lower.endsWith('.dat') ||
        lower.endsWith('.bin') ||
        lower.endsWith('.pck') ||
        lower.endsWith('.afs') ||
        lower.endsWith('.awb') ||
        lower.endsWith('.cpk') ||
        lower.endsWith('.prx')
      );
    });
  }, [classifiedItems]);

  const runHeaderAnalysis = async (target: QuickBmsTarget) => {
    setActiveTarget(target);
    setAnalyzing(true);
    setAnalysisError(null);
    setIsManuallyEdited(false);
    try {
      const res = await analyzeHeaderForQuickBms(target.blob, target.fileName);
      setProfile(res);
      setOptions({
        template: 'AUTO',
        endian: res.recommendedEndian,
        compression: 'auto',
        tocStartHex: res.detectedToc ? toHexOffset(res.detectedToc.tableStart) : '0x08',
        countOffsetHex:
          res.detectedToc?.countOffset !== null && res.detectedToc?.countOffset !== undefined
            ? toHexOffset(res.detectedToc.countOffset)
            : '0x04',
        entryStride: res.detectedToc?.entryStride ?? 8,
        includeSignatureCarver: true,
        xorKeyHex: '',
        outputPrefix: target.fileName.replace(/\.[^.]+$/, ''),
      });
    } catch (err) {
      setAnalysisError(
        err instanceof Error ? err.message : 'No se pudo leer la cabecera del archivo.'
      );
      setProfile(null);
    } finally {
      setAnalyzing(false);
    }
  };

  // Sync when user clicks QuickBMS from Tab 1 or Tab 2
  useEffect(() => {
    if (externalTarget) {
      void runHeaderAnalysis(externalTarget);
    }
  }, [externalTarget]);

  const generatedScript = useMemo(() => {
    return buildQuickBmsScript(profile, options);
  }, [profile, options]);

  useEffect(() => {
    if (!isManuallyEdited) {
      setEditedScript(generatedScript);
    }
  }, [generatedScript, isManuallyEdited]);

  const effectiveTemplate =
    options.template === 'AUTO'
      ? profile?.detectedTemplate ?? 'TOC_OFFSET_SIZE'
      : options.template;

  const showTocParams =
    effectiveTemplate === 'TOC_OFFSET_SIZE' || effectiveTemplate === 'PCK1_CONTAINER';

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    void runHeaderAnalysis({
      blob: file,
      fileName: file.name,
      path: `/${file.name}`,
    });
    e.target.value = '';
  };

  const handleCopyScript = async () => {
    try {
      await navigator.clipboard.writeText(editedScript);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Fallback if clipboard blocked
      downloadTextFile(
        editedScript,
        sanitizeBmsDownloadName(profile?.fileName || 'script_psp')
      );
    }
  };

  return (
    <div className="space-y-6">
      <input
        ref={fileInputRef}
        type="file"
        accept=".dat,.bin,.pck,.awb,.afs,.cpk,.prx,.pak,*/*"
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Top Selection & File Picker */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="max-w-2xl">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
              Generador de Scripts QuickBMS (.bms) para Contenedores .DAT, .BIN y .PCK
            </h2>
            <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
              Inspecciona los magic bytes, tablas TOC (<span className="font-mono">[Offset, Tamaño]</span>), flujos comprimidos (<span className="font-mono">BLZ4 · ZLIB · GZIP</span>) y cabeceras <span className="font-mono">PRES · PCK1 · AFS2 · AFS · ~PSP</span> para generar un script <span className="font-mono">.bms</span> listo para ejecutar en PC con QuickBMS.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Upload className="h-4 w-4" />
              Cargar .DAT / .BIN / .PCK
            </button>

            {activeTarget && onOpenInDecryptor && (
              <button
                type="button"
                onClick={() =>
                  onOpenInDecryptor(activeTarget.blob, activeTarget.fileName, activeTarget.path)
                }
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <LockOpen className="h-3.5 w-3.5" />
                Probar Descompresión en Pestaña 2
              </button>
            )}
          </div>
        </div>

        {/* Loaded Folder/ISO Candidates */}
        {containerCandidates.length > 0 && (
          <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
            <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
              Contenedores cargados en memoria:
            </span>
            {containerCandidates.slice(0, 10).map((cand) => {
              const isSelected = activeTarget?.fileName === cand.name && activeTarget?.path === cand.path;
              return (
                <button
                  key={cand.id}
                  type="button"
                  onClick={() =>
                    void runHeaderAnalysis({
                      blob: cand.blob,
                      fileName: cand.name,
                      path: cand.path,
                    })
                  }
                  className={`inline-flex min-h-[30px] items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11px] font-mono transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    isSelected
                      ? 'border-blue-600 bg-blue-50 font-semibold text-blue-700 dark:border-blue-500 dark:bg-blue-950/30 dark:text-blue-300'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300 dark:hover:bg-slate-800'
                  }`}
                >
                  {cand.name}
                  <span className="text-slate-400 tabular-nums">({formatBytes(cand.size)})</span>
                </button>
              );
            })}
          </div>
        )}
      </section>

      {analyzing && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 text-xs text-blue-700 dark:border-slate-800 dark:bg-slate-900 dark:text-blue-300">
          Analizando cabecera binaria, punteros TOC y firmas embebidas...
        </div>
      )}

      {analysisError && (
        <div className="rounded-xl border border-red-300 bg-red-50 p-4 text-xs text-red-800 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-300">
          {analysisError}
        </div>
      )}

      {/* Header Analysis Diagnostics + Hex Dump */}
      {profile && (
        <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-baseline justify-between gap-3 border-b border-slate-100 pb-3 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Diagnóstico de Cabecera: <span className="font-mono">{profile.fileName}</span>
              </h3>
              <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                <span>{profile.detectedFormatLabel}</span>
                <span aria-hidden="true">·</span>
                <span className="font-medium text-slate-700 dark:text-slate-300">
                  Confianza {profile.confidence}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums">{formatBytes(profile.fileSize)}</span>
              </div>
            </div>

            <div className="font-mono text-xs text-slate-600 dark:text-slate-400">
              Magic: <strong className="text-slate-900 dark:text-slate-200">{profile.magicAscii4 || 'BIN'}</strong> ({profile.magicHex.slice(0, 23)})
            </div>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-6 lg:grid-cols-2">
            {/* Left: Metadata & Notes */}
            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-x-4 gap-y-2 border-b border-slate-100 pb-3 dark:border-slate-800">
                <div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">Tabla TOC detectada</div>
                  <div className="mt-0.5 font-mono font-semibold text-slate-900 tabular-nums dark:text-white">
                    {profile.detectedToc
                      ? profile.detectedToc.layoutDescription
                      : 'Sin tabla TOC fija en primeros 64 KB'}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">Compresión recomendada</div>
                  <div className="mt-0.5 font-mono font-semibold text-slate-900 dark:text-white">
                    {profile.recommendedCompression === 'none'
                      ? 'Sin compresión (raw log)'
                      : profile.recommendedCompression.toUpperCase()}
                  </div>
                </div>
              </div>

              <div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  Firmas detectadas (muestra inicial 4 MB)
                </div>
                <div className="mt-1 font-mono text-xs text-slate-800 tabular-nums dark:text-slate-200">
                  {profile.detectedSignatures.length > 0
                    ? profile.detectedSignatures
                        .map((s) => `${s.signature} (${s.count})`)
                        .join(' · ')
                    : 'Ninguna firma estándar en la muestra inicial'}
                </div>
              </div>

              {profile.notes.length > 0 && (
                <ul className="space-y-1 pt-1 text-xs text-slate-600 dark:text-slate-300">
                  {profile.notes.map((n, i) => (
                    <li key={i}>• {n}</li>
                  ))}
                </ul>
              )}
            </div>

            {/* Right: 64-byte Hex Header Inspection */}
            <div>
              <div className="mb-1.5 text-[11px] font-medium text-slate-500 dark:text-slate-400">
                Primeros 64 bytes de cabecera (Hex / ASCII)
              </div>
              <pre className="overflow-x-auto rounded-lg border border-slate-200 bg-slate-50 p-3 font-mono text-[11px] leading-relaxed text-slate-800 tabular-nums dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200">
                {profile.headerDumpLines.join('\n')}
              </pre>
            </div>
          </div>
        </section>
      )}

      {/* Script Generator Parameters + Live Editor */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <FileCode2 className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Parámetros y Código QuickBMS (.bms)
            </h3>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {isManuallyEdited && (
              <button
                type="button"
                onClick={() => {
                  setIsManuallyEdited(false);
                  setEditedScript(generatedScript);
                }}
                className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Regenerar desde Cabecera
              </button>
            )}

            <button
              type="button"
              onClick={() => void handleCopyScript()}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
              {copied ? 'Copiado' : 'Copiar .bms'}
            </button>

            <button
              type="button"
              onClick={() =>
                downloadTextFile(
                  editedScript,
                  sanitizeBmsDownloadName(profile?.fileName || options.outputPrefix || 'psp_archive')
                )
              }
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              Descargar {sanitizeBmsDownloadName(profile?.fileName || options.outputPrefix || 'psp_archive')}
            </button>
          </div>
        </div>

        {/* Parameter Controls */}
        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="sm:col-span-2">
            <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
              Plantilla / Motor de Extracción
            </label>
            <select
              value={options.template}
              onChange={(e) => {
                setIsManuallyEdited(false);
                setOptions((prev) => ({
                  ...prev,
                  template: e.target.value as QuickBmsTemplateId,
                }));
              }}
              className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              {(Object.keys(QUICKBMS_TEMPLATE_LABELS) as QuickBmsTemplateId[]).map((tpl) => (
                <option key={tpl} value={tpl}>
                  {QUICKBMS_TEMPLATE_LABELS[tpl]}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
              Orden de Bytes (Endianness)
            </label>
            <select
              value={options.endian}
              onChange={(e) => {
                setIsManuallyEdited(false);
                setOptions((prev) => ({
                  ...prev,
                  endian: e.target.value as 'little' | 'big',
                }));
              }}
              className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="little">Little Endian (PSP / x86 estándar)</option>
              <option value="big">Big Endian (BE)</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
              Compresión Interna (clog / comtype)
            </label>
            <select
              value={options.compression}
              onChange={(e) => {
                setIsManuallyEdited(false);
                setOptions((prev) => ({
                  ...prev,
                  compression: e.target.value as QuickBmsGenOptions['compression'],
                }));
              }}
              className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="auto">Automática según análisis</option>
              <option value="none">Sin compresión (log directo)</option>
              <option value="zlib">ZLIB (comtype zlib_noerror)</option>
              <option value="deflate">Deflate / LZ raw</option>
              <option value="gzip">GZIP (comtype gzip)</option>
            </select>
          </div>

          {showTocParams && (
            <>
              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                  Offset Contador Archivos (hex)
                </label>
                <input
                  type="text"
                  value={options.countOffsetHex}
                  onChange={(e) => {
                    setIsManuallyEdited(false);
                    setOptions((prev) => ({ ...prev, countOffsetHex: e.target.value }));
                  }}
                  placeholder="0x04"
                  className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                  Inicio Tabla TOC (hex)
                </label>
                <input
                  type="text"
                  value={options.tocStartHex}
                  onChange={(e) => {
                    setIsManuallyEdited(false);
                    setOptions((prev) => ({ ...prev, tocStartHex: e.target.value }));
                  }}
                  placeholder="0x08"
                  className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                  Estructura de Entrada TOC
                </label>
                <select
                  value={options.entryStride}
                  onChange={(e) => {
                    setIsManuallyEdited(false);
                    setOptions((prev) => ({
                      ...prev,
                      entryStride: Number(e.target.value) as 8 | 12 | 16,
                    }));
                  }}
                  className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                >
                  <option value={8}>8 bytes: [Offset, Tamaño]</option>
                  <option value={12}>12 bytes: [ID/Hash, Offset, Tamaño]</option>
                  <option value={16}>16 bytes: [Flags, Offset, Tamaño, ZSize]</option>
                </select>
              </div>
            </>
          )}

          <div>
            <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
              Clave XOR Opcional (hex)
            </label>
            <input
              type="text"
              value={options.xorKeyHex}
              onChange={(e) => {
                setIsManuallyEdited(false);
                setOptions((prev) => ({ ...prev, xorKeyHex: e.target.value }));
              }}
              placeholder="Ej: 0xFF o 1234ABCD"
              className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-3 dark:border-slate-800">
          <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={options.includeSignatureCarver}
              onChange={(e) => {
                setIsManuallyEdited(false);
                setOptions((prev) => ({
                  ...prev,
                  includeSignatureCarver: e.target.checked,
                }));
              }}
              className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
            />
            Incluir escáner findloc de firmas embebidas (ZLIB, GZIP, BLZ4, OMG, MIG, TIM2, PNG)
          </label>

          <div className="text-[11px] text-slate-500 dark:text-slate-400">
            Comando PC: <code className="font-mono text-slate-800 dark:text-slate-200">quickbms.exe {sanitizeBmsDownloadName(profile?.fileName || 'script')} "{profile?.fileName || 'ARCHIVO.DAT'}" ./salida/</code>
          </div>
        </div>

        {/* Editable QuickBMS Script Textarea */}
        <div className="mt-4">
          <div className="mb-1.5 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
            <span className="inline-flex items-center gap-1.5">
              <Code2 className="h-3.5 w-3.5" />
              Editor de script QuickBMS {isManuallyEdited ? '(editado manualmente)' : '(sincronizado con cabecera)'}
            </span>
            <span className="font-mono tabular-nums">
              {editedScript.split('\n').length} líneas
            </span>
          </div>
          <textarea
            value={editedScript}
            onChange={(e) => {
              setIsManuallyEdited(true);
              setEditedScript(e.target.value);
            }}
            spellCheck={false}
            rows={18}
            aria-label="Código del script QuickBMS generado"
            className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3.5 font-mono text-xs leading-relaxed text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-800 dark:bg-slate-950 dark:text-slate-100"
          />
        </div>
      </section>
    </div>
  );
};
