import React, { useMemo, useRef, useState } from 'react';
import {
  Binary,
  Download,
  FolderPlus,
  Languages,
  Search,
  Sparkles,
  Table,
  Upload,
} from 'lucide-react';
import {
  encodeTextToBytes,
  parseCodeTable,
  PRESET_TBL_CONTROL,
  PRESET_TBL_ESPANOL,
  PRESET_TBL_SHIFTJIS,
  type TextEncodingMode,
} from '../lib/codeTable';
import {
  applyTranslationsToBinary,
  exportTranslationScriptCsv,
  extractTranslatableSlots,
  parseTranslationScriptCsv,
  suggestOfflineTranslation,
  type TargetLangCode,
  type TranslatableTextSlot,
} from '../lib/textTranslator';
import type { EbootAnalysis } from '../lib/types';

interface TextTranslatorPanelProps {
  analysis: EbootAnalysis;
  onJumpToHex: (offset: number) => void;
  onApplyModifiedBytes: (newBytes: Uint8Array) => void;
  onSendPatchedToIso?: (items: Array<{ path: string; data: Uint8Array }>) => void;
}

function hex(val: number, width = 6): string {
  return `0x${(val >>> 0).toString(16).toUpperCase().padStart(width, '0')}`;
}

function downloadBlob(data: BlobPart, filename: string, mime: string) {
  const blob = new Blob([data], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export const TextTranslatorPanel: React.FC<TextTranslatorPanelProps> = ({
  analysis,
  onJumpToHex,
  onApplyModifiedBytes,
  onSendPatchedToIso,
}) => {
  const [sourceEncoding, setSourceEncoding] = useState<TextEncodingMode>('windows-1252');
  const [targetEncoding, setTargetEncoding] = useState<TextEncodingMode>('windows-1252');
  const [targetLang, setTargetLang] = useState<TargetLangCode>('es');
  const [applyTblOverlay, setApplyTblOverlay] = useState(false);
  const [showTblEditor, setShowTblEditor] = useState(false);
  const [tblText, setTblText] = useState(PRESET_TBL_ESPANOL);
  const [hideSystemStrings, setHideSystemStrings] = useState(true);
  const [autoFitAccents, setAutoFitAccents] = useState(true);
  const [query, setQuery] = useState('');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const tblInputRef = useRef<HTMLInputElement | null>(null);
  const csvInputRef = useRef<HTMLInputElement | null>(null);

  const parsedTable = useMemo(() => parseCodeTable(tblText), [tblText]);

  const extractedSlots = useMemo(
    () =>
      extractTranslatableSlots(
        analysis.rawBytes,
        sourceEncoding,
        parsedTable,
        applyTblOverlay,
        analysis,
        3
      ),
    [analysis, sourceEncoding, parsedTable, applyTblOverlay]
  );

  const [editsByOffset, setEditsByOffset] = useState<Record<number, string>>({});

  const mergedSlots: TranslatableTextSlot[] = useMemo(
    () =>
      extractedSlots.map((slot) => ({
        ...slot,
        translatedText:
          editsByOffset[slot.offset] !== undefined
            ? editsByOffset[slot.offset]
            : slot.originalText,
      })),
    [extractedSlots, editsByOffset]
  );

  const visibleSlots = useMemo(() => {
    const q = query.trim().toLowerCase();
    return mergedSlots.filter((s) => {
      if (hideSystemStrings && s.isSystemToken) return false;
      if (!q) return true;
      return (
        s.originalText.toLowerCase().includes(q) ||
        s.translatedText.toLowerCase().includes(q) ||
        hex(s.offset).toLowerCase().includes(q)
      );
    });
  }, [mergedSlots, hideSystemStrings, query]);

  const modifiedCount = useMemo(
    () => mergedSlots.filter((s) => s.translatedText !== s.originalText).length,
    [mergedSlots]
  );

  const handleAutoTranslateGlossary = () => {
    const next: Record<number, string> = { ...editsByOffset };
    let matched = 0;
    for (const s of mergedSlots) {
      if (hideSystemStrings && s.isSystemToken) continue;
      const suggestion = suggestOfflineTranslation(s.originalText, targetLang);
      if (suggestion && suggestion !== s.originalText) {
        next[s.offset] = suggestion;
        matched++;
      }
    }
    setEditsByOffset(next);
    setStatusMsg(
      matched > 0
        ? `Glosario offline aplicado: ${matched} cadenas sugeridas en ${targetLang.toUpperCase()}.`
        : 'No hubo coincidencias nuevas de glosario en el filtro actual; puedes editar cualquier línea manualmente o importar un guion .CSV.'
    );
  };

  const handleApplyToBinary = (downloadAfter: boolean) => {
    const res = applyTranslationsToBinary(
      analysis.rawBytes,
      mergedSlots,
      targetEncoding,
      parsedTable,
      applyTblOverlay,
      autoFitAccents
    );
    onApplyModifiedBytes(res.patchedBytes);
    setStatusMsg(
      `Traducciones inyectadas en binario: ${res.appliedCount} textos parcheados con relleno 0x00.${
        res.truncatedCount > 0 ? ` (${res.truncatedCount} recortados al límite de bytes)` : ''
      }`
    );
    if (downloadAfter) {
      const cleanName = analysis.targetBinaryPath.split('/').pop() || 'EBOOT_TRADUCIDO.BIN';
      downloadBlob(
        res.patchedBytes.buffer as ArrayBuffer,
        `TRADUCIDO_${cleanName}`,
        'application/octet-stream'
      );
    }
  };

  const handleSendToIso = () => {
    if (!onSendPatchedToIso) return;
    const res = applyTranslationsToBinary(
      analysis.rawBytes,
      mergedSlots,
      targetEncoding,
      parsedTable,
      applyTblOverlay,
      autoFitAccents
    );
    const targetPath = analysis.targetBinaryPath.startsWith('/')
      ? analysis.targetBinaryPath
      : `/PSP_GAME/SYSDIR/${analysis.targetBinaryPath}`;
    onSendPatchedToIso([{ path: targetPath, data: res.patchedBytes }]);
  };

  const handleTblUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      setTblText(await f.text());
      setApplyTblOverlay(true);
      setShowTblEditor(true);
    }
    e.target.value = '';
  };

  const handleCsvImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      const parsed = parseTranslationScriptCsv(await f.text());
      const next: Record<number, string> = { ...editsByOffset };
      let loaded = 0;
      for (const [off, txt] of parsed.entries()) {
        next[off] = txt;
        loaded++;
      }
      setEditsByOffset(next);
      setStatusMsg(`Guion importado: ${loaded} traducciones cargadas desde ${f.name}.`);
    }
    e.target.value = '';
  };

  return (
    <div className="space-y-6">
      <input ref={tblInputRef} type="file" accept=".tbl,.txt" onChange={(e) => void handleTblUpload(e)} className="hidden" />
      <input ref={csvInputRef} type="file" accept=".csv,.txt" onChange={(e) => void handleCsvImport(e)} className="hidden" />

      {/* Header & Configuration */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-3xl">
            <h2 className="flex items-center gap-2 text-lg font-semibold text-slate-900 dark:text-white">
              <Languages className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              Traductor de Idiomas Binario (EBOOT.BIN / .TBL / Guion CSV)
            </h2>
            <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
              Extrae los textos del binario respetando el presupuesto exacto de bytes y terminador <span className="font-mono">0x00</span> para no corromper punteros MIPS. Soporta Español (<span className="font-mono">Windows-1252</span> / <span className="font-mono">UTF-8</span>), Japonés (<span className="font-mono">Shift-JIS</span>), Inglés, Portugués, Francés, Italiano y tablas <span className="font-mono">.TBL</span>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleAutoTranslateGlossary}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-blue-600 bg-blue-50 px-3 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-100 dark:border-blue-500 dark:bg-blue-950/30 dark:text-blue-300 cursor-pointer"
            >
              <Sparkles className="h-3.5 w-3.5" />
              Auto-traducir Glosario PSP
            </button>
            <button
              type="button"
              onClick={() => setShowTblEditor((s) => !s)}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
            >
              <Table className="h-3.5 w-3.5" />
              Tabla .TBL ({parsedTable.entryCount})
            </button>
            <button
              type="button"
              onClick={() =>
                downloadBlob(
                  exportTranslationScriptCsv(visibleSlots),
                  'GUION_TRADUCCION_PSP.csv',
                  'text/csv;charset=utf-8'
                )
              }
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              Exportar .CSV
            </button>
            <button
              type="button"
              onClick={() => csvInputRef.current?.click()}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
            >
              <Upload className="h-3.5 w-3.5" />
              Importar .CSV
            </button>
          </div>
        </div>

        {/* Encoding & Language Controls */}
        <div className="mt-4 grid grid-cols-1 gap-3 border-t border-slate-100 pt-4 sm:grid-cols-2 lg:grid-cols-4 text-xs dark:border-slate-800">
          <div>
            <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
              Codificación lectura origen
            </label>
            <select
              value={sourceEncoding}
              onChange={(e) => setSourceEncoding(e.target.value as TextEncodingMode)}
              className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="windows-1252">Windows-1252 (Español / Latin-1)</option>
              <option value="utf-8">UTF-8 (Multilenguaje)</option>
              <option value="shift_jis">Shift-JIS (Japonés PSP)</option>
              <option value="utf-16le">UTF-16LE (Unicode)</option>
              <option value="custom_tbl">Solo Tabla .TBL</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
              Idioma destino (Glosario)
            </label>
            <select
              value={targetLang}
              onChange={(e) => setTargetLang(e.target.value as TargetLangCode)}
              className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="es">Español (ES / LATAM)</option>
              <option value="en">Inglés (EN)</option>
              <option value="pt">Portugués (PT)</option>
              <option value="fr">Francés (FR)</option>
              <option value="it">Italiano (IT)</option>
              <option value="ja">Japonés (JA)</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
              Codificación escritura en binario
            </label>
            <select
              value={targetEncoding}
              onChange={(e) => setTargetEncoding(e.target.value as TextEncodingMode)}
              className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="windows-1252">Windows-1252 (1 B por ñ/á/é/í/ó/ú)</option>
              <option value="utf-8">UTF-8</option>
              <option value="shift_jis">Shift-JIS</option>
              <option value="utf-16le">UTF-16LE</option>
              <option value="custom_tbl">Usar Tabla .TBL</option>
            </select>
          </div>

          <div className="flex flex-col justify-end gap-1.5">
            <label className="inline-flex items-center gap-2 text-slate-700 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={hideSystemStrings}
                onChange={(e) => setHideSystemStrings(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 text-blue-600"
              />
              <span>Ocultar rutas disc0:/ y nombres ELF</span>
            </label>
            <label className="inline-flex items-center gap-2 text-slate-700 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={autoFitAccents}
                onChange={(e) => setAutoFitAccents(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 text-blue-600"
              />
              <span>Ajustar tildes a ASCII si falta espacio</span>
            </label>
          </div>
        </div>

        {/* Optional TBL Drawer */}
        {showTblEditor && (
          <div className="mt-4 space-y-2 border-t border-slate-100 pt-4 text-xs dark:border-slate-800">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-2">
                <label className="inline-flex items-center gap-1.5 font-medium text-slate-700 dark:text-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={applyTblOverlay}
                    onChange={(e) => setApplyTblOverlay(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-300 text-blue-600"
                  />
                  <span>Activar tabla .TBL personalizada</span>
                </label>
                <button
                  type="button"
                  onClick={() => tblInputRef.current?.click()}
                  className="rounded border border-slate-300 px-2.5 py-1 text-[11px] font-medium hover:bg-slate-50 dark:border-slate-700 cursor-pointer"
                >
                  Subir .TBL
                </button>
              </div>
              <div className="flex flex-wrap items-center gap-1.5">
                <button type="button" onClick={() => setTblText(PRESET_TBL_ESPANOL)} className="rounded border border-slate-200 px-2 py-1 text-[11px] dark:border-slate-700 cursor-pointer">Preset Español</button>
                <button type="button" onClick={() => setTblText(PRESET_TBL_SHIFTJIS)} className="rounded border border-slate-200 px-2 py-1 text-[11px] dark:border-slate-700 cursor-pointer">Preset Shift-JIS</button>
                <button type="button" onClick={() => setTblText(PRESET_TBL_CONTROL)} className="rounded border border-slate-200 px-2 py-1 text-[11px] dark:border-slate-700 cursor-pointer">Preset Control</button>
              </div>
            </div>
            <textarea
              value={tblText}
              onChange={(e) => setTblText(e.target.value)}
              rows={5}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2.5 font-mono text-[11px] text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>
        )}

        {statusMsg && (
          <div className="mt-4 rounded-lg border border-blue-200 bg-blue-50/70 px-4 py-2.5 text-xs text-slate-800 dark:border-blue-900/50 dark:bg-blue-950/30 dark:text-slate-200">
            {statusMsg}
          </div>
        )}
      </section>

      {/* Search + Patch Action Bar */}
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-4 py-3 dark:border-slate-800">
          <div className="relative w-full max-w-md">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar cadena original, traducción u offset (0x000454)..."
              className="min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 pl-8 pr-3 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="font-mono text-slate-500 tabular-nums dark:text-slate-400">
              {visibleSlots.length} textos · {modifiedCount} editados
            </span>
            <button
              type="button"
              disabled={modifiedCount === 0}
              onClick={() => handleApplyToBinary(false)}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
            >
              Aplicar al Binario ({modifiedCount})
            </button>
            <button
              type="button"
              disabled={modifiedCount === 0}
              onClick={() => handleApplyToBinary(true)}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-1.5 font-semibold text-white hover:bg-slate-800 disabled:opacity-40 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              Descargar Traducido
            </button>
            {onSendPatchedToIso && analysis.isoInfo && (
              <button
                type="button"
                disabled={modifiedCount === 0}
                onClick={handleSendToIso}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-emerald-600 bg-emerald-50 px-3 py-1.5 font-semibold text-emerald-700 hover:bg-emerald-100 disabled:opacity-40 dark:border-emerald-500 dark:bg-emerald-950/30 dark:text-emerald-300 cursor-pointer"
              >
                <FolderPlus className="h-3.5 w-3.5" />
                Inyectar en ISO
              </button>
            )}
          </div>
        </div>

        {visibleSlots.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500 dark:text-slate-400">
            No se encontraron textos legibles con la codificación o filtro seleccionado. Prueba cambiar a <span className="font-mono">Shift-JIS</span> o desmarcar &ldquo;Ocultar rutas disc0:/&rdquo;.
          </div>
        ) : (
          <div className="max-h-[480px] overflow-auto">
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                  <th className="px-3 py-2.5 font-semibold">Offset / RAM</th>
                  <th className="px-3 py-2.5 font-semibold">Origen</th>
                  <th className="px-3 py-2.5 font-semibold">Texto original detectado</th>
                  <th className="px-3 py-2.5 font-semibold">Traducción destino (editable)</th>
                  <th className="px-3 py-2.5 text-right font-semibold">Bytes / Máx.</th>
                  <th className="px-3 py-2.5 text-right font-semibold">HxD</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {visibleSlots.slice(0, 250).map((slot) => {
                  const encodedLen = encodeTextToBytes(
                    slot.translatedText,
                    targetEncoding,
                    parsedTable,
                    applyTblOverlay
                  ).bytes.length;
                  const overBudget = encodedLen > slot.maxByteCapacity;
                  const isDirty = slot.translatedText !== slot.originalText;

                  return (
                    <tr key={`${slot.id}-${slot.offset}`} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                      <td className="px-3 py-2 font-mono whitespace-nowrap">
                        <div className="text-slate-700 tabular-nums dark:text-slate-300">{hex(slot.offset)}</div>
                        <div className="text-[10px] text-blue-600 tabular-nums dark:text-blue-400">{hex(slot.ramAddress, 8)}</div>
                      </td>
                      <td className="px-3 py-2 font-mono text-[11px] uppercase text-slate-500">
                        {slot.detectedLang}
                      </td>
                      <td className="max-w-xs px-3 py-2 font-mono text-slate-800 break-words dark:text-slate-200">
                        {slot.originalText}
                      </td>
                      <td className="min-w-[240px] px-3 py-2">
                        <input
                          type="text"
                          value={slot.translatedText}
                          onChange={(e) =>
                            setEditsByOffset((prev) => ({ ...prev, [slot.offset]: e.target.value }))
                          }
                          className={`min-h-[34px] w-full rounded border px-2.5 py-1 font-mono text-xs focus:outline-none ${
                            overBudget
                              ? 'border-red-400 bg-red-50/70 text-red-900 dark:border-red-700 dark:bg-red-950/30 dark:text-red-200'
                              : isDirty
                              ? 'border-blue-500 bg-blue-50/50 text-slate-900 dark:border-blue-500 dark:bg-blue-950/30 dark:text-white'
                              : 'border-slate-200 bg-slate-50 text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100'
                          }`}
                        />
                      </td>
                      <td
                        className={`px-3 py-2 text-right font-mono tabular-nums whitespace-nowrap ${
                          overBudget
                            ? 'font-semibold text-red-600 dark:text-red-400'
                            : 'text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        {encodedLen} / {slot.maxByteCapacity} B
                      </td>
                      <td className="px-3 py-2 text-right">
                        <button
                          type="button"
                          onClick={() => onJumpToHex(slot.offset)}
                          className="inline-flex min-h-[30px] items-center gap-1 rounded bg-slate-900 px-2 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
                        >
                          <Binary className="h-3 w-3" />
                          HxD
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};
