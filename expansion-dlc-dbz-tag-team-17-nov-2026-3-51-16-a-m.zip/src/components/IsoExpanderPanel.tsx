import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  Archive,
  Check,
  CheckCircle2,
  Copy,
  Download,
  Edit3,
  FilePlus2,
  Film,
  FolderPlus,
  HardDrive,
  Layers,
  Plus,
  RefreshCw,
  ShieldCheck,
  Trash2,
  Upload,
} from 'lucide-react';
import {
  buildExpandedPspIsoBlob,
  buildIsoExpanderPythonScript,
  buildLobby256Char46MapPack,
  buildModDlcReplacementTemplates,
  checkIsoExpansionPermissions,
  exportModFolderZip,
  normalizeIsoTargetPath,
  PMF_FFMPEG_COMMAND,
  STANDARD_MOD_DLC_SUBFOLDERS,
  validatePmfVideoBytes,
  type ExpandedIsoBuildResult,
  type InjectedIsoFileInput,
  type IsoExpansionCheckResult,
  type Lobby256Char46MapPackOptions,
} from '../lib/isoExpander';
import { inspectPspIso } from '../lib/iso9660';
import { readDroppedItemsWithFolders } from '../lib/isoPacker';
import type { EbootAnalysis } from '../lib/types';

interface IsoExpanderPanelProps {
  analysis: EbootAnalysis;
  isoFileBlob: Blob | null;
  queuedFiles: InjectedIsoFileInput[];
  onUpdateQueuedFiles: React.Dispatch<React.SetStateAction<InjectedIsoFileInput[]>>;
  onLoadGeneratedIso?: (blob: Blob, fileName: string) => void;
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

const TARGET_SLOT_PRESETS = [
  { path: '/PSP_GAME/MOD/DLC/CASILLAS_ROSTER', label: 'Casillas Roster (Reemplazo)' },
  { path: '/PSP_GAME/MOD/DLC/BARRA_DE_VIDA', label: 'Barra de Vida HUD' },
  { path: '/PSP_GAME/MOD/DLC/LOBBY', label: 'Lobby / Menú' },
  { path: '/PSP_GAME/MOD/DLC/PERSONAJES', label: 'Personajes (.GMO/.BIN)' },
  { path: '/PSP_GAME/MOD/DLC/MAPAS', label: 'Mapas (.MAP/.BIN)' },
  { path: '/PSP_GAME/MOD/DLC/MINIMAPAS', label: 'Minimapas (.GIM/.TM2)' },
  { path: '/PSP_GAME/MOD/DLC/MUSICA_AT3', label: 'Música .AT3' },
  { path: '/PSP_GAME/MOD/DLC/OBJ', label: 'Modelos .OBJ' },
  { path: '/PSP_GAME/MOD/DLC/VIDEOS_PMF', label: 'Videos DLC .PMF (480×272)' },
] as const;

export const IsoExpanderPanel: React.FC<IsoExpanderPanelProps> = ({
  analysis,
  isoFileBlob,
  queuedFiles,
  onUpdateQueuedFiles,
  onLoadGeneratedIso,
}) => {
  const [targetSubfolder, setTargetSubfolder] = useState('/PSP_GAME/MOD/DLC/CASILLAS_ROSTER');
  const [explicitSubfolders, setExplicitSubfolders] = useState<string[]>(
    STANDARD_MOD_DLC_SUBFOLDERS.filter((s) => !s.endsWith('/VIDEOS_PMF'))
  );
  const [volumeLabel, setVolumeLabel] = useState(
    (analysis.isoInfo?.volume.volumeId || 'PSP_MOD_DLC').slice(0, 32)
  );
  const [permCheck, setPermCheck] = useState<IsoExpansionCheckResult | null>(null);
  const [checking, setChecking] = useState(false);
  const [building, setBuilding] = useState(false);
  const [buildError, setBuildError] = useState<string | null>(null);
  const [lastBuilt, setLastBuilt] = useState<{
    result: ExpandedIsoBuildResult;
    fileName: string;
    verifiedDirs: number;
    verifiedFiles: number;
    verifiedMod2048: boolean;
  } | null>(null);
  const [showPython, setShowPython] = useState(false);
  const [copiedPy, setCopiedPy] = useState(false);
  const [showPmfGuide, setShowPmfGuide] = useState(false);
  const [copiedFfmpeg, setCopiedFfmpeg] = useState(false);
  const [uploadAlert, setUploadAlert] = useState<string | null>(null);
  const [megaPackMode, setMegaPackMode] = useState<Lobby256Char46MapPackOptions['mode']>('INDIVIDUAL_FILES');
  const [megaPackNotice, setMegaPackNotice] = useState<string | null>(null);
  const [folderDropActive, setFolderDropActive] = useState(false);
  const [emptyFileNameInput, setEmptyFileNameInput] = useState('DLC_VACIO_01.BIN');
  const [renamingPath, setRenamingPath] = useState<string | null>(null);
  const [renameDraft, setRenameDraft] = useState('');

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const folderInputRef = useRef<HTMLInputElement | null>(null);
  const pythonScript = useMemo(() => buildIsoExpanderPythonScript(), []);

  const totalQueuedBytes = useMemo(
    () => queuedFiles.reduce((acc, f) => acc + f.data.length, 0),
    [queuedFiles]
  );

  const allPlannedPaths = useMemo(() => {
    const set = new Set<string>(explicitSubfolders);
    for (const f of queuedFiles) {
      set.add(normalizeIsoTargetPath(f.path));
    }
    return Array.from(set);
  }, [explicitSubfolders, queuedFiles]);

  useEffect(() => {
    if (!analysis.isoInfo) {
      setPermCheck(null);
      return;
    }
    let active = true;
    setChecking(true);
    void checkIsoExpansionPermissions(
      analysis.isoInfo,
      isoFileBlob,
      allPlannedPaths,
      totalQueuedBytes
    ).then((res) => {
      if (active) {
        setPermCheck(res);
        setChecking(false);
      }
    });
    return () => {
      active = false;
    };
  }, [analysis.isoInfo, isoFileBlob, allPlannedPaths, totalQueuedBytes]);

  const handleAddSubfolder = () => {
    const cleaned = normalizeIsoTargetPath(targetSubfolder);
    if (!explicitSubfolders.includes(cleaned)) {
      setExplicitSubfolders((prev) => [...prev, cleaned]);
    }
  };

  const handleRestoreModDlcTree = () => {
    setExplicitSubfolders((prev) =>
      Array.from(
        new Set([
          ...prev,
          ...STANDARD_MOD_DLC_SUBFOLDERS.filter((s) => !s.endsWith('/VIDEOS_PMF')),
        ])
      )
    );
  };

  const handleInjectReplacementTemplates = () => {
    handleRestoreModDlcTree();
    const templates = buildModDlcReplacementTemplates({ includeVideoPmf: false });
    onUpdateQueuedFiles((prev) => {
      const map = new Map(prev.map((x) => [x.path, x]));
      for (const t of templates) {
        if (!map.has(t.path)) {
          map.set(t.path, t);
        }
      }
      return Array.from(map.values());
    });
  };

  const handleInjectLobby256Pack = () => {
    handleRestoreModDlcTree();
    const packFiles = buildLobby256Char46MapPack({
      mode: megaPackMode,
      charCount: 256,
      mapCount: 46,
      includeLobby: true,
      includeRoster: true,
      includeLifeBar: true,
      includeVideoPmf: false,
    });
    onUpdateQueuedFiles((prev) => {
      const map = new Map(prev.map((x) => [x.path, x]));
      for (const f of packFiles) {
        map.set(f.path, f);
      }
      return Array.from(map.values());
    });
    setMegaPackNotice(
      `Pack agregado (${packFiles.length} archivos): Lobby + 256 Personajes (8 colores) + 46 Mapas + 46 Minimapas .TM2 + Roster (sin carpeta VIDEOS_PMF).`
    );
  };

  const handleAddEmptyFileInSubfolder = () => {
    const baseFolder = normalizeIsoTargetPath(targetSubfolder);
    const rawNames = emptyFileNameInput
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    const names = rawNames.length > 0 ? rawNames : ['DLC_VACIO_01.BIN'];

    if (!explicitSubfolders.includes(baseFolder)) {
      setExplicitSubfolders((prev) => [...prev, baseFolder]);
    }
    onUpdateQueuedFiles((prev) => {
      const map = new Map(prev.map((x) => [x.path, x]));
      for (const n of names) {
        const fullPath = normalizeIsoTargetPath(`${baseFolder}/${n}`);
        map.set(fullPath, { path: fullPath, data: new Uint8Array(0) });
      }
      return Array.from(map.values());
    });
    setMegaPackNotice(
      `Agregado(s) ${names.length} archivo(s) vacío(s) renombrado(s) (0 B) en ${baseFolder}/.`
    );
  };

  const handleFillAllDlcWithRenamedEmptyFiles = () => {
    handleRestoreModDlcTree();
    const rawBase = emptyFileNameInput
      .split(',')[0]
      .trim()
      .replace(/\.[^.]+$/, '')
      .replace(/[^A-Za-z0-9_-]+/g, '_')
      .toUpperCase();
    const prefix = rawBase || 'DLC_VACIO';
    const slots = [
      { folder: '/PSP_GAME/MOD/DLC/CASILLAS_ROSTER', file: `${prefix}_CASILLAS.GIM` },
      { folder: '/PSP_GAME/MOD/DLC/BARRA_DE_VIDA', file: `${prefix}_BARRA_VIDA.GIM` },
      { folder: '/PSP_GAME/MOD/DLC/LOBBY', file: `${prefix}_LOBBY.BIN` },
      { folder: '/PSP_GAME/MOD/DLC/PERSONAJES', file: `${prefix}_PERSONAJE.BIN` },
      { folder: '/PSP_GAME/MOD/DLC/MAPAS', file: `${prefix}_MAPA.BIN` },
      { folder: '/PSP_GAME/MOD/DLC/MINIMAPAS', file: `${prefix}_MINIMAPA.GIM` },
      { folder: '/PSP_GAME/MOD/DLC/MUSICA_AT3', file: `${prefix}_MUSICA.AT3` },
      { folder: '/PSP_GAME/MOD/DLC/OBJ', file: `${prefix}_OBJETO.OBJ` },
    ];
    onUpdateQueuedFiles((prev) => {
      const map = new Map(prev.map((x) => [x.path, x]));
      for (const s of slots) {
        const fullPath = normalizeIsoTargetPath(`${s.folder}/${s.file}`);
        map.set(fullPath, { path: fullPath, data: new Uint8Array(0) });
      }
      return Array.from(map.values());
    });
    setMegaPackNotice(
      `Agregados ${slots.length} archivos vacíos renombrados (0 B, prefijo "${prefix}_*") en todas las carpetas DLC.`
    );
  };

  const handleCommitQueuedRename = (oldPath: string) => {
    const nextPath = normalizeIsoTargetPath(renameDraft || oldPath);
    if (!nextPath || nextPath === oldPath) {
      setRenamingPath(null);
      return;
    }
    onUpdateQueuedFiles((prev) =>
      prev.map((item) => (item.path === oldPath ? { ...item, path: nextPath } : item))
    );
    setRenamingPath(null);
    setMegaPackNotice(`Archivo DLC renombrado: ${oldPath} → ${nextPath}`);
  };

  const handleExportModZip = () => {
    const zipBlob = exportModFolderZip(queuedFiles, explicitSubfolders);
    const discSlug = (analysis.sfoInfo?.discId || 'PSP_MOD').replace(/[^a-zA-Z0-9_-]+/g, '_');
    downloadBlob(zipBlob, `${discSlug}_PSP_GAME_MOD_DLC.zip`);
  };

  const handleAttachFilesToSubfolder = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (!list || list.length === 0) return;
    const baseFolder = normalizeIsoTargetPath(targetSubfolder);
    if (!explicitSubfolders.includes(baseFolder)) {
      setExplicitSubfolders((prev) => [...prev, baseFolder]);
    }
    const added: InjectedIsoFileInput[] = [];
    const alerts: string[] = [];
    for (let i = 0; i < list.length; i++) {
      const f = list[i];
      const buf = new Uint8Array(await f.arrayBuffer());
      const fullPath = normalizeIsoTargetPath(`${baseFolder}/${f.name}`);
      const pmfCheck = validatePmfVideoBytes(buf, f.name);
      if (pmfCheck.warning) {
        alerts.push(`${f.name}: ${pmfCheck.warning}`);
      }
      added.push({ path: fullPath, data: buf });
    }
    setUploadAlert(alerts.length > 0 ? alerts.join(' ') : null);
    onUpdateQueuedFiles((prev) => {
      const map = new Map(prev.map((x) => [x.path, x]));
      for (const a of added) map.set(a.path, a);
      return Array.from(map.values());
    });
    e.target.value = '';
  };

  const ingestFolderItemsToSubfolder = async (
    items: Array<{ file: File; relativePath: string }>
  ) => {
    if (items.length === 0) return;
    const baseFolder = normalizeIsoTargetPath(targetSubfolder);
    const baseTail = baseFolder.split('/').filter(Boolean).pop()?.toUpperCase();
    const addedDirs = new Set<string>([baseFolder]);
    const addedFiles: InjectedIsoFileInput[] = [];
    const alerts: string[] = [];

    for (const item of items) {
      const relParts = (item.relativePath || item.file.webkitRelativePath || item.file.name)
        .replace(/\\/g, '/')
        .split('/')
        .map((s) => s.trim())
        .filter(Boolean);
      if (relParts.length === 0) continue;

      const dedupParts =
        baseTail && relParts.length > 1 && relParts[0].toUpperCase() === baseTail
          ? relParts.slice(1)
          : relParts;

      const fullPath = normalizeIsoTargetPath(`${baseFolder}/${dedupParts.join('/')}`);
      const segs = fullPath.split('/').filter(Boolean);
      for (let k = 1; k < segs.length; k++) {
        addedDirs.add('/' + segs.slice(0, k).join('/'));
      }

      const buf = new Uint8Array(await item.file.arrayBuffer());
      const pmfCheck = validatePmfVideoBytes(buf, item.file.name);
      if (pmfCheck.warning) {
        alerts.push(`${item.file.name}: ${pmfCheck.warning}`);
      }
      addedFiles.push({ path: fullPath, data: buf });
    }

    setExplicitSubfolders((prev) => Array.from(new Set([...prev, ...addedDirs])).sort());
    setUploadAlert(alerts.length > 0 ? alerts.join(' ') : null);
    onUpdateQueuedFiles((prev) => {
      const map = new Map(prev.map((x) => [x.path, x]));
      for (const a of addedFiles) map.set(a.path, a);
      return Array.from(map.values());
    });
    setMegaPackNotice(
      `Carpeta agregada en ${baseFolder}/ (${addedFiles.length} archivos procesados).`
    );
  };

  const handleAttachFolderToSubfolder = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (!list || list.length === 0) return;
    const items = Array.from(list).map((file) => ({
      file,
      relativePath: file.webkitRelativePath || file.name,
    }));
    await ingestFolderItemsToSubfolder(items);
    e.target.value = '';
  };

  const handleDropFolder = async (e: React.DragEvent<HTMLElement>) => {
    e.preventDefault();
    setFolderDropActive(false);
    const items = await readDroppedItemsWithFolders(e.dataTransfer);
    await ingestFolderItemsToSubfolder(items);
  };

  const handleGenerateIso = async () => {
    if (!isoFileBlob || !analysis.isoInfo) return;
    setBuilding(true);
    setBuildError(null);
    try {
      const built = await buildExpandedPspIsoBlob(
        isoFileBlob,
        analysis.isoInfo,
        queuedFiles,
        {
          volumeId: volumeLabel,
          explicitSubfolders,
        }
      );

      const verified = await inspectPspIso(built.isoBlob);
      const discSlug = (analysis.sfoInfo?.discId || 'PSP_MOD').replace(/[^a-zA-Z0-9_-]+/g, '_');
      const outName = `${discSlug}_MOD_DLC_EXPANDIDA.ISO`;

      setLastBuilt({
        result: built,
        fileName: outName,
        verifiedDirs: verified.totalDirs,
        verifiedFiles: verified.totalFiles,
        verifiedMod2048: built.isoBlob.size % 2048 === 0,
      });

      downloadBlob(built.isoBlob, outName);
    } catch (err) {
      setBuildError(
        err instanceof Error ? err.message : 'No se pudo generar la imagen ISO expandida.'
      );
    } finally {
      setBuilding(false);
    }
  };

  const handleCopyPython = async () => {
    try {
      await navigator.clipboard.writeText(pythonScript);
      setCopiedPy(true);
      setTimeout(() => setCopiedPy(false), 1500);
    } catch {
      // ignore
    }
  };

  const handleCopyFfmpeg = async () => {
    try {
      await navigator.clipboard.writeText(PMF_FFMPEG_COMMAND);
      setCopiedFfmpeg(true);
      setTimeout(() => setCopiedFfmpeg(false), 1500);
    } catch {
      // ignore
    }
  };

  if (!analysis.isoInfo || !isoFileBlob) {
    return (
      <div className="space-y-4">
        <div className="rounded-xl border border-slate-200 bg-white p-6 text-xs text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300">
          Carga una imagen <span className="font-mono font-semibold">.ISO</span> completa (o pulsa <span className="font-semibold">Probar ISO de Muestra</span>) para comprobar los permisos ISO 9660 y generar el árbol <span className="font-mono font-semibold">/PSP_GAME/MOD/DLC/</span> directamente dentro de la <span className="font-mono">.ISO</span>. Mientras tanto, también puedes descargar la estructura de carpetas <span className="font-mono">PSP_GAME/MOD/DLC</span> en <span className="font-mono">.ZIP</span>:
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <select
              value={megaPackMode}
              onChange={(e) => setMegaPackMode(e.target.value as Lobby256Char46MapPackOptions['mode'])}
              aria-label="Modo del pack DLC 256 personajes y 46 minimapas"
              className="min-h-[38px] rounded-lg border border-slate-300 bg-slate-50 px-3 text-xs text-slate-800 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            >
              <option value="INDIVIDUAL_FILES">Individuales: Lobby + 256 CHARxxx + 46 MAPSxx + 46 MINIMAPxx</option>
              <option value="INDEXED_BIN">Contenedor Indexado: Lobby + CHAR256.BIN + MAPS46.BIN + 46 Minimapas</option>
              <option value="BOTH">Ambos (Contenedores Indexados + Archivos Individuales)</option>
            </select>
            <button
              type="button"
              onClick={handleInjectLobby256Pack}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
            >
              <FolderPlus className="h-3.5 w-3.5" />
              Agregar DLC Lobby + 256 Personajes + 46 Minimapas
            </button>
            <button
              type="button"
              onClick={handleInjectReplacementTemplates}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
            >
              <Layers className="h-3.5 w-3.5" />
              Plantillas Base ({queuedFiles.length})
            </button>
            <button
              type="button"
              onClick={handleExportModZip}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
            >
              <Archive className="h-3.5 w-3.5" />
              Descargar Carpeta PSP_GAME/MOD (.ZIP)
            </button>
          </div>
          {megaPackNotice && (
            <div className="mt-3 rounded-lg border border-emerald-300 bg-emerald-50/70 px-3 py-2 text-xs text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200">
              {megaPackNotice}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <input
        ref={fileInputRef}
        type="file"
        multiple
        onChange={(e) => void handleAttachFilesToSubfolder(e)}
        className="hidden"
      />
      <input
        ref={folderInputRef}
        type="file"
        multiple
        onChange={(e) => void handleAttachFolderToSubfolder(e)}
        className="hidden"
        {...({ webkitdirectory: '', directory: '' } as Record<string, string>)}
      />

      {/* 1. Verificación de Permisos de Expansión ISO 9660 */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-3xl">
            <h2 className="flex items-center gap-2 text-lg font-semibold text-slate-900 dark:text-white">
              <ShieldCheck className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              Permisos de Expansión ISO 9660 y Generador /PSP_GAME/MOD/DLC
            </h2>
            <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
              Comprueba si la <span className="font-mono">.ISO</span> permite agregar la carpeta <span className="font-mono">/PSP_GAME/MOD/DLC/</span> con sus subcarpetas de reemplazo (<span className="font-mono">PERSONAJES</span>, <span className="font-mono">MAPAS</span>, <span className="font-mono">MINIMAPAS</span>, <span className="font-mono">MUSICA_AT3</span>, <span className="font-mono">OBJ</span>, <span className="font-mono">LOBBY</span>, <span className="font-mono">CASILLAS_ROSTER</span>, <span className="font-mono">BARRA_DE_VIDA</span> y <span className="font-mono">VIDEOS_PMF</span>) respetando ECMA-119.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setShowPmfGuide((s) => !s)}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Film className="h-3.5 w-3.5" />
              {showPmfGuide ? 'Ocultar Guía .PMF' : 'Guía y FFmpeg para Videos .PMF (480×272)'}
            </button>
            <button
              type="button"
              onClick={() => setShowPython((s) => !s)}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              {showPython ? 'Ocultar Python ISO' : 'Script Python Expansión ISO'}
            </button>
          </div>
        </div>

        {checking || !permCheck ? (
          <div className="mt-4 text-xs text-slate-500">Evaluando estructura ISO 9660…</div>
        ) : (
          <div className="mt-4 space-y-4">
            <div
              className={`rounded-xl border p-4 text-xs ${
                permCheck.canExpand
                  ? 'border-emerald-300 bg-emerald-50/70 text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200'
                  : 'border-red-300 bg-red-50/70 text-red-900 dark:border-red-800 dark:bg-red-950/30 dark:text-red-200'
              }`}
            >
              <div className="flex items-center gap-2 font-semibold">
                {permCheck.canExpand ? (
                  <CheckCircle2 className="h-4 w-4 shrink-0" />
                ) : (
                  <AlertTriangle className="h-4 w-4 shrink-0" />
                )}
                {permCheck.verdictTitle}
              </div>
              <p className="mt-1 leading-relaxed">{permCheck.verdictSummary}</p>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4 text-xs">
              <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                <div className="text-slate-500 dark:text-slate-400">Sectores ISO actuales</div>
                <div className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums dark:text-white">
                  {permCheck.currentSectors.toLocaleString('es-ES')}
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                <div className="text-slate-500 dark:text-slate-400">Profundidad ECMA-119</div>
                <div className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums dark:text-white">
                  {permCheck.currentMaxDepth} / 8 niveles
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                <div className="text-slate-500 dark:text-slate-400">Libre en UMD (1.8 GB)</div>
                <div className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums dark:text-white">
                  {(permCheck.umdRemainingBytes / (1024 * 1024)).toFixed(1)} MB
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                <div className="text-slate-500 dark:text-slate-400">Libre sector PSP_GAME</div>
                <div className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums dark:text-white">
                  {permCheck.pspGameDirFreeBytes} B
                </div>
              </div>
            </div>

            <div className="divide-y divide-slate-100 rounded-lg border border-slate-200 dark:divide-slate-800 dark:border-slate-800">
              {permCheck.checks.map((c) => (
                <div key={c.id} className="flex items-start justify-between gap-4 p-3 text-xs">
                  <div>
                    <div className="font-semibold text-slate-900 dark:text-white">{c.title}</div>
                    <div className="mt-0.5 text-slate-600 dark:text-slate-300">{c.detail}</div>
                  </div>
                  <span
                    className={`font-mono text-[11px] font-bold shrink-0 ${
                      c.status === 'OK'
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : c.status === 'WARN'
                        ? 'text-amber-600 dark:text-amber-400'
                        : 'text-red-600 dark:text-red-400'
                    }`}
                  >
                    {c.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {showPython && (
          <div className="mt-4 space-y-2 border-t border-slate-100 pt-4 dark:border-slate-800">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="font-mono text-xs font-semibold text-slate-900 dark:text-white">
                expandir_iso_subcarpetas.py (Streaming para ISOs UMD grandes hasta 4 GB)
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => void handleCopyPython()}
                  className="inline-flex min-h-[34px] items-center gap-1 rounded border border-slate-300 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  {copiedPy ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                  {copiedPy ? 'Copiado' : 'Copiar'}
                </button>
                <button
                  type="button"
                  onClick={() =>
                    downloadBlob(
                      new Blob([pythonScript], { type: 'text/plain;charset=utf-8' }),
                      'expandir_iso_subcarpetas.py'
                    )
                  }
                  className="inline-flex min-h-[34px] items-center gap-1 rounded bg-slate-900 px-3 py-1 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
                >
                  <Download className="h-3.5 w-3.5" />
                  Descargar .PY
                </button>
              </div>
            </div>
            <pre className="max-h-72 overflow-auto rounded-lg border border-slate-200 bg-slate-950 p-3 font-mono text-[11px] leading-relaxed text-slate-100 dark:border-slate-800">
              {pythonScript}
            </pre>
          </div>
        )}

        {showPmfGuide && (
          <div className="mt-4 space-y-3 border-t border-slate-100 pt-4 text-xs dark:border-slate-800">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="font-semibold text-slate-900 dark:text-white">
                Videos DLC nativos .PMF (PSMF0014 · Streaming por hardware sceMpeg sin saturar RAM)
              </div>
              <button
                type="button"
                onClick={() => void handleCopyFfmpeg()}
                className="inline-flex min-h-[34px] items-center gap-1 rounded border border-slate-300 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
              >
                {copiedFfmpeg ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                {copiedFfmpeg ? 'Copiado' : 'Copiar comando FFmpeg'}
              </button>
            </div>
            <ul className="space-y-1 text-slate-600 dark:text-slate-300">
              <li>
                • <strong className="text-slate-900 dark:text-white">Contenedor obligatorio:</strong> <span className="font-mono">.PMF</span> (cabecera <span className="font-mono">PSMF0014</span>) en <span className="font-mono">disc0:/PSP_GAME/MOD/DLC/VIDEOS_PMF/</span>. No uses <span className="font-mono">.mp4/.avi</span> sin empaquetar porque el decodificador <span className="font-mono">sceMpeg</span> los rechaza y satura la memoria.
              </li>
              <li>
                • <strong className="text-slate-900 dark:text-white">Especificaciones PSP:</strong> <span className="font-mono">480×272 px</span> · Video <span className="font-mono">H.264 / AVC Main Profile Level 2.1</span> a <span className="font-mono">29.97 fps (30000/1001)</span> · Audio <span className="font-mono">ATRAC3plus (.at3)</span> estéreo a <span className="font-mono">44100 Hz</span> o <span className="font-mono">48000 Hz</span>.
              </li>
              <li>
                • <strong className="text-slate-900 dark:text-white">Empaquetado final:</strong> Genera <span className="font-mono">intro_video.264</span> + <span className="font-mono">intro_audio.wav</span> con FFmpeg y únelos con <span className="font-mono">UmdStreamComposer</span> + <span className="font-mono">MPS to PMF Converter</span> antes de subirlos a <span className="font-mono">VIDEOS_PMF/</span>.
              </li>
            </ul>
            <pre className="overflow-x-auto rounded-lg border border-slate-200 bg-slate-950 p-3 font-mono text-[11px] leading-relaxed text-slate-100 dark:border-slate-800">
              {PMF_FFMPEG_COMMAND}
            </pre>
          </div>
        )}
      </section>

      {/* 2. Constructor de Carpeta /PSP_GAME/MOD/DLC & Reemplazo Original */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
              <FolderPlus className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              Carpeta PSP_GAME/MOD/DLC (Reemplazo de Roster, Barra de Vida, Lobby y Assets)
            </h3>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              Elige la casilla destino dentro de <span className="font-mono">/PSP_GAME/MOD/DLC/</span>, sube tus archivos o genera las plantillas de reemplazo listas para sustituir el juego original.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleRestoreModDlcTree}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
              Restaurar árbol MOD/DLC
            </button>
            <button
              type="button"
              onClick={handleInjectReplacementTemplates}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Layers className="h-3.5 w-3.5" />
              Plantillas Base
            </button>
          </div>
        </div>

        {/* Mega Pack Builder: Lobby + 256 Personajes + 46 Mapas + 46 Minimapas */}
        <div className="mt-4 rounded-xl border border-blue-200 bg-blue-50/50 p-4 dark:border-blue-900/50 dark:bg-blue-950/20">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="text-xs font-semibold text-slate-900 dark:text-white">
                Constructor Rápido: DLC Lobby + 256 Personajes + 46 Mapas + 46 Minimapas
              </div>
              <div className="mt-0.5 text-[11px] text-slate-600 dark:text-slate-300">
                Crea automáticamente <span className="font-mono">LOBBY_CONFIG.BIN / .GIM / .MAP</span>, <span className="font-mono">ROSTER_256_46.BIN</span>, los <span className="font-mono">256</span> slots de personaje (×8 colores) y los <span className="font-mono">46</span> mapas + <span className="font-mono">46</span> minimapas <span className="font-mono">.TM2 (128×128)</span> listos para compilar la ISO.
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={megaPackMode}
                onChange={(e) => setMegaPackMode(e.target.value as Lobby256Char46MapPackOptions['mode'])}
                aria-label="Formato del pack DLC 256 personajes y 46 minimapas"
                className="min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 text-xs text-slate-800 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
              >
                <option value="INDIVIDUAL_FILES">Individuales (256 CHAR + 46 MAPS + 46 MINIMAP + Lobby)</option>
                <option value="INDEXED_BIN">Contenedor Indexado (CHAR256.BIN + MAPS46.BIN + 46 Minimapas)</option>
                <option value="BOTH">Ambos (Contenedores + Archivos Individuales)</option>
              </select>
              <button
                type="button"
                onClick={handleInjectLobby256Pack}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <FolderPlus className="h-3.5 w-3.5" />
                Agregar DLC Lobby + 256 Personajes + 46 Minimapas
              </button>
            </div>
          </div>
          {megaPackNotice && (
            <div className="mt-2.5 text-xs font-medium text-emerald-700 dark:text-emerald-300">
              {megaPackNotice}
            </div>
          )}
        </div>

        {/* Preset Selector for each MOD/DLC subfolder */}
        <div className="mt-4">
          <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
            Seleccionar carpeta destino dentro de PSP_GAME/MOD/DLC/
          </div>
          <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {TARGET_SLOT_PRESETS.map((preset) => {
              const active = normalizeIsoTargetPath(targetSubfolder) === preset.path;
              return (
                <button
                  key={preset.path}
                  type="button"
                  onClick={() => setTargetSubfolder(preset.path)}
                  className={`min-h-[40px] rounded-lg border px-3 py-2 text-left text-xs transition-colors cursor-pointer ${
                    active
                      ? 'border-blue-600 bg-blue-50 font-semibold text-blue-700 dark:border-blue-500 dark:bg-blue-950/30 dark:text-blue-300'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className="truncate">{preset.label}</div>
                  <div className="truncate font-mono text-[10px] opacity-75">
                    {preset.path.replace('/PSP_GAME/MOD/DLC/', 'MOD/DLC/')}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Subfolder Input & File Uploader */}
        <div className="mt-4 grid grid-cols-1 gap-3 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
              Ruta exacta en la ISO
            </label>
            <input
              type="text"
              value={targetSubfolder}
              onChange={(e) => setTargetSubfolder(e.target.value)}
              placeholder="/PSP_GAME/MOD/DLC/CASILLAS_ROSTER"
              className="mt-1 min-h-[40px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div className="lg:col-span-3">
            <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
              Etiqueta Volumen PVD (máx. 32)
            </label>
            <input
              type="text"
              value={volumeLabel}
              maxLength={32}
              onChange={(e) => setVolumeLabel(e.target.value)}
              className="mt-1 min-h-[40px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div className="flex flex-wrap items-end gap-2 lg:col-span-4">
            <button
              type="button"
              onClick={handleAddSubfolder}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <FolderPlus className="h-3.5 w-3.5" />
              Añadir Ruta
            </button>
            <button
              type="button"
              onClick={() => folderInputRef.current?.click()}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-blue-600 bg-white px-3 py-2 text-xs font-semibold text-blue-600 hover:bg-blue-50 dark:border-blue-500 dark:bg-slate-900 dark:text-blue-400 dark:hover:bg-blue-950/30 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <FolderPlus className="h-3.5 w-3.5" />
              Agregar Carpeta Aquí
            </button>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Upload className="h-3.5 w-3.5" />
              Subir Archivos Aquí
            </button>
          </div>
        </div>

        {/* Drag & Drop Folder Zone */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setFolderDropActive(true);
          }}
          onDragLeave={() => setFolderDropActive(false)}
          onDrop={(e) => void handleDropFolder(e)}
          className={`mt-3 rounded-lg border border-dashed px-4 py-3 text-xs transition-colors ${
            folderDropActive
              ? 'border-blue-600 bg-blue-50/70 text-blue-900 dark:border-blue-400 dark:bg-blue-950/30 dark:text-blue-200'
              : 'border-slate-200 bg-slate-50/70 text-slate-600 dark:border-slate-800 dark:bg-slate-950/40 dark:text-slate-400'
          }`}
        >
          Arrastra y suelta aquí una carpeta o archivos locales para agregarlos dentro de{' '}
          <span className="font-mono font-semibold text-slate-900 dark:text-white">
            {normalizeIsoTargetPath(targetSubfolder)}/
          </span>{' '}
          respetando subcarpetas.
        </div>

        {/* Empty Renamed Files Generator (0 B) for DLC Folders */}
        <div className="mt-3 flex flex-wrap items-end gap-2 rounded-lg border border-slate-200 bg-slate-50/70 p-3 dark:border-slate-800 dark:bg-slate-950/60">
          <div className="min-w-[240px] flex-1">
            <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
              Nombre para archivo vacío (0 B) o lista separada por comas (ej. GOKU_DLC.BIN, MAPA_01.BIN)
            </label>
            <input
              type="text"
              value={emptyFileNameInput}
              onChange={(e) => setEmptyFileNameInput(e.target.value)}
              placeholder="DLC_VACIO_01.BIN"
              className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-white px-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            />
          </div>
          <button
            type="button"
            onClick={handleAddEmptyFileInSubfolder}
            className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-blue-600 bg-white px-3 py-1.5 text-xs font-semibold text-blue-600 hover:bg-blue-50 dark:border-blue-500 dark:bg-slate-900 dark:text-blue-400 whitespace-nowrap cursor-pointer"
          >
            <FilePlus2 className="h-3.5 w-3.5" />
            Crear Archivo Vacío en Carpeta
          </button>
          <button
            type="button"
            onClick={handleFillAllDlcWithRenamedEmptyFiles}
            className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-emerald-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 whitespace-nowrap cursor-pointer"
          >
            <FilePlus2 className="h-3.5 w-3.5" />
            + Vacíos Renombrados en Todas las DLC (0 B)
          </button>
        </div>

        {/* Subfolders list */}
        <div className="mt-4">
          <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
            Subcarpetas activas en ISO ({explicitSubfolders.length})
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            {explicitSubfolders.map((dir) => (
              <div
                key={dir}
                className="inline-flex items-center gap-2 rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-[11px] text-slate-800 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              >
                <span>{dir}/</span>
                <button
                  type="button"
                  onClick={() => setExplicitSubfolders((prev) => prev.filter((x) => x !== dir))}
                  className="text-slate-400 hover:text-red-600 cursor-pointer"
                  aria-label={`Quitar ${dir}`}
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Queued Files Table */}
        <div className="mt-4">
          <div className="flex items-center justify-between text-[11px] font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
            <span>
              Archivos listos en /PSP_GAME/MOD/DLC/ ({queuedFiles.length} ·{' '}
              {(totalQueuedBytes / 1024).toFixed(1)} KB)
            </span>
            {queuedFiles.length > 0 && (
              <button
                type="button"
                onClick={() => onUpdateQueuedFiles([])}
                className="font-normal text-red-600 hover:underline cursor-pointer"
              >
                Limpiar archivos
              </button>
            )}
          </div>

          {uploadAlert && (
            <div className="mt-2 rounded-lg border border-amber-300 bg-amber-50 p-3 text-xs text-amber-900 dark:border-amber-800 dark:bg-amber-950/30 dark:text-amber-200">
              {uploadAlert}
            </div>
          )}

          {queuedFiles.length > 0 && (
            <div className="mt-2 max-h-56 overflow-auto rounded-lg border border-slate-200 dark:border-slate-800">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                    <th className="px-3 py-2 font-semibold">Ruta ISO 9660 (Reemplazo)</th>
                    <th className="px-3 py-2 font-semibold">Permiso / Formato</th>
                    <th className="px-3 py-2 text-right font-semibold">Tamaño</th>
                    <th className="px-3 py-2 text-right font-semibold">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {queuedFiles.slice(0, 120).map((f) => {
                    const pmfCheck = validatePmfVideoBytes(f.data, f.path);
                    const isRenaming = renamingPath === f.path;
                    return (
                      <tr key={f.path}>
                        <td className="px-3 py-2 font-mono text-slate-900 dark:text-slate-100">
                          {isRenaming ? (
                            <div className="flex items-center gap-1.5">
                              <input
                                type="text"
                                value={renameDraft}
                                onChange={(e) => setRenameDraft(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') handleCommitQueuedRename(f.path);
                                  if (e.key === 'Escape') setRenamingPath(null);
                                }}
                                className="min-h-[28px] w-full rounded border border-blue-500 bg-white px-2 font-mono text-[11px] text-slate-900 dark:bg-slate-900 dark:text-white"
                              />
                              <button
                                type="button"
                                onClick={() => handleCommitQueuedRename(f.path)}
                                className="rounded bg-blue-600 px-2 py-1 font-sans text-[11px] font-semibold text-white cursor-pointer"
                              >
                                Guardar
                              </button>
                            </div>
                          ) : (
                            <div>{f.path}</div>
                          )}
                          {pmfCheck.warning && (
                            <div className="mt-0.5 font-sans text-[11px] text-amber-700 dark:text-amber-300">
                              {pmfCheck.warning}
                            </div>
                          )}
                        </td>
                        <td className="px-3 py-2 font-mono text-[11px] text-slate-500">
                          {pmfCheck.isPmf
                            ? `PSMF${pmfCheck.version || '0014'} · 0x00 (;1)`
                            : '0x00 (;1 Lectura)'}
                        </td>
                        <td className="px-3 py-2 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                          {f.data.length.toLocaleString('es-ES')} B
                        </td>
                        <td className="px-3 py-2 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                setRenamingPath(f.path);
                                setRenameDraft(f.path);
                              }}
                              title="Renombrar ruta/archivo"
                              className="inline-flex items-center gap-1 rounded border border-slate-200 px-2 py-0.5 text-[11px] text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                            >
                              <Edit3 className="h-3 w-3" />
                              Renombrar
                            </button>
                            <button
                              type="button"
                              onClick={() => onUpdateQueuedFiles((prev) => prev.filter((x) => x.path !== f.path))}
                              className="text-slate-400 hover:text-red-600 cursor-pointer"
                              aria-label={`Quitar ${f.path}`}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {queuedFiles.length > 120 && (
                <div className="border-t border-slate-200 bg-slate-50 px-3 py-2 text-[11px] text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                  Mostrando los primeros 120 de {queuedFiles.length} archivos en cola (los {queuedFiles.length} archivos completos se incluirán al generar la .ISO o el .ZIP).
                </div>
              )}
            </div>
          )}
        </div>

        {/* Generate Action */}
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4 dark:border-slate-800">
          <div className="text-xs text-slate-500 dark:text-slate-400">
            Recompila sectores <span className="font-mono">2048 B</span>, tablas <span className="font-mono">L/M</span>, bandera <span className="font-mono">0x02</span> para subcarpetas y sufijo <span className="font-mono">;1</span> para archivos.
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleExportModZip}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Archive className="h-4 w-4" />
              Exportar Carpeta MOD (.ZIP)
            </button>

            <button
              type="button"
              disabled={building || (permCheck !== null && !permCheck.canExpand)}
              onClick={() => void handleGenerateIso()}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-lg bg-slate-900 px-5 py-2.5 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-blue-600 dark:hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <HardDrive className="h-4 w-4" />
              {building ? 'Generando ISO 9660…' : 'Generar y Descargar .ISO con MOD/DLC'}
            </button>
          </div>
        </div>

        {buildError && (
          <div className="mt-3 rounded-lg border border-red-300 bg-red-50 p-3 text-xs text-red-800 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-300">
            {buildError}
          </div>
        )}

        {lastBuilt && (
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-emerald-300 bg-emerald-50/70 p-4 text-xs text-emerald-950 dark:border-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200">
            <div>
              <div className="font-semibold">
                ISO generada y autoverificada: <span className="font-mono">{lastBuilt.fileName}</span>
              </div>
              <div className="mt-1 font-mono tabular-nums">
                {lastBuilt.verifiedDirs} directorios · {lastBuilt.verifiedFiles} archivos ·{' '}
                {lastBuilt.result.totalSectors} sectores ({lastBuilt.result.totalBytes.toLocaleString('es-ES')} B) ·{' '}
                {lastBuilt.verifiedMod2048 ? 'mod 2048 = 0 OK' : 'Revisar alineación'}
              </div>
            </div>

            {onLoadGeneratedIso && (
              <button
                type="button"
                onClick={() => onLoadGeneratedIso(lastBuilt.result.isoBlob, lastBuilt.fileName)}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Cargar .ISO Generada en el Analizador
              </button>
            )}
          </div>
        )}
      </section>
    </div>
  );
};
