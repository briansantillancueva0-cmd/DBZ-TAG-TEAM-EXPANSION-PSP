import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  Binary,
  CheckCircle2,
  Cpu,
  Download,
  FolderCheck,
  HardDrive,
  Route,
} from 'lucide-react';
import { runModVerificationSuite, type ModVerificationSuite } from '../lib/dlcVerifier';
import type { EbootAnalysis } from '../lib/types';

interface DlcVerifierPanelProps {
  analysis: EbootAnalysis;
  isoFileBlob: Blob | null;
  onJumpToHex: (offset: number) => void;
}

function hex(val: number | null | undefined, width = 8): string {
  if (val === null || val === undefined || Number.isNaN(val)) return '—';
  return `0x${(val >>> 0).toString(16).toUpperCase().padStart(width, '0')}`;
}

function downloadText(content: string, filename: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export const DlcVerifierPanel: React.FC<DlcVerifierPanelProps> = ({
  analysis,
  isoFileBlob,
  onJumpToHex,
}) => {
  const [suite, setSuite] = useState<ModVerificationSuite | null>(null);
  const [loading, setLoading] = useState(true);
  const [pathFilter, setPathFilter] = useState<'ALL' | 'DLC' | 'NO_NULL'>('ALL');
  const [roleFilter, setRoleFilter] = useState<'ALL' | 'PERSONAJES' | 'MAPAS'>('ALL');

  useEffect(() => {
    let active = true;
    setLoading(true);
    void runModVerificationSuite(analysis, isoFileBlob).then((res) => {
      if (active) {
        setSuite(res);
        setLoading(false);
      }
    });
    return () => {
      active = false;
    };
  }, [analysis, isoFileBlob]);

  const filteredPaths = useMemo(() => {
    if (!suite) return [];
    return suite.disc0Paths.filter((p) => {
      if (pathFilter === 'DLC') return p.kind === 'DLC';
      if (pathFilter === 'NO_NULL') return !p.nullTerminated;
      return true;
    });
  }, [suite, pathFilter]);

  const filteredMips = useMemo(() => {
    if (!suite) return [];
    return suite.mipsLimits.filter((m) => {
      if (roleFilter === 'PERSONAJES') return m.likelyRole === 'PERSONAJES';
      if (roleFilter === 'MAPAS') return m.likelyRole === 'MAPAS';
      return true;
    });
  }, [suite, roleFilter]);

  const handleExportAudit = () => {
    if (!suite) return;
    const lines: string[] = [];
    lines.push('========================================================================');
    lines.push('      AUDITORÍA DLC / DISC0:/ / SECTORES LBA ISO / LÍMITES MIPS PSP     ');
    lines.push('========================================================================');
    lines.push(`Archivo origen : ${analysis.sourceName}`);
    lines.push(`Binario        : ${analysis.targetBinaryPath}`);
    lines.push('');

    lines.push('--- [1] VALIDACIÓN DE SECTORES LBA ISO (SECTOR 16 PVD) ---');
    if (suite.isoAlignment) {
      lines.push(`  • Tamaño bloque lógico   : ${suite.isoAlignment.logicalBlockSize} bytes`);
      lines.push(`  • Tamaño total archivo   : ${suite.isoAlignment.totalSizeBytes} bytes`);
      lines.push(`  • Múltiplo exacto 2048 B : ${suite.isoAlignment.isSizeMultipleOf2048 ? 'SÍ' : 'NO'}`);
      lines.push(`  • Archivos sin alinear   : ${suite.isoAlignment.unalignedFilesCount}`);
      suite.isoAlignment.notes.forEach((n) => lines.push(`  • ${n}`));
    } else {
      lines.push('  (No se cargó imagen ISO completa)');
    }
    lines.push('');

    lines.push(`--- [2] VERIFICADOR DE RUTAS disc0:/ Y ms0:/ (${suite.disc0Paths.length} hallazgos) ---`);
    suite.disc0Paths.forEach((p) => {
      lines.push(
        `  #${String(p.index).padStart(3, '0')} [${p.kind.padEnd(6)}] Off: ${hex(p.fileOffset, 6)} | RAM: ${hex(p.ramAddress)} | 0x00: ${p.nullTerminated ? 'OK' : 'FALTA'} | ${p.path}`
      );
    });
    lines.push('');

    lines.push(`--- [3] LÍMITES DE IDS MIPS EN .text (${suite.mipsLimits.length} candidatos) ---`);
    suite.mipsLimits.forEach((m) => {
      lines.push(
        `  #${String(m.index).padStart(3, '0')} [${m.likelyRole.padEnd(11)}] Off: ${hex(m.fileOffset, 6)} | RAM: ${hex(m.ramAddress)} | ${m.mnemonic} | ${m.suggestion}`
      );
    });
    lines.push('');

    lines.push('--- [4] AUDITORÍA DE CARPETA PSP_GAME/DLC/ ---');
    if (suite.dlcAudit && suite.dlcAudit.hasDlcFolder) {
      lines.push(
        `  Archivos detectados: ${suite.dlcAudit.totalDlcFiles} (${suite.dlcAudit.totalDlcBytes.toLocaleString('es-ES')} B)`
      );
      suite.dlcAudit.missingCharWarnings.forEach((w) => lines.push(`  [!] ${w}`));
      suite.dlcAudit.missingMapWarnings.forEach((w) => lines.push(`  [!] ${w}`));
      suite.dlcAudit.containers.forEach((c) => {
        lines.push(`  [CONTENEDOR] ${c.fileName} (${c.sizeBytes} B) -> ${c.detail}`);
      });
      suite.dlcAudit.sequentialChars.forEach((c) => {
        lines.push(`  [CHAR] ${c.fileName} | ${c.status} | ${c.detail}`);
      });
      suite.dlcAudit.sequentialMaps.forEach((m) => {
        lines.push(`  [MAP ] ${m.fileName} | ${m.status} | ${m.detail}`);
      });
      suite.dlcAudit.sequentialBgm.forEach((b) => {
        lines.push(`  [BGM ] ${b.fileName} | ${b.status} | ${b.detail}`);
      });
    } else {
      lines.push('  (No se detectó carpeta /PSP_GAME/DLC/ en la imagen ISO)');
    }

    const safeSlug = (analysis.sfoInfo?.discId || analysis.sourceName)
      .replace(/[^a-zA-Z0-9_-]+/g, '_')
      .slice(0, 32);
    downloadText(lines.join('\n'), `AUDITORIA_DLC_${safeSlug}.txt`);
  };

  if (loading || !suite) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-6 text-sm text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300">
        Ejecutando verificaciones de rutas disc0:/, alineación LBA 2048 B, instrucciones MIPS y carpeta PSP_GAME/DLC/…
      </div>
    );
  }

  const nullOkCount = suite.disc0Paths.filter((p) => p.nullTerminated).length;
  const totalWarnings =
    (suite.dlcAudit?.missingCharWarnings.length ?? 0) +
    (suite.dlcAudit?.missingMapWarnings.length ?? 0);

  return (
    <div className="space-y-6">
      {/* Header + Export */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div>
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
            Auditoría de Expansión DLC, Rutas disc0:/, Sectores ISO y Límites MIPS
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Verificación técnica para mods PSP: redirecciones <span className="font-mono">disc0:/PSP_GAME/</span> terminadas en <span className="font-mono">0x00</span>, alineación de sectores <span className="font-mono">2048 B</span>, instrucciones <span className="font-mono">sltiu</span> en <span className="font-mono">.text</span> y estructura <span className="font-mono">PSP_GAME/DLC/</span>.
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportAudit}
          className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Download className="h-3.5 w-3.5" />
          Exportar Auditoría DLC (.TXT)
        </button>
      </div>

      {/* 4 KPI Verification Summary Cards */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Rutas disc0:/ y ms0:/</span>
            <Route className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums dark:text-white">
            {suite.disc0Paths.length}
          </div>
          <div className="mt-1 text-[11px] font-mono text-slate-500 tabular-nums dark:text-slate-400">
            {nullOkCount} con fin 0x00 · {suite.disc0Paths.length - nullOkCount} sin nulo
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Alineación LBA ISO</span>
            <HardDrive className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums dark:text-white">
            {suite.isoAlignment
              ? suite.isoAlignment.isBlockSize2048 && suite.isoAlignment.isSizeMultipleOf2048
                ? '2048 B OK'
                : 'Revisar'
              : 'Sin ISO'}
          </div>
          <div className="mt-1 text-[11px] font-mono text-slate-500 tabular-nums dark:text-slate-400">
            {suite.isoAlignment
              ? `PVD: ${suite.isoAlignment.logicalBlockSize} B · ${suite.isoAlignment.unalignedFilesCount} desalineados`
              : 'Carga una .ISO para validar sectores'}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Límites IDs en .text</span>
            <Cpu className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums dark:text-white">
            {suite.mipsLimits.length}
          </div>
          <div className="mt-1 text-[11px] font-mono text-slate-500 tabular-nums dark:text-slate-400">
            {suite.mipsLimits.filter((m) => m.likelyRole === 'PERSONAJES').length} chars ·{' '}
            {suite.mipsLimits.filter((m) => m.likelyRole === 'MAPAS').length} mapas
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Carpeta PSP_GAME/DLC/</span>
            <FolderCheck className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums dark:text-white">
            {suite.dlcAudit?.totalDlcFiles ?? 0} archivos
          </div>
          <div className="mt-1 text-[11px] font-mono text-slate-500 tabular-nums dark:text-slate-400">
            {totalWarnings > 0 ? `${totalWarnings} advertencia(s) de secuencia` : 'Secuencia continua o sin DLC'}
          </div>
        </div>
      </div>

      {/* 1. Validación de Sectores LBA ISO (Sector 16 PVD) */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
          1. Validación de Sectores LBA de la ISO (Sector 16 · Primary Volume Descriptor)
        </h3>
        {suite.isoAlignment ? (
          <div className="mt-3 space-y-3">
            <dl className="grid grid-cols-1 gap-3 border-t border-slate-100 pt-3 text-xs sm:grid-cols-4 dark:border-slate-800">
              <div>
                <dt className="text-slate-500">Bloque lógico PVD</dt>
                <dd className="mt-0.5 font-mono font-semibold text-slate-900 tabular-nums dark:text-white">
                  {suite.isoAlignment.logicalBlockSize} bytes
                </dd>
              </div>
              <div>
                <dt className="text-slate-500">Tamaño real archivo ISO</dt>
                <dd className="mt-0.5 font-mono font-semibold text-slate-900 tabular-nums dark:text-white">
                  {suite.isoAlignment.totalSizeBytes.toLocaleString('es-ES')} B
                </dd>
              </div>
              <div>
                <dt className="text-slate-500">Múltiplo de 2048 B</dt>
                <dd
                  className={`mt-0.5 font-mono font-semibold ${
                    suite.isoAlignment.isSizeMultipleOf2048
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-amber-600 dark:text-amber-400'
                  }`}
                >
                  {suite.isoAlignment.isSizeMultipleOf2048 ? 'Correcto (mod 2048 = 0)' : 'Error de alineación'}
                </dd>
              </div>
              <div>
                <dt className="text-slate-500">Espacio declarado PVD</dt>
                <dd className="mt-0.5 font-mono text-slate-800 tabular-nums dark:text-slate-200">
                  {suite.isoAlignment.pvdDeclaredBytes.toLocaleString('es-ES')} B
                </dd>
              </div>
            </dl>
            <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-300">
              {suite.isoAlignment.notes.map((n, i) => (
                <li key={i}>• {n}</li>
              ))}
            </ul>
          </div>
        ) : (
          <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
            Se analizó un binario suelto sin contenedor ISO. Carga la imagen <span className="font-mono">.ISO</span> modificada para validar el sector 16 (PVD) y la alineación a 2048 bytes.
          </p>
        )}
      </section>

      {/* 2. Verificador de Rutas disc0:/ */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              2. Verificador de Rutas disc0:/PSP_GAME/ y Byte Nulo (0x00)
            </h3>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              Confirma que las redirecciones desde <span className="font-mono">ms0:/</span> hacia <span className="font-mono">disc0:/PSP_GAME/</span> estén bien terminadas en byte <span className="font-mono">0x00</span> sin caracteres residuales.
            </p>
          </div>

          <div className="flex items-center rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
            {(
              [
                { key: 'ALL', label: `Todas (${suite.disc0Paths.length})` },
                { key: 'DLC', label: 'Solo DLC' },
                { key: 'NO_NULL', label: 'Sin 0x00' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.key}
                type="button"
                onClick={() => setPathFilter(tab.key)}
                className={`min-h-[34px] rounded-md px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  pathFilter === tab.key
                    ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {filteredPaths.length === 0 ? (
          <p className="mt-4 text-xs text-slate-500 dark:text-slate-400">
            No se encontraron rutas con el filtro activo en este binario.
          </p>
        ) : (
          <div className="mt-4 max-h-72 overflow-y-auto overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                  <th className="px-3 py-2 font-semibold">#</th>
                  <th className="px-3 py-2 font-semibold">Tipo</th>
                  <th className="px-3 py-2 font-semibold">Ruta detectada</th>
                  <th className="px-3 py-2 font-semibold">Offset</th>
                  <th className="px-3 py-2 font-semibold">RAM PSP</th>
                  <th className="px-3 py-2 font-semibold">Fin 0x00</th>
                  <th className="px-3 py-2 text-right font-semibold">Editar</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredPaths.map((item) => (
                  <tr key={`${item.index}-${item.fileOffset}`} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="px-3 py-2 font-mono text-slate-400 tabular-nums">
                      {String(item.index).padStart(3, '0')}
                    </td>
                    <td className="px-3 py-2 font-mono text-[11px] text-slate-500 dark:text-slate-400">
                      {item.kind}
                    </td>
                    <td className="max-w-md truncate px-3 py-2 font-mono text-slate-900 dark:text-slate-100" title={item.path}>
                      {item.path}
                    </td>
                    <td className="px-3 py-2 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      {hex(item.fileOffset, 6)}
                    </td>
                    <td className="px-3 py-2 font-mono font-semibold tabular-nums text-blue-600 dark:text-blue-400">
                      {hex(item.ramAddress)}
                    </td>
                    <td className="px-3 py-2 font-mono whitespace-nowrap">
                      {item.nullTerminated ? (
                        <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          0x00 OK
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-red-600 dark:text-red-400">
                          <AlertTriangle className="h-3.5 w-3.5" />
                          Sin 0x00
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-2 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => onJumpToHex(item.fileOffset)}
                        className="inline-flex min-h-[30px] items-center gap-1 rounded bg-slate-900 px-2.5 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
                      >
                        <Binary className="h-3 w-3" />
                        HxD
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* 3. Parcheo de Límites de IDs en .text */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              3. Buscador de Límites de IDs en .text (Instrucciones MIPS sltiu / slti)
            </h3>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              Localiza comparaciones <span className="font-mono">0x46 / 0x4C</span> (personajes base → <span className="font-mono">0xFF</span> para 256 slots) y <span className="font-mono">0x10 / 0x0A</span> (mapas base → <span className="font-mono">0x2E</span> para 46 mapas).
            </p>
          </div>

          <div className="flex items-center rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
            {(
              [
                { key: 'ALL', label: `Todos (${suite.mipsLimits.length})` },
                { key: 'PERSONAJES', label: 'Personajes' },
                { key: 'MAPAS', label: 'Mapas' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.key}
                type="button"
                onClick={() => setRoleFilter(tab.key)}
                className={`min-h-[34px] rounded-md px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  roleFilter === tab.key
                    ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {filteredMips.length === 0 ? (
          <p className="mt-4 text-xs text-slate-500 dark:text-slate-400">
            No se detectaron instrucciones <span className="font-mono">sltiu/slti</span> con límites estándar en <span className="font-mono">.text</span> (o el binario está sellado como <span className="font-mono">~PSP</span> sin ELF expuesto).
          </p>
        ) : (
          <div className="mt-4 max-h-72 overflow-y-auto overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                  <th className="px-3 py-2 font-semibold">#</th>
                  <th className="px-3 py-2 font-semibold">Rol</th>
                  <th className="px-3 py-2 font-semibold">Instrucción MIPS</th>
                  <th className="px-3 py-2 font-semibold">Offset</th>
                  <th className="px-3 py-2 font-semibold">RAM PSP</th>
                  <th className="px-3 py-2 font-semibold">Guía de parcheo</th>
                  <th className="px-3 py-2 text-right font-semibold">Parchear</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredMips.map((m) => (
                  <tr key={`${m.index}-${m.fileOffset}`} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="px-3 py-2 font-mono text-slate-400 tabular-nums">
                      {String(m.index).padStart(3, '0')}
                    </td>
                    <td className="px-3 py-2 font-mono text-[11px] font-semibold text-slate-700 dark:text-slate-200">
                      {m.likelyRole}
                    </td>
                    <td className="px-3 py-2 font-mono font-semibold text-slate-900 dark:text-white">
                      {m.mnemonic}
                    </td>
                    <td className="px-3 py-2 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      {hex(m.fileOffset, 6)}
                    </td>
                    <td className="px-3 py-2 font-mono font-semibold tabular-nums text-blue-600 dark:text-blue-400">
                      {hex(m.ramAddress)}
                    </td>
                    <td className="max-w-md px-3 py-2 text-slate-600 dark:text-slate-300">
                      {m.suggestion}
                    </td>
                    <td className="px-3 py-2 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => onJumpToHex(m.fileOffset)}
                        className="inline-flex min-h-[30px] items-center gap-1 rounded bg-slate-900 px-2.5 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
                      >
                        <Binary className="h-3 w-3" />
                        Ir a HxD
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* 4. Auditoría de carpeta PSP_GAME/DLC/ */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
          4. Auditoría de Carpeta PSP_GAME/DLC/ (Archivos Secuenciales y Contenedores DLC\0)
        </h3>

        {!suite.dlcAudit || !suite.dlcAudit.hasDlcFolder ? (
          <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
            No se detectaron archivos dentro de <span className="font-mono">/PSP_GAME/DLC/</span> en la imagen cargada.
          </p>
        ) : (
          <div className="mt-4 space-y-5">
            {totalWarnings > 0 && (
              <div className="rounded-xl border border-amber-300 bg-amber-50/70 p-4 text-xs text-amber-900 dark:border-amber-800 dark:bg-amber-950/30 dark:text-amber-200">
                <div className="flex items-center gap-2 font-semibold">
                  <AlertTriangle className="h-4 w-4 shrink-0" />
                  Advertencias de saltos en secuencia continua ({totalWarnings})
                </div>
                <ul className="mt-2 space-y-1">
                  {suite.dlcAudit.missingCharWarnings.map((w, i) => (
                    <li key={`cw-${i}`}>• {w}</li>
                  ))}
                  {suite.dlcAudit.missingMapWarnings.map((w, i) => (
                    <li key={`mw-${i}`}>• {w}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Contenedores DLC\0 */}
            {suite.dlcAudit.containers.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                  Contenedores Indexados DLC\0 ({suite.dlcAudit.containers.length})
                </h4>
                <div className="mt-2 overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
                  <table className="w-full border-collapse text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                        <th className="px-3 py-2 font-semibold">Archivo</th>
                        <th className="px-3 py-2 font-semibold">Firma</th>
                        <th className="px-3 py-2 font-semibold">Entradas</th>
                        <th className="px-3 py-2 font-semibold">Estado</th>
                        <th className="px-3 py-2 text-right font-semibold">Tamaño</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {suite.dlcAudit.containers.map((c) => (
                        <tr key={c.path}>
                          <td className="px-3 py-2 font-mono font-semibold text-slate-900 dark:text-white">
                            {c.fileName}
                          </td>
                          <td className="px-3 py-2 font-mono">
                            {c.hasDlcMagic ? (
                              <span className="text-emerald-600 dark:text-emerald-400">DLC\0 OK</span>
                            ) : (
                              <span className="text-red-600 dark:text-red-400">Sin firma</span>
                            )}
                          </td>
                          <td className="px-3 py-2 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                            {c.populatedEntries} con datos · {c.emptyStubEntries} stubs / {c.declaredEntries}
                          </td>
                          <td className="px-3 py-2 text-slate-600 dark:text-slate-300">{c.detail}</td>
                          <td className="px-3 py-2 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                            {c.sizeBytes.toLocaleString('es-ES')} B
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Personajes Secuenciales */}
            {suite.dlcAudit.sequentialChars.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                  Personajes Secuenciales CHAR077.BIN – CHAR256.BIN ({suite.dlcAudit.sequentialChars.length} slots evaluados)
                </h4>
                <div className="mt-2 max-h-60 overflow-y-auto overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
                  <table className="w-full border-collapse text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                        <th className="px-3 py-2 font-semibold">Archivo</th>
                        <th className="px-3 py-2 font-semibold">Slot ID</th>
                        <th className="px-3 py-2 font-semibold">Estado</th>
                        <th className="px-3 py-2 font-semibold">Colores / Cabecera 64 B</th>
                        <th className="px-3 py-2 text-right font-semibold">Tamaño</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {suite.dlcAudit.sequentialChars.map((c) => (
                        <tr key={c.fileName}>
                          <td className="px-3 py-2 font-mono font-semibold text-slate-900 dark:text-white">
                            {c.fileName}
                          </td>
                          <td className="px-3 py-2 font-mono tabular-nums text-slate-600 dark:text-slate-400">
                            #{c.idNumber}
                          </td>
                          <td className="px-3 py-2 font-mono">
                            {c.status === 'OK' ? (
                              <span className="text-emerald-600 dark:text-emerald-400">OK</span>
                            ) : c.status === 'MISSING' ? (
                              <span className="font-semibold text-red-600 dark:text-red-400">FALTA EN ISO</span>
                            ) : (
                              <span className="text-amber-600 dark:text-amber-400">STUB VACÍO</span>
                            )}
                          </td>
                          <td className="px-3 py-2 text-slate-600 dark:text-slate-300">{c.detail}</td>
                          <td className="px-3 py-2 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                            {c.sizeBytes > 0 ? `${c.sizeBytes.toLocaleString('es-ES')} B` : '—'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Mapas & BGM Secuenciales */}
            {(suite.dlcAudit.sequentialMaps.length > 0 || suite.dlcAudit.sequentialBgm.length > 0) && (
              <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
                {suite.dlcAudit.sequentialMaps.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                      Mapas Secuenciales MAPS11.BIN – MAPS46.BIN
                    </h4>
                    <div className="mt-2 overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
                      <table className="w-full border-collapse text-left text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                            <th className="px-3 py-2 font-semibold">Archivo</th>
                            <th className="px-3 py-2 font-semibold">Estado</th>
                            <th className="px-3 py-2 font-semibold">Detalle</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                          {suite.dlcAudit.sequentialMaps.map((m) => (
                            <tr key={m.fileName}>
                              <td className="px-3 py-2 font-mono font-semibold text-slate-900 dark:text-white">
                                {m.fileName}
                              </td>
                              <td className="px-3 py-2 font-mono">
                                {m.status === 'OK' ? (
                                  <span className="text-emerald-600 dark:text-emerald-400">OK</span>
                                ) : (
                                  <span className="text-red-600 dark:text-red-400">{m.status}</span>
                                )}
                              </td>
                              <td className="px-3 py-2 text-slate-600 dark:text-slate-300">{m.detail}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {suite.dlcAudit.sequentialBgm.length > 0 && (
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                      Pistas de Audio BGM001.AT3+
                    </h4>
                    <div className="mt-2 overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
                      <table className="w-full border-collapse text-left text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                            <th className="px-3 py-2 font-semibold">Archivo</th>
                            <th className="px-3 py-2 font-semibold">Detalle</th>
                            <th className="px-3 py-2 text-right font-semibold">Tamaño</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                          {suite.dlcAudit.sequentialBgm.map((b) => (
                            <tr key={b.fileName}>
                              <td className="px-3 py-2 font-mono font-semibold text-slate-900 dark:text-white">
                                {b.fileName}
                              </td>
                              <td className="px-3 py-2 text-slate-600 dark:text-slate-300">{b.detail}</td>
                              <td className="px-3 py-2 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                                {b.sizeBytes.toLocaleString('es-ES')} B
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
};
