import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  Archive,
  Binary,
  Check,
  CheckCircle2,
  Copy,
  Download,
  Edit3,
  FileCode2,
  FilePlus2,
  Film,
  FolderInput,
  FolderPlus,
  HardDrive,
  Package,
  RefreshCw,
  Replace,
  Save,
  Search,
  Terminal,
  Trash2,
  Upload,
} from 'lucide-react';
import { extractIsoFileBytes, inspectPspIso } from '../lib/iso9660';
import {
  appendFolderFilesToTarget,
  buildFolderPackerPythonScript,
  buildMinimalPspPackerTemplate,
  buildUmdDataBin,
  extractIsoSelectionToZip,
  importIsoToPackerEntries,
  normalizeIsoFolderPath,
  normalizeIsoPackerPath,
  normalizeUploadedFolderFiles,
  packPspIsoBlob,
  readDroppedItemsWithFolders,
  validatePackerProject,
  writeIsoPartsToWritableStream,
  type PackerEntry,
  type PackerValidationResult,
  type PackPspIsoResult,
} from '../lib/isoPacker';
import type { EbootAnalysis, IsoFileEntry } from '../lib/types';
import { IsoPmfVideoEditor } from './IsoPmfVideoEditor';

interface IsoPackerExtractorPanelProps {
  analysis: EbootAnalysis | null;
  isoFileBlob: Blob | null;
  onRequestLoadFile: () => void;
  onLoadSampleIso: () => void;
  onInspectIsoAssetBytes?: (bytes: Uint8Array, assetPath: string) => void;
  onLoadGeneratedIso?: (blob: Blob, fileName: string) => void;
  initialDroppedItems?: Array<{ file: File; relativePath: string }> | null;
  onConsumeInitialDroppedItems?: () => void;
}

type WorkspaceMode = 'extract' | 'pack' | 'videos_pmf';

function hex(val: number | null | undefined, width = 8): string {
  if (val === null || val === undefined || Number.isNaN(val)) return '—';
  return `0x${(val >>> 0).toString(16).toUpperCase().padStart(width, '0')}`;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes.toLocaleString('es-ES')} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

const ORIGIN_LABEL: Record<PackerEntry['origin'], string> = {
  BASE_ISO: 'ISO base',
  LOCAL_FOLDER: 'Carpeta local',
  LOCAL_FILE: 'Archivo local',
  MODIFIED_EBOOT: 'EBOOT editado',
  GENERATED: 'Generado',
};

const TARGET_FOLDER_PRESETS = [
  '/',
  '/PSP_GAME',
  '/PSP_GAME/INSDIR',
  '/PSP_GAME/SYSDIR',
  '/PSP_GAME/SYSDIR/UPDATE',
  '/PSP_GAME/USRDIR',
  '/PSP_GAME/MOD/DLC',
] as const;

export const IsoPackerExtractorPanel: React.FC<IsoPackerExtractorPanelProps> = ({
  analysis,
  isoFileBlob,
  onRequestLoadFile,
  onLoadSampleIso,
  onInspectIsoAssetBytes,
  onLoadGeneratedIso,
  initialDroppedItems,
  onConsumeInitialDroppedItems,
}) => {
  const hasIso = Boolean(analysis?.isoInfo && isoFileBlob);
  const [mode, setMode] = useState<WorkspaceMode>(
    initialDroppedItems && initialDroppedItems.length > 0 ? 'pack' : hasIso ? 'extract' : 'pack'
  );

  // --- Extractor State ---
  const [extractQuery, setExtractQuery] = useState('');
  const [selectedFolder, setSelectedFolder] = useState<string>('ALL');
  const [extractingZip, setExtractingZip] = useState(false);
  const [extractProgress, setExtractProgress] = useState<{
    done: number;
    total: number;
    currentPath: string;
  } | null>(null);
  const [extractNotice, setExtractNotice] = useState<string | null>(null);
  const [extractError, setExtractError] = useState<string | null>(null);

  // --- Packer State ---
  const [packerEntries, setPackerEntries] = useState<PackerEntry[]>([]);
  const [packerEmptyDirs, setPackerEmptyDirs] = useState<string[]>([]);
  const [targetAddFolder, setTargetAddFolder] = useState('/PSP_GAME/USRDIR');
  const [newSubfolderInput, setNewSubfolderInput] = useState('/PSP_GAME/USRDIR/CUSTOM');
  const [packerSearch, setPackerSearch] = useState('');
  const [packerFolderFilter, setPackerFolderFilter] = useState('ALL');
  const [preserveCase, setPreserveCase] = useState(true);
  const [volumeId, setVolumeId] = useState('PSP_CUSTOM_ISO');
  const [systemId, setSystemId] = useState('PSP GAME');
  const [publisher, setPublisher] = useState('PSP EBOOT INSPECTOR');
  const [outputFileName, setOutputFileName] = useState('PSP_EMPAQUETADA.ISO');
  const [autoGenerateUmdData, setAutoGenerateUmdData] = useState(true);
  const [packerDragActive, setPackerDragActive] = useState(false);
  const [packerNotice, setPackerNotice] = useState<string | null>(null);
  const [validation, setValidation] = useState<PackerValidationResult | null>(null);
  const [packing, setPacking] = useState(false);
  const [packProgress, setPackProgress] = useState<{ phase: string; percent: number } | null>(null);
  const [packError, setPackError] = useState<string | null>(null);
  const [showPythonPacker, setShowPythonPacker] = useState(false);
  const [copiedPython, setCopiedPython] = useState(false);
  const [lastPacked, setLastPacked] = useState<{
    result: PackPspIsoResult;
    fileName: string;
    verifiedFiles: number;
    verifiedDirs: number;
    verifiedMod2048: boolean;
    verifiedSfoTitle: string | null;
    verifiedHasEboot: boolean;
  } | null>(null);

  const folderInputRef = useRef<HTMLInputElement | null>(null);
  const addFolderToTargetRef = useRef<HTMLInputElement | null>(null);
  const filesInputRef = useRef<HTMLInputElement | null>(null);
  const replaceInputRef = useRef<HTMLInputElement | null>(null);
  const [replaceTargetPath, setReplaceTargetPath] = useState<string | null>(null);
  const [packerEmptyNamePrefix, setPackerEmptyNamePrefix] = useState('DLC_VACIO');
  const [renamingPackerPath, setRenamingPackerPath] = useState<string | null>(null);
  const [renamePackerDraft, setRenamePackerDraft] = useState('');

  const pythonPackerScript = useMemo(() => buildFolderPackerPythonScript(), []);
  const supportsStreamingSave =
    typeof window !== 'undefined' &&
    typeof (window as unknown as { showSaveFilePicker?: unknown }).showSaveFilePicker === 'function';

  // Keep mode sensible when user loads an ISO while empty
  useEffect(() => {
    if (hasIso && packerEntries.length === 0 && !(initialDroppedItems && initialDroppedItems.length > 0)) {
      setMode('extract');
    }
  }, [hasIso, packerEntries.length, initialDroppedItems]);

  // Re-validate packer entries whenever they change
  useEffect(() => {
    let active = true;
    void validatePackerProject(packerEntries, packerEmptyDirs).then((res) => {
      if (active) setValidation(res);
    });
    return () => {
      active = false;
    };
  }, [packerEntries, packerEmptyDirs]);

  // Auto-update suggested Volume ID and filename when PARAM.SFO is detected in packer
  useEffect(() => {
    if (validation?.detectedSfo?.discId) {
      const disc = validation.detectedSfo.discId.replace(/[^A-Za-z0-9_-]+/g, '_');
      setVolumeId((prev) => (prev === 'PSP_CUSTOM_ISO' ? disc.slice(0, 32) : prev));
      setOutputFileName((prev) =>
        prev === 'PSP_EMPAQUETADA.ISO' ? `${disc}_PACKED.ISO` : prev
      );
    }
  }, [validation?.detectedSfo]);

  // --- Extractor Computations ---
  const isoFolders = useMemo(() => {
    if (!analysis?.isoInfo) return [];
    return analysis.isoInfo.files
      .filter((f) => f.isDirectory)
      .map((f) => f.path)
      .sort();
  }, [analysis?.isoInfo]);

  const isoFileRows = useMemo(() => {
    if (!analysis?.isoInfo) return [];
    const q = extractQuery.trim().toLowerCase();
    return analysis.isoInfo.files.filter((f) => {
      if (f.isDirectory) return false;
      if (selectedFolder !== 'ALL') {
        const prefix = selectedFolder.endsWith('/') ? selectedFolder : `${selectedFolder}/`;
        if (!f.path.startsWith(prefix)) return false;
      }
      if (!q) return true;
      return f.path.toLowerCase().includes(q) || f.name.toLowerCase().includes(q);
    });
  }, [analysis?.isoInfo, extractQuery, selectedFolder]);

  const quickEntries = useMemo(() => {
    if (!analysis?.isoInfo) return [];
    const targets = [
      '/PSP_GAME/PARAM.SFO',
      '/PSP_GAME/SYSDIR/EBOOT.BIN',
      '/PSP_GAME/SYSDIR/BOOT.BIN',
      '/UMD_DATA.BIN',
      '/PSP_GAME/ICON0.PNG',
    ];
    return targets
      .map((t) =>
        analysis.isoInfo!.files.find(
          (f) => !f.isDirectory && f.path.toUpperCase() === t.toUpperCase()
        )
      )
      .filter((x): x is IsoFileEntry => Boolean(x));
  }, [analysis?.isoInfo]);

  const handleExtractSingleFile = async (entry: IsoFileEntry) => {
    if (!isoFileBlob) return;
    setExtractError(null);
    try {
      const slice = isoFileBlob.slice(entry.byteOffset, entry.byteOffset + entry.size);
      downloadBlob(slice, entry.name);
      setExtractNotice(`Archivo extraído: ${entry.path} (${formatBytes(entry.size)}).`);
    } catch (err) {
      setExtractError(err instanceof Error ? err.message : 'No se pudo extraer el archivo.');
    }
  };

  const handleOpenInHxd = async (entry: IsoFileEntry) => {
    if (!isoFileBlob || !onInspectIsoAssetBytes) return;
    if (entry.size > 16 * 1024 * 1024) {
      setExtractError(
        `El archivo ${entry.name} pesa ${formatBytes(entry.size)} (>16 MB). Usa "Extraer" para descargarlo directamente.`
      );
      return;
    }
    const bytes = await extractIsoFileBytes(isoFileBlob, entry);
    onInspectIsoAssetBytes(bytes, entry.path);
  };

  const handleExtractZip = async (folderPrefix: string | null) => {
    if (!isoFileBlob || !analysis?.isoInfo) return;
    setExtractingZip(true);
    setExtractError(null);
    setExtractNotice(null);
    setExtractProgress({ done: 0, total: 1, currentPath: 'Preparando lista de archivos...' });

    try {
      const targetFiles = analysis.isoInfo.files.filter((f) => {
        if (f.isDirectory) return false;
        if (!folderPrefix || folderPrefix === 'ALL') return true;
        const p = folderPrefix.replace(/\/+$/, '').toUpperCase();
        return f.path.toUpperCase().startsWith(`${p}/`);
      });
      const totalSelectedBytes = targetFiles.reduce((acc, f) => acc + f.size, 0);
      if (totalSelectedBytes > 750 * 1024 * 1024) {
        throw new Error(
          `La selección ocupa ${formatBytes(totalSelectedBytes)} y supera el límite seguro de Blob ZIP en navegador (750 MB). Selecciona una subcarpeta específica (ej. /PSP_GAME/SYSDIR o /PSP_GAME/DLC) o extrae los archivos grandes individualmente.`
        );
      }

      const res = await extractIsoSelectionToZip(
        isoFileBlob,
        analysis.isoInfo,
        folderPrefix === 'ALL' ? null : folderPrefix,
        (done, total, currentPath) => setExtractProgress({ done, total, currentPath })
      );

      const discSlug = (analysis.sfoInfo?.discId || analysis.sourceName.replace(/\.iso$/i, ''))
        .replace(/[^a-zA-Z0-9_-]+/g, '_')
        .slice(0, 32);
      const folderTag =
        folderPrefix && folderPrefix !== 'ALL'
          ? '_' + folderPrefix.replace(/^\/+/, '').replace(/[^a-zA-Z0-9_-]+/g, '_')
          : '_EXTRAIDA';
      const zipName = `${discSlug}${folderTag}.zip`;

      downloadBlob(res.zipBlob, zipName);
      setExtractNotice(
        `Extraídos ${res.fileCount} archivos (${formatBytes(res.totalBytes)}) en ${zipName}.`
      );
    } catch (err) {
      setExtractError(err instanceof Error ? err.message : 'Error al generar el ZIP extraído.');
    } finally {
      setExtractingZip(false);
      setExtractProgress(null);
    }
  };

  // --- Packer Handlers ---
  const mergePackerEntries = (incoming: PackerEntry[], extraEmptyDirs: string[] = []) => {
    setPackerEntries((prev) => {
      const map = new Map(prev.map((item) => [item.path.toUpperCase(), item]));
      for (const item of incoming) {
        map.set(item.path.toUpperCase(), item);
      }
      return Array.from(map.values()).sort((a, b) => a.path.localeCompare(b.path));
    });
    if (extraEmptyDirs.length > 0) {
      setPackerEmptyDirs((prev) =>
        Array.from(
          new Set([
            ...prev,
            ...extraEmptyDirs.map((d) => normalizeIsoFolderPath(d, preserveCase)),
          ])
        ).sort()
      );
    }
  };

  // Load dropped folder items forwarded from Home Dropzone
  useEffect(() => {
    if (!initialDroppedItems || initialDroppedItems.length === 0) return;
    const { entries, strippedWrapper } = normalizeUploadedFolderFiles(
      initialDroppedItems,
      preserveCase
    );
    mergePackerEntries(entries);
    setMode('pack');
    setPackerNotice(
      strippedWrapper
        ? `Carpeta "${strippedWrapper}" cargada desde inicio (${entries.length} archivos en estructura PSP).`
        : `Cargados ${entries.length} archivos con subcarpetas desde inicio.`
    );
    onConsumeInitialDroppedItems?.();
  }, [initialDroppedItems]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleImportLoadedIsoToPacker = () => {
    if (!isoFileBlob || !analysis?.isoInfo) return;
    const { entries, emptyDirs } = importIsoToPackerEntries(isoFileBlob, analysis.isoInfo);
    setPackerEntries(entries);
    setPackerEmptyDirs(emptyDirs);
    setVolumeId((analysis.isoInfo.volume.volumeId || 'PSP_CUSTOM_ISO').slice(0, 32));
    setPublisher((analysis.isoInfo.volume.publisher || 'PSP EBOOT INSPECTOR').slice(0, 128));
    const discSlug = (analysis.sfoInfo?.discId || analysis.sourceName.replace(/\.iso$/i, ''))
      .replace(/[^a-zA-Z0-9_-]+/g, '_')
      .slice(0, 32);
    setOutputFileName(`${discSlug}_REEMPAQUETADA.ISO`);
    setPackerNotice(
      `Importados ${entries.length} archivos desde ${analysis.sourceName} al Empaquetador ISO.`
    );
    setMode('pack');
  };

  const ensurePackerBaseline = (): { entries: PackerEntry[]; emptyDirs: string[] } => {
    if (packerEntries.length === 0 && isoFileBlob && analysis?.isoInfo) {
      const imported = importIsoToPackerEntries(isoFileBlob, analysis.isoInfo);
      setVolumeId((analysis.isoInfo.volume.volumeId || 'PSP_CUSTOM_ISO').slice(0, 32));
      setPublisher((analysis.isoInfo.volume.publisher || 'PSP EBOOT INSPECTOR').slice(0, 128));
      return imported;
    }
    return { entries: packerEntries, emptyDirs: packerEmptyDirs };
  };

  const handleUpsertVideoPackerFiles = (
    incoming: Array<{ path: string; data: Uint8Array; origin?: PackerEntry['origin'] }>,
    notice?: string
  ) => {
    const base = ensurePackerBaseline();
    const map = new Map(base.entries.map((item) => [item.path.toUpperCase(), item]));
    for (const item of incoming) {
      const normPath = normalizeIsoPackerPath(item.path, preserveCase);
      map.set(normPath.toUpperCase(), {
        path: normPath,
        size: item.data.length,
        source: item.data,
        origin: item.origin ?? 'GENERATED',
      });
    }
    setPackerEntries(Array.from(map.values()).sort((a, b) => a.path.localeCompare(b.path)));
    if (base.entries !== packerEntries) {
      setPackerEmptyDirs(base.emptyDirs);
    }
    if (notice) setPackerNotice(notice);
  };

  const handleDeleteVideoTargets = (
    pathsToRemove: string[],
    folderPrefixes: string[],
    notice: string
  ) => {
    const base = ensurePackerBaseline();
    const removeSet = new Set(pathsToRemove.map((p) => p.toUpperCase()));
    const normPrefixes = folderPrefixes.map((p) => p.toUpperCase().replace(/\/+$/, ''));

    const filteredEntries = base.entries.filter((e) => {
      const up = e.path.toUpperCase();
      if (removeSet.has(up)) return false;
      if (normPrefixes.some((pref) => up.startsWith(`${pref}/`))) return false;
      return true;
    });

    const filteredDirs = base.emptyDirs.filter((d) => {
      const up = d.toUpperCase().replace(/\/+$/, '');
      return !normPrefixes.some((pref) => up === pref || up.startsWith(`${pref}/`));
    });

    setPackerEntries(filteredEntries);
    setPackerEmptyDirs(filteredDirs);
    setPackerNotice(notice);
  };

  const handleInjectCurrentEboot = () => {
    if (!analysis || analysis.rawBytes.length === 0) return;
    const targetPath = '/PSP_GAME/SYSDIR/EBOOT.BIN';
    mergePackerEntries([
      {
        path: targetPath,
        size: analysis.rawBytes.length,
        source: analysis.rawBytes,
        origin: 'MODIFIED_EBOOT',
      },
    ]);
    setPackerNotice(
      `Inyectado ${analysis.targetBinaryPath} (${formatBytes(analysis.rawBytes.length)}) en ${targetPath}.`
    );
    setMode('pack');
  };

  const handleFolderSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const items = Array.from(fileList).map((file) => ({
      file,
      relativePath: file.webkitRelativePath || file.name,
    }));
    const { entries, strippedWrapper } = normalizeUploadedFolderFiles(items, preserveCase);
    mergePackerEntries(entries);
    setPackerNotice(
      strippedWrapper
        ? `Carpeta "${strippedWrapper}" cargada (${entries.length} archivos normalizados a raíz PSP).`
        : `Cargados ${entries.length} archivos desde carpeta local.`
    );
    e.target.value = '';
  };

  const handleAddFolderToTargetSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const items = Array.from(fileList).map((file) => ({
      file,
      relativePath: file.webkitRelativePath || file.name,
    }));
    const baseTarget = normalizeIsoFolderPath(targetAddFolder, preserveCase);
    const { entries, folderName } = appendFolderFilesToTarget(items, baseTarget, {
      preserveCase,
    });
    mergePackerEntries(entries);
    setPackerNotice(
      `Carpeta "${folderName || 'subcarpeta'}" agregada en ${baseTarget === '/' ? '' : baseTarget}/ (${entries.length} archivos).`
    );
    e.target.value = '';
  };

  const handleLooseFilesSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const baseDir = normalizeIsoFolderPath(targetAddFolder, preserveCase);
    const incoming: PackerEntry[] = Array.from(fileList).map((file) => ({
      path: normalizeIsoPackerPath(
        `${baseDir === '/' ? '' : baseDir}/${file.name}`,
        preserveCase
      ),
      size: file.size,
      source: file,
      origin: 'LOCAL_FILE',
    }));
    mergePackerEntries(incoming);
    setPackerNotice(`Agregados ${incoming.length} archivos en ${baseDir === '/' ? '/' : `${baseDir}/`}.`);
    e.target.value = '';
  };

  const handlePackerDrop = async (e: React.DragEvent<HTMLElement>) => {
    e.preventDefault();
    setPackerDragActive(false);
    const items = await readDroppedItemsWithFolders(e.dataTransfer);
    if (items.length === 0) return;

    const hasSubpaths = items.some((it) => it.relativePath.includes('/'));
    if (hasSubpaths) {
      const looksLikeRootGame = items.some((it) =>
        /(^|\/)(PSP_GAME|UMD_DATA\.BIN|SYSDIR|PARAM\.SFO)(\/|$)/i.test(it.relativePath)
      );
      if (looksLikeRootGame) {
        const { entries, strippedWrapper } = normalizeUploadedFolderFiles(items, preserveCase);
        mergePackerEntries(entries);
        setPackerNotice(
          strippedWrapper
            ? `Carpeta "${strippedWrapper}" soltada (${entries.length} archivos en estructura PSP).`
            : `Soltados ${entries.length} archivos con estructura de subcarpetas PSP.`
        );
      } else {
        const baseTarget = normalizeIsoFolderPath(targetAddFolder, preserveCase);
        const { entries, folderName } = appendFolderFilesToTarget(items, baseTarget, {
          preserveCase,
        });
        mergePackerEntries(entries);
        setPackerNotice(
          `Carpeta "${folderName || 'custom'}" agregada en ${baseTarget === '/' ? '/' : `${baseTarget}/`} (${entries.length} archivos).`
        );
      }
    } else {
      const baseDir = normalizeIsoFolderPath(targetAddFolder, preserveCase);
      const incoming: PackerEntry[] = items.map((it) => ({
        path: normalizeIsoPackerPath(
          `${baseDir === '/' ? '' : baseDir}/${it.file.name}`,
          preserveCase
        ),
        size: it.file.size,
        source: it.file,
        origin: 'LOCAL_FILE',
      }));
      mergePackerEntries(incoming);
      setPackerNotice(`Soltados ${incoming.length} archivos en ${baseDir === '/' ? '/' : `${baseDir}/`}.`);
    }
  };

  const handleLoadMinimalTemplate = () => {
    const tpl = buildMinimalPspPackerTemplate();
    setPackerEntries(tpl.entries);
    setPackerEmptyDirs(tpl.emptyDirs);
    setVolumeId('ULES99999');
    setOutputFileName('PSP_MINIMAL_PACK.ISO');
    setPackerNotice(
      'Cargada plantilla PSP mínima válida (UMD_DATA.BIN + PARAM.SFO + EBOOT.BIN + USRDIR).'
    );
  };

  const handleGenerateUmdDataNow = () => {
    const discId = validation?.detectedSfo?.discId || volumeId || 'ULES99999';
    const data = buildUmdDataBin(discId);
    mergePackerEntries([
      {
        path: '/UMD_DATA.BIN',
        size: data.length,
        source: data,
        origin: 'GENERATED',
      },
    ]);
    setPackerNotice(`Generado /UMD_DATA.BIN para ${discId} (${data.length} B).`);
  };

  const handleReplaceSinglePackerFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !replaceTargetPath) return;
    mergePackerEntries([
      {
        path: replaceTargetPath,
        size: file.size,
        source: file,
        origin: 'LOCAL_FILE',
      },
    ]);
    setPackerNotice(`Reemplazado ${replaceTargetPath} con ${file.name} (${formatBytes(file.size)}).`);
    setReplaceTargetPath(null);
    e.target.value = '';
  };

  const handleReplaceFromExtractor = (entry: IsoFileEntry) => {
    if (!isoFileBlob || !analysis?.isoInfo) return;
    if (packerEntries.length === 0) {
      const imported = importIsoToPackerEntries(isoFileBlob, analysis.isoInfo);
      setPackerEntries(imported.entries);
      setPackerEmptyDirs(imported.emptyDirs);
    }
    setMode('pack');
    setReplaceTargetPath(normalizeIsoPackerPath(entry.path));
    setTimeout(() => replaceInputRef.current?.click(), 50);
  };

  const handleAddEmptySubfolder = () => {
    const norm = normalizeIsoFolderPath(newSubfolderInput);
    setPackerEmptyDirs((prev) => (prev.includes(norm) ? prev : [...prev, norm].sort()));
    setPackerNotice(`Carpeta agregada al árbol ISO: ${norm}/`);
  };

  const handleAddEmptyRenamedDlcFiles = () => {
    const base = ensurePackerBaseline();
    const safePrefix =
      packerEmptyNamePrefix
        .trim()
        .replace(/[^A-Za-z0-9._-]+/g, '_')
        .replace(/^_+|_+$/g, '') || 'DLC_VACIO';

    const emptyDlcTargets = [
      `/PSP_GAME/DLC/PERSONAJES/${safePrefix}_PERSONAJES.bin`,
      `/PSP_GAME/DLC/MAPAS/${safePrefix}_MAPAS.bin`,
      `/PSP_GAME/DLC/MINIMAPAS/${safePrefix}_MINIMAPAS.tm2`,
      `/PSP_GAME/DLC/LOBBY/${safePrefix}_LOBBY.bin`,
      `/PSP_GAME/DLC/CHIBIS/${safePrefix}_CHIBIS.gim`,
      `/PSP_GAME/DLC/MUSICA/${safePrefix}_MUSICA.at3`,
      `/PSP_GAME/DLC/UI/${safePrefix}_UI.pck`,
      `/PSP_GAME/MOD/DLC/CASILLAS_ROSTER/${safePrefix}_ROSTER.gim`,
      `/PSP_GAME/MOD/DLC/BARRA_DE_VIDA/${safePrefix}_HUD.gim`,
      `/PSP_GAME/MOD/DLC/OBJ/${safePrefix}_OBJ.obj`,
    ];

    const map = new Map(base.entries.map((item) => [item.path.toUpperCase(), item]));
    for (const rawTarget of emptyDlcTargets) {
      const normPath = normalizeIsoPackerPath(rawTarget, preserveCase);
      map.set(normPath.toUpperCase(), {
        path: normPath,
        size: 0,
        source: new Uint8Array(0),
        origin: 'GENERATED',
      });
    }

    // Registrar todo el contenido DLC en un índice JSON legible para el juego
    const dlcPaths = Array.from(map.values())
      .filter((e) => /^\/PSP_GAME\/(MOD\/)?DLC\//i.test(e.path))
      .map((e) => ({ path: e.path, size: e.size }));
    const manifestJson = new TextEncoder().encode(
      JSON.stringify(
        {
          schema: 'DBZ_DLC_IN_GAME_INDEX_V1',
          totalDlcFiles: dlcPaths.length,
          syncMode: 'ALL_DLC_VISIBLE_IN_GAME',
          files: dlcPaths,
        },
        null,
        2
      )
    );
    const indexPath = normalizeIsoPackerPath('/PSP_GAME/DLC/DLC_IN_GAME_INDEX.json', preserveCase);
    map.set(indexPath.toUpperCase(), {
      path: indexPath,
      size: manifestJson.length,
      source: manifestJson,
      origin: 'GENERATED',
    });

    setPackerEntries(Array.from(map.values()).sort((a, b) => a.path.localeCompare(b.path)));
    if (base.entries !== packerEntries) {
      setPackerEmptyDirs(base.emptyDirs);
    }
    setPackerNotice(
      `Agregados ${emptyDlcTargets.length} archivos vacíos (0 B) renombrados con prefijo "${safePrefix}" en carpetas DLC + índice DLC_IN_GAME_INDEX.json.`
    );
  };

  const handleCommitPackerRename = (oldPath: string) => {
    const cleanNew = normalizeIsoPackerPath(renamePackerDraft.trim(), preserveCase);
    if (!cleanNew || cleanNew === '/') {
      setRenamingPackerPath(null);
      return;
    }
    setPackerEntries((prev) => {
      const existing = prev.find((e) => e.path === oldPath);
      if (!existing) return prev;
      const filtered = prev.filter(
        (e) => e.path !== oldPath && e.path.toUpperCase() !== cleanNew.toUpperCase()
      );
      return [...filtered, { ...existing, path: cleanNew }].sort((a, b) =>
        a.path.localeCompare(b.path)
      );
    });
    setPackerNotice(`Renombrado: ${oldPath} → ${cleanNew}`);
    setRenamingPackerPath(null);
  };

  const handlePackIso = async (useStreamingSave = false) => {
    if (packerEntries.length === 0 && packerEmptyDirs.length === 0) return;
    setPacking(true);
    setPackError(null);
    setPackProgress({ phase: 'Iniciando empaquetado ECMA-119...', percent: 5 });

    try {
      const cleanOutName = outputFileName.trim().toLowerCase().endsWith('.iso')
        ? outputFileName.trim()
        : `${outputFileName.trim() || 'PSP_EMPAQUETADA'}.ISO`;

      type SaveFilePickerFn = (opts: {
        suggestedName?: string;
        types?: Array<{ description: string; accept: Record<string, string[]> }>;
      }) => Promise<{
        createWritable: () => Promise<{
          write: (data: Uint8Array | Blob) => Promise<void>;
          close: () => Promise<void>;
        }>;
      }>;

      let writable: {
        write: (data: Uint8Array | Blob) => Promise<void>;
        close: () => Promise<void>;
      } | null = null;

      if (useStreamingSave && supportsStreamingSave) {
        const picker = (window as unknown as { showSaveFilePicker: SaveFilePickerFn })
          .showSaveFilePicker;
        const handle = await picker({
          suggestedName: cleanOutName,
          types: [{ description: 'Imagen ISO PSP', accept: { 'application/octet-stream': ['.iso'] } }],
        });
        writable = await handle.createWritable();
      }

      const result = await packPspIsoBlob(packerEntries, packerEmptyDirs, {
        volumeId,
        systemId,
        publisher,
        baseIsoBlob: isoFileBlob,
        autoGenerateUmdData,
        preserveCase,
        discIdHint: validation?.detectedSfo?.discId || volumeId,
        onProgress: (phase, percent) => setPackProgress({ phase, percent }),
      });

      const verified = await inspectPspIso(result.isoBlob);

      setLastPacked({
        result,
        fileName: cleanOutName,
        verifiedFiles: verified.totalFiles,
        verifiedDirs: verified.totalDirs,
        verifiedMod2048: result.isoBlob.size % 2048 === 0,
        verifiedSfoTitle: verified.sfo?.title ?? null,
        verifiedHasEboot: Boolean(verified.ebootEntry || verified.bootEntry),
      });

      if (writable) {
        setPackProgress({ phase: 'Escribiendo archivo .ISO por streaming en disco...', percent: 90 });
        await writeIsoPartsToWritableStream(
          result.parts,
          result.totalBytes,
          writable,
          (written, total) => {
            const pct = total > 0 ? Math.min(100, Math.round((written / total) * 100)) : 100;
            setPackProgress({
              phase: `Escribiendo en disco: ${formatBytes(written)} / ${formatBytes(total)}`,
              percent: pct,
            });
          }
        );
        setPackerNotice(`Imagen ${cleanOutName} guardada directamente en disco por streaming.`);
      } else {
        downloadBlob(result.isoBlob, cleanOutName);
      }
    } catch (err) {
      setPackError(
        err instanceof Error ? err.message : 'No se pudo empaquetar la imagen .ISO PSP.'
      );
    } finally {
      setPacking(false);
      setPackProgress(null);
    }
  };

  const handleCopyPython = async () => {
    try {
      await navigator.clipboard.writeText(pythonPackerScript);
      setCopiedPython(true);
      setTimeout(() => setCopiedPython(false), 1500);
    } catch {
      // ignore
    }
  };

  const packerFolders = useMemo(() => {
    const dirs = new Set<string>();
    for (const e of packerEntries) {
      const parts = e.path.split('/').filter(Boolean);
      for (let i = 1; i < parts.length; i++) {
        dirs.add('/' + parts.slice(0, i).join('/'));
      }
    }
    for (const d of packerEmptyDirs) {
      dirs.add(d);
    }
    return Array.from(dirs).sort();
  }, [packerEntries, packerEmptyDirs]);

  const filteredPackerEntries = useMemo(() => {
    const q = packerSearch.trim().toLowerCase();
    return packerEntries.filter((e) => {
      if (packerFolderFilter !== 'ALL') {
        const prefix = packerFolderFilter.endsWith('/')
          ? packerFolderFilter.toUpperCase()
          : `${packerFolderFilter.toUpperCase()}/`;
        if (!e.path.toUpperCase().startsWith(prefix)) return false;
      }
      if (!q) return true;
      return e.path.toLowerCase().includes(q);
    });
  }, [packerEntries, packerSearch, packerFolderFilter]);

  const totalPackerBytes = useMemo(
    () => packerEntries.reduce((acc, e) => acc + e.size, 0),
    [packerEntries]
  );

  return (
    <div className="space-y-6">
      {/* Hidden inputs */}
      <input
        ref={folderInputRef}
        type="file"
        multiple
        onChange={handleFolderSelected}
        className="hidden"
        {...({ webkitdirectory: '', directory: '' } as Record<string, string>)}
      />
      <input
        ref={addFolderToTargetRef}
        type="file"
        multiple
        onChange={handleAddFolderToTargetSelected}
        className="hidden"
        {...({ webkitdirectory: '', directory: '' } as Record<string, string>)}
      />
      <input
        ref={filesInputRef}
        type="file"
        multiple
        onChange={handleLooseFilesSelected}
        className="hidden"
      />
      <input
        ref={replaceInputRef}
        type="file"
        onChange={handleReplaceSinglePackerFile}
        className="hidden"
      />

      {/* Workspace Header & Segmented Switcher */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="max-w-2xl">
            <h1 className="text-lg font-semibold text-slate-900 dark:text-white">
              Cargar, Extraer y Empaquetar ISO PSP (ISO 9660 / ECMA-119)
            </h1>
            <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
              Explora y extrae archivos o carpetas completas de cualquier <span className="font-mono">.ISO</span> de PSP, o carga una carpeta <span className="font-mono">PSP_GAME/</span> extraída para reempaquetarla en una imagen <span className="font-mono">.ISO</span> compatible con PSP y PPSSPP.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex items-center rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
              <button
                type="button"
                onClick={() => setMode('extract')}
                className={`min-h-[38px] rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  mode === 'extract'
                    ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
                }`}
              >
                Extraer ISO PSP {hasIso ? `(${analysis!.isoInfo!.totalFiles})` : ''}
              </button>
              <button
                type="button"
                onClick={() => setMode('pack')}
                className={`min-h-[38px] rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  mode === 'pack'
                    ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
                }`}
              >
                Empaquetar ISO PSP ({packerEntries.length})
              </button>
              <button
                type="button"
                onClick={() => setMode('videos_pmf')}
                className={`inline-flex items-center gap-1.5 min-h-[38px] rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  mode === 'videos_pmf'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
                }`}
              >
                <Film className="h-3.5 w-3.5" />
                Editor Videos .PMF ISO
              </button>
            </div>
          </div>
        </div>
      </section>

      {mode === 'videos_pmf' ? (
        <IsoPmfVideoEditor
          analysis={analysis}
          isoFileBlob={isoFileBlob}
          packerEntries={packerEntries}
          packerEmptyDirs={packerEmptyDirs}
          onUpsertPackerFiles={handleUpsertVideoPackerFiles}
          onDeleteVideoTargets={handleDeleteVideoTargets}
          onInspectAssetBytes={onInspectIsoAssetBytes}
        />
      ) : mode === 'extract' ? (
        !hasIso ? (
          <section className="rounded-xl border border-slate-200 bg-white p-8 dark:border-slate-800 dark:bg-slate-900">
            <div className="max-w-xl space-y-4">
              <h2 className="text-base font-semibold text-slate-900 dark:text-white">
                Carga una imagen .ISO de PSP para explorar y extraer su contenido
              </h2>
              <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                La lectura se realiza por sectores de <span className="font-mono">2048 B</span> directamente en tu navegador sin subir archivos a ningún servidor. Podrás descargar archivos individuales (<span className="font-mono">PARAM.SFO</span>, <span className="font-mono">EBOOT.BIN</span>, <span className="font-mono">USRDIR/*</span>), carpetas o toda la ISO en <span className="font-mono">.ZIP</span>.
              </p>
              <div className="flex flex-wrap items-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={onRequestLoadFile}
                  className="inline-flex min-h-[42px] items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Upload className="h-4 w-4" />
                  Cargar archivo .ISO PSP
                </button>
                <button
                  type="button"
                  onClick={onLoadSampleIso}
                  className="inline-flex min-h-[42px] items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <FileCode2 className="h-4 w-4" />
                  Probar ISO de Muestra
                </button>
                <button
                  type="button"
                  onClick={() => setMode('pack')}
                  className="inline-flex min-h-[42px] items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Package className="h-4 w-4" />
                  Empaquetar carpeta en .ISO
                </button>
              </div>
            </div>
          </section>
        ) : (
          <div className="space-y-6">
            {/* KPI Strip */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                <div className="text-xs text-slate-500 dark:text-slate-400">Volumen / DISC_ID</div>
                <div className="mt-1 truncate font-mono text-sm font-semibold text-slate-900 dark:text-white">
                  {analysis!.sfoInfo?.discId || analysis!.isoInfo!.volume.volumeId}
                </div>
                <div className="mt-0.5 truncate text-[11px] text-slate-500 dark:text-slate-400">
                  {analysis!.sfoInfo?.title || analysis!.sourceName}
                </div>
              </div>
              <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                <div className="text-xs text-slate-500 dark:text-slate-400">Archivos en ISO</div>
                <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums dark:text-white">
                  {analysis!.isoInfo!.totalFiles.toLocaleString('es-ES')}
                </div>
              </div>
              <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                <div className="text-xs text-slate-500 dark:text-slate-400">Carpetas ISO 9660</div>
                <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums dark:text-white">
                  {analysis!.isoInfo!.totalDirs.toLocaleString('es-ES')}
                </div>
              </div>
              <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                <div className="text-xs text-slate-500 dark:text-slate-400">Tamaño de imagen</div>
                <div className="mt-1 font-mono text-xl font-bold text-slate-900 tabular-nums dark:text-white">
                  {formatBytes(analysis!.isoInfo!.volume.totalSizeBytes)}
                </div>
              </div>
            </div>

            {/* Quick Extract & Send to Packer Bar */}
            <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
                    Extracción Rápida y Transferencia al Empaquetador
                  </h2>
                  <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                    Descarga los archivos principales del sistema PSP, extrae toda la estructura a <span className="font-mono">.ZIP</span> o envía el contenido al empaquetador para editarlo y generar una nueva <span className="font-mono">.ISO</span>.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    disabled={extractingZip}
                    onClick={() => void handleExtractZip(null)}
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-blue-600 dark:hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Archive className="h-4 w-4" />
                    {extractingZip ? 'Extrayendo .ZIP…' : 'Extraer ISO Completa (.ZIP)'}
                  </button>
                  <button
                    type="button"
                    onClick={handleImportLoadedIsoToPacker}
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-blue-600 bg-white px-3.5 py-2 text-xs font-semibold text-blue-600 hover:bg-blue-50 dark:border-blue-400 dark:bg-slate-900 dark:text-blue-400 dark:hover:bg-blue-950/30 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Package className="h-4 w-4" />
                    Editar y Reempaquetar esta ISO
                  </button>
                </div>
              </div>

              {quickEntries.length > 0 && (
                <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
                  <span className="text-xs text-slate-500 dark:text-slate-400">Extraer directo:</span>
                  {quickEntries.map((entry) => (
                    <button
                      key={entry.path}
                      type="button"
                      onClick={() => void handleExtractSingleFile(entry)}
                      className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1 font-mono text-xs text-slate-800 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Download className="h-3 w-3" />
                      {entry.name} ({formatBytes(entry.size)})
                    </button>
                  ))}
                </div>
              )}

              {extractProgress && (
                <div className="mt-3 space-y-1 text-xs text-blue-700 dark:text-blue-300">
                  <div className="flex justify-between font-mono tabular-nums">
                    <span className="truncate">{extractProgress.currentPath}</span>
                    <span>
                      {extractProgress.done} / {extractProgress.total}
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
                    <div
                      className="h-full bg-blue-600 transition-all"
                      style={{
                        width: `${Math.round(
                          (extractProgress.done / Math.max(1, extractProgress.total)) * 100
                        )}%`,
                      }}
                    />
                  </div>
                </div>
              )}

              {extractNotice && (
                <div className="mt-3 rounded-lg border border-emerald-300 bg-emerald-50/70 px-3 py-2 text-xs text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200">
                  {extractNotice}
                </div>
              )}

              {extractError && (
                <div className="mt-3 rounded-lg border border-red-300 bg-red-50 px-3 py-2 text-xs text-red-800 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-300">
                  {extractError}
                </div>
              )}
            </section>

            {/* Full ISO 9660 Directory Browser */}
            <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
              <div className="flex flex-col gap-3 border-b border-slate-200 p-4 dark:border-slate-800 lg:flex-row lg:items-center lg:justify-between">
                <div className="flex flex-1 flex-wrap items-center gap-2">
                  <div className="relative flex-1 min-w-[220px] max-w-md">
                    <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={extractQuery}
                      onChange={(e) => setExtractQuery(e.target.value)}
                      placeholder="Buscar archivo dentro de la ISO (EBOOT, PARAM, GMO, AT3, BIN)..."
                      className="min-h-[40px] w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                    />
                  </div>

                  <select
                    value={selectedFolder}
                    onChange={(e) => setSelectedFolder(e.target.value)}
                    aria-label="Filtrar por carpeta ISO"
                    className="min-h-[40px] max-w-xs rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-800 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
                  >
                    <option value="ALL">Todas las carpetas ({analysis!.isoInfo!.totalFiles})</option>
                    {isoFolders.map((dir) => (
                      <option key={dir} value={dir}>
                        {dir}/
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  {selectedFolder !== 'ALL' && (
                    <button
                      type="button"
                      disabled={extractingZip}
                      onClick={() => void handleExtractZip(selectedFolder)}
                      className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Archive className="h-3.5 w-3.5" />
                      Extraer carpeta (.ZIP)
                    </button>
                  )}
                  <span className="font-mono text-xs text-slate-500 tabular-nums dark:text-slate-400">
                    {isoFileRows.length} archivos
                  </span>
                </div>
              </div>

              {isoFileRows.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500 dark:text-slate-400">
                  No hay archivos que coincidan con el filtro seleccionado.
                </div>
              ) : (
                <div className="max-h-[460px] overflow-auto">
                  <table className="w-full border-collapse text-left text-xs">
                    <thead className="sticky top-0 z-10 border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                      <tr>
                        <th className="px-4 py-2.5 font-semibold">#</th>
                        <th className="px-4 py-2.5 font-semibold">Ruta ISO 9660</th>
                        <th className="px-4 py-2.5 font-semibold">LBA</th>
                        <th className="px-4 py-2.5 font-semibold">Offset</th>
                        <th className="px-4 py-2.5 text-right font-semibold">Tamaño</th>
                        <th className="px-4 py-2.5 text-right font-semibold">Acciones</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {isoFileRows.slice(0, 400).map((entry, idx) => (
                        <tr
                          key={entry.path}
                          className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40"
                        >
                          <td className="px-4 py-2 font-mono text-slate-400 tabular-nums">
                            {String(idx + 1).padStart(3, '0')}
                          </td>
                          <td className="max-w-md truncate px-4 py-2 font-mono text-slate-900 dark:text-slate-100" title={entry.path}>
                            {entry.path}
                          </td>
                          <td className="px-4 py-2 font-mono tabular-nums text-slate-600 dark:text-slate-400">
                            {entry.lba}
                          </td>
                          <td className="px-4 py-2 font-mono tabular-nums text-slate-600 dark:text-slate-400">
                            {hex(entry.byteOffset, 8)}
                          </td>
                          <td className="px-4 py-2 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                            {formatBytes(entry.size)}
                          </td>
                          <td className="px-4 py-2 text-right whitespace-nowrap">
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => void handleExtractSingleFile(entry)}
                                className="inline-flex min-h-[30px] items-center gap-1 rounded bg-slate-900 px-2.5 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
                              >
                                <Download className="h-3 w-3" />
                                Extraer
                              </button>
                              {onInspectIsoAssetBytes && entry.size <= 16 * 1024 * 1024 && (
                                <button
                                  type="button"
                                  onClick={() => void handleOpenInHxd(entry)}
                                  className="inline-flex min-h-[30px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                                >
                                  <Binary className="h-3 w-3" />
                                  HxD
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => handleReplaceFromExtractor(entry)}
                                title="Reemplazar este archivo en el Empaquetador ISO"
                                className="inline-flex min-h-[30px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                              >
                                <Replace className="h-3 w-3" />
                                Reemplazar
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {isoFileRows.length > 400 && (
                    <div className="border-t border-slate-200 bg-slate-50 px-4 py-2 text-[11px] text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                      Mostrando los primeros 400 de {isoFileRows.length} archivos. Usa el buscador o el selector de carpeta para filtrar.
                    </div>
                  )}
                </div>
              )}
            </section>
          </div>
        )
      ) : (
        /* ================= PACKER MODE ================= */
        <div className="space-y-6">
          {/* Source Loaders & Dropzone */}
          <section
            onDragOver={(e) => {
              e.preventDefault();
              setPackerDragActive(true);
            }}
            onDragLeave={() => setPackerDragActive(false)}
            onDrop={(e) => void handlePackerDrop(e)}
            className={`rounded-xl border-2 border-dashed p-5 transition-colors ${
              packerDragActive
                ? 'border-blue-600 bg-blue-50/60 dark:border-blue-500 dark:bg-blue-950/20'
                : 'border-slate-300 bg-white dark:border-slate-800 dark:bg-slate-900'
            }`}
          >
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="max-w-2xl">
                <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
                  1. Cargar Carpeta o Archivos para Empaquetar en .ISO PSP
                </h2>
                <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
                  Arrastra y suelta aquí una carpeta extraída de juego PSP (con <span className="font-mono">PSP_GAME/</span> y <span className="font-mono">UMD_DATA.BIN</span>) o usa los botones para cargar una carpeta completa, importar la ISO abierta o inyectar tu <span className="font-mono">EBOOT.BIN</span> modificado.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => folderInputRef.current?.click()}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <FolderInput className="h-4 w-4" />
                  Cargar Carpeta PSP
                </button>
                <button
                  type="button"
                  onClick={() => addFolderToTargetRef.current?.click()}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-blue-600 bg-white px-3.5 py-2 text-xs font-semibold text-blue-600 hover:bg-blue-50 dark:border-blue-500 dark:bg-slate-900 dark:text-blue-400 dark:hover:bg-blue-950/30 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <FolderPlus className="h-4 w-4" />
                  Agregar Carpeta a Ruta
                </button>
                <button
                  type="button"
                  onClick={() => filesInputRef.current?.click()}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Upload className="h-3.5 w-3.5" />
                  Agregar Archivos a Ruta
                </button>
                {hasIso && (
                  <button
                    type="button"
                    onClick={handleImportLoadedIsoToPacker}
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <HardDrive className="h-3.5 w-3.5" />
                    Importar ISO Cargada
                  </button>
                )}
                {analysis && analysis.rawBytes.length > 0 && (
                  <button
                    type="button"
                    onClick={handleInjectCurrentEboot}
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Binary className="h-3.5 w-3.5" />
                    Inyectar EBOOT Actual
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleLoadMinimalTemplate}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <FileCode2 className="h-3.5 w-3.5" />
                  Plantilla PSP Mínima
                </button>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-1 gap-3 border-t border-slate-100 pt-4 sm:grid-cols-2 dark:border-slate-800">
              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                  Carpeta destino al usar "Agregar Carpeta a Ruta" / "Agregar Archivos a Ruta"
                </label>
                <input
                  type="text"
                  value={targetAddFolder}
                  onChange={(e) => setTargetAddFolder(e.target.value)}
                  placeholder="/PSP_GAME/USRDIR"
                  className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  {TARGET_FOLDER_PRESETS.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setTargetAddFolder(preset)}
                      className={`rounded border px-2 py-1 font-mono text-[11px] transition-colors cursor-pointer ${
                        targetAddFolder === preset
                          ? 'border-blue-600 bg-blue-50 font-semibold text-blue-700 dark:border-blue-500 dark:bg-blue-950/40 dark:text-blue-300'
                          : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300'
                      }`}
                    >
                      {preset === '/' ? '/ (Raíz)' : preset}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-col justify-between gap-2">
                <div className="flex items-end gap-2">
                  <div className="flex-1">
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                      Crear subcarpeta vacía en la ISO
                    </label>
                    <input
                      type="text"
                      value={newSubfolderInput}
                      onChange={(e) => setNewSubfolderInput(e.target.value)}
                      placeholder="/PSP_GAME/USRDIR/CUSTOM"
                      className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleAddEmptySubfolder}
                    className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <FolderPlus className="h-3.5 w-3.5" />
                    Añadir Carpeta
                  </button>
                </div>
                <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={preserveCase}
                    onChange={(e) => setPreserveCase(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  Conservar minúsculas/mayúsculas originales (ej. <span className="font-mono">font.pgf</span>, <span className="font-mono">bgm.awb</span>)
                </label>

                <div className="flex flex-wrap items-end gap-2 pt-1">
                  <div className="min-w-[150px] flex-1">
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                      Prefijo para archivos vacíos DLC (0 B)
                    </label>
                    <input
                      type="text"
                      value={packerEmptyNamePrefix}
                      onChange={(e) => setPackerEmptyNamePrefix(e.target.value)}
                      placeholder="DLC_VACIO"
                      className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleAddEmptyRenamedDlcFiles}
                    className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-emerald-600 bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-800 hover:bg-emerald-100 dark:border-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-200 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <FilePlus2 className="h-3.5 w-3.5" />
                    + Archivos Vacíos DLC Renombrados (0 B)
                  </button>
                </div>
              </div>
            </div>

            {packerNotice && (
              <div className="mt-3 rounded-lg border border-blue-200 bg-blue-50/70 px-3 py-2 text-xs text-blue-900 dark:border-blue-900/50 dark:bg-blue-950/30 dark:text-blue-200">
                {packerNotice}
              </div>
            )}
          </section>

          {/* 2-Column Split: Validation Checklist + PVD Options */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
            {/* Validation Checklist */}
            <section className="lg:col-span-7 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                  2. Validación de Estructura PSP y ECMA-119
                </h3>
                {validation && !validation.hasUmdData && (
                  <button
                    type="button"
                    onClick={handleGenerateUmdDataNow}
                    className="text-xs font-semibold text-blue-600 hover:underline dark:text-blue-400 cursor-pointer"
                  >
                    + Generar /UMD_DATA.BIN
                  </button>
                )}
              </div>

              {validation ? (
                <div className="mt-3 divide-y divide-slate-100 rounded-lg border border-slate-200 dark:divide-slate-800 dark:border-slate-800">
                  {validation.items.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-start justify-between gap-4 p-3 text-xs"
                    >
                      <div>
                        <div className="font-semibold text-slate-900 dark:text-white">
                          {item.title}
                        </div>
                        <div className="mt-0.5 text-slate-600 dark:text-slate-300">
                          {item.detail}
                        </div>
                      </div>
                      <span
                        className={`inline-flex items-center gap-1 font-mono text-[11px] font-bold shrink-0 ${
                          item.status === 'OK'
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : item.status === 'WARN'
                            ? 'text-amber-600 dark:text-amber-400'
                            : 'text-red-600 dark:text-red-400'
                        }`}
                      >
                        {item.status === 'OK' ? (
                          <CheckCircle2 className="h-3.5 w-3.5" />
                        ) : (
                          <AlertTriangle className="h-3.5 w-3.5" />
                        )}
                        {item.status}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="mt-3 text-xs text-slate-500">Validando estructura...</div>
              )}
            </section>

            {/* Volume Descriptor & Pack Trigger */}
            <section className="lg:col-span-5 flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                  3. Cabecera PVD y Empaquetado .ISO
                </h3>

                <div>
                  <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                    Volume ID (máx. 32 caracteres ASCII)
                  </label>
                  <input
                    type="text"
                    value={volumeId}
                    maxLength={32}
                    onChange={(e) => setVolumeId(e.target.value)}
                    className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                  />
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                      System ID
                    </label>
                    <input
                      type="text"
                      value={systemId}
                      maxLength={32}
                      onChange={(e) => setSystemId(e.target.value)}
                      className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                      Nombre de salida (.ISO)
                    </label>
                    <input
                      type="text"
                      value={outputFileName}
                      onChange={(e) => setOutputFileName(e.target.value)}
                      className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400">
                    Publisher (PVD)
                  </label>
                  <input
                    type="text"
                    value={publisher}
                    maxLength={64}
                    onChange={(e) => setPublisher(e.target.value)}
                    className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                  />
                </div>

                <label className="flex items-center gap-2 pt-1 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoGenerateUmdData}
                    onChange={(e) => setAutoGenerateUmdData(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                  />
                  Auto-generar <span className="font-mono">/UMD_DATA.BIN</span> si falta en el árbol
                </label>
              </div>

              <div className="mt-5 space-y-3 border-t border-slate-100 pt-4 dark:border-slate-800">
                <div className="flex items-center justify-between font-mono text-xs text-slate-500 tabular-nums dark:text-slate-400">
                  <span>{packerEntries.length} archivos · {packerEmptyDirs.length} dir. vacíos</span>
                  <span>{formatBytes(totalPackerBytes)}</span>
                </div>

                <div className="flex flex-col gap-2 sm:flex-row">
                  <button
                    type="button"
                    disabled={packing || !validation?.canPack}
                    onClick={() => void handlePackIso(false)}
                    className="inline-flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-blue-600 dark:hover:bg-blue-700 whitespace-nowrap cursor-pointer"
                  >
                    <HardDrive className="h-4 w-4" />
                    {packing ? 'Empaquetando .ISO PSP…' : 'Empaquetar y Descargar .ISO PSP'}
                  </button>
                  {supportsStreamingSave && (
                    <button
                      type="button"
                      disabled={packing || !validation?.canPack}
                      onClick={() => void handlePackIso(true)}
                      title="Escribe directamente en tu disco por bloques de 4 MB (ideal para juegos de 1 GB - 4 GB)"
                      className="inline-flex min-h-[44px] items-center justify-center gap-1.5 rounded-lg border border-blue-600 bg-white px-3.5 py-2.5 text-xs font-semibold text-blue-600 hover:bg-blue-50 disabled:opacity-50 dark:border-blue-500 dark:bg-slate-900 dark:text-blue-400 dark:hover:bg-blue-950/30 whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <Save className="h-4 w-4" />
                      Guardar Streaming (&gt;1 GB)
                    </button>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => setShowPythonPacker((s) => !s)}
                  className="inline-flex items-center gap-1.5 text-[11px] font-medium text-slate-600 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 cursor-pointer"
                >
                  <Terminal className="h-3.5 w-3.5" />
                  {showPythonPacker
                    ? 'Ocultar script Python offline (1 GB - 4 GB)'
                    : '¿Carpeta >1.5 GB? Ver script Python empaquetador offline'}
                </button>

                {packProgress && (
                  <div className="space-y-1 text-xs text-blue-700 dark:text-blue-300">
                    <div className="flex justify-between font-mono tabular-nums">
                      <span className="truncate">{packProgress.phase}</span>
                      <span>{packProgress.percent}%</span>
                    </div>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
                      <div
                        className="h-full bg-blue-600 transition-all"
                        style={{ width: `${packProgress.percent}%` }}
                      />
                    </div>
                  </div>
                )}

                {packError && (
                  <div className="rounded-lg border border-red-300 bg-red-50 p-3 text-xs text-red-800 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-300">
                    {packError}
                  </div>
                )}
              </div>
            </section>
          </div>

          {showPythonPacker && (
            <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h4 className="font-mono text-xs font-semibold text-slate-900 dark:text-white">
                    empaquetar_carpeta_iso.py (Empaquetador streaming Python para carpetas de 1 GB - 4 GB)
                  </h4>
                  <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                    Uso: <span className="font-mono">python3 empaquetar_carpeta_iso.py ./CarpetaJuegoPSP --out Juego.iso</span>
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => void handleCopyPython()}
                    className="inline-flex min-h-[34px] items-center gap-1 rounded border border-slate-300 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                  >
                    {copiedPython ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                    {copiedPython ? 'Copiado' : 'Copiar'}
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      downloadBlob(
                        new Blob([pythonPackerScript], { type: 'text/plain;charset=utf-8' }),
                        'empaquetar_carpeta_iso.py'
                      )
                    }
                    className="inline-flex min-h-[34px] items-center gap-1 rounded bg-slate-900 px-3 py-1 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Descargar .PY
                  </button>
                </div>
              </div>
              <pre className="mt-3 max-h-72 overflow-auto rounded-lg border border-slate-200 bg-slate-950 p-3 font-mono text-[11px] leading-relaxed text-slate-100 dark:border-slate-800">
                {pythonPackerScript}
              </pre>
            </section>
          )}

          {lastPacked && (
            <section className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-emerald-300 bg-emerald-50/70 p-4 text-xs text-emerald-950 dark:border-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200">
              <div>
                <div className="font-semibold">
                  ISO PSP empaquetada y verificada: <span className="font-mono">{lastPacked.fileName}</span>
                </div>
                <div className="mt-1 font-mono tabular-nums">
                  {lastPacked.verifiedDirs} directorios · {lastPacked.verifiedFiles} archivos ·{' '}
                  {lastPacked.result.totalSectors.toLocaleString('es-ES')} sectores ({formatBytes(lastPacked.result.totalBytes)}) ·{' '}
                  {lastPacked.verifiedMod2048 ? 'mod 2048 = 0 OK' : 'Revisar alineación'}
                  {lastPacked.verifiedSfoTitle ? ` · "${lastPacked.verifiedSfoTitle}"` : ''}
                  {lastPacked.verifiedHasEboot ? ' · Boot OK' : ''}
                </div>
              </div>

              {onLoadGeneratedIso && (
                <button
                  type="button"
                  onClick={() => onLoadGeneratedIso(lastPacked.result.isoBlob, lastPacked.fileName)}
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  Abrir .ISO empaquetada en Analizador
                </button>
              )}
            </section>
          )}

          {/* Packer Tree Table */}
          <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-4 dark:border-slate-800">
              <div className="flex flex-1 flex-wrap items-center gap-2">
                <div className="relative flex-1 min-w-[200px] max-w-md">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={packerSearch}
                    onChange={(e) => setPackerSearch(e.target.value)}
                    placeholder="Filtrar archivos en cola de empaquetado..."
                    className="min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                  />
                </div>

                <select
                  value={packerFolderFilter}
                  onChange={(e) => setPackerFolderFilter(e.target.value)}
                  aria-label="Filtrar por carpeta en empaquetador"
                  className="min-h-[38px] max-w-xs rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-800 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
                >
                  <option value="ALL">Todas las carpetas ({packerEntries.length})</option>
                  {packerFolders.map((dir) => (
                    <option key={dir} value={dir}>
                      {dir}/
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <span className="font-mono text-xs text-slate-500 tabular-nums dark:text-slate-400">
                  {filteredPackerEntries.length} de {packerEntries.length} archivos
                </span>
                {packerFolderFilter !== 'ALL' && (
                  <button
                    type="button"
                    onClick={() => {
                      const prefix = `${packerFolderFilter.toUpperCase()}/`;
                      setPackerEntries((prev) =>
                        prev.filter((e) => !e.path.toUpperCase().startsWith(prefix))
                      );
                      setPackerEmptyDirs((prev) =>
                        prev.filter(
                          (d) =>
                            d.toUpperCase() !== packerFolderFilter.toUpperCase() &&
                            !d.toUpperCase().startsWith(prefix)
                        )
                      );
                      setPackerNotice(`Carpeta ${packerFolderFilter}/ eliminada de la cola.`);
                      setPackerFolderFilter('ALL');
                    }}
                    className="text-xs font-medium text-red-600 hover:underline dark:text-red-400 cursor-pointer"
                  >
                    Eliminar carpeta
                  </button>
                )}
                {(packerEntries.length > 0 || packerEmptyDirs.length > 0) && (
                  <button
                    type="button"
                    onClick={() => {
                      setPackerEntries([]);
                      setPackerEmptyDirs([]);
                      setPackerFolderFilter('ALL');
                      setLastPacked(null);
                      setPackerNotice('Lista del empaquetador vaciada.');
                    }}
                    className="text-xs font-medium text-red-600 hover:underline dark:text-red-400 cursor-pointer"
                  >
                    Limpiar todo
                  </button>
                )}
              </div>
            </div>

            {packerEmptyDirs.length > 0 && (
              <div className="flex flex-wrap items-center gap-2 border-b border-slate-100 bg-slate-50/70 px-4 py-2.5 dark:border-slate-800 dark:bg-slate-950/40">
                <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                  Carpetas vacías:
                </span>
                {packerEmptyDirs.map((dir) => (
                  <span
                    key={dir}
                    className="inline-flex items-center gap-1.5 rounded border border-slate-200 bg-white px-2 py-0.5 font-mono text-[11px] text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
                  >
                    {dir}/
                    <button
                      type="button"
                      onClick={() =>
                        setPackerEmptyDirs((prev) => prev.filter((d) => d !== dir))
                      }
                      aria-label={`Quitar carpeta ${dir}`}
                      className="text-slate-400 hover:text-red-600 cursor-pointer"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}

            {filteredPackerEntries.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500 dark:text-slate-400">
                No hay archivos en cola todavía. Carga una carpeta <span className="font-mono">PSP_GAME</span>, importa la ISO actual o prueba la <span className="font-semibold">Plantilla PSP Mínima</span>.
              </div>
            ) : (
              <div className="max-h-[420px] overflow-auto">
                <table className="w-full border-collapse text-left text-xs">
                  <thead className="sticky top-0 z-10 border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    <tr>
                      <th className="px-4 py-2.5 font-semibold">#</th>
                      <th className="px-4 py-2.5 font-semibold">Ruta destino ISO 9660</th>
                      <th className="px-4 py-2.5 font-semibold">Origen</th>
                      <th className="px-4 py-2.5 text-right font-semibold">Tamaño</th>
                      <th className="px-4 py-2.5 text-right font-semibold">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredPackerEntries.slice(0, 400).map((entry, idx) => (
                      <tr
                        key={entry.path}
                        className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40"
                      >
                        <td className="px-4 py-2 font-mono text-slate-400 tabular-nums">
                          {String(idx + 1).padStart(3, '0')}
                        </td>
                        <td className="max-w-md px-4 py-2 font-mono text-slate-900 dark:text-slate-100" title={entry.path}>
                          {renamingPackerPath === entry.path ? (
                            <div className="flex items-center gap-1">
                              <input
                                type="text"
                                value={renamePackerDraft}
                                onChange={(e) => setRenamePackerDraft(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') handleCommitPackerRename(entry.path);
                                  if (e.key === 'Escape') setRenamingPackerPath(null);
                                }}
                                autoFocus
                                className="min-h-[28px] w-full rounded border border-blue-500 bg-white px-2 font-mono text-[11px] text-slate-900 focus:outline-none dark:bg-slate-950 dark:text-white"
                              />
                              <button
                                type="button"
                                onClick={() => handleCommitPackerRename(entry.path)}
                                className="rounded bg-blue-600 px-2 py-1 text-[10px] font-semibold text-white hover:bg-blue-700 cursor-pointer"
                              >
                                OK
                              </button>
                            </div>
                          ) : (
                            <span className="block truncate">{entry.path}</span>
                          )}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-slate-600 dark:text-slate-400">
                          {ORIGIN_LABEL[entry.origin]}
                        </td>
                        <td className="px-4 py-2 text-right font-mono tabular-nums text-slate-800 dark:text-slate-200">
                          {formatBytes(entry.size)}
                        </td>
                        <td className="px-4 py-2 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => {
                                setRenamingPackerPath(entry.path);
                                setRenamePackerDraft(entry.path);
                              }}
                              className="inline-flex min-h-[30px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                            >
                              <Edit3 className="h-3 w-3" />
                              Renombrar
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setReplaceTargetPath(entry.path);
                                replaceInputRef.current?.click();
                              }}
                              className="inline-flex min-h-[30px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                            >
                              <Replace className="h-3 w-3" />
                              Reemplazar
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setPackerEntries((prev) =>
                                  prev.filter((x) => x.path !== entry.path)
                                )
                              }
                              aria-label={`Eliminar ${entry.path}`}
                              className="inline-flex min-h-[30px] items-center rounded border border-slate-200 px-2 py-1 text-slate-500 hover:text-red-600 dark:border-slate-700 dark:hover:text-red-400 cursor-pointer"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {filteredPackerEntries.length > 400 && (
                  <div className="border-t border-slate-200 bg-slate-50 px-4 py-2 text-[11px] text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    Mostrando los primeros 400 de {filteredPackerEntries.length} archivos (todos se incluirán al empaquetar la .ISO).
                  </div>
                )}
              </div>
            )}
          </section>
        </div>
      )}
    </div>
  );
};
