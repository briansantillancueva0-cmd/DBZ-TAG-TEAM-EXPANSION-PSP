import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Archive,
  Binary,
  Box,
  Check,
  Copy,
  Download,
  FolderOutput,
  FolderPlus,
  Image as ImageIcon,
  Layers,
  Map as MapIcon,
  Music,
  Navigation,
  Play,
  Search,
  Upload,
  User,
} from 'lucide-react';
import {
  buildPck1PythonUnpackerScript,
  exportPck1SubfoldersZip,
  extractPck1EntryData,
  parseAndScanPck1Blob,
  renderPspImageBytesToDataUrl,
  type Pck1AnalysisResult,
  type Pck1AssetCategory,
  type Pck1ExtractedEntry,
} from '../lib/pck1Parser';
import type { EbootAnalysis, IsoFileEntry } from '../lib/types';

export interface InjectedSubfolderBatchItem {
  path: string;
  data: Uint8Array;
}

interface Pck1UnpackerPanelProps {
  analysis: EbootAnalysis;
  isoFileBlob: Blob | null;
  standalonePackBlob?: Blob | null;
  onInspectOffsetBytes: (bytes: Uint8Array, label: string) => void;
  onSendToIsoExpander?: (items: InjectedSubfolderBatchItem[]) => void;
}

function hex(val: number, width = 6): string {
  return `0x${(val >>> 0).toString(16).toUpperCase().padStart(width, '0')}`;
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

const CAT_ICON: Record<Pck1AssetCategory, React.ReactNode> = {
  PERSONAJES: <User className="h-4 w-4" />,
  MAPAS: <MapIcon className="h-4 w-4" />,
  MINIMAPAS: <Navigation className="h-4 w-4" />,
  OBJ_3D: <Box className="h-4 w-4" />,
  MUSICA_AT3: <Music className="h-4 w-4" />,
  IMAGENES: <ImageIcon className="h-4 w-4" />,
  OTROS: <Layers className="h-4 w-4" />,
};

export const Pck1UnpackerPanel: React.FC<Pck1UnpackerPanelProps> = ({
  analysis,
  isoFileBlob,
  standalonePackBlob = null,
  onInspectOffsetBytes,
  onSendToIsoExpander,
}) => {
  const [pck1Result, setPck1Result] = useState<Pck1AnalysisResult | null>(null);
  const [activeBlob, setActiveBlob] = useState<Blob | null>(null);
  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [exporting, setExporting] = useState<string | null>(null);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [selectedCat, setSelectedCat] = useState<'ALL' | Pck1AssetCategory>('ALL');
  const [query, setQuery] = useState('');
  const [showPython, setShowPython] = useState(false);
  const [copiedPy, setCopiedPy] = useState(false);
  const [audioPreviewUrl, setAudioPreviewUrl] = useState<{ label: string; url: string } | null>(null);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<{ label: string; url: string } | null>(null);

  const fileRef = useRef<HTMLInputElement | null>(null);
  const pythonScript = useMemo(() => buildPck1PythonUnpackerScript(), []);

  const isoContainerCandidates = useMemo(() => {
    if (!analysis.isoInfo) return [];
    return analysis.isoInfo.files.filter(
      (f) =>
        !f.isDirectory &&
        (/\.(pck|pac|bin|cpk|afs|arc|pak|dat)$/i.test(f.name) &&
          /(pck|packfile|pack|dlc|data|archive|resource)/i.test(f.name))
    );
  }, [analysis.isoInfo]);

  const runUnpackAnalysis = async (blob: Blob, name: string) => {
    setScanning(true);
    setProgress(0);
    setStatusMsg(null);
    setActiveBlob(blob);
    try {
      const res = await parseAndScanPck1Blob(blob, name, (pct) => setProgress(pct));
      setPck1Result(res);
      setSelectedCat('ALL');
    } finally {
      setScanning(false);
    }
  };

  useEffect(() => {
    if (standalonePackBlob) {
      void runUnpackAnalysis(standalonePackBlob, analysis.sourceName);
    }
  }, [standalonePackBlob, analysis.sourceName]);

  useEffect(() => {
    return () => {
      if (audioPreviewUrl) URL.revokeObjectURL(audioPreviewUrl.url);
      if (imagePreviewUrl && imagePreviewUrl.url.startsWith('blob:')) {
        URL.revokeObjectURL(imagePreviewUrl.url);
      }
    };
  }, [audioPreviewUrl, imagePreviewUrl]);

  const handleAnalyzeIsoEntry = (entry: IsoFileEntry) => {
    if (!isoFileBlob) return;
    const slice = isoFileBlob.slice(entry.byteOffset, entry.byteOffset + entry.size);
    void runUnpackAnalysis(slice, entry.path);
  };

  const handleUploadExternal = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      void runUnpackAnalysis(file, file.name);
    }
    e.target.value = '';
  };

  const filteredEntries = useMemo(() => {
    if (!pck1Result) return [];
    const q = query.trim().toLowerCase();
    return pck1Result.entries.filter((e) => {
      if (selectedCat !== 'ALL' && e.category !== selectedCat) return false;
      if (!q) return true;
      return (
        e.name.toLowerCase().includes(q) ||
        e.subfolder.toLowerCase().includes(q) ||
        e.signature.toLowerCase().includes(q) ||
        e.notes.toLowerCase().includes(q)
      );
    });
  }, [pck1Result, selectedCat, query]);

  const safeSlug = (pck1Result?.packName || analysis.sfoInfo?.discId || analysis.sourceName)
    .replace(/[^a-zA-Z0-9_-]+/g, '_')
    .slice(0, 32);

  const handleExportZip = async (cat?: Pck1AssetCategory) => {
    if (!activeBlob || !pck1Result) return;
    const tag = cat ?? 'ALL';
    setExporting(tag);
    setStatusMsg(null);
    try {
      const zipBlob = await exportPck1SubfoldersZip(activeBlob, pck1Result, cat);
      const filename =
        cat === 'MUSICA_AT3'
          ? `MUSICA_AT3_${safeSlug}.zip`
          : `PCK1_SUBCARPETAS_${safeSlug}.zip`;
      downloadBlob(zipBlob, filename);
      setStatusMsg(`Archivo ${filename} generado con subcarpetas organizadas.`);
    } finally {
      setExporting(null);
    }
  };

  const handleExtractToLocalFolder = async () => {
    if (!activeBlob || !pck1Result) return;
    const win = window as unknown as {
      showDirectoryPicker?: () => Promise<FileSystemDirectoryHandle>;
    };
    if (typeof win.showDirectoryPicker !== 'function') {
      setStatusMsg(
        'Este navegador o contexto embebido no permite acceso directo a carpetas locales; usa "Exportar PCK1 en Subcarpetas (.ZIP)" para descargar todas las carpetas organizadas.'
      );
      return;
    }

    setExporting('DISK');
    setStatusMsg(null);
    try {
      const rootDir = await win.showDirectoryPicker();
      let written = 0;
      for (const entry of pck1Result.entries.slice(0, 400)) {
        const subHandle = await rootDir.getDirectoryHandle(entry.subfolder, { create: true });
        const fileHandle = await subHandle.getFileHandle(entry.name, { create: true });
        const writable = await fileHandle.createWritable();
        const data = await extractPck1EntryData(activeBlob, entry);
        await writable.write(new Uint8Array(data));
        await writable.close();
        written++;
      }
      setStatusMsg(`Descompresión directa completada: ${written} archivos guardados en subcarpetas.`);
    } catch (err) {
      setStatusMsg(
        err instanceof Error && err.name === 'AbortError'
          ? 'Selección de carpeta cancelada.'
          : 'No se pudo escribir en la carpeta seleccionada. Usa la exportación .ZIP.'
      );
    } finally {
      setExporting(null);
    }
  };

  const handleSendUnpackedToIso = async () => {
    if (!activeBlob || !pck1Result || !onSendToIsoExpander) return;
    setExporting('ISO');
    setStatusMsg(null);
    const folderMap: Record<Pck1AssetCategory, string> = {
      PERSONAJES: 'PERSONAJES',
      MAPAS: 'MAPAS',
      MINIMAPAS: 'MINIMAPAS',
      OBJ_3D: 'OBJ',
      MUSICA_AT3: 'MUSICA_AT3',
      IMAGENES: 'BARRA_DE_VIDA',
      OTROS: 'LOBBY',
    };
    try {
      const items: InjectedSubfolderBatchItem[] = [];
      for (const entry of pck1Result.entries.slice(0, 200)) {
        const data = await extractPck1EntryData(activeBlob, entry);
        const destFolder =
          entry.extension === 'pmf' ? 'VIDEOS_PMF' : folderMap[entry.category];
        items.push({
          path: `/PSP_GAME/MOD/DLC/${destFolder}/${entry.name}`,
          data,
        });
      }
      onSendToIsoExpander(items);
    } finally {
      setExporting(null);
    }
  };

  const handleExtractOne = async (entry: Pck1ExtractedEntry) => {
    if (!activeBlob) return;
    const data = await extractPck1EntryData(activeBlob, entry);
    downloadBlob(new Blob([data.buffer as ArrayBuffer], { type: 'application/octet-stream' }), entry.name);
  };

  const handleInspectOne = async (entry: Pck1ExtractedEntry) => {
    if (!activeBlob) return;
    const data = await extractPck1EntryData(activeBlob, entry);
    onInspectOffsetBytes(data, `${entry.subfolder}/${entry.name}`);
  };

  const handlePreviewOne = async (entry: Pck1ExtractedEntry) => {
    if (!activeBlob) return;
    const data = await extractPck1EntryData(activeBlob, entry);
    if (entry.category === 'MUSICA_AT3') {
      const url = URL.createObjectURL(new Blob([data.buffer as ArrayBuffer]));
      if (audioPreviewUrl) URL.revokeObjectURL(audioPreviewUrl.url);
      setAudioPreviewUrl({ label: `${entry.subfolder}/${entry.name}`, url });
    } else if (
      entry.extension === 'png' ||
      entry.extension === 'gim' ||
      entry.extension === 'tm2' ||
      entry.category === 'IMAGENES' ||
      entry.category === 'MINIMAPAS'
    ) {
      const dataUrl = renderPspImageBytesToDataUrl(data);
      const url = dataUrl ?? URL.createObjectURL(new Blob([data.buffer as ArrayBuffer]));
      if (imagePreviewUrl && imagePreviewUrl.url.startsWith('blob:')) {
        URL.revokeObjectURL(imagePreviewUrl.url);
      }
      setImagePreviewUrl({ label: `${entry.subfolder}/${entry.name}`, url });
    }
  };

  const handleCopyPython = async () => {
    try {
      await navigator.clipboard.writeText(pythonScript);
      setCopiedPy(true);
      setTimeout(() => setCopiedPy(false), 1500);
    } catch {
      // ignore clipboard errors
    }
  };

  const at3Count =
    pck1Result?.summaries.find((s) => s.category === 'MUSICA_AT3')?.count ?? 0;

  return (
    <div className="space-y-6">
      <input
        ref={fileRef}
        type="file"
        onChange={handleUploadExternal}
        className="hidden"
        accept=".pck,.bin,.pac,.cpk,.afs,.pak,.dat,*/*"
      />

      {/* Header + Container Selector */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-3xl">
            <h2 className="flex items-center gap-2 text-lg font-semibold text-slate-900 dark:text-white">
              <Archive className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              Descomprimidor PCK1 / PACKFILE.BIN en Subcarpetas
            </h2>
            <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
              Analiza tablas <span className="font-mono">PCK1</span>, bloques comprimidos <span className="font-mono">Zlib (0x789C)</span> y contenedores <span className="font-mono">PACKFILE.BIN</span>, separando automáticamente en subcarpetas: <span className="font-mono">Personajes/</span>, <span className="font-mono">Mapas/</span>, <span className="font-mono">Minimapas/</span>, <span className="font-mono">Modelos_OBJ/</span>, <span className="font-mono">Musica_AT3/</span> e <span className="font-mono">Imagenes/</span>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {isoContainerCandidates.map((cand) => (
              <button
                key={cand.path}
                type="button"
                disabled={scanning}
                onClick={() => handleAnalyzeIsoEntry(cand)}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Search className="h-3.5 w-3.5" />
                Descomprimir {cand.name}
              </button>
            ))}
            {!isoFileBlob && (standalonePackBlob || analysis.rawBytes.length > 0) && (
              <button
                type="button"
                disabled={scanning}
                onClick={() =>
                  void runUnpackAnalysis(
                    standalonePackBlob ?? new Blob([new Uint8Array(analysis.rawBytes).buffer]),
                    analysis.sourceName
                  )
                }
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Search className="h-3.5 w-3.5" />
                Analizar {analysis.sourceName}
              </button>
            )}
            <button
              type="button"
              disabled={scanning}
              onClick={() => fileRef.current?.click()}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Upload className="h-3.5 w-3.5" />
              Cargar .PCK / PACKFILE.BIN
            </button>
          </div>
        </div>

        {scanning && (
          <div className="mt-4 text-xs font-medium text-blue-600 tabular-nums dark:text-blue-400">
            Analizando tabla PCK1 y descomprimiendo bloques Zlib: {progress}%…
          </div>
        )}

        {statusMsg && (
          <div className="mt-4 rounded-lg border border-blue-200 bg-blue-50/70 px-4 py-2.5 text-xs text-slate-800 dark:border-blue-900/50 dark:bg-blue-950/30 dark:text-slate-200">
            {statusMsg}
          </div>
        )}
      </section>

      {pck1Result && (
        <>
          {/* 6 Category Filter KPI Cards */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-6">
            {pck1Result.summaries.slice(0, 6).map((sum) => {
              const active = selectedCat === sum.category;
              return (
                <button
                  key={sum.category}
                  type="button"
                  onClick={() => setSelectedCat(active ? 'ALL' : sum.category)}
                  className={`flex flex-col justify-between rounded-xl border p-4 text-left transition-colors cursor-pointer ${
                    active
                      ? 'border-blue-600 bg-blue-50/70 dark:border-blue-500 dark:bg-blue-950/30'
                      : 'border-slate-200 bg-white hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs font-semibold text-slate-900 dark:text-white">
                      {sum.folderName}/
                    </span>
                    <span className="text-slate-400 dark:text-slate-500">
                      {CAT_ICON[sum.category]}
                    </span>
                  </div>
                  <div className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums dark:text-white">
                    {sum.count}
                  </div>
                  <div className="mt-1 truncate text-[11px] text-slate-500 dark:text-slate-400">
                    {sum.label}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Export & Unpack Action Bar */}
          <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="text-xs text-slate-600 dark:text-slate-300">
                <strong className="font-mono text-slate-900 dark:text-white">{pck1Result.packName}</strong>
                <span aria-hidden="true"> · </span>
                <span className="tabular-nums">{pck1Result.pck1BlocksFound} bloque(s) PCK1</span>
                <span aria-hidden="true"> · </span>
                <span className="tabular-nums">{pck1Result.entries.length} archivos clasificados</span>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  disabled={exporting !== null || pck1Result.entries.length === 0}
                  onClick={() => void handleExportZip()}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-blue-600 dark:hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Download className="h-3.5 w-3.5" />
                  {exporting === 'ALL' ? 'Empaquetando…' : 'Exportar PCK1 en Subcarpetas (.ZIP)'}
                </button>

                <button
                  type="button"
                  disabled={exporting !== null || at3Count === 0}
                  onClick={() => void handleExportZip('MUSICA_AT3')}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-blue-600 bg-blue-50 px-3.5 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-100 disabled:opacity-40 dark:border-blue-500 dark:bg-blue-950/30 dark:text-blue-300 dark:hover:bg-blue-900/40 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Music className="h-3.5 w-3.5" />
                  Exportar Solo Música .AT3 ({at3Count})
                </button>

                <button
                  type="button"
                  disabled={exporting !== null || pck1Result.entries.length === 0}
                  onClick={() => void handleExtractToLocalFolder()}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <FolderOutput className="h-3.5 w-3.5" />
                  Extraer a Carpeta en Disco
                </button>

                {onSendToIsoExpander && analysis.isoInfo && (
                  <button
                    type="button"
                    disabled={exporting !== null || pck1Result.entries.length === 0}
                    onClick={() => void handleSendUnpackedToIso()}
                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-emerald-600 bg-emerald-50 px-3.5 py-2 text-xs font-semibold text-emerald-700 hover:bg-emerald-100 disabled:opacity-50 dark:border-emerald-500 dark:bg-emerald-950/30 dark:text-emerald-300 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <FolderPlus className="h-3.5 w-3.5" />
                    Inyectar en Subcarpetas ISO
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setShowPython((s) => !s)}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {showPython ? 'Ocultar Python PCK1' : 'Ver Script Python PCK1'}
                </button>
              </div>
            </div>

            {pck1Result.notes.length > 0 && (
              <ul className="mt-3 space-y-1 border-t border-slate-100 pt-3 text-xs text-slate-600 dark:border-slate-800 dark:text-slate-400">
                {pck1Result.notes.map((n, i) => (
                  <li key={i}>• {n}</li>
                ))}
              </ul>
            )}

            {showPython && (
              <div className="mt-4 space-y-2 border-t border-slate-100 pt-4 dark:border-slate-800">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-mono text-xs font-semibold text-slate-900 dark:text-white">
                    descomprimir_pck1_subcarpetas.py
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => void handleCopyPython()}
                      className="inline-flex min-h-[34px] items-center gap-1 rounded border border-slate-300 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                    >
                      {copiedPy ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                      {copiedPy ? 'Copiado' : 'Copiar'}
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        downloadBlob(
                          new Blob([pythonScript], { type: 'text/plain;charset=utf-8' }),
                          'descomprimir_pck1_subcarpetas.py'
                        )
                      }
                      className="inline-flex min-h-[34px] items-center gap-1 rounded bg-slate-900 px-3 py-1 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
                    >
                      <Download className="h-3.5 w-3.5" />
                      Descargar .PY
                    </button>
                  </div>
                </div>
                <pre className="max-h-72 overflow-auto rounded-lg border border-slate-200 bg-slate-950 p-3 font-mono text-[11px] leading-relaxed text-slate-100 dark:border-slate-800">
                  {pythonScript}
                </pre>
              </div>
            )}
          </section>

          {/* Optional Audio / PNG Previews */}
          {audioPreviewUrl && (
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-blue-200 bg-blue-50/70 p-4 text-xs dark:border-blue-900/50 dark:bg-blue-950/30">
              <div>
                <div className="font-semibold text-slate-900 dark:text-white">
                  Reproducción rápida: <span className="font-mono">{audioPreviewUrl.label}</span>
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  Nota: RIFF PCM se reproduce nativamente; los flujos ATRAC3+ puros pueden requerir exportación a PC / PPSSPP.
                </div>
              </div>
              <audio controls src={audioPreviewUrl.url} className="h-9" />
            </div>
          )}

          {imagePreviewUrl && (
            <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-4 text-xs dark:border-slate-800 dark:bg-slate-900">
              <div className="font-mono font-semibold text-slate-900 dark:text-white">
                Vista previa Textura PSP (.GIM/.TM2/.PNG): {imagePreviewUrl.label}
              </div>
              <img
                src={imagePreviewUrl.url}
                alt={imagePreviewUrl.label}
                className="h-20 w-20 rounded border border-slate-200 bg-slate-950 dark:border-slate-700"
                style={{ imageRendering: 'pixelated' }}
              />
            </div>
          )}

          {/* Search & Table */}
          <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 px-4 py-3 dark:border-slate-800">
              <div className="relative w-full max-w-md">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Buscar .AT3, .OBJ, .GMO, .MAP, .GIM o subcarpeta..."
                  className="min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 pl-8 pr-3 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div className="flex items-center gap-2 text-xs text-slate-500 tabular-nums dark:text-slate-400">
                <span>
                  Mostrando {filteredEntries.length} de {pck1Result.entries.length} archivos
                </span>
                {selectedCat !== 'ALL' && (
                  <button
                    type="button"
                    onClick={() => setSelectedCat('ALL')}
                    className="rounded border border-slate-300 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                  >
                    Todas las subcarpetas
                  </button>
                )}
              </div>
            </div>

            {filteredEntries.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500 dark:text-slate-400">
                No se encontraron entradas con el filtro actual.
              </div>
            ) : (
              <div className="max-h-[420px] overflow-auto">
                <table className="w-full border-collapse text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                      <th className="px-3 py-2.5 font-semibold">#</th>
                      <th className="px-3 py-2.5 font-semibold">Subcarpeta / Archivo</th>
                      <th className="px-3 py-2.5 font-semibold">Formato</th>
                      <th className="px-3 py-2.5 font-semibold">Compresión</th>
                      <th className="px-3 py-2.5 font-semibold">Offset</th>
                      <th className="px-3 py-2.5 text-right font-semibold">Tamaño</th>
                      <th className="px-3 py-2.5 text-right font-semibold">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredEntries.slice(0, 300).map((entry) => (
                      <tr key={`${entry.id}-${entry.offset}`} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                        <td className="px-3 py-2 font-mono text-slate-400 tabular-nums">
                          {String(entry.id).padStart(4, '0')}
                        </td>
                        <td className="px-3 py-2 font-mono text-slate-900 dark:text-slate-100">
                          <span className="text-blue-600 dark:text-blue-400">{entry.subfolder}/</span>
                          {entry.name}
                        </td>
                        <td className="px-3 py-2 font-mono text-[11px] text-slate-600 dark:text-slate-300">
                          {entry.signature}
                        </td>
                        <td className="px-3 py-2 font-mono text-[11px] text-slate-500 dark:text-slate-400">
                          {entry.compressed === 'ZLIB' ? 'Zlib (descomp.)' : 'Raw'}
                        </td>
                        <td className="px-3 py-2 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                          {hex(entry.offset, 6)}
                        </td>
                        <td className="px-3 py-2 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                          {entry.uncompressedSize.toLocaleString('es-ES')} B
                        </td>
                        <td className="px-3 py-2 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            {(entry.category === 'MUSICA_AT3' ||
                              entry.category === 'IMAGENES' ||
                              entry.category === 'MINIMAPAS' ||
                              entry.extension === 'png' ||
                              entry.extension === 'gim' ||
                              entry.extension === 'tm2') && (
                              <button
                                type="button"
                                onClick={() => void handlePreviewOne(entry)}
                                className="inline-flex min-h-[30px] items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                              >
                                <Play className="h-3 w-3" />
                                Probar
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => void handleInspectOne(entry)}
                              className="inline-flex min-h-[30px] items-center gap-1 rounded bg-slate-900 px-2 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
                            >
                              <Binary className="h-3 w-3" />
                              HxD
                            </button>
                            <button
                              type="button"
                              onClick={() => void handleExtractOne(entry)}
                              className="inline-flex min-h-[30px] items-center rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                            >
                              Extraer
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
};
