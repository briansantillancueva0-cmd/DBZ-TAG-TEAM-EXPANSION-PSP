import React, { useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeftRight,
  Binary,
  CheckCircle2,
  Download,
  FileImage,
  GripVertical,
  Image as ImageIcon,
  RefreshCw,
  Search,
  Sparkles,
  Trash2,
  Upload,
} from 'lucide-react';
import type { DbzRoster256JsonManifest } from '../lib/dbzTagTeamExpander';
import type { EbootAnalysis } from '../lib/types';

export interface GimModelAssignment {
  slotId: number; // 1..256 (vinculado al slot del personaje)
  gimId: number; // ID único 0..255 (0x00..0xFF)
  fileName: string;
  dlcPath: string;
  sourceKind: 'DEFAULT_TEMPLATE' | 'ISO_INTERNAL' | 'DRAG_DROP';
  hasPspGimMagic: boolean;
  fileSizeBytes: number;
  customBytes?: Uint8Array;
}

interface DroppedPoolItem {
  poolId: string;
  fileName: string;
  sizeBytes: number;
  hasPspGimMagic: boolean;
  bytes?: Uint8Array;
  isoPath?: string;
}

interface DbzGimModelTableProps {
  analysis: EbootAnalysis | null;
  gameId: string;
  manifest: DbzRoster256JsonManifest;
  assignments: GimModelAssignment[];
  onChangeAssignments: (next: GimModelAssignment[]) => void;
  onInspectAssetBytes?: (bytes: Uint8Array, assetPath: string) => void;
}

export function buildInitialGimAssignments(
  manifest: DbzRoster256JsonManifest
): GimModelAssignment[] {
  return manifest.characters.map((ch, idx) => {
    const gimId = Math.max(0, Math.min(255, idx));
    const baseName = ch.gimPortraitPath.split('/').pop() || `MODEL_${String(gimId).padStart(3, '0')}.GIM`;
    return {
      slotId: ch.id,
      gimId,
      fileName: baseName,
      dlcPath: ch.gimPortraitPath,
      sourceKind: 'DEFAULT_TEMPLATE',
      hasPspGimMagic: false,
      fileSizeBytes: 0,
    };
  });
}

export function buildGimBindingsOverlayFiles(
  gameId: string,
  assignments: GimModelAssignment[],
  manifest: DbzRoster256JsonManifest
): Array<{ path: string; data: Uint8Array }> {
  const enc = new TextEncoder();
  const files: Array<{ path: string; data: Uint8Array }> = [];

  for (const item of assignments) {
    if (item.customBytes && item.customBytes.length > 0) {
      const normalized = item.dlcPath.replace(/^disc0:/i, '');
      const cleanPath = normalized.startsWith('/') ? normalized : `/${normalized}`;
      files.push({
        path: cleanPath,
        data: item.customBytes,
      });
    }
  }

  const charMap = new Map(manifest.characters.map((c) => [c.id, c.displayName]));
  const tableJson = {
    schema: 'DBZ_TT_GIM_MODEL_TABLE_256',
    gameId,
    uniqueRange: '0..255',
    totalEntries: assignments.length,
    bindings: assignments.map((a) => ({
      gimId: a.gimId,
      gimHexId: `0x${a.gimId.toString(16).toUpperCase().padStart(2, '0')}`,
      characterSlotId: a.slotId,
      characterName: charMap.get(a.slotId) ?? `Slot #${a.slotId}`,
      fileName: a.fileName,
      dlcPath: a.dlcPath,
      sourceKind: a.sourceKind,
      hasPspGimMagic: a.hasPspGimMagic,
      fileSizeBytes: a.fileSizeBytes,
    })),
  };

  files.push({
    path: '/PSP_GAME/DLC/PERSONAJES/GIM_MODEL_TABLE_256.json',
    data: enc.encode(JSON.stringify(tableJson, null, 2)),
  });

  return files;
}

function normalizeNameForMatch(s: string): string {
  return s
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\.(gim|gmo|tm2|bin|png)$/i, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function hasMigHeader(bytes: Uint8Array): boolean {
  if (bytes.length < 4) return false;
  // Sony PSP GIM magic: "MIG." (little or big endian)
  return (
    (bytes[0] === 0x4d && bytes[1] === 0x49 && bytes[2] === 0x47 && bytes[3] === 0x2e) ||
    (bytes[0] === 0x2e && bytes[1] === 0x47 && bytes[2] === 0x49 && bytes[3] === 0x4d)
  );
}

function formatGimHex(gimId: number): string {
  return `0x${(gimId & 0xff).toString(16).toUpperCase().padStart(2, '0')}`;
}

export const DbzGimModelTable: React.FC<DbzGimModelTableProps> = ({
  analysis,
  gameId,
  manifest,
  assignments,
  onChangeAssignments,
  onInspectAssetBytes,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMode, setFilterMode] = useState<'ALL' | 'LINKED' | 'DUPLICATES' | 'DEFAULT'>('ALL');
  const [pageIdx, setPageIdx] = useState(0);
  const [autoSwapOnCollision, setAutoSwapOnCollision] = useState(true);
  const [idBaseConvention, setIdBaseConvention] = useState<'ZERO_BASED' | 'ONE_BASED'>('ZERO_BASED');
  const [sequentialStartGimId, setSequentialStartGimId] = useState<number>(0);
  const [isGlobalDragOver, setIsGlobalDragOver] = useState(false);
  const [dragOverSlotId, setDragOverSlotId] = useState<number | null>(null);
  const [resourcePool, setResourcePool] = useState<DroppedPoolItem[]>([]);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const batchInputRef = useRef<HTMLInputElement | null>(null);
  const rowUploadSlotRef = useRef<number | null>(null);
  const rowInputRef = useRef<HTMLInputElement | null>(null);

  const charNameBySlot = useMemo(() => {
    const m = new Map<number, string>();
    for (const c of manifest.characters) {
      m.set(c.id, c.displayName);
    }
    return m;
  }, [manifest.characters]);

  // Detect duplicate GIM IDs across 0..255
  const { duplicateGimIds, uniqueCount, linkedCount } = useMemo(() => {
    const counts = new Map<number, number>();
    let linked = 0;
    for (const a of assignments) {
      counts.set(a.gimId, (counts.get(a.gimId) ?? 0) + 1);
      if (a.sourceKind !== 'DEFAULT_TEMPLATE') linked++;
    }
    const dupes = new Set<number>();
    counts.forEach((cnt, id) => {
      if (cnt > 1) dupes.add(id);
    });
    return {
      duplicateGimIds: dupes,
      uniqueCount: counts.size,
      linkedCount: linked,
    };
  }, [assignments]);

  // Discover .GIM files inside loaded ISO if present
  const isoGimEntries = useMemo(() => {
    if (!analysis?.isoInfo) return [];
    return analysis.isoInfo.files
      .filter((f) => !f.isDirectory && /\.(gim|tm2|gmo)$/i.test(f.name))
      .slice(0, 64);
  }, [analysis]);

  const filteredAssignments = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    return assignments.filter((a) => {
      if (filterMode === 'LINKED' && a.sourceKind === 'DEFAULT_TEMPLATE') return false;
      if (filterMode === 'DEFAULT' && a.sourceKind !== 'DEFAULT_TEMPLATE') return false;
      if (filterMode === 'DUPLICATES' && !duplicateGimIds.has(a.gimId)) return false;
      if (!q) return true;
      const charName = (charNameBySlot.get(a.slotId) ?? '').toLowerCase();
      return (
        String(a.gimId).includes(q) ||
        formatGimHex(a.gimId).toLowerCase().includes(q) ||
        String(a.slotId).includes(q) ||
        charName.includes(q) ||
        a.fileName.toLowerCase().includes(q) ||
        a.dlcPath.toLowerCase().includes(q)
      );
    });
  }, [assignments, filterMode, searchTerm, duplicateGimIds, charNameBySlot]);

  const PAGE_SIZE = 32;
  const totalPages = Math.max(1, Math.ceil(filteredAssignments.length / PAGE_SIZE));
  const clampedPage = Math.min(pageIdx, totalPages - 1);
  const pageItems = filteredAssignments.slice(
    clampedPage * PAGE_SIZE,
    (clampedPage + 1) * PAGE_SIZE
  );

  // Change GIM ID (0..255) for a slot with optional collision swap
  const handleChangeGimId = (slotId: number, rawNewId: number) => {
    const targetGimId = Math.max(0, Math.min(255, Math.floor(rawNewId) || 0));
    const currentItem = assignments.find((a) => a.slotId === slotId);
    if (!currentItem || currentItem.gimId === targetGimId) return;

    const oldGimId = currentItem.gimId;
    const occupant = assignments.find(
      (a) => a.slotId !== slotId && a.gimId === targetGimId
    );

    const next = assignments.map((a) => {
      if (a.slotId === slotId) {
        return { ...a, gimId: targetGimId };
      }
      if (autoSwapOnCollision && occupant && a.slotId === occupant.slotId) {
        return { ...a, gimId: oldGimId };
      }
      return a;
    });

    onChangeAssignments(next);
    if (autoSwapOnCollision && occupant) {
      setFeedbackMsg(
        `ID único ${targetGimId} (${formatGimHex(targetGimId)}) intercambiado entre Slot #${String(slotId).padStart(3, '0')} y Slot #${String(occupant.slotId).padStart(3, '0')}.`
      );
    }
  };

  // Auto-resolve any duplicate 0..255 IDs
  const handleNormalizeUniqueIds = () => {
    const used = new Set<number>();
    const freePool: number[] = [];
    for (let id = 0; id <= 255; id++) {
      if (!assignments.some((a) => a.gimId === id)) {
        freePool.push(id);
      }
    }

    const next = assignments.map((a) => {
      if (!used.has(a.gimId)) {
        used.add(a.gimId);
        return a;
      }
      const replacement = freePool.shift();
      if (replacement !== undefined) {
        used.add(replacement);
        return { ...a, gimId: replacement };
      }
      return a;
    });

    onChangeAssignments(next);
    setFeedbackMsg('IDs 0–255 normalizados: los 256 slots ahora tienen identificadores únicos sin colisiones.');
  };

  // Reset IDs to sequential 0..255 matching Slot #001..#256
  const handleResetSequential = () => {
    const next = assignments.map((a, idx) => ({
      ...a,
      gimId: Math.max(0, Math.min(255, idx)),
    }));
    onChangeAssignments(next);
    setFeedbackMsg('IDs restablecidos en orden secuencial 0 → 255 (0x00 → 0xFF).');
  };

  const applyResourceToSlot = (
    targetSlotId: number,
    res: {
      fileName: string;
      bytes?: Uint8Array;
      sizeBytes?: number;
      sourceKind: 'ISO_INTERNAL' | 'DRAG_DROP';
      isoPath?: string;
    }
  ) => {
    const cleanName = res.fileName.trim() || `MODEL_${String(targetSlotId).padStart(3, '0')}.GIM`;
    const isMig = res.bytes ? hasMigHeader(res.bytes) : false;
    const nextPath = res.isoPath
      ? `disc0:${res.isoPath.startsWith('/') ? res.isoPath : `/${res.isoPath}`}`
      : `disc0:/PSP_GAME/DLC/CHIBIS/${cleanName}`;

    const next = assignments.map((a) => {
      if (a.slotId !== targetSlotId) return a;
      return {
        ...a,
        fileName: cleanName,
        dlcPath: nextPath,
        sourceKind: res.sourceKind,
        hasPspGimMagic: isMig,
        fileSizeBytes: res.bytes ? res.bytes.length : res.sizeBytes ?? a.fileSizeBytes,
        customBytes: res.bytes,
      };
    });

    onChangeAssignments(next);
    const charName = charNameBySlot.get(targetSlotId) ?? `Slot #${targetSlotId}`;
    setFeedbackMsg(
      `Modelo "${cleanName}" vinculado a ${charName} (Slot #${String(targetSlotId).padStart(3, '0')}).`
    );
  };

  // Smart auto-linker for batch dropped files
  const autoLinkBatchFiles = async (fileList: FileList | File[]) => {
    const files = Array.from(fileList);
    if (files.length === 0) return;

    const updated = [...assignments];
    const touchedSlots = new Set<number>();
    const newPoolItems: DroppedPoolItem[] = [];
    let seqCursor = Math.max(0, Math.min(255, sequentialStartGimId));
    let linkedCountNow = 0;

    for (const file of files) {
      const buf = new Uint8Array(await file.arrayBuffer());
      const isMig = hasMigHeader(buf);
      const normName = normalizeNameForMatch(file.name);

      newPoolItems.push({
        poolId: `${file.name}-${file.size}-${Math.random().toString(36).slice(2, 7)}`,
        fileName: file.name,
        sizeBytes: buf.length,
        hasPspGimMagic: isMig,
        bytes: buf,
      });

      let targetIndex = -1;

      // 1. Try matching by explicit number in filename (e.g. CHIBI001.GIM, model_255.gim, 0x0A)
      const hexMatch = file.name.match(/0x([0-9a-f]{1,2})/i);
      const numMatch = file.name.match(/(\d{1,3})/);
      if (hexMatch) {
        const parsedHex = parseInt(hexMatch[1], 16);
        targetIndex = updated.findIndex((a) => a.gimId === parsedHex && !touchedSlots.has(a.slotId));
      } else if (numMatch) {
        const n = parseInt(numMatch[1], 10);
        if (idBaseConvention === 'ONE_BASED' && n >= 1 && n <= 256) {
          targetIndex = updated.findIndex((a) => a.slotId === n && !touchedSlots.has(a.slotId));
        } else if (n >= 0 && n <= 255) {
          targetIndex = updated.findIndex((a) => a.gimId === n && !touchedSlots.has(a.slotId));
        }
      }

      // 2. Try matching by character name inside filename (e.g. vegeta.gim, peq_bu.gim)
      if (targetIndex === -1 && normName.length >= 3) {
        targetIndex = updated.findIndex((a) => {
          if (touchedSlots.has(a.slotId)) return false;
          const cname = normalizeNameForMatch(charNameBySlot.get(a.slotId) ?? '');
          return cname.length >= 3 && (normName.includes(cname) || cname.includes(normName));
        });
      }

      // 3. Fallback: assign sequentially starting from sequentialStartGimId
      if (targetIndex === -1) {
        while (seqCursor <= 255) {
          const idx = updated.findIndex(
            (a) => a.gimId === seqCursor && !touchedSlots.has(a.slotId)
          );
          seqCursor++;
          if (idx !== -1) {
            targetIndex = idx;
            break;
          }
        }
      }

      if (targetIndex !== -1) {
        const target = updated[targetIndex];
        touchedSlots.add(target.slotId);
        updated[targetIndex] = {
          ...target,
          fileName: file.name,
          dlcPath: `disc0:/PSP_GAME/DLC/CHIBIS/${file.name}`,
          sourceKind: 'DRAG_DROP',
          hasPspGimMagic: isMig,
          fileSizeBytes: buf.length,
          customBytes: buf,
        };
        linkedCountNow++;
      }
    }

    onChangeAssignments(updated);
    setResourcePool((prev) => [...newPoolItems, ...prev].slice(0, 64));
    setFeedbackMsg(
      `${linkedCountNow} de ${files.length} archivo(s) .GIM vinculados automáticamente a sus slots de personaje.`
    );
  };

  const handleGlobalDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsGlobalDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      await autoLinkBatchFiles(e.dataTransfer.files);
    }
  };

  const handleRowDrop = async (
    e: React.DragEvent<HTMLTableRowElement>,
    targetSlotId: number
  ) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOverSlotId(null);

    // Case A: Dropped a resource chip from inside the app (Resource Pool or ISO entry or another row)
    const internalPayload = e.dataTransfer.getData('application/x-dbz-gim-resource');
    if (internalPayload) {
      try {
        const parsed = JSON.parse(internalPayload) as {
          kind: 'POOL' | 'ISO' | 'ROW_SWAP';
          poolId?: string;
          fileName?: string;
          isoPath?: string;
          sizeBytes?: number;
          sourceSlotId?: number;
        };

        if (parsed.kind === 'POOL' && parsed.poolId) {
          const found = resourcePool.find((p) => p.poolId === parsed.poolId);
          if (found) {
            applyResourceToSlot(targetSlotId, {
              fileName: found.fileName,
              bytes: found.bytes,
              sizeBytes: found.sizeBytes,
              sourceKind: 'DRAG_DROP',
            });
          }
          return;
        }

        if (parsed.kind === 'ISO' && parsed.fileName && parsed.isoPath) {
          applyResourceToSlot(targetSlotId, {
            fileName: parsed.fileName,
            sizeBytes: parsed.sizeBytes,
            isoPath: parsed.isoPath,
            sourceKind: 'ISO_INTERNAL',
          });
          return;
        }

        if (parsed.kind === 'ROW_SWAP' && parsed.sourceSlotId && parsed.sourceSlotId !== targetSlotId) {
          const src = assignments.find((a) => a.slotId === parsed.sourceSlotId);
          const dst = assignments.find((a) => a.slotId === targetSlotId);
          if (src && dst) {
            const next = assignments.map((a) => {
              if (a.slotId === dst.slotId) {
                return {
                  ...a,
                  fileName: src.fileName,
                  dlcPath: src.dlcPath,
                  sourceKind: src.sourceKind,
                  hasPspGimMagic: src.hasPspGimMagic,
                  fileSizeBytes: src.fileSizeBytes,
                  customBytes: src.customBytes,
                };
              }
              if (a.slotId === src.slotId) {
                return {
                  ...a,
                  fileName: dst.fileName,
                  dlcPath: dst.dlcPath,
                  sourceKind: dst.sourceKind,
                  hasPspGimMagic: dst.hasPspGimMagic,
                  fileSizeBytes: dst.fileSizeBytes,
                  customBytes: dst.customBytes,
                };
              }
              return a;
            });
            onChangeAssignments(next);
            setFeedbackMsg(
              `Modelo .GIM intercambiado entre Slot #${String(src.slotId).padStart(3, '0')} y Slot #${String(dst.slotId).padStart(3, '0')}.`
            );
          }
          return;
        }
      } catch {
        // ignore invalid payload
      }
    }

    // Case B: Dropped real file(s) from OS file explorer directly onto the table row
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      const buf = new Uint8Array(await file.arrayBuffer());
      const isMig = hasMigHeader(buf);
      applyResourceToSlot(targetSlotId, {
        fileName: file.name,
        bytes: buf,
        sizeBytes: buf.length,
        sourceKind: 'DRAG_DROP',
      });
      setResourcePool((prev) =>
        [
          {
            poolId: `${file.name}-${Date.now()}`,
            fileName: file.name,
            sizeBytes: buf.length,
            hasPspGimMagic: isMig,
            bytes: buf,
          },
          ...prev,
        ].slice(0, 64)
      );
    }
  };

  const handleAutoLinkIsoGims = () => {
    if (isoGimEntries.length === 0) return;
    const updated = [...assignments];
    let linked = 0;

    isoGimEntries.forEach((isoFile, idx) => {
      const numMatch = isoFile.name.match(/(\d{1,3})/);
      let targetIdx = -1;
      if (numMatch) {
        const n = parseInt(numMatch[1], 10);
        if (n >= 0 && n <= 255) {
          targetIdx = updated.findIndex((a) => a.gimId === n);
        }
      }
      if (targetIdx === -1 && idx < updated.length) {
        targetIdx = idx;
      }
      if (targetIdx !== -1) {
        updated[targetIdx] = {
          ...updated[targetIdx],
          fileName: isoFile.name,
          dlcPath: `disc0:${isoFile.path}`,
          sourceKind: 'ISO_INTERNAL',
          fileSizeBytes: isoFile.size,
        };
        linked++;
      }
    });

    onChangeAssignments(updated);
    setFeedbackMsg(`${linked} recursos .GIM internos de la ISO vinculados a los slots de personaje.`);
  };

  const handleDownloadGimTableJson = () => {
    const overlay = buildGimBindingsOverlayFiles(gameId, assignments, manifest);
    const tableFile = overlay[overlay.length - 1];
    const blob = new Blob([tableFile.data as unknown as BlobPart], {
      type: 'application/json;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${gameId}_GIM_MODEL_TABLE_256.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-5">
      <input
        ref={batchInputRef}
        type="file"
        multiple
        accept=".gim,.gmo,.tm2,.bin,.png,*/*"
        onChange={(e) => {
          if (e.target.files) void autoLinkBatchFiles(e.target.files);
          e.target.value = '';
        }}
        className="hidden"
      />
      <input
        ref={rowInputRef}
        type="file"
        accept=".gim,.gmo,.tm2,.bin,.png,*/*"
        onChange={async (e) => {
          const file = e.target.files?.[0];
          const slotId = rowUploadSlotRef.current;
          e.target.value = '';
          if (!file || slotId === null) return;
          const buf = new Uint8Array(await file.arrayBuffer());
          applyResourceToSlot(slotId, {
            fileName: file.name,
            bytes: buf,
            sizeBytes: buf.length,
            sourceKind: 'DRAG_DROP',
          });
        }}
        className="hidden"
      />

      {/* Top Header + Global Drag & Drop Auto-Linker Zone */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
          <div>
            <h3 className="flex items-center gap-2 text-base font-bold text-slate-900 dark:text-white">
              <FileImage className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              Tabla Interactiva de Modelos .GIM (IDs Únicos 0–255) + Arrastrar y Soltar
            </h3>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-300">
              Asigna un ID hexadecimal único (<span className="font-mono font-semibold">0–255 / 0x00–0xFF</span>) a cada archivo <span className="font-mono">.GIM</span>. Arrastra archivos desde tu PC hacia la zona global para vincularlos por nombre/ID o suéltalos directamente sobre cualquier fila de personaje.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleNormalizeUniqueIds}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 cursor-pointer"
            >
              <ArrowLeftRight className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
              Resolver Duplicados
            </button>
            <button
              type="button"
              onClick={handleResetSequential}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 cursor-pointer"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              Secuencial 0–255
            </button>
            <button
              type="button"
              onClick={handleDownloadGimTableJson}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              Exportar Tabla .JSON
            </button>
          </div>
        </div>

        {/* Metrics & Collision Banner */}
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4 text-xs">
          <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950">
            <div className="text-slate-500">IDs Únicos (0–255)</div>
            <div
              className={`mt-1 font-mono text-sm font-bold tabular-nums ${
                duplicateGimIds.size === 0
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-red-600 dark:text-red-400'
              }`}
            >
              {uniqueCount} / {assignments.length}
            </div>
          </div>
          <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950">
            <div className="text-slate-500">Modelos .GIM Vinculados</div>
            <div className="mt-1 font-mono text-sm font-bold tabular-nums text-blue-600 dark:text-blue-400">
              {linkedCount} personalizados
            </div>
          </div>
          <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950">
            <div className="text-slate-500">Colisiones de ID</div>
            <div className="mt-1 font-mono text-sm font-bold tabular-nums text-slate-900 dark:text-white">
              {duplicateGimIds.size === 0 ? '0 (Limpio)' : `${duplicateGimIds.size} duplicados`}
            </div>
          </div>
          <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950">
            <div className="text-slate-500">.GIM Detectados en ISO</div>
            <div className="mt-1 font-mono text-sm font-bold tabular-nums text-slate-900 dark:text-white">
              {isoGimEntries.length} archivos
            </div>
          </div>
        </div>

        {/* Batch Drag & Drop Zone */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsGlobalDragOver(true);
          }}
          onDragLeave={() => setIsGlobalDragOver(false)}
          onDrop={(e) => void handleGlobalDrop(e)}
          className={`mt-4 rounded-xl border-2 border-dashed p-5 text-center transition-colors ${
            isGlobalDragOver
              ? 'border-blue-500 bg-blue-50/80 dark:border-blue-400 dark:bg-blue-950/40'
              : 'border-slate-300 bg-slate-50/70 hover:border-blue-400 dark:border-slate-700 dark:bg-slate-950/60'
          }`}
        >
          <Upload className="mx-auto h-7 w-7 text-blue-600 dark:text-blue-400" />
          <p className="mt-2 text-xs font-semibold text-slate-900 dark:text-white">
            Arrastra y suelta múltiples archivos <span className="font-mono">.GIM</span> aquí para vincularlos automáticamente a los personajes
          </p>
          <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
            Auto-detección inteligente por número en archivo (<span className="font-mono">000..255</span> / <span className="font-mono">0x00..0xFF</span>), nombre del personaje (ej. <span className="font-mono">vegeta.gim</span>, <span className="font-mono">broly.gim</span>) o asignación secuencial.
          </p>

          <div className="mt-3 flex flex-wrap items-center justify-center gap-3 text-xs">
            <button
              type="button"
              onClick={() => batchInputRef.current?.click()}
              className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-1.5 font-semibold text-white hover:bg-blue-700 cursor-pointer"
            >
              <Upload className="h-3.5 w-3.5" />
              Seleccionar archivos .GIM (Lote)
            </button>

            <label className="inline-flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
              <span>Números en nombre:</span>
              <select
                value={idBaseConvention}
                onChange={(e) =>
                  setIdBaseConvention(e.target.value as 'ZERO_BASED' | 'ONE_BASED')
                }
                className="rounded-md border border-slate-300 bg-white px-2 py-1 font-mono text-[11px] dark:border-slate-700 dark:bg-slate-900"
              >
                <option value="ZERO_BASED">0–255 (ID GIM directo)</option>
                <option value="ONE_BASED">1–256 (Slot CHAR001)</option>
              </select>
            </label>

            <label className="inline-flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
              <span>Secuencial desde ID:</span>
              <input
                type="number"
                min={0}
                max={255}
                value={sequentialStartGimId}
                onChange={(e) =>
                  setSequentialStartGimId(Math.max(0, Math.min(255, Number(e.target.value) || 0)))
                }
                className="w-16 rounded-md border border-slate-300 bg-white px-2 py-1 font-mono text-[11px] tabular-nums dark:border-slate-700 dark:bg-slate-900"
              />
            </label>
          </div>
        </div>

        {/* Draggable Resource Bank (Uploaded Files + ISO Detected .GIMs) */}
        {(resourcePool.length > 0 || isoGimEntries.length > 0) && (
          <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-3.5 dark:border-slate-800 dark:bg-slate-950">
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
                <Sparkles className="h-3.5 w-3.5 text-amber-500" />
                Banco de Recursos Arrastrables (Arrastra una ficha hacia cualquier fila de la tabla ↓)
              </div>
              {isoGimEntries.length > 0 && (
                <button
                  type="button"
                  onClick={handleAutoLinkIsoGims}
                  className="rounded-md bg-slate-900 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
                >
                  Auto-vincular {isoGimEntries.length} .GIM de la ISO
                </button>
              )}
            </div>

            <div className="flex max-h-28 flex-wrap gap-1.5 overflow-y-auto">
              {resourcePool.map((item) => (
                <div
                  key={item.poolId}
                  draggable
                  onDragStart={(e) => {
                    e.dataTransfer.setData(
                      'application/x-dbz-gim-resource',
                      JSON.stringify({ kind: 'POOL', poolId: item.poolId })
                    );
                  }}
                  title="Arrastra hacia cualquier fila para vincular"
                  className="inline-flex items-center gap-1.5 rounded-lg border border-blue-300 bg-white px-2.5 py-1 font-mono text-[11px] text-slate-800 shadow-xs hover:border-blue-500 dark:border-blue-800 dark:bg-slate-900 dark:text-slate-200 cursor-grab active:cursor-grabbing"
                >
                  <GripVertical className="h-3 w-3 text-slate-400" />
                  <ImageIcon className="h-3 w-3 text-blue-600 dark:text-blue-400" />
                  <span>{item.fileName}</span>
                  <span className="text-[10px] text-slate-400">
                    {(item.sizeBytes / 1024).toFixed(1)}K
                  </span>
                </div>
              ))}

              {isoGimEntries.map((isoFile) => (
                <div
                  key={isoFile.path}
                  draggable
                  onDragStart={(e) => {
                    e.dataTransfer.setData(
                      'application/x-dbz-gim-resource',
                      JSON.stringify({
                        kind: 'ISO',
                        fileName: isoFile.name,
                        isoPath: isoFile.path,
                        sizeBytes: isoFile.size,
                      })
                    );
                  }}
                  title={`ISO: ${isoFile.path} — Arrastra a una fila`}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-300 bg-white px-2.5 py-1 font-mono text-[11px] text-slate-800 hover:border-emerald-500 dark:border-emerald-800 dark:bg-slate-900 dark:text-slate-200 cursor-grab active:cursor-grabbing"
                >
                  <GripVertical className="h-3 w-3 text-slate-400" />
                  <span>[ISO] {isoFile.name}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {feedbackMsg && (
          <div className="mt-3 flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-xs text-blue-900 dark:border-blue-900/50 dark:bg-blue-950/30 dark:text-blue-200">
            <CheckCircle2 className="h-4 w-4 shrink-0 text-blue-600 dark:text-blue-400" />
            <span>{feedbackMsg}</span>
          </div>
        )}
      </section>

      {/* Interactive Table (0–255 Unique GIM IDs <-> Character Slots) */}
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-4 dark:border-slate-800">
          <div className="flex flex-1 flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[200px] max-w-sm">
              <Search className="pointer-events-none absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setPageIdx(0);
                }}
                placeholder="Buscar ID (0–255 / 0x00), personaje o .GIM..."
                className="min-h-[34px] w-full rounded-lg border border-slate-200 bg-slate-50 pl-8 pr-3 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <select
              value={filterMode}
              onChange={(e) => {
                setFilterMode(e.target.value as 'ALL' | 'LINKED' | 'DUPLICATES' | 'DEFAULT');
                setPageIdx(0);
              }}
              className="min-h-[34px] rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              <option value="ALL">Todos ({assignments.length})</option>
              <option value="LINKED">Vinculados Custom / ISO ({linkedCount})</option>
              <option value="DUPLICATES">Con ID Duplicado ({duplicateGimIds.size})</option>
              <option value="DEFAULT">Plantilla Base</option>
            </select>
          </div>

          <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={autoSwapOnCollision}
              onChange={(e) => setAutoSwapOnCollision(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 accent-blue-600"
            />
            Intercambiar ID automáticamente si ya existe (mantener 0–255 únicos)
          </label>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs">
            <thead className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
              <tr>
                <th className="px-3 py-2.5 font-semibold w-10">Arr.</th>
                <th className="px-3 py-2.5 font-semibold">ID Único .GIM (0–255)</th>
                <th className="px-3 py-2.5 font-semibold">Slot Personaje</th>
                <th className="px-3 py-2.5 font-semibold">Archivo Modelo .GIM</th>
                <th className="px-3 py-2.5 font-semibold">Ruta en /PSP_GAME/DLC/</th>
                <th className="px-3 py-2.5 font-semibold">Estado / Cabecera</th>
                <th className="px-3 py-2.5 text-right font-semibold">Vincular / Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {pageItems.map((item) => {
                const isDup = duplicateGimIds.has(item.gimId);
                const isDropActive = dragOverSlotId === item.slotId;
                const charName = charNameBySlot.get(item.slotId) ?? `Guerrero #${item.slotId}`;

                return (
                  <tr
                    key={item.slotId}
                    draggable
                    onDragStart={(e) => {
                      e.dataTransfer.setData(
                        'application/x-dbz-gim-resource',
                        JSON.stringify({ kind: 'ROW_SWAP', sourceSlotId: item.slotId })
                      );
                    }}
                    onDragOver={(e) => {
                      e.preventDefault();
                      setDragOverSlotId(item.slotId);
                    }}
                    onDragLeave={() => {
                      if (dragOverSlotId === item.slotId) setDragOverSlotId(null);
                    }}
                    onDrop={(e) => void handleRowDrop(e, item.slotId)}
                    className={`transition-colors ${
                      isDropActive
                        ? 'bg-blue-100/80 ring-2 ring-inset ring-blue-500 dark:bg-blue-900/40'
                        : isDup
                        ? 'bg-red-50/70 dark:bg-red-950/20'
                        : 'hover:bg-slate-50/70 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <td
                      className="px-3 py-2 text-slate-400 cursor-grab active:cursor-grabbing"
                      title="Arrastra esta fila sobre otra para intercambiar sus modelos .GIM"
                    >
                      <GripVertical className="h-4 w-4" />
                    </td>

                    <td className="px-3 py-2 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          min={0}
                          max={255}
                          value={item.gimId}
                          onChange={(e) =>
                            handleChangeGimId(item.slotId, Number(e.target.value))
                          }
                          aria-label={`ID .GIM para ${charName}`}
                          className={`w-16 rounded border px-2 py-1 font-mono text-xs font-bold tabular-nums focus:outline-none ${
                            isDup
                              ? 'border-red-500 bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300'
                              : 'border-slate-300 bg-white text-slate-900 focus:border-blue-500 dark:border-slate-700 dark:bg-slate-950 dark:text-white'
                          }`}
                        />
                        <span className="font-mono text-[11px] font-semibold text-blue-600 dark:text-blue-400">
                          {formatGimHex(item.gimId)}
                        </span>
                      </div>
                    </td>

                    <td className="px-3 py-2 whitespace-nowrap">
                      <div className="font-mono text-[11px] text-slate-500">
                        Slot #{String(item.slotId).padStart(3, '0')}
                      </div>
                      <div className="font-semibold text-slate-900 dark:text-white">
                        {charName}
                      </div>
                    </td>

                    <td className="px-3 py-2 min-w-[170px]">
                      <input
                        type="text"
                        value={item.fileName}
                        onChange={(e) => {
                          const fname = e.target.value;
                          const next = assignments.map((a) =>
                            a.slotId === item.slotId
                              ? {
                                  ...a,
                                  fileName: fname,
                                  dlcPath: `disc0:/PSP_GAME/DLC/CHIBIS/${fname}`,
                                }
                              : a
                          );
                          onChangeAssignments(next);
                        }}
                        className="w-full rounded border border-slate-200 bg-slate-50 px-2 py-1 font-mono text-[11px] text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                      />
                    </td>

                    <td className="px-3 py-2 min-w-[230px]">
                      <input
                        type="text"
                        value={item.dlcPath}
                        onChange={(e) => {
                          const p = e.target.value;
                          const next = assignments.map((a) =>
                            a.slotId === item.slotId ? { ...a, dlcPath: p } : a
                          );
                          onChangeAssignments(next);
                        }}
                        className="w-full rounded border border-slate-200 bg-slate-50 px-2 py-1 font-mono text-[11px] text-slate-700 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300"
                      />
                    </td>

                    <td className="px-3 py-2 whitespace-nowrap font-mono text-[11px]">
                      {isDup ? (
                        <span className="inline-flex items-center gap-1 font-bold text-red-600 dark:text-red-400">
                          <AlertTriangle className="h-3.5 w-3.5" />
                          ID Duplicado
                        </span>
                      ) : item.sourceKind === 'DRAG_DROP' ? (
                        <span className="text-emerald-700 dark:text-emerald-400">
                          {item.hasPspGimMagic ? 'MIG.00.1PSP ✓' : 'Vinculado'} ·{' '}
                          {(item.fileSizeBytes / 1024).toFixed(1)} KB
                        </span>
                      ) : item.sourceKind === 'ISO_INTERNAL' ? (
                        <span className="text-blue-600 dark:text-blue-400">
                          ISO Interno · {(item.fileSizeBytes / 1024).toFixed(1)} KB
                        </span>
                      ) : (
                        <span className="text-slate-400">Suelta .GIM aquí</span>
                      )}
                    </td>

                    <td className="px-3 py-2 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            rowUploadSlotRef.current = item.slotId;
                            rowInputRef.current?.click();
                          }}
                          className="inline-flex items-center gap-1 rounded border border-slate-300 bg-white px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 cursor-pointer"
                          title="Seleccionar archivo .GIM para este slot"
                        >
                          <Upload className="h-3 w-3" />
                          .GIM
                        </button>

                        {item.customBytes && onInspectAssetBytes && (
                          <button
                            type="button"
                            onClick={() =>
                              onInspectAssetBytes(item.customBytes!, item.fileName)
                            }
                            className="inline-flex items-center gap-1 rounded bg-slate-900 px-2 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
                            title="Inspeccionar bytes .GIM en HxD"
                          >
                            <Binary className="h-3 w-3" />
                            HxD
                          </button>
                        )}

                        {item.sourceKind !== 'DEFAULT_TEMPLATE' && (
                          <button
                            type="button"
                            onClick={() => {
                              const idStr = String(item.slotId).padStart(3, '0');
                              const defName = `CHIBI${idStr}.GIM`;
                              const next = assignments.map((a) =>
                                a.slotId === item.slotId
                                  ? {
                                      ...a,
                                      fileName: defName,
                                      dlcPath: `disc0:/PSP_GAME/DLC/CHIBIS/${defName}`,
                                      sourceKind: 'DEFAULT_TEMPLATE' as const,
                                      hasPspGimMagic: false,
                                      fileSizeBytes: 0,
                                      customBytes: undefined,
                                    }
                                  : a
                              );
                              onChangeAssignments(next);
                            }}
                            className="inline-flex items-center rounded border border-slate-200 p-1 text-slate-500 hover:text-red-600 dark:border-slate-700 cursor-pointer"
                            title="Restaurar plantilla base"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-200 p-3.5 text-xs text-slate-600 dark:border-slate-800 dark:text-slate-400">
          <span>
            Mostrando {pageItems.length} de {filteredAssignments.length} modelos .GIM (Página {clampedPage + 1}/{totalPages})
          </span>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              disabled={clampedPage === 0}
              onClick={() => setPageIdx((p) => Math.max(0, p - 1))}
              className="rounded border border-slate-300 px-2.5 py-1 disabled:opacity-40 dark:border-slate-700 cursor-pointer"
            >
              Anterior
            </button>
            <button
              type="button"
              disabled={clampedPage >= totalPages - 1}
              onClick={() => setPageIdx((p) => Math.min(totalPages - 1, p + 1))}
              className="rounded border border-slate-300 px-2.5 py-1 disabled:opacity-40 dark:border-slate-700 cursor-pointer"
            >
              Siguiente
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
