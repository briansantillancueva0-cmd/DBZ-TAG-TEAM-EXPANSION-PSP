import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Archive,
  Binary,
  Download,
  FileText,
  Layers,
  Map as MapIcon,
  Music,
  Navigation,
  Search,
  Upload,
  User,
} from 'lucide-react';
import {
  buildGameAssetReport,
  detectAssetMagicSignature,
  formatAssetReportCsv,
  formatAssetReportMarkdown,
  formatAssetReportText,
} from '../lib/assetClassifier';
import { extractIsoFileBytes } from '../lib/iso9660';
import {
  formatPackScanCsv,
  formatPackScanText,
  scanPackfileBlob,
  type PackEmbeddedEntry,
  type PackScanResult,
} from '../lib/packScanner';
import type { EbootAnalysis, GameAssetCategory, GameAssetItem, IsoFileEntry } from '../lib/types';
import type { InjectedIsoFileInput } from '../lib/isoExpander';
import { DlcVerifierPanel } from './DlcVerifierPanel';
import { IsoExpanderPanel } from './IsoExpanderPanel';
import { Pck1UnpackerPanel } from './Pck1UnpackerPanel';
import { RamExpanderPanel } from './RamExpanderPanel';
import { TextTranslatorPanel } from './TextTranslatorPanel';

export type AssetSubTab =
  | 'inventory'
  | 'pck1'
  | 'iso_expand'
  | 'ram'
  | 'translator'
  | 'dlc';

interface AssetReportViewProps {
  analysis: EbootAnalysis;
  isoFileBlob: Blob | null;
  standalonePackBlob?: Blob | null;
  onInspectEbootOffset: (offset: number) => void;
  onInspectIsoAssetBytes: (bytes: Uint8Array, assetPath: string) => void;
  onApplyModifiedBytes?: (newBytes: Uint8Array) => void;
  onLoadGeneratedIso?: (blob: Blob, fileName: string) => void;
  initialSubTab?: AssetSubTab;
}

type SourceFilter = 'ALL' | 'ISO_FILE' | 'EBOOT';

function hex(val: number | null, width = 8): string {
  if (val === null || Number.isNaN(val)) return '—';
  return `0x${(val >>> 0).toString(16).toUpperCase().padStart(width, '0')}`;
}

function downloadText(content: string, filename: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

const CATEGORY_ICON: Record<GameAssetCategory, React.ReactNode> = {
  CHARACTERS: <User className="h-4 w-4" />,
  MAPS: <MapIcon className="h-4 w-4" />,
  TEXTURES: <Layers className="h-4 w-4" />,
  MUSIC: <Music className="h-4 w-4" />,
  MINIMAPS: <Navigation className="h-4 w-4" />,
};

export const AssetReportView: React.FC<AssetReportViewProps> = ({
  analysis,
  isoFileBlob,
  standalonePackBlob = null,
  onInspectEbootOffset,
  onInspectIsoAssetBytes,
  onApplyModifiedBytes,
  onLoadGeneratedIso,
  initialSubTab = 'inventory',
}) => {
  const [subTab, setSubTab] = useState<AssetSubTab>(initialSubTab);
  const [queuedIsoFiles, setQueuedIsoFiles] = useState<InjectedIsoFileInput[]>([]);
  const report = useMemo(() => buildGameAssetReport(analysis), [analysis]);
  const [selectedCat, setSelectedCat] = useState<'ALL' | GameAssetCategory>('ALL');
  const [sourceFilter, setSourceFilter] = useState<SourceFilter>('ALL');
  const [query, setQuery] = useState('');
  const [inspectedSignature, setInspectedSignature] = useState<{
    name: string;
    signature: string;
    size: number;
  } | null>(null);

  const [packScan, setPackScan] = useState<PackScanResult | null>(null);
  const [packScanning, setPackScanning] = useState(false);
  const [packProgress, setPackProgress] = useState(0);
  const [activePackBlob, setActivePackBlob] = useState<Blob | null>(null);
  const [packQuery, setPackQuery] = useState('');
  const packInputRef = useRef<HTMLInputElement | null>(null);

  const isoPackCandidates = useMemo(() => {
    if (!analysis.isoInfo) return [];
    return analysis.isoInfo.files.filter(
      (f) =>
        !f.isDirectory &&
        /(packfile|pack|data|archive|resource|game)\.(bin|pac|cpk|afs|arc|pak|dat)$/i.test(f.name)
    );
  }, [analysis.isoInfo]);

  const filteredItems = useMemo(() => {
    const q = query.trim().toLowerCase();
    return report.items.filter((item) => {
      if (selectedCat !== 'ALL' && item.category !== selectedCat) return false;
      if (sourceFilter === 'ISO_FILE' && item.source !== 'ISO_FILE') return false;
      if (sourceFilter === 'EBOOT' && item.source === 'ISO_FILE') return false;
      if (!q) return true;
      return (
        item.name.toLowerCase().includes(q) ||
        item.pathOrSymbol.toLowerCase().includes(q) ||
        item.extension.toLowerCase().includes(q) ||
        item.notes.toLowerCase().includes(q)
      );
    });
  }, [report.items, selectedCat, sourceFilter, query]);

  const safeSlug = (analysis.sfoInfo?.discId || analysis.sourceName)
    .replace(/[^a-zA-Z0-9_-]+/g, '_')
    .slice(0, 32);

  const handleInspectIsoItem = async (item: GameAssetItem, openInHxd: boolean) => {
    if (!isoFileBlob || !analysis.isoInfo || !item.isoEntryPath) return;
    const entry = analysis.isoInfo.files.find(
      (f) => !f.isDirectory && f.path === item.isoEntryPath
    );
    if (!entry) return;

    const bytes = await extractIsoFileBytes(isoFileBlob, entry);
    const sig = detectAssetMagicSignature(bytes);
    setInspectedSignature({ name: entry.path, signature: sig, size: bytes.length });
    if (openInHxd) {
      onInspectIsoAssetBytes(bytes, entry.path);
    }
  };

  const runPackScan = async (blob: Blob, name: string) => {
    setPackScanning(true);
    setPackProgress(0);
    setActivePackBlob(blob);
    try {
      const res = await scanPackfileBlob(blob, name, (pct) => setPackProgress(pct));
      setPackScan(res);
    } finally {
      setPackScanning(false);
    }
  };

  useEffect(() => {
    if (standalonePackBlob) {
      void runPackScan(standalonePackBlob, analysis.sourceName);
    }
  }, [standalonePackBlob, analysis.sourceName]);

  const filteredPackEntries = useMemo(() => {
    if (!packScan) return [];
    const q = packQuery.trim().toLowerCase();
    return packScan.entries.filter((e) => {
      if (selectedCat !== 'ALL' && e.category !== selectedCat) return false;
      if (!q) return true;
      return (
        e.label.toLowerCase().includes(q) ||
        e.signature.toLowerCase().includes(q) ||
        e.categoryLabel.toLowerCase().includes(q) ||
        e.extension.toLowerCase().includes(q) ||
        e.sourceMethod.toLowerCase().includes(q)
      );
    });
  }, [packScan, packQuery, selectedCat]);

  const handleScanIsoPackEntry = (entry: IsoFileEntry) => {
    if (!isoFileBlob) return;
    const sliced = isoFileBlob.slice(entry.byteOffset, entry.byteOffset + entry.size);
    void runPackScan(sliced, entry.path);
  };

  const handleExternalPackUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      void runPackScan(file, file.name);
    }
    e.target.value = '';
  };

  const handleOpenPackChunkInHxd = async (entry: PackEmbeddedEntry) => {
    if (!activePackBlob) return;
    const len = Math.min(entry.estimatedSize, 4 * 1024 * 1024);
    const bytes = new Uint8Array(
      await activePackBlob.slice(entry.offset, Math.min(activePackBlob.size, entry.offset + len)).arrayBuffer()
    );
    onInspectIsoAssetBytes(bytes, `${packScan?.packName || 'PACKFILE.BIN'} @ 0x${hex(entry.offset, 6).slice(2)}`);
  };

  const handleDownloadPackChunk = async (entry: PackEmbeddedEntry) => {
    if (!activePackBlob) return;
    const len = Math.min(entry.estimatedSize, 32 * 1024 * 1024);
    const slice = activePackBlob.slice(entry.offset, Math.min(activePackBlob.size, entry.offset + len));
    const url = URL.createObjectURL(slice);
    const a = document.createElement('a');
    a.href = url;
    a.download = `PACK_0x${(entry.offset >>> 0).toString(16).toUpperCase().padStart(6, '0')}.${entry.extension.toLowerCase()}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const dlcFileCount = useMemo(
    () =>
      analysis.isoInfo?.files.filter(
        (f) => !f.isDirectory && f.path.toUpperCase().startsWith('/PSP_GAME/DLC/')
      ).length ?? 0,
    [analysis.isoInfo]
  );

  return (
    <div className="space-y-6">
      <input
        ref={packInputRef}
        type="file"
        onChange={handleExternalPackUpload}
        className="hidden"
        accept=".bin,.pac,.cpk,.afs,.arc,.pak,.dat,*/*"
      />

      {/* Sub-view Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex flex-wrap items-center gap-1 rounded-lg bg-slate-200/70 p-1 dark:bg-slate-800">
          <button
            type="button"
            onClick={() => setSubTab('inventory')}
            className={`min-h-[38px] rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              subTab === 'inventory'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
            }`}
          >
            Inventario y PACKFILE.BIN ({report.totalCount})
          </button>
          <button
            type="button"
            onClick={() => setSubTab('pck1')}
            className={`min-h-[38px] rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              subTab === 'pck1'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
            }`}
          >
            Descomprimidor PCK1 y Música AT3
          </button>
          <button
            type="button"
            onClick={() => setSubTab('iso_expand')}
            className={`min-h-[38px] rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              subTab === 'iso_expand'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
            }`}
          >
            Expansión ISO y Subcarpetas{queuedIsoFiles.length > 0 ? ` (${queuedIsoFiles.length})` : ''}
          </button>
          <button
            type="button"
            onClick={() => setSubTab('ram')}
            className={`min-h-[38px] rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              subTab === 'ram'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
            }`}
          >
            Memoria RAM EBOOT
          </button>
          <button
            type="button"
            onClick={() => setSubTab('translator')}
            className={`min-h-[38px] rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              subTab === 'translator'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
            }`}
          >
            Traductor Idiomas
          </button>
          <button
            type="button"
            onClick={() => setSubTab('dlc')}
            className={`min-h-[38px] rounded-md px-3.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              subTab === 'dlc'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
            }`}
          >
            Auditoría DLC / Límites MIPS ({dlcFileCount} DLC)
          </button>
        </div>
      </div>

      {subTab === 'dlc' ? (
        <DlcVerifierPanel
          analysis={analysis}
          isoFileBlob={isoFileBlob}
          onJumpToHex={onInspectEbootOffset}
        />
      ) : subTab === 'ram' ? (
        <RamExpanderPanel
          analysis={analysis}
          onJumpToHex={onInspectEbootOffset}
          onApplyModifiedBytes={onApplyModifiedBytes}
          onSendPatchedToIso={(items) => {
            setQueuedIsoFiles((prev) => {
              const map = new Map(prev.map((x) => [x.path, x]));
              for (const it of items) map.set(it.path, it);
              return Array.from(map.values());
            });
            setSubTab('iso_expand');
          }}
        />
      ) : subTab === 'translator' ? (
        <TextTranslatorPanel
          analysis={analysis}
          onJumpToHex={onInspectEbootOffset}
          onApplyModifiedBytes={(newBytes) => onApplyModifiedBytes?.(newBytes)}
          onSendPatchedToIso={(items) => {
            setQueuedIsoFiles((prev) => {
              const map = new Map(prev.map((x) => [x.path, x]));
              for (const it of items) map.set(it.path, it);
              return Array.from(map.values());
            });
            setSubTab('iso_expand');
          }}
        />
      ) : subTab === 'pck1' ? (
        <Pck1UnpackerPanel
          analysis={analysis}
          isoFileBlob={isoFileBlob}
          standalonePackBlob={standalonePackBlob}
          onInspectOffsetBytes={onInspectIsoAssetBytes}
          onSendToIsoExpander={(items) => {
            setQueuedIsoFiles((prev) => {
              const map = new Map(prev.map((x) => [x.path, x]));
              for (const it of items) map.set(it.path, it);
              return Array.from(map.values());
            });
            setSubTab('iso_expand');
          }}
        />
      ) : subTab === 'iso_expand' ? (
        <IsoExpanderPanel
          analysis={analysis}
          isoFileBlob={isoFileBlob}
          queuedFiles={queuedIsoFiles}
          onUpdateQueuedFiles={setQueuedIsoFiles}
          onLoadGeneratedIso={onLoadGeneratedIso}
        />
      ) : (
        <>
      {/* Header & Export Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div>
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
            Informe de Personajes, Mapas, Texturas, Música y Minimapas
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Clasificación automática de archivos en ISO 9660 (<span className="font-mono">USRDIR</span>) y referencias/rutas detectadas dentro de <span className="font-mono">EBOOT.BIN</span>.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() =>
              downloadText(
                formatAssetReportText(report, analysis.sourceName),
                `ACTIVOS_${safeSlug}.txt`,
                'text/plain;charset=utf-8'
              )
            }
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            Informe .TXT
          </button>
          <button
            type="button"
            onClick={() =>
              downloadText(
                formatAssetReportMarkdown(report, analysis.sourceName),
                `ACTIVOS_${safeSlug}.md`,
                'text/markdown;charset=utf-8'
              )
            }
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <FileText className="h-3.5 w-3.5" />
            .MD
          </button>
          <button
            type="button"
            onClick={() =>
              downloadText(
                formatAssetReportCsv(report),
                `ACTIVOS_${safeSlug}.csv`,
                'text/csv;charset=utf-8'
              )
            }
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Exportar .CSV
          </button>
        </div>
      </div>

      {/* 5 Category Summary Cards */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {report.summaries.map((sum) => {
          const isActive = selectedCat === sum.category;
          return (
            <button
              key={sum.category}
              type="button"
              onClick={() => setSelectedCat(isActive ? 'ALL' : sum.category)}
              className={`flex flex-col justify-between rounded-xl border p-4 text-left transition-colors cursor-pointer ${
                isActive
                  ? 'border-blue-600 bg-blue-50/70 dark:border-blue-500 dark:bg-blue-950/30'
                  : 'border-slate-200 bg-white hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-slate-900 dark:text-white">
                  {sum.label}
                </span>
                <span className="text-slate-400 dark:text-slate-500">
                  {CATEGORY_ICON[sum.category]}
                </span>
              </div>
              <div className="mt-3 flex items-baseline justify-between gap-2">
                <span className="font-mono text-2xl font-bold text-slate-900 tabular-nums dark:text-white">
                  {sum.count}
                </span>
                <span className="font-mono text-[11px] text-slate-500 tabular-nums dark:text-slate-400">
                  {sum.isoFileCount} ISO · {sum.ebootRefCount} EBOOT
                </span>
              </div>
              <p className="mt-2 line-clamp-2 text-[11px] leading-snug text-slate-500 dark:text-slate-400">
                {sum.description}
              </p>
            </button>
          );
        })}
      </div>

      {/* Escáner de PACKFILE.BIN y Contenedores */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
              <Archive className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              Escáner de PACKFILE.BIN y Contenedores (.BIN / .CPK / .AFS)
            </h3>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Explora archivos empaquetados dentro de <span className="font-mono">PACKFILE.BIN</span> detectando tabla AFS, nombres internos y firmas <span className="font-mono">OMG</span> (Personajes), <span className="font-mono">MIG/TIM2</span> (Texturas/Minimapas) y <span className="font-mono">RIFF/VAG/PSMF</span> (Música/Video).
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {isoPackCandidates.map((cand) => (
              <button
                key={cand.path}
                type="button"
                disabled={packScanning}
                onClick={() => handleScanIsoPackEntry(cand)}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Search className="h-3.5 w-3.5" />
                Escanear {cand.name} ({(cand.size / 1024).toFixed(0)} KB)
              </button>
            ))}
            {!isoFileBlob && (standalonePackBlob || analysis.rawBytes.length > 0) && (
              <button
                type="button"
                disabled={packScanning}
                onClick={() =>
                  void runPackScan(
                    standalonePackBlob ?? new Blob([new Uint8Array(analysis.rawBytes).buffer]),
                    analysis.sourceName
                  )
                }
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Search className="h-3.5 w-3.5" />
                Escanear {analysis.sourceName}
              </button>
            )}
            <button
              type="button"
              disabled={packScanning}
              onClick={() => packInputRef.current?.click()}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Upload className="h-3.5 w-3.5" />
              Cargar PACKFILE.BIN externo
            </button>
          </div>
        </div>

        {packScanning && (
          <div className="mt-4 text-xs text-blue-600 dark:text-blue-400 tabular-nums">
            Escaneando bloques del contenedor: {packProgress}%…
          </div>
        )}

        {packScan && (
          <div className="mt-4 space-y-3 border-t border-slate-100 pt-4 dark:border-slate-800">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="text-slate-700 dark:text-slate-300">
                <strong className="font-mono text-slate-900 dark:text-white">{packScan.packName}</strong> ·{' '}
                {packScan.containerType} · <strong className="tabular-nums">{packScan.entries.length}</strong> hallazgos internos
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-[11px] text-slate-500 tabular-nums">
                  Personajes: {packScan.categoryCounts.CHARACTERS} · Mapas: {packScan.categoryCounts.MAPS} · Texturas: {packScan.categoryCounts.TEXTURES} · Música: {packScan.categoryCounts.MUSIC} · Minimapas: {packScan.categoryCounts.MINIMAPS}
                </span>
                {packScan.entries.length > 0 && (
                  <>
                    <button
                      type="button"
                      onClick={() =>
                        downloadText(
                          formatPackScanText(packScan),
                          `PACKFILE_${safeSlug}.txt`,
                          'text/plain;charset=utf-8'
                        )
                      }
                      className="inline-flex min-h-[32px] items-center gap-1 rounded border border-slate-300 px-2.5 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      <Download className="h-3 w-3" />
                      Índice .TXT
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        downloadText(
                          formatPackScanCsv(packScan),
                          `PACKFILE_${safeSlug}.csv`,
                          'text/csv;charset=utf-8'
                        )
                      }
                      className="inline-flex min-h-[32px] items-center rounded border border-slate-300 px-2.5 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      .CSV
                    </button>
                  </>
                )}
              </div>
            </div>

            {packScan.entries.length > 0 && (
              <div className="relative max-w-md">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={packQuery}
                  onChange={(e) => setPackQuery(e.target.value)}
                  placeholder="Filtrar entradas internas (OMG, MIG, TIM2, RIFF, ZLIB, TOC_PTR)..."
                  className="min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 pl-8 pr-3 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>
            )}

            {filteredPackEntries.length > 0 ? (
              <div className="max-h-72 overflow-y-auto overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
                <table className="w-full border-collapse text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                      <th className="px-3 py-2 font-semibold">#</th>
                      <th className="px-3 py-2 font-semibold">Categoría</th>
                      <th className="px-3 py-2 font-semibold">Firma / Método</th>
                      <th className="px-3 py-2 font-semibold">Offset PACK</th>
                      <th className="px-3 py-2 text-right font-semibold">Tamaño est.</th>
                      <th className="px-3 py-2 font-semibold">Detalle</th>
                      <th className="px-3 py-2 text-right font-semibold">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredPackEntries.slice(0, 250).map((entry) => (
                      <tr key={`${entry.index}-${entry.offset}`} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                        <td className="px-3 py-2 font-mono text-slate-400 tabular-nums">{String(entry.index).padStart(3, '0')}</td>
                        <td className="px-3 py-2 whitespace-nowrap font-medium text-slate-800 dark:text-slate-200">
                          {entry.categoryLabel}
                        </td>
                        <td className="px-3 py-2 font-mono text-[11px] text-slate-500">
                          {entry.signature} · {entry.sourceMethod}
                        </td>
                        <td className="px-3 py-2 font-mono font-semibold text-blue-600 tabular-nums dark:text-blue-400">
                          {hex(entry.offset, 6)}
                        </td>
                        <td className="px-3 py-2 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                          {entry.estimatedSize.toLocaleString('es-ES')} B
                        </td>
                        <td className="max-w-xs truncate px-3 py-2 font-mono text-slate-900 dark:text-slate-100">
                          {entry.label}
                        </td>
                        <td className="px-3 py-2 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => void handleOpenPackChunkInHxd(entry)}
                              className="inline-flex min-h-[30px] items-center gap-1 rounded bg-slate-900 px-2 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
                            >
                              <Binary className="h-3 w-3" />
                              HxD
                            </button>
                            <button
                              type="button"
                              onClick={() => void handleDownloadPackChunk(entry)}
                              className="inline-flex min-h-[30px] items-center rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                            >
                              Extraer
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-xs text-slate-500">
                No se detectaron cabeceras estándar sin comprimir dentro de {packScan.packName} (puede estar comprimido con LZSS/Zlib o cifrado).
              </p>
            )}
          </div>
        )}
      </section>

      {/* Search & Source Filter Bar */}
      <div className="flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 lg:flex-row lg:items-center lg:justify-between">
        <div className="relative flex-1 max-w-xl">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filtrar por nombre, extensión (.GMO, .GIM, .AT3, .MAP), ruta o notas..."
            className="min-h-[44px] w-full rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-sm text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
            {(
              [
                { key: 'ALL', label: 'Todos' },
                { key: 'ISO_FILE', label: 'Archivos ISO' },
                { key: 'EBOOT', label: 'Referencias EBOOT' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.key}
                type="button"
                onClick={() => setSourceFilter(tab.key)}
                className={`min-h-[36px] rounded-md px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  sourceFilter === tab.key
                    ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {selectedCat !== 'ALL' && (
            <button
              type="button"
              onClick={() => setSelectedCat('ALL')}
              className="min-h-[36px] rounded-lg border border-slate-300 px-3 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
            >
              Ver las 5 categorías
            </button>
          )}
        </div>
      </div>

      {inspectedSignature && (
        <div className="rounded-xl border border-blue-200 bg-blue-50/60 p-4 text-xs text-slate-800 dark:border-blue-900/50 dark:bg-blue-950/30 dark:text-slate-200">
          <span className="font-semibold">Firma detectada en {inspectedSignature.name}:</span>{' '}
          <span className="font-mono">{inspectedSignature.signature}</span> ·{' '}
          <span className="font-mono tabular-nums">
            {inspectedSignature.size.toLocaleString('es-ES')} bytes
          </span>
        </div>
      )}

      {/* Asset Table */}
      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
          <span className="tabular-nums">
            Mostrando {filteredItems.length} de {report.totalCount} recursos clasificados
          </span>
          <span>
            Nota: si el juego empaqueta recursos en un contenedor único (.CPK / .AFS / .DAT), inspecciona ese contenedor o las rutas en EBOOT.BIN.
          </span>
        </div>

        {filteredItems.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500 dark:text-slate-400">
            No se encontraron recursos con el filtro seleccionado.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                  <th className="px-4 py-2.5 font-semibold">#</th>
                  <th className="px-4 py-2.5 font-semibold">Categoría</th>
                  <th className="px-4 py-2.5 font-semibold">Origen</th>
                  <th className="px-4 py-2.5 font-semibold">Recurso / Ruta</th>
                  <th className="px-4 py-2.5 font-semibold">Offset</th>
                  <th className="px-4 py-2.5 font-semibold">RAM PSP</th>
                  <th className="px-4 py-2.5 text-right font-semibold">Tamaño</th>
                  <th className="px-4 py-2.5 text-right font-semibold">Inspección</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredItems.slice(0, 300).map((item) => (
                  <tr
                    key={`${item.index}-${item.pathOrSymbol}`}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40"
                  >
                    <td className="px-4 py-2.5 font-mono text-slate-400 tabular-nums">
                      {String(item.index).padStart(3, '0')}
                    </td>
                    <td className="px-4 py-2.5 whitespace-nowrap font-medium text-slate-800 dark:text-slate-200">
                      {item.categoryLabel}
                    </td>
                    <td className="px-4 py-2.5 whitespace-nowrap font-mono text-[11px] text-slate-500 dark:text-slate-400">
                      {item.source === 'ISO_FILE'
                        ? 'ISO 9660'
                        : item.source === 'EBOOT_LIB'
                        ? 'SDK NID'
                        : 'EBOOT.BIN'}
                    </td>
                    <td className="max-w-md px-4 py-2.5">
                      <div className="truncate font-mono text-slate-900 dark:text-slate-100" title={item.pathOrSymbol}>
                        {item.pathOrSymbol}
                      </div>
                      <div className="truncate text-[11px] text-slate-500 dark:text-slate-400">
                        {item.extension} · {item.notes}
                      </div>
                    </td>
                    <td className="px-4 py-2.5 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      {item.fileOffset !== null ? hex(item.fileOffset, 6) : '—'}
                    </td>
                    <td className="px-4 py-2.5 font-mono font-semibold tabular-nums text-blue-600 dark:text-blue-400">
                      {item.ramAddress !== null ? hex(item.ramAddress, 8) : '—'}
                    </td>
                    <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      {item.sizeBytes !== null ? `${item.sizeBytes.toLocaleString('es-ES')} B` : 'Ref'}
                    </td>
                    <td className="px-4 py-2.5 text-right whitespace-nowrap">
                      {item.source === 'EBOOT_REF' && item.fileOffset !== null ? (
                        <button
                          type="button"
                          onClick={() => onInspectEbootOffset(item.fileOffset!)}
                          className="inline-flex min-h-[32px] items-center gap-1 rounded bg-slate-900 px-2.5 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
                        >
                          <Binary className="h-3 w-3" />
                          HxD
                        </button>
                      ) : item.source === 'ISO_FILE' && isoFileBlob ? (
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => void handleInspectIsoItem(item, false)}
                            className="inline-flex min-h-[32px] items-center rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                          >
                            Firma
                          </button>
                          <button
                            type="button"
                            onClick={() => void handleInspectIsoItem(item, true)}
                            className="inline-flex min-h-[32px] items-center gap-1 rounded bg-slate-900 px-2.5 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
                          >
                            <Binary className="h-3 w-3" />
                            HxD
                          </button>
                        </div>
                      ) : (
                        <span className="text-[11px] text-slate-400">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
        </>
      )}
    </div>
  );
};
