import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Code2,
  Copy,
  Cpu,
  Download,
  FileCode,
  Gamepad2,
  HardDrive,
  MemoryStick,
  Music,
  Play,
  RotateCcw,
  Save,
  ShieldAlert,
  Sparkles,
  StepForward,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  buildDbzCwCheatAndPpssppIni,
  buildDbzSave256DataBin,
  DBZ_TAG_TEAM_CANONICAL_MUSIC,
  DBZ_TAG_TEAM_CANONICAL_NAMES,
} from '../lib/dbzTagTeamExpander';
import { extractIsoFileBytes } from '../lib/iso9660';
import {
  buildPspEmulatorSourceBundle,
  buildPspEmulatorSourceZip,
  MIPS_REG_NAMES,
  PspAllegrexVm,
  type MipsVmSnapshot,
} from '../lib/pspAllegrexVm';
import {
  buildPpsspp256MbUnifiedDiff,
  calculateDlcRamBudget,
  type RamTargetProfile,
} from '../lib/ramExpander';
import type { EbootAnalysis } from '../lib/types';

export type EmulatorRamHardwareMode = '32MB_PSP1000' | '64MB_PSP2000' | '128MB_PPSSPP' | '256MB_MOD_NATIVE';
type EmulatorSubMode = 'native_port' | 'virtual_ram' | 'cpu_source';
type PspGameScreen = 'BOOT' | 'OOM_CRASH' | 'LOBBY' | 'MAPS' | 'BATTLE';

export interface EmulatorModConfig {
  ramProfile: RamTargetProfile;
  charCount: number;
  mapCount: number;
  lobbyCount: number;
  chibiCount: number;
  musicTrackCount: number;
  gameId: string;
  ebootPatched: boolean;
  freeBattlePreset?: string;
  customCharNames?: string[];
  customMapNames?: string[];
  customMusicTitles?: string[];
  dlcAssetPaths?: string[];
}

interface PspTagTeamEmulatorProps {
  analysis: EbootAnalysis | null;
  isoFileBlob: Blob | null;
  initialModConfig?: EmulatorModConfig | null;
  onOpenDbzExpander?: () => void;
}

interface PersistentSave256 {
  gameId: string;
  zeni: number;
  wins: number;
  unlockedChars: number;
  unlockedMaps: number;
  p1Slot: number;
  p1Color: number;
  p2Slot: number;
  p2Color: number;
  cpu1Slot: number;
  cpu2Slot: number;
  selectedMap: number;
  selectedBgm: number;
  lastSavedAt: string;
}

interface FighterRuntime {
  slotId: number;
  colorIdx: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: 1 | -1;
  hp: number;
  maxHp: number;
  ki: number;
  dashTimer: number;
  attackTimer: number;
}

interface KiProjectile {
  x: number;
  y: number;
  vx: number;
  vy: number;
  ownerTeam: 'PLAYER' | 'CPU';
  color: string;
}

const SAVE_STORAGE_KEY = 'psp_dbz_tt_save_256_v1';

const COSTUME_PALETTES = [
  { name: 'C1 Clásico', primary: '#f97316', secondary: '#1d4ed8', aura: '#facc15' },
  { name: 'C2 Oscuro', primary: '#1e293b', secondary: '#991b1b', aura: '#ef4444' },
  { name: 'C3 Torneos', primary: '#dc2626', secondary: '#fbbf24', aura: '#fb923c' },
  { name: 'C4 Majin', primary: '#7e22ce', secondary: '#f8fafc', aura: '#c084fc' },
  { name: 'C5 Blue/God', primary: '#0284c7', secondary: '#172554', aura: '#38bdf8' },
  { name: 'C6 Ultra', primary: '#cbd5e1', secondary: '#0f172a', aura: '#e2e8f0' },
  { name: 'C7 Emerald', primary: '#059669', secondary: '#064e3b', aura: '#34d399' },
  { name: 'C8 Dorado', primary: '#eab308', secondary: '#422006', aura: '#fef08a' },
];

const ARCHETYPE_NAMES = [
  'Goku', 'Vegeta', 'Gohan', 'Piccolo', 'Trunks', 'Freezer', 'Cell', 'Buu',
  'Broly', 'Bardock', 'Vegito', 'Gogeta', 'Gotenks', 'Krillin', 'Ten', 'Android 18',
];

const MAP_THEMES = [
  { name: 'Yermo', skyTop: '#0f172a', skyBot: '#c2410c', ground: '#78350f', accent: '#fb923c' },
  { name: 'Zona rocosa', skyTop: '#451a03', skyBot: '#d97706', ground: '#92400e', accent: '#fcd34d' },
  { name: 'Isla', skyTop: '#0284c7', skyBot: '#7dd3fc', ground: '#16a34a', accent: '#facc15' },
  { name: 'Ciudad en ruinas', skyTop: '#18181b', skyBot: '#7f1d1d', ground: '#3f3f46', accent: '#f87171' },
  { name: 'Planeta Namek', skyTop: '#064e3b', skyBot: '#34d399', ground: '#047857', accent: '#a7f3d0' },
  { name: 'Planeta (Aldea)', skyTop: '#047857', skyBot: '#6ee7b7', ground: '#0f766e', accent: '#fde68a' },
  { name: 'Planeta destruido', skyTop: '#450a0a', skyBot: '#b91c1c', ground: '#1c1917', accent: '#fb7185' },
  { name: 'Carrera montañosa', skyTop: '#7c2d12', skyBot: '#fb923c', ground: '#713f12', accent: '#fde047' },
  { name: 'Estadio Juegos de Cell', skyTop: '#1d4ed8', skyBot: '#93c5fd', ground: '#cbd5e1', accent: '#f59e0b' },
  { name: 'Atalaya de Kami', skyTop: '#1e1b4b', skyBot: '#38bdf8', ground: '#f8fafc', accent: '#facc15' },
  { name: 'Aleatorio', skyTop: '#1e3a8a', skyBot: '#60a5fa', ground: '#1d4ed8', accent: '#facc15' },
  { name: 'Torre de Karin', skyTop: '#1e1b4b', skyBot: '#4338ca', ground: '#15803d', accent: '#fbbf24' },
  { name: 'Planeta Supremo', skyTop: '#4c1d95', skyBot: '#c084fc', ground: '#15803d', accent: '#f0abfc' },
];

const BGM_TITLES = DBZ_TAG_TEAM_CANONICAL_MUSIC.map((t) => t.title);

function getCharDisplayName(slot: number): string {
  if (slot >= 1 && slot <= DBZ_TAG_TEAM_CANONICAL_NAMES.length) {
    return DBZ_TAG_TEAM_CANONICAL_NAMES[slot - 1];
  }
  return `Guerrero DLC #${String(slot).padStart(3, '0')}`;
}

function getCharHairColor(slot: number): string {
  const mod = slot % 7;
  if (mod === 0) return '#facc15'; // SSJ Gold
  if (mod === 1) return '#0f172a'; // Saiyan Black
  if (mod === 2) return '#38bdf8'; // SSJ Blue
  if (mod === 3) return '#ec4899'; // Rose
  if (mod === 4) return '#e2e8f0'; // Silver UI
  if (mod === 5) return '#22c55e'; // Broly LSSJ
  return '#a855f7'; // Hakai Purple
}

function mapRamProfileToHw(profile?: RamTargetProfile): EmulatorRamHardwareMode {
  if (profile === '64MB') return '64MB_PSP2000';
  if (profile === '128MB') return '128MB_PPSSPP';
  return '256MB_MOD_NATIVE';
}

function getHwUserLimitMb(mode: EmulatorRamHardwareMode): number {
  switch (mode) {
    case '32MB_PSP1000':
      return 24;
    case '64MB_PSP2000':
      return 52;
    case '128MB_PPSSPP':
      return 116;
    case '256MB_MOD_NATIVE':
      return 248;
  }
}

function getHwTotalMb(mode: EmulatorRamHardwareMode): number {
  switch (mode) {
    case '32MB_PSP1000':
      return 32;
    case '64MB_PSP2000':
      return 64;
    case '128MB_PPSSPP':
      return 128;
    case '256MB_MOD_NATIVE':
      return 256;
  }
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function loadInitialSave(gameId: string, maxChars: number, maxMaps: number): PersistentSave256 {
  try {
    const raw = localStorage.getItem(SAVE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<PersistentSave256>;
      return {
        gameId: parsed.gameId || gameId,
        zeni: parsed.zeni ?? 256000,
        wins: parsed.wins ?? 0,
        unlockedChars: Math.max(parsed.unlockedChars ?? maxChars, maxChars),
        unlockedMaps: Math.max(parsed.unlockedMaps ?? maxMaps, maxMaps),
        p1Slot: Math.min(maxChars, Math.max(1, parsed.p1Slot ?? 1)),
        p1Color: parsed.p1Color ?? 0,
        p2Slot: Math.min(maxChars, Math.max(1, parsed.p2Slot ?? 2)),
        p2Color: parsed.p2Color ?? 4,
        cpu1Slot: Math.min(maxChars, Math.max(1, parsed.cpu1Slot ?? 71)),
        cpu2Slot: Math.min(maxChars, Math.max(1, parsed.cpu2Slot ?? 128)),
        selectedMap: Math.min(maxMaps, Math.max(1, parsed.selectedMap ?? 1)),
        selectedBgm: parsed.selectedBgm ?? 1,
        lastSavedAt: parsed.lastSavedAt || new Date().toLocaleTimeString('es-ES'),
      };
    }
  } catch {
    // fallback default
  }
  return {
    gameId,
    zeni: 256000,
    wins: 0,
    unlockedChars: maxChars,
    unlockedMaps: maxMaps,
    p1Slot: 1,
    p1Color: 0,
    p2Slot: 2,
    p2Color: 4,
    cpu1Slot: Math.min(maxChars, 71),
    cpu2Slot: Math.min(maxChars, 128),
    selectedMap: 1,
    selectedBgm: 1,
    lastSavedAt: 'Sin guardar',
  };
}

function drawChibiPortrait(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  radius: number,
  slotId: number,
  colorIdx: number
) {
  const pal = COSTUME_PALETTES[colorIdx % COSTUME_PALETTES.length];
  const hair = getCharHairColor(slotId);

  ctx.save();
  // Aura ring
  ctx.fillStyle = `${pal.aura}33`;
  ctx.beginPath();
  ctx.arc(cx, cy, radius + 3, 0, Math.PI * 2);
  ctx.fill();

  // Body / Gi
  ctx.fillStyle = pal.primary;
  ctx.beginPath();
  ctx.roundRect(cx - radius * 0.55, cy + radius * 0.12, radius * 1.1, radius * 0.72, 4);
  ctx.fill();
  ctx.fillStyle = pal.secondary;
  ctx.fillRect(cx - radius * 0.25, cy + radius * 0.16, radius * 0.5, radius * 0.6);

  // Chibi big head
  ctx.fillStyle = '#fed7aa';
  ctx.beginPath();
  ctx.arc(cx, cy - radius * 0.16, radius * 0.52, 0, Math.PI * 2);
  ctx.fill();

  // Spiky Saiyan hair crown
  ctx.fillStyle = hair;
  ctx.beginPath();
  ctx.moveTo(cx - radius * 0.56, cy - radius * 0.22);
  ctx.lineTo(cx - radius * 0.65, cy - radius * 0.65);
  ctx.lineTo(cx - radius * 0.22, cy - radius * 0.48);
  ctx.lineTo(cx, cy - radius * 0.85);
  ctx.lineTo(cx + radius * 0.26, cy - radius * 0.48);
  ctx.lineTo(cx + radius * 0.65, cy - radius * 0.65);
  ctx.lineTo(cx + radius * 0.55, cy - radius * 0.22);
  ctx.closePath();
  ctx.fill();

  // Eyes
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(cx - radius * 0.24, cy - radius * 0.16, Math.max(2, radius * 0.12), Math.max(2, radius * 0.14));
  ctx.fillRect(cx + radius * 0.12, cy - radius * 0.16, Math.max(2, radius * 0.12), Math.max(2, radius * 0.14));
  ctx.restore();
}

export const PspTagTeamEmulator: React.FC<PspTagTeamEmulatorProps> = ({
  analysis,
  isoFileBlob,
  initialModConfig,
  onOpenDbzExpander,
}) => {
  const detectedGameId =
    initialModConfig?.gameId ||
    analysis?.sfoInfo?.discId ||
    'ULUS10537';

  const charCount = initialModConfig?.charCount ?? 256;
  const mapCount = initialModConfig?.mapCount ?? 46;
  const lobbyCount = initialModConfig?.lobbyCount ?? 256;
  const chibiCount = initialModConfig?.chibiCount ?? 256;
  const musicTrackCount = initialModConfig?.musicTrackCount ?? 64;

  const [subMode, setSubMode] = useState<EmulatorSubMode>('native_port');
  const [hwRamMode, setHwRamMode] = useState<EmulatorRamHardwareMode>(() =>
    mapRamProfileToHw(initialModConfig?.ramProfile)
  );
  const [screen, setScreen] = useState<PspGameScreen>('BOOT');
  const [bootProgress, setBootProgress] = useState<number>(0);

  // Lobby & Map cursor state
  const [rosterPage, setRosterPage] = useState<number>(0); // 0..7 (32 slots per page)
  const [cursorInPage, setCursorInPage] = useState<number>(0); // 0..31
  const [assignTarget, setAssignTarget] = useState<'P1' | 'P2' | 'CPU1' | 'CPU2'>('P1');
  const [mapCursor, setMapCursor] = useState<number>(1);
  const [audioMuted, setAudioMuted] = useState<boolean>(true);
  const [statusBanner, setStatusBanner] = useState<string>(
    'Consola lista · Ejecutando Port Nativo Tag Team 256 con modificación de RAM.'
  );
  const [ioTraceLogs, setIoTraceLogs] = useState<string[]>([
    '[KERNEL] sceKernelInit: 0x08000000 -> 0x18000000 (Mod RAM 256 MB activo)',
    '[PARAM.SFO] MEMSIZE=1 detectado · Partición Usuario extendida',
  ]);

  const [activeGameMode, setActiveGameMode] = useState<string>('Batalla Libre (Free Battle)');
  const [showDlcInGameDrawer, setShowDlcInGameDrawer] = useState<boolean>(true);

  const [saveState, setSaveState] = useState<PersistentSave256>(() =>
    loadInitialSave(detectedGameId, charCount, mapCount)
  );

  // Real audio tracks discovered inside loaded ISO
  const isoAudioEntries = useMemo(() => {
    if (!analysis?.isoInfo) return [];
    return analysis.isoInfo.files
      .filter((f) => !f.isDirectory && /\.(at3|wav|ogg|bgm)$/i.test(f.name))
      .slice(0, 20);
  }, [analysis]);

  const discoveredDlcPaths = useMemo(() => {
    const merged = new Set<string>(initialModConfig?.dlcAssetPaths ?? []);
    if (analysis?.isoInfo) {
      for (const f of analysis.isoInfo.files) {
        if (
          !f.isDirectory &&
          (/^\/PSP_GAME\/(MOD\/)?DLC\//i.test(f.path) ||
            /PACKFILE\.BIN$/i.test(f.path) ||
            /ICON1\.PMF$/i.test(f.path) ||
            /\/MOVIE\/.*\.PMF$/i.test(f.path))
        ) {
          merged.add(f.path);
        }
      }
    }
    return Array.from(merged).sort();
  }, [analysis, initialModConfig?.dlcAssetPaths]);

  const isoDlcCounts = useMemo(() => {
    const files = analysis?.isoInfo?.files ?? [];
    const chars = Math.max(
      files.filter((f) => /PERSONAJES|CHAR\d+/i.test(f.path)).length,
      discoveredDlcPaths.filter((p) => /PERSONAJES|CHAR\d+/i.test(p)).length
    );
    const maps = Math.max(
      files.filter((f) => /MAPAS|MAPS\d+/i.test(f.path)).length,
      discoveredDlcPaths.filter((p) => /MAPAS|MAPS\d+/i.test(p)).length
    );
    const minimaps = Math.max(
      files.filter((f) => /MINIMAPA/i.test(f.path)).length,
      discoveredDlcPaths.filter((p) => /MINIMAPA/i.test(p)).length
    );
    const chibis = Math.max(
      files.filter((f) => /CHIBI/i.test(f.path)).length,
      discoveredDlcPaths.filter((p) => /CHIBI/i.test(p)).length
    );
    return { chars, maps, minimaps, chibis };
  }, [analysis, discoveredDlcPaths]);

  const resolveCharName = useCallback(
    (slot: number) => {
      const custom = initialModConfig?.customCharNames?.[slot - 1];
      return custom || getCharDisplayName(slot);
    },
    [initialModConfig?.customCharNames]
  );

  const resolveMapName = useCallback(
    (mapId: number) => {
      const custom = initialModConfig?.customMapNames?.[mapId - 1];
      if (custom) return custom;
      return MAP_THEMES[(mapId - 1) % MAP_THEMES.length].name;
    },
    [initialModConfig?.customMapNames]
  );

  const resolveBgmName = useCallback(
    (bgmId: number) => {
      const custom = initialModConfig?.customMusicTitles?.[bgmId - 1];
      if (custom) return custom;
      return BGM_TITLES[(bgmId - 1) % BGM_TITLES.length] ?? `${bgmId}. Pista DLC AT3`;
    },
    [initialModConfig?.customMusicTitles]
  );

  const sfoHasMemsize = analysis?.sfoInfo?.entries?.some(
    (e) => e.key.toUpperCase() === 'MEMSIZE' && (e.value === 1 || String(e.value) === '1')
  );

  const ramBudget = useMemo(
    () =>
      calculateDlcRamBudget({
        fightersOnScreen: 4,
        modelType: 'GMO_OPTIMIZED',
        loadingMode: 'STREAMING',
        extraAudioBufferMb: Math.round(musicTrackCount * 0.15),
      }),
    [musicTrackCount]
  );

  // Realistic memory check: 256 lobby tables + chibis + 4 GMO fighters + stage + minimap + AT3 stream
  const requiredActiveRamMb = useMemo(() => {
    const rosterTableMb = Math.round((charCount * 0.045 + chibiCount * 0.03 + lobbyCount * 0.015) * 10) / 10;
    return Math.round((ramBudget.totalActiveMb + rosterTableMb) * 10) / 10;
  }, [ramBudget.totalActiveMb, charCount, chibiCount, lobbyCount]);

  const hwUserLimitMb = getHwUserLimitMb(hwRamMode);
  const hwTotalMb = getHwTotalMb(hwRamMode);
  const isOomForHardware = requiredActiveRamMb > hwUserLimitMb;

  // MIPS R4000 Allegrex VM & PSP Core C++ Source state
  const allegrexVmRef = useRef<PspAllegrexVm | null>(null);
  if (!allegrexVmRef.current) {
    allegrexVmRef.current = new PspAllegrexVm(hwTotalMb);
  }
  const [vmSnapshot, setVmSnapshot] = useState<MipsVmSnapshot | null>(null);
  const [selectedSourceIdx, setSelectedSourceIdx] = useState<number>(0);
  const [sourceCopyMsg, setSourceCopyMsg] = useState<string | null>(null);

  const pspSourceFiles = useMemo(
    () => buildPspEmulatorSourceBundle(detectedGameId, hwTotalMb),
    [detectedGameId, hwTotalMb]
  );

  const reloadAllegrexVm = useCallback(() => {
    const vm = allegrexVmRef.current ?? new PspAllegrexVm(hwTotalMb);
    allegrexVmRef.current = vm;
    vm.ramLimitMb = hwTotalMb;
    vm.loadElfOrFallbackStub(
      analysis?.rawBytes ?? null,
      analysis?.targetBinaryPath || analysis?.sourceName || 'EBOOT.BIN'
    );
    setVmSnapshot(vm.getSnapshot());
  }, [analysis, hwTotalMb]);

  useEffect(() => {
    reloadAllegrexVm();
  }, [reloadAllegrexVm]);

  // Sync RAM mode when launched directly from DBZ Expander
  useEffect(() => {
    if (initialModConfig) {
      setHwRamMode(mapRamProfileToHw(initialModConfig.ramProfile));
      setScreen('BOOT');
      setBootProgress(0);
    }
  }, [initialModConfig]);

  const pushIoLog = useCallback((line: string) => {
    setIoTraceLogs((prev) => [line, ...prev].slice(0, 18));
  }, []);

  // Battle runtime refs (for smooth 60 FPS Canvas without triggering React re-renders each frame)
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pressedKeysRef = useRef<Set<string>>(new Set());
  const analogVectorRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const analogStickDomRef = useRef<HTMLDivElement | null>(null);
  const draggingAnalogRef = useRef(false);
  const [analogUiPos, setAnalogUiPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [activeBtnFlash, setActiveBtnFlash] = useState<string | null>(null);
  const [connectedGamepadName, setConnectedGamepadName] = useState<string | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const synthTimerRef = useRef<number | null>(null);

  const battleRef = useRef<{
    p1: FighterRuntime;
    p2: FighterRuntime;
    cpu1: FighterRuntime;
    cpu2: FighterRuntime;
    activePlayer: 1 | 2;
    activeCpu: 1 | 2;
    projectiles: KiProjectile[];
    tick: number;
    winner: 'PLAYER' | 'CPU' | null;
  }>({
    p1: { slotId: 1, colorIdx: 0, x: 110, y: 195, vx: 0, vy: 0, facing: 1, hp: 100, maxHp: 100, ki: 100, dashTimer: 0, attackTimer: 0 },
    p2: { slotId: 2, colorIdx: 4, x: 70, y: 195, vx: 0, vy: 0, facing: 1, hp: 100, maxHp: 100, ki: 100, dashTimer: 0, attackTimer: 0 },
    cpu1: { slotId: 71, colorIdx: 1, x: 350, y: 195, vx: 0, vy: 0, facing: -1, hp: 100, maxHp: 100, ki: 100, dashTimer: 0, attackTimer: 0 },
    cpu2: { slotId: 128, colorIdx: 3, x: 390, y: 195, vx: 0, vy: 0, facing: -1, hp: 100, maxHp: 100, ki: 100, dashTimer: 0, attackTimer: 0 },
    activePlayer: 1,
    activeCpu: 1,
    projectiles: [],
    tick: 0,
    winner: null,
  });

  const persistSave = useCallback(
    (next: PersistentSave256) => {
      setSaveState(next);
      try {
        localStorage.setItem(SAVE_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // ignore quota errors
      }
      pushIoLog(`[SAVEDATA] ms0:/PSP/SAVEDATA/${next.gameId}/${next.gameId}_256_SAVE.BIN guardado (${next.unlockedChars} Chars).`);
    },
    [pushIoLog]
  );

  const startBattleMatch = useCallback(() => {
    battleRef.current = {
      p1: {
        slotId: saveState.p1Slot,
        colorIdx: saveState.p1Color,
        x: 115,
        y: 195,
        vx: 0,
        vy: 0,
        facing: 1,
        hp: 100,
        maxHp: 100,
        ki: 100,
        dashTimer: 0,
        attackTimer: 0,
      },
      p2: {
        slotId: saveState.p2Slot,
        colorIdx: saveState.p2Color,
        x: 68,
        y: 195,
        vx: 0,
        vy: 0,
        facing: 1,
        hp: 100,
        maxHp: 100,
        ki: 100,
        dashTimer: 0,
        attackTimer: 0,
      },
      cpu1: {
        slotId: saveState.cpu1Slot,
        colorIdx: 1,
        x: 350,
        y: 195,
        vx: 0,
        vy: 0,
        facing: -1,
        hp: 100,
        maxHp: 100,
        ki: 100,
        dashTimer: 0,
        attackTimer: 0,
      },
      cpu2: {
        slotId: saveState.cpu2Slot,
        colorIdx: 3,
        x: 405,
        y: 195,
        vx: 0,
        vy: 0,
        facing: -1,
        hp: 100,
        maxHp: 100,
        ki: 100,
        dashTimer: 0,
        attackTimer: 0,
      },
      activePlayer: 1,
      activeCpu: 1,
      projectiles: [],
      tick: 0,
      winner: null,
    };

    const mStr = String(saveState.selectedMap).padStart(2, '0');
    const c1Str = String(saveState.p1Slot).padStart(3, '0');
    const c2Str = String(saveState.p2Slot).padStart(3, '0');
    pushIoLog(`[STREAM] sceIoOpen("disc0:/PSP_GAME/DLC/MAPAS/MAPS${mStr}.BIN") OK`);
    pushIoLog(`[STREAM] sceIoOpen("disc0:/PSP_GAME/DLC/MINIMAPAS/MINIMAP${mStr}.TM2") OK`);
    pushIoLog(`[STREAM] Cargando CHAR${c1Str}.BIN + CHAR${c2Str}.BIN en Heap (${requiredActiveRamMb} MB)`);

    if (isOomForHardware) {
      setScreen('OOM_CRASH');
      setStatusBanner(`Crash OOM (0x800200D9): ${requiredActiveRamMb} MB exceden los ${hwUserLimitMb} MB de usuario.`);
      pushIoLog(`[ERROR] 0x800200D9 SCE_KERNEL_ERROR_NO_MEMORY en sceKernelAllocPartitionMemory`);
      return;
    }

    setScreen('BATTLE');
    setStatusBanner(`Combate Tag 2v2 iniciado en Mapa #${mStr} · L para cambio Tag, ○ Ki Blast, × Combo, □ Dash.`);
  }, [saveState, requiredActiveRamMb, isOomForHardware, hwUserLimitMb, pushIoLog]);

  // Boot sequence progression
  useEffect(() => {
    if (screen !== 'BOOT') return;
    const timer = window.setInterval(() => {
      setBootProgress((prev) => {
        const next = prev + 8;
        if (next >= 100) {
          window.clearInterval(timer);
          if (isOomForHardware) {
            setScreen('OOM_CRASH');
            pushIoLog(
              `[BOOT FAIL] ${requiredActiveRamMb} MB requeridos > ${hwUserLimitMb} MB (${hwRamMode}). Cambia a PPSSPP 256 MB.`
            );
          } else {
            setScreen('LOBBY');
            pushIoLog(
              `[LOBBY 256] Montados ${charCount} Chars + ${chibiCount} Chibis desde disc0:/PSP_GAME/DLC/LOBBY/`
            );
          }
          return 100;
        }
        return next;
      });
    }, 65);
    return () => window.clearInterval(timer);
  }, [screen, isOomForHardware, requiredActiveRamMb, hwUserLimitMb, hwRamMode, charCount, chibiCount, pushIoLog]);

  // Web Audio API BGM Synth (for instant offline music preview without external assets)
  useEffect(() => {
    if (audioMuted) {
      if (synthTimerRef.current) {
        window.clearInterval(synthTimerRef.current);
        synthTimerRef.current = null;
      }
      return;
    }

    const AudioCtor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtor) return;
    const ctx = audioCtxRef.current ?? new AudioCtor();
    audioCtxRef.current = ctx;
    if (ctx.state === 'suspended') {
      void ctx.resume();
    }

    const scale = [220, 261.63, 293.66, 329.63, 392.0, 440.0, 523.25, 440.0];
    let step = 0;
    synthTimerRef.current = window.setInterval(() => {
      try {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const freq = scale[(step + saveState.selectedBgm) % scale.length];
        osc.type = screen === 'BATTLE' ? 'sawtooth' : 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);
        gain.gain.setValueAtTime(0.035, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.16);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.17);
        step++;
      } catch {
        // ignore audio glitches
      }
    }, screen === 'BATTLE' ? 185 : 280);

    return () => {
      if (synthTimerRef.current) {
        window.clearInterval(synthTimerRef.current);
        synthTimerRef.current = null;
      }
    };
  }, [audioMuted, screen, saveState.selectedBgm]);

  const handlePlayIsoAudio = async (entryPath: string) => {
    if (!isoFileBlob || !analysis?.isoInfo) return;
    const entry = analysis.isoInfo.files.find((f) => f.path === entryPath);
    if (!entry) return;
    try {
      const bytes = await extractIsoFileBytes(isoFileBlob, entry);
      const header = new TextDecoder('ascii', { fatal: false }).decode(bytes.subarray(0, 4));
      if (header === 'RIFF') {
        const blob = new Blob([bytes as unknown as BlobPart], { type: 'audio/wav' });
        const url = URL.createObjectURL(blob);
        const audio = new Audio(url);
        audio.onended = () => URL.revokeObjectURL(url);
        await audio.play();
        pushIoLog(`[AUDIO] Reproduciendo RIFF desde ISO: ${entryPath}`);
      } else {
        setAudioMuted(false);
        pushIoLog(`[AUDIO] ${entryPath} usa códec ATRAC3+ (${header || 'RAW'}); sintetizador Tag activo.`);
      }
    } catch {
      pushIoLog(`[AUDIO] No se pudo decodificar directamente ${entryPath} en el navegador.`);
    }
  };

  // Unified PSP button dispatcher (works for onscreen buttons, keyboard, and Web Gamepad API)
  const triggerPspButton = useCallback(
    (btn: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT' | 'CROSS' | 'CIRCLE' | 'TRIANGLE' | 'SQUARE' | 'L' | 'R' | 'START' | 'SELECT' | 'HOME') => {
      setActiveBtnFlash(btn);
      window.setTimeout(() => {
        setActiveBtnFlash((cur) => (cur === btn ? null : cur));
      }, 130);

      if (btn === 'HOME') {
        if (screen === 'BATTLE') {
          setScreen('LOBBY');
          setStatusBanner('Menú HOME: regreso al Lobby 256.');
        } else if (screen === 'LOBBY') {
          setMapCursor(saveState.selectedMap);
          setScreen('MAPS');
        } else {
          setScreen('LOBBY');
        }
        return;
      }

      if (screen === 'OOM_CRASH') {
        if (btn === 'CROSS' || btn === 'START') {
          setHwRamMode('256MB_MOD_NATIVE');
          setScreen('BOOT');
          setBootProgress(0);
          setStatusBanner('RAM ampliada a PPSSPP 256 MB (0x18000000). Reiniciando...');
        }
        return;
      }

      if (screen === 'BOOT') {
        if (btn === 'START') {
          setScreen(isOomForHardware ? 'OOM_CRASH' : 'LOBBY');
        }
        return;
      }

      if (screen === 'LOBBY') {
        const cols = 4;
        const pageSize = 24;
        const totalPages = Math.max(1, Math.ceil(charCount / pageSize));
        if (btn === 'RIGHT') setCursorInPage((c) => (c + 1) % pageSize);
        if (btn === 'LEFT') setCursorInPage((c) => (c - 1 + pageSize) % pageSize);
        if (btn === 'DOWN') setCursorInPage((c) => (c + cols) % pageSize);
        if (btn === 'UP') setCursorInPage((c) => (c - cols + pageSize) % pageSize);
        if (btn === 'R') setRosterPage((p) => (p + 1) % totalPages);
        if (btn === 'L') setRosterPage((p) => (p - 1 + totalPages) % totalPages);

        if (btn === 'SELECT') {
          const order: Array<'P1' | 'P2' | 'CPU1' | 'CPU2'> = ['P1', 'P2', 'CPU1', 'CPU2'];
          setAssignTarget((cur) => order[(order.indexOf(cur) + 1) % order.length]);
        }

        const absoluteSlot = Math.min(charCount, rosterPage * pageSize + cursorInPage + 1);
        if (btn === 'CROSS') {
          const updated = { ...saveState };
          if (assignTarget === 'P1') updated.p1Slot = absoluteSlot;
          if (assignTarget === 'P2') updated.p2Slot = absoluteSlot;
          if (assignTarget === 'CPU1') updated.cpu1Slot = absoluteSlot;
          if (assignTarget === 'CPU2') updated.cpu2Slot = absoluteSlot;
          persistSave({ ...updated, lastSavedAt: new Date().toLocaleTimeString('es-ES') });
          pushIoLog(
            `[CHIBI] Asignado ${assignTarget} = Slot #${String(absoluteSlot).padStart(3, '0')} (CHIBI${String(absoluteSlot).padStart(3, '0')}.GIM)`
          );
        }
        if (btn === 'TRIANGLE') {
          const updated = {
            ...saveState,
            p1Color: (saveState.p1Color + 1) % 8,
            p2Color: (saveState.p2Color + 1) % 8,
            lastSavedAt: new Date().toLocaleTimeString('es-ES'),
          };
          persistSave(updated);
        }
        if (btn === 'SQUARE') {
          setMapCursor(saveState.selectedMap);
          setScreen('MAPS');
        }
        if (btn === 'START') {
          startBattleMatch();
        }
        return;
      }

      if (screen === 'MAPS') {
        if (btn === 'RIGHT' || btn === 'DOWN') setMapCursor((m) => (m % mapCount) + 1);
        if (btn === 'LEFT' || btn === 'UP') setMapCursor((m) => ((m - 2 + mapCount) % mapCount) + 1);
        if (btn === 'R' || btn === 'L') {
          const nextBgm = (saveState.selectedBgm % Math.min(musicTrackCount, 64)) + 1;
          persistSave({ ...saveState, selectedBgm: nextBgm });
        }
        if (btn === 'TRIANGLE') {
          setAudioMuted((m) => !m);
        }
        if (btn === 'CIRCLE') {
          setScreen('LOBBY');
        }
        if (btn === 'CROSS' || btn === 'START') {
          persistSave({
            ...saveState,
            selectedMap: mapCursor,
            lastSavedAt: new Date().toLocaleTimeString('es-ES'),
          });
          startBattleMatch();
        }
        return;
      }

      if (screen === 'BATTLE') {
        const b = battleRef.current;
        if (btn === 'START') {
          setScreen('LOBBY');
          return;
        }
        if (b.winner) {
          if (btn === 'CROSS') startBattleMatch();
          if (btn === 'CIRCLE') setScreen('LOBBY');
          return;
        }

        const active = b.activePlayer === 1 ? b.p1 : b.p2;
        const standby = b.activePlayer === 1 ? b.p2 : b.p1;
        const target = b.activeCpu === 1 ? b.cpu1 : b.cpu2;

        if (btn === 'L') {
          // Tag-In Switch between P1 and P2!
          const nextActive: 1 | 2 = b.activePlayer === 1 ? 2 : 1;
          const oldX = active.x;
          const oldY = active.y;
          standby.x = oldX;
          standby.y = oldY;
          active.x = 45;
          b.activePlayer = nextActive;
          pushIoLog(
            `[TAG SWAP] Relevo a Slot #${String(standby.slotId).padStart(3, '0')} en Arena`
          );
        } else if (btn === 'CIRCLE' && active.ki >= 15) {
          // Ki Blast
          active.ki = Math.max(0, active.ki - 15);
          const dir = target.x >= active.x ? 1 : -1;
          active.facing = dir;
          const pal = COSTUME_PALETTES[active.colorIdx % COSTUME_PALETTES.length];
          b.projectiles.push({
            x: active.x + dir * 20,
            y: active.y - 12,
            vx: dir * 5.2,
            vy: (target.y - active.y) * 0.025,
            ownerTeam: 'PLAYER',
            color: pal.aura,
          });
        } else if (btn === 'CROSS') {
          // Melee Strike
          active.attackTimer = 14;
          const dist = Math.hypot(target.x - active.x, target.y - active.y);
          if (dist < 46) {
            target.hp = Math.max(0, target.hp - 12);
            target.vx += (active.facing) * 4;
          }
        } else if (btn === 'SQUARE') {
          // Dragon Dash towards enemy
          active.dashTimer = 14;
          const dir = target.x >= active.x ? 1 : -1;
          active.vx = dir * 6.5;
          active.facing = dir;
        } else if (btn === 'TRIANGLE') {
          // Charge Ki
          active.ki = Math.min(100, active.ki + 22);
        } else if (btn === 'R') {
          // Partner quick ki assist
          const pal = COSTUME_PALETTES[standby.colorIdx % COSTUME_PALETTES.length];
          b.projectiles.push({
            x: standby.x + 25,
            y: standby.y - 25,
            vx: 4.5,
            vy: 0,
            ownerTeam: 'PLAYER',
            color: pal.aura,
          });
        }
      }
    },
    [
      screen,
      isOomForHardware,
      charCount,
      rosterPage,
      cursorInPage,
      assignTarget,
      saveState,
      persistSave,
      pushIoLog,
      startBattleMatch,
      mapCursor,
      mapCount,
      musicTrackCount,
    ]
  );

  // Keyboard + Web Gamepad API listener for emulator controls
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement ||
        e.target instanceof HTMLSelectElement
      ) {
        return;
      }
      const k = e.key.toLowerCase();
      pressedKeysRef.current.add(k);

      if (k === 'arrowup') {
        e.preventDefault();
        triggerPspButton('UP');
      } else if (k === 'arrowdown') {
        e.preventDefault();
        triggerPspButton('DOWN');
      } else if (k === 'arrowleft') {
        e.preventDefault();
        triggerPspButton('LEFT');
      } else if (k === 'arrowright') {
        e.preventDefault();
        triggerPspButton('RIGHT');
      } else if (k === 'z') {
        triggerPspButton('CROSS');
      } else if (k === 'x') {
        triggerPspButton('CIRCLE');
      } else if (k === 'a') {
        triggerPspButton('SQUARE');
      } else if (k === 's') {
        triggerPspButton('TRIANGLE');
      } else if (k === 'q') {
        triggerPspButton('L');
      } else if (k === 'e') {
        triggerPspButton('R');
      } else if (k === 'enter') {
        e.preventDefault();
        triggerPspButton('START');
      } else if (k === 'shift') {
        triggerPspButton('SELECT');
      } else if (k === 'h') {
        triggerPspButton('HOME');
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      pressedKeysRef.current.delete(e.key.toLowerCase());
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, [triggerPspButton]);

  // Web Gamepad API loop (USB/Bluetooth controllers)
  useEffect(() => {
    if (typeof navigator === 'undefined' || !navigator.getGamepads) return;
    let rafId = 0;
    const prevButtons: boolean[] = [];
    let prevAxisDir: string | null = null;

    const poll = () => {
      try {
        const gp = navigator.getGamepads()?.[0] ?? null;
        if (gp) {
          setConnectedGamepadName((prev) => (prev === gp.id ? prev : gp.id));
          const map: Array<[number, 'CROSS' | 'CIRCLE' | 'SQUARE' | 'TRIANGLE' | 'L' | 'R' | 'SELECT' | 'START' | 'UP' | 'DOWN' | 'LEFT' | 'RIGHT' | 'HOME']> = [
            [0, 'CROSS'],
            [1, 'CIRCLE'],
            [2, 'SQUARE'],
            [3, 'TRIANGLE'],
            [4, 'L'],
            [5, 'R'],
            [8, 'SELECT'],
            [9, 'START'],
            [12, 'UP'],
            [13, 'DOWN'],
            [14, 'LEFT'],
            [15, 'RIGHT'],
            [16, 'HOME'],
          ];
          for (const [idx, btnName] of map) {
            const down = Boolean(gp.buttons[idx]?.pressed);
            if (down && !prevButtons[idx]) {
              triggerPspButton(btnName);
            }
            prevButtons[idx] = down;
          }
          const ax = Math.abs(gp.axes[0] ?? 0) > 0.16 ? gp.axes[0] : 0;
          const ay = Math.abs(gp.axes[1] ?? 0) > 0.16 ? gp.axes[1] : 0;
          if (!draggingAnalogRef.current) {
            analogVectorRef.current = { x: ax, y: ay };
            setAnalogUiPos({ x: ax, y: ay });
          }
          if (screen !== 'BATTLE') {
            const dir =
              Math.abs(ax) > Math.abs(ay)
                ? ax > 0.55
                  ? 'RIGHT'
                  : ax < -0.55
                  ? 'LEFT'
                  : null
                : ay > 0.55
                ? 'DOWN'
                : ay < -0.55
                ? 'UP'
                : null;
            if (dir && dir !== prevAxisDir) {
              triggerPspButton(dir as 'UP' | 'DOWN' | 'LEFT' | 'RIGHT');
            }
            prevAxisDir = dir;
          }
        } else {
          setConnectedGamepadName((prev) => (prev === null ? null : null));
        }
      } catch {
        // ignore sandbox gamepad restriction
      }
      rafId = window.requestAnimationFrame(poll);
    };
    rafId = window.requestAnimationFrame(poll);
    return () => window.cancelAnimationFrame(rafId);
  }, [triggerPspButton, screen]);

  // 480x272 Native PSP Canvas Render Loop
  useEffect(() => {
    let rafId = 0;

    const renderFrame = () => {
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, 480, 272);

          if (screen === 'BOOT') {
            ctx.fillStyle = '#020617';
            ctx.fillRect(0, 0, 480, 272);
            ctx.fillStyle = '#38bdf8';
            ctx.font = 'bold 16px monospace';
            ctx.fillText('PSP-3000 / PPSSPP MOD NATIVO 256 MB', 58, 72);

            ctx.fillStyle = '#cbd5e1';
            ctx.font = '11px monospace';
            ctx.fillText(`GAME ID : ${detectedGameId} · DBZ TENKAICHI TAG TEAM`, 58, 102);
            ctx.fillText(`RAM CFG : ${hwTotalMb} MB TOTAL (${hwUserLimitMb} MB USER HEAP)`, 58, 120);
            ctx.fillText(`DLC DIR : disc0:/PSP_GAME/DLC/ (${charCount} CHARS · ${mapCount} MAPAS)`, 58, 138);
            ctx.fillText(`SAVEDATA: 256 SLOTS + LOBBY CHIBIS (${chibiCount})`, 58, 156);

            // Progress bar
            ctx.strokeStyle = '#334155';
            ctx.strokeRect(58, 184, 364, 16);
            ctx.fillStyle = '#f97316';
            ctx.fillRect(60, 186, Math.round((360 * bootProgress) / 100), 12);

            ctx.fillStyle = '#94a3b8';
            ctx.font = '10px monospace';
            ctx.fillText(`Cargando EBOOT.BIN + PARAM.SFO [MEMSIZE=${sfoHasMemsize || hwTotalMb >= 64 ? '1' : '0'}]... ${bootProgress}%`, 58, 220);
          } else if (screen === 'OOM_CRASH') {
            ctx.fillStyle = '#450a0a';
            ctx.fillRect(0, 0, 480, 272);
            ctx.fillStyle = '#fca5a5';
            ctx.font = 'bold 15px monospace';
            ctx.fillText('ERROR KERNEL PSP: 0x800200D9 (OUT OF MEMORY)', 34, 54);
            ctx.fillStyle = '#fee2e2';
            ctx.font = '11px monospace';
            ctx.fillText(`Heap requerido: ${requiredActiveRamMb} MB (256 Personajes + 46 Mapas + Chibis)`, 34, 90);
            ctx.fillText(`Límite actual (${hwRamMode}): ${hwUserLimitMb} MB libres en Usuario`, 34, 110);
            ctx.fillText('Solución:', 34, 146);
            ctx.fillText('1. Activa "PPSSPP Mod Nativo 256 MB (0x18000000)" en el selector.', 34, 166);
            ctx.fillText('2. Asegura MEMSIZE=1 en PARAM.SFO y parche LUI en EBOOT.BIN.', 34, 186);

            ctx.fillStyle = '#f97316';
            ctx.fillRect(34, 212, 310, 30);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 11px monospace';
            ctx.fillText('PULSA × / START PARA ACTIVAR RAM 256 MB', 46, 231);
          } else if (screen === 'LOBBY') {
            // Authentic DBZ Tenkaichi Tag Team: "SELECCIÓN DE PERSONAJE"
            const pageSize = 24;
            const totalPages = Math.max(1, Math.ceil(charCount / pageSize));
            const safePage = rosterPage % totalPages;
            const hoveredSlot = Math.min(charCount, safePage * pageSize + cursorInPage + 1);

            // Sky-blue background
            const grad = ctx.createLinearGradient(0, 0, 0, 272);
            grad.addColorStop(0, '#0284c7');
            grad.addColorStop(1, '#0369a1');
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, 480, 272);

            // Top Header Banner with Dragon Ball & "SELECCIÓN DE PERSONAJE"
            ctx.fillStyle = '#0ea5e9';
            ctx.fillRect(0, 0, 480, 28);
            ctx.fillStyle = '#f59e0b';
            ctx.beginPath();
            ctx.arc(10, 12, 18, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#dc2626';
            ctx.fillText('★', 8, 16);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 14px sans-serif';
            ctx.fillText('SELECCIÓN DE PERSONAJE', 34, 20);
            ctx.fillStyle = '#fef08a';
            ctx.font = 'bold 9px monospace';
            ctx.fillText(`PÁG ${safePage + 1}/${totalPages} (${charCount} CHARS · RAM ${hwTotalMb}MB)`, 286, 18);

            // Top-left Player A / J1 Strip
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 28, 268, 22);
            ctx.fillStyle = '#dc2626';
            ctx.fillRect(0, 28, 28, 22);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 12px sans-serif';
            ctx.fillText('A', 9, 44);
            ctx.fillStyle = '#dc2626';
            ctx.fillText(assignTarget, 34, 44);
            ctx.fillStyle = '#0f172a';
            ctx.font = 'bold 10px sans-serif';
            ctx.fillText(
              `${activeGameMode.split('(')[0].trim()} · ${initialModConfig?.freeBattlePreset ?? COSTUME_PALETTES[saveState.p1Color].name}`,
              76,
              43
            );

            // Left Preview Area: Yellow Speed Lines + 4-Star Dragon Ball + Enlarged Chibi Preview
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 50, 268, 134);
            ctx.fillStyle = '#fef08a';
            for (let sy = 54; sy < 180; sy += 6) {
              ctx.fillRect(4, sy, 180, 2);
            }
            // Glowing Dragon Ball backdrop
            ctx.fillStyle = '#f59e0b';
            ctx.beginPath();
            ctx.arc(198, 114, 52, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#dc2626';
            ctx.font = 'bold 14px sans-serif';
            ctx.fillText('★', 184, 96);
            ctx.fillText('★', 210, 108);
            ctx.fillText('★', 192, 128);

            drawChibiPortrait(ctx, 116, 112, 42, hoveredSlot, saveState.p1Color);

            // Character Name Ribbon with real 0x00..0xFF hex ID
            ctx.fillStyle = 'rgba(254, 249, 195, 0.92)';
            ctx.fillRect(34, 152, 228, 26);
            ctx.fillStyle = '#dc2626';
            ctx.font = 'bold 12px sans-serif';
            const hoveredHex = (hoveredSlot - 1).toString(16).toUpperCase().padStart(2, '0');
            ctx.fillText(`${hoveredHex} · ${resolveCharName(hoveredSlot)}`, 44, 170);

            // Bottom-Left 4 Fighter Cards: J1, J2 CPU, J3 CPU, J4 CPU
            const teamCards = [
              { label: 'J1', sub: '', slot: saveState.p1Slot, cIdx: saveState.p1Color, bg: '#dc2626' },
              { label: 'J2', sub: 'CPU', slot: saveState.p2Slot, cIdx: saveState.p2Color, bg: '#0284c7' },
              { label: 'J3', sub: 'CPU', slot: saveState.cpu1Slot, cIdx: 1, bg: '#f59e0b' },
              { label: 'J4', sub: 'CPU', slot: saveState.cpu2Slot, cIdx: 3, bg: '#16a34a' },
            ];
            teamCards.forEach((tc, idx) => {
              const cx = 4 + idx * 66;
              const cy = 186;
              ctx.fillStyle = '#0f172a';
              ctx.fillRect(cx, cy, 62, 54);
              ctx.strokeStyle = '#ffffff';
              ctx.lineWidth = 1.5;
              ctx.strokeRect(cx, cy, 62, 54);
              drawChibiPortrait(ctx, cx + 31, cy + 32, 16, tc.slot, tc.cIdx);
              ctx.fillStyle = tc.bg;
              ctx.fillRect(cx + 2, cy + 2, 18, 11);
              ctx.fillStyle = '#ffffff';
              ctx.font = 'bold 8px sans-serif';
              ctx.fillText(tc.label, cx + 5, cy + 10);
              if (tc.sub) {
                ctx.fillStyle = '#c084fc';
                ctx.fillText(tc.sub, cx + 34, cy + 10);
              }
            });

            // Right Side: Authentic 4x6 Roster Minicasilla Grid (24 per page + ▲▼ scroll + scrollbar)
            ctx.fillStyle = '#0c4a6e';
            ctx.fillRect(272, 30, 204, 212);
            ctx.fillStyle = '#facc15';
            ctx.font = 'bold 9px sans-serif';
            ctx.fillText('▲ (L)', 358, 39);
            ctx.fillText('▼ (R)', 358, 239);

            const gx0 = 280;
            const gy0 = 43;
            const cw = 45;
            const ch = 31;
            for (let i = 0; i < 24; i++) {
              const slotNum = safePage * pageSize + i + 1;
              const col = i % 4;
              const row = Math.floor(i / 4);
              const x = gx0 + col * cw;
              const y = gy0 + row * ch;
              const disabled = slotNum > charCount;
              const isSelected = i === cursorInPage % 24;

              ctx.fillStyle = disabled ? '#0f172a' : '#312e81';
              ctx.fillRect(x, y, cw - 3, ch - 3);
              if (!disabled) {
                drawChibiPortrait(ctx, x + 21, y + 14, 10, slotNum, slotNum % 8);
                ctx.fillStyle = '#e2e8f0';
                ctx.font = '7px monospace';
                ctx.fillText(`${String(slotNum).padStart(3, '0')}`, x + 2, y + 26);
              }
              ctx.strokeStyle = isSelected ? '#facc15' : '#020617';
              ctx.lineWidth = isSelected ? 2.5 : 1;
              ctx.strokeRect(x, y, cw - 3, ch - 3);
            }

            // Right scrollbar thumb
            ctx.fillStyle = '#075985';
            ctx.fillRect(466, 43, 6, 184);
            ctx.fillStyle = '#38bdf8';
            const barH = Math.max(18, Math.round(184 / totalPages));
            const barY = 43 + Math.round(((184 - barH) * safePage) / Math.max(1, totalPages - 1));
            ctx.fillRect(466, barY, 6, barH);

            // Bottom Control Hint Bar
            ctx.fillStyle = '#0284c7';
            ctx.fillRect(0, 246, 480, 26);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 9px sans-serif';
            ctx.fillText(
              '[START] Omitir  [△] Color  [×] Confirmar  [□] Mapas/Música  [SELECT] J1-J4',
              18,
              263
            );
          } else if (screen === 'MAPS') {
            // Authentic DBZ Tenkaichi Tag Team: "SELECCIÓN DE MAPA" + Music Bar
            const theme = MAP_THEMES[(mapCursor - 1) % MAP_THEMES.length];
            const sky = ctx.createLinearGradient(0, 0, 0, 272);
            sky.addColorStop(0, '#0284c7');
            sky.addColorStop(1, '#0369a1');
            ctx.fillStyle = sky;
            ctx.fillRect(0, 0, 480, 272);

            // Top Header "SELECCIÓN DE MAPA"
            ctx.fillStyle = '#0ea5e9';
            ctx.fillRect(0, 0, 480, 28);
            ctx.fillStyle = '#f59e0b';
            ctx.beginPath();
            ctx.arc(10, 12, 18, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 14px sans-serif';
            ctx.fillText('SELECCIÓN DE MAPA', 34, 20);
            ctx.fillStyle = '#fef08a';
            ctx.font = 'bold 9px monospace';
            ctx.fillText(`MAPA #${String(mapCursor).padStart(2, '0')} / ${mapCount}`, 368, 18);

            // Left Large Map Preview
            const pGrad = ctx.createLinearGradient(0, 32, 0, 166);
            pGrad.addColorStop(0, theme.skyTop);
            pGrad.addColorStop(0.7, theme.skyBot);
            pGrad.addColorStop(1, theme.ground);
            ctx.fillStyle = pGrad;
            ctx.fillRect(4, 32, 286, 136);

            // Minimap TM2 Radar Badge inside corner
            ctx.fillStyle = 'rgba(2,6,23,0.75)';
            ctx.fillRect(10, 38, 62, 46);
            ctx.strokeStyle = theme.accent;
            ctx.strokeRect(10, 38, 62, 46);
            ctx.fillStyle = '#cbd5e1';
            ctx.font = '7px monospace';
            ctx.fillText('MINIMAPA', 14, 48);
            ctx.fillStyle = '#38bdf8';
            ctx.fillRect(26, 62, 4, 4);
            ctx.fillStyle = '#ef4444';
            ctx.fillRect(50, 58, 4, 4);

            // Center ? if Aleatorio (Map 11)
            if (theme.name === 'Aleatorio') {
              ctx.fillStyle = '#ea580c';
              ctx.font = 'bold 42px sans-serif';
              ctx.fillText('?', 135, 112);
            }

            // Yellow stage name ribbon
            ctx.fillStyle = 'rgba(254, 240, 138, 0.92)';
            ctx.fillRect(72, 136, 218, 24);
            ctx.fillStyle = '#1e293b';
            ctx.font = 'bold 12px sans-serif';
            ctx.fillText(`${mapCursor}. ${resolveMapName(mapCursor)}`.slice(0, 30), 80, 153);

            // Right Settings Panel: Límite de tiempo + Número de semillas Senzu
            ctx.fillStyle = '#0369a1';
            ctx.fillRect(294, 32, 182, 136);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 10px sans-serif';
            ctx.fillText('⏱ Límite de tiempo', 306, 52);
            ctx.fillStyle = '#1e3a8a';
            ctx.fillRect(306, 60, 158, 22);
            ctx.fillStyle = '#facc15';
            ctx.font = 'bold 11px monospace';
            ctx.fillText('◀      180      ▶', 324, 75);

            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 10px sans-serif';
            ctx.fillText('🌱 Número de semillas Senzu', 306, 102);
            ctx.fillStyle = '#1e3a8a';
            ctx.fillRect(306, 110, 158, 22);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 10px monospace';
            ctx.fillText('Equipo A   ◀  1  ▶', 318, 125);
            ctx.fillStyle = '#1e3a8a';
            ctx.fillRect(306, 136, 158, 22);
            ctx.fillStyle = '#ffffff';
            ctx.fillText('Equipo B   ◀  1  ▶', 318, 151);

            // Bottom Horizontal 6-Minicasilla Map Carousel
            ctx.fillStyle = '#0c4a6e';
            ctx.fillRect(10, 174, 460, 44);
            ctx.fillStyle = '#facc15';
            ctx.font = 'bold 12px sans-serif';
            ctx.fillText('◀', 16, 200);
            ctx.fillText('▶', 452, 200);

            const stripStart = Math.max(1, Math.min(Math.max(1, mapCount - 5), mapCursor - 2));
            for (let k = 0; k < 6; k++) {
              const mId = stripStart + k;
              if (mId > mapCount) break;
              const mTheme = MAP_THEMES[(mId - 1) % MAP_THEMES.length];
              const tx = 36 + k * 69;
              const ty = 178;
              const mg = ctx.createLinearGradient(0, ty, 0, ty + 36);
              mg.addColorStop(0, mTheme.skyTop);
              mg.addColorStop(1, mTheme.ground);
              ctx.fillStyle = mg;
              ctx.fillRect(tx, ty, 64, 36);
              if (mTheme.name === 'Aleatorio') {
                ctx.fillStyle = '#ea580c';
                ctx.font = 'bold 16px sans-serif';
                ctx.fillText('?', tx + 27, ty + 23);
              } else {
                ctx.fillStyle = '#ffffff';
                ctx.font = 'bold 8px monospace';
                ctx.fillText(`M${String(mId).padStart(2, '0')}`, tx + 4, ty + 11);
              }
              ctx.strokeStyle = mId === mapCursor ? '#facc15' : '#020617';
              ctx.lineWidth = mId === mapCursor ? 2.5 : 1;
              ctx.strokeRect(tx, ty, 64, 36);
            }

            // Music Selector Bar with Musical Note & "9. Explosión"
            ctx.fillStyle = '#fef08a';
            ctx.fillRect(14, 223, 452, 20);
            ctx.fillStyle = '#22c55e';
            ctx.font = 'bold 12px sans-serif';
            ctx.fillText('🎵', 16, 237);
            ctx.fillStyle = '#1e3a8a';
            ctx.font = 'bold 11px sans-serif';
            const bgmLabel = resolveBgmName(saveState.selectedBgm);
            ctx.fillText(`◀                  ${bgmLabel}                  ▶`, 52, 237);

            // Bottom Footer Controls
            ctx.fillStyle = '#0284c7';
            ctx.fillRect(0, 246, 480, 26);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 9px sans-serif';
            ctx.fillText(
              '[L/R] Música  [△] Audio/Aleatorio  [×/START] Confirmar  [○] Atrás',
              84,
              263
            );
          } else if (screen === 'BATTLE') {
            const b = battleRef.current;
            const theme = MAP_THEMES[(saveState.selectedMap - 1) % MAP_THEMES.length];

            // Update physics if match active
            if (!b.winner) {
              b.tick++;
              const active = b.activePlayer === 1 ? b.p1 : b.p2;
              const target = b.activeCpu === 1 ? b.cpu1 : b.cpu2;
              const keys = pressedKeysRef.current;
              const analog = analogVectorRef.current;

              if (Math.abs(analog.x) > 0.15) {
                active.vx = analog.x * 3.8;
                active.facing = analog.x > 0 ? 1 : -1;
              } else if (keys.has('arrowleft')) {
                active.vx = -3.2;
                active.facing = -1;
              } else if (keys.has('arrowright')) {
                active.vx = 3.2;
                active.facing = 1;
              } else {
                active.vx *= 0.8;
              }
              if (Math.abs(analog.y) > 0.15) {
                active.vy = analog.y * 3.2;
              } else if (keys.has('arrowup')) {
                active.vy = -2.8;
              } else if (keys.has('arrowdown')) {
                active.vy = 2.8;
              } else {
                active.vy *= 0.8;
              }

              active.x = Math.max(24, Math.min(456, active.x + active.vx));
              active.y = Math.max(84, Math.min(234, active.y + active.vy));
              active.ki = Math.min(100, active.ki + 0.08);
              if (active.attackTimer > 0) active.attackTimer--;
              if (active.dashTimer > 0) active.dashTimer--;

              // Simple CPU AI movement & attacks
              const dx = active.x - target.x;
              const dy = active.y - target.y;
              target.facing = dx >= 0 ? 1 : -1;
              if (Math.abs(dx) > 65) {
                target.x += Math.sign(dx) * 1.1;
              }
              target.y += Math.sign(dy) * 0.7;
              target.x = Math.max(24, Math.min(456, target.x));
              target.y = Math.max(84, Math.min(234, target.y));

              if (b.tick % 95 === 0) {
                b.projectiles.push({
                  x: target.x + target.facing * 18,
                  y: target.y - 12,
                  vx: target.facing * 3.8,
                  vy: (active.y - target.y) * 0.018,
                  ownerTeam: 'CPU',
                  color: '#f87171',
                });
              }

              // Projectiles update + hit detection
              const nextProj: KiProjectile[] = [];
              for (const pr of b.projectiles) {
                pr.x += pr.vx;
                pr.y += pr.vy;
                if (pr.x < -10 || pr.x > 490 || pr.y < 30 || pr.y > 272) continue;
                const victim = pr.ownerTeam === 'PLAYER' ? target : active;
                if (Math.hypot(pr.x - victim.x, pr.y - (victim.y - 10)) < 20) {
                  victim.hp = Math.max(0, victim.hp - 10);
                  continue;
                }
                nextProj.push(pr);
              }
              b.projectiles = nextProj;

              // Tag switch CPU when first KO'd
              if (b.cpu1.hp <= 0 && b.activeCpu === 1 && b.cpu2.hp > 0) {
                b.activeCpu = 2;
              }
              if (b.p1.hp <= 0 && b.activePlayer === 1 && b.p2.hp > 0) {
                b.activePlayer = 2;
              }

              if (b.cpu1.hp <= 0 && b.cpu2.hp <= 0) {
                b.winner = 'PLAYER';
                persistSave({
                  ...saveState,
                  wins: saveState.wins + 1,
                  zeni: saveState.zeni + 5000,
                  lastSavedAt: new Date().toLocaleTimeString('es-ES'),
                });
              } else if (b.p1.hp <= 0 && b.p2.hp <= 0) {
                b.winner = 'CPU';
              }
            }

            // Draw Stage sky + floor
            const sky = ctx.createLinearGradient(0, 0, 0, 195);
            sky.addColorStop(0, theme.skyTop);
            sky.addColorStop(1, theme.skyBot);
            ctx.fillStyle = sky;
            ctx.fillRect(0, 0, 480, 195);
            ctx.fillStyle = theme.ground;
            ctx.fillRect(0, 195, 480, 77);

            // Grid horizon lines
            ctx.strokeStyle = `${theme.accent}44`;
            ctx.beginPath();
            for (let gx = 0; gx <= 480; gx += 48) {
              ctx.moveTo(240 + (gx - 240) * 0.4, 195);
              ctx.lineTo(gx, 272);
            }
            ctx.stroke();

            // Draw active fighters
            const pActive = b.activePlayer === 1 ? b.p1 : b.p2;
            const cActive = b.activeCpu === 1 ? b.cpu1 : b.cpu2;

            drawChibiPortrait(ctx, pActive.x, pActive.y - 14, 15, pActive.slotId, pActive.colorIdx);
            drawChibiPortrait(ctx, cActive.x, cActive.y - 14, 15, cActive.slotId, cActive.colorIdx);

            // Attack shockwave
            if (pActive.attackTimer > 0) {
              ctx.strokeStyle = '#facc15';
              ctx.lineWidth = 2;
              ctx.beginPath();
              ctx.arc(pActive.x + pActive.facing * 20, pActive.y - 14, 16, 0, Math.PI * 2);
              ctx.stroke();
            }

            // Ki Projectiles
            for (const pr of b.projectiles) {
              ctx.fillStyle = pr.color;
              ctx.beginPath();
              ctx.arc(pr.x, pr.y, 6, 0, Math.PI * 2);
              ctx.fill();
              ctx.fillStyle = '#ffffff';
              ctx.beginPath();
              ctx.arc(pr.x, pr.y, 3, 0, Math.PI * 2);
              ctx.fill();
            }

            // Top HUD: Player HP & Ki
            ctx.fillStyle = 'rgba(2,6,23,0.75)';
            ctx.fillRect(8, 8, 178, 36);
            ctx.fillStyle = '#f8fafc';
            ctx.font = 'bold 9px monospace';
            ctx.fillText(`P${b.activePlayer}: ${resolveCharName(pActive.slotId)}`, 14, 19);
            ctx.fillStyle = '#334155';
            ctx.fillRect(14, 23, 164, 7);
            ctx.fillStyle = '#22c55e';
            ctx.fillRect(14, 23, Math.round((164 * pActive.hp) / pActive.maxHp), 7);
            ctx.fillStyle = '#38bdf8';
            ctx.fillRect(14, 33, Math.round((164 * pActive.ki) / 100), 4);

            // CPU HP HUD
            ctx.fillStyle = 'rgba(2,6,23,0.75)';
            ctx.fillRect(210, 8, 178, 36);
            ctx.fillStyle = '#fca5a5';
            ctx.font = 'bold 9px monospace';
            ctx.fillText(`CPU${b.activeCpu}: ${resolveCharName(cActive.slotId)}`, 216, 19);
            ctx.fillStyle = '#334155';
            ctx.fillRect(216, 23, 164, 7);
            ctx.fillStyle = '#ef4444';
            ctx.fillRect(216, 23, Math.round((164 * cActive.hp) / cActive.maxHp), 7);

            // Top-right Live Radar Minimap (.TM2)
            ctx.fillStyle = 'rgba(2,6,23,0.82)';
            ctx.fillRect(398, 8, 72, 56);
            ctx.strokeStyle = theme.accent;
            ctx.strokeRect(398, 8, 72, 56);
            ctx.fillStyle = '#38bdf8';
            ctx.fillRect(398 + Math.round((pActive.x / 480) * 66), 8 + Math.round((pActive.y / 272) * 50), 5, 5);
            ctx.fillStyle = '#ef4444';
            ctx.fillRect(398 + Math.round((cActive.x / 480) * 66), 8 + Math.round((cActive.y / 272) * 50), 5, 5);

            // Bottom subtle battle hint
            ctx.fillStyle = 'rgba(2,6,23,0.75)';
            ctx.fillRect(0, 250, 480, 22);
            ctx.fillStyle = '#cbd5e1';
            ctx.font = '9px monospace';
            ctx.fillText(
              `[L] Cambio Tag  [○] Ki Blast  [×] Golpe  [□] Dash  [△] Cargar Ki  [START] Lobby`,
              14,
              264
            );

            if (b.winner) {
              ctx.fillStyle = 'rgba(2,6,23,0.82)';
              ctx.fillRect(90, 86, 300, 96);
              ctx.strokeStyle = b.winner === 'PLAYER' ? '#facc15' : '#ef4444';
              ctx.strokeRect(90, 86, 300, 96);
              ctx.fillStyle = b.winner === 'PLAYER' ? '#facc15' : '#f87171';
              ctx.font = 'bold 16px monospace';
              ctx.fillText(
                b.winner === 'PLAYER' ? '¡VICTORIA TAG TEAM! (+5000 Z)' : 'DERROTA EN ARENA',
                110,
                122
              );
              ctx.fillStyle = '#e2e8f0';
              ctx.font = '10px monospace';
              ctx.fillText('[×] Revancha rápida   [○] Volver al Lobby 256', 112, 154);
            }
          }
        }
      }
      rafId = window.requestAnimationFrame(renderFrame);
    };

    rafId = window.requestAnimationFrame(renderFrame);
    return () => window.cancelAnimationFrame(rafId);
  }, [
    screen,
    bootProgress,
    detectedGameId,
    hwTotalMb,
    hwUserLimitMb,
    charCount,
    mapCount,
    chibiCount,
    sfoHasMemsize,
    requiredActiveRamMb,
    hwRamMode,
    rosterPage,
    cursorInPage,
    assignTarget,
    saveState,
    persistSave,
    activeGameMode,
    initialModConfig?.freeBattlePreset,
    resolveCharName,
    resolveMapName,
    resolveBgmName,
  ]);

  const handleDownloadSaveBin = () => {
    const bin = buildDbzSave256DataBin(
      saveState.gameId,
      saveState.unlockedChars,
      saveState.unlockedMaps,
      saveState.zeni
    );
    downloadBlob(new Blob([bin as unknown as BlobPart]), `${saveState.gameId}_256_SAVE.BIN`);
  };

  const handleDownloadIniAndPatch = () => {
    const { cwCheatIni, ppssppCompatIni } = buildDbzCwCheatAndPpssppIni(saveState.gameId);
    const diff = buildPpsspp256MbUnifiedDiff({
      forceAlways256: true,
      kernelMb: 8,
      exposeCompatFlag: true,
    });
    downloadBlob(new Blob([cwCheatIni], { type: 'text/plain;charset=utf-8' }), `${saveState.gameId}.ini`);
    downloadBlob(new Blob([ppssppCompatIni], { type: 'text/plain;charset=utf-8' }), 'PPSSPP_COMPAT_256MB.ini');
    downloadBlob(new Blob([diff], { type: 'text/plain;charset=utf-8' }), 'ppsspp_256mb_ram.patch');
  };

  const handleVmStep = (cyclesCount: number) => {
    const vm = allegrexVmRef.current;
    if (!vm) return;
    vm.step(cyclesCount);
    setVmSnapshot(vm.getSnapshot());
  };

  const activeSourceFile = pspSourceFiles[selectedSourceIdx] ?? pspSourceFiles[0];

  const handleCopySourceFile = async () => {
    if (!activeSourceFile) return;
    try {
      await navigator.clipboard.writeText(activeSourceFile.content);
      setSourceCopyMsg(`Copiado: ${activeSourceFile.path}`);
      window.setTimeout(() => setSourceCopyMsg(null), 2500);
    } catch {
      setSourceCopyMsg('No se pudo copiar al portapapeles.');
    }
  };

  const handleDownloadSourceFile = () => {
    if (!activeSourceFile) return;
    const fileName = activeSourceFile.path.split('/').pop() || 'psp_core.cpp';
    downloadBlob(new Blob([activeSourceFile.content], { type: 'text/plain;charset=utf-8' }), fileName);
  };

  const handleDownloadSourceZip = () => {
    const zipBlob = buildPspEmulatorSourceZip(detectedGameId, hwTotalMb);
    downloadBlob(zipBlob, `PSP_Core_TagTeam_${detectedGameId}_${hwTotalMb}MB_src.zip`);
  };

  return (
    <div className="space-y-6">
      {/* Header Control Bar */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-slate-900 text-amber-400 dark:bg-blue-600 dark:text-white">
              <Gamepad2 className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Emulador PSP (RAM Modificada) &amp; Port Nativo DBZ Tag Team 256
              </h2>
              <p className="mt-0.5 text-xs text-slate-600 dark:text-slate-300">
                Simula el arranque de <span className="font-mono font-semibold">{detectedGameId}</span> con expansión de RAM (32 / 64 / 128 / 256 MB), streaming desde{' '}
                <span className="font-mono">disc0:/PSP_GAME/DLC/</span> y ejecuta el Port Nativo jugable de 256 personajes, chibis, 46 mapas, minimapa y Save en juego.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {onOpenDbzExpander && (
              <button
                type="button"
                onClick={onOpenDbzExpander}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 cursor-pointer"
              >
                <Sparkles className="h-4 w-4 text-amber-500" />
                Configurar EBOOT/.OLD 256 DLC
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                setScreen('BOOT');
                setBootProgress(0);
              }}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
            >
              <RotateCcw className="h-4 w-4" />
              Reiniciar Consola PSP
            </button>
          </div>
        </div>

        {/* Sub-mode + Hardware RAM switcher */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4 dark:border-slate-800">
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setSubMode('native_port')}
              className={`min-h-[38px] rounded-lg border px-3.5 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                subMode === 'native_port'
                  ? 'border-blue-600 bg-blue-600 text-white'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200'
              }`}
            >
              1. Consola Port Nativo Tag Team 256
            </button>
            <button
              type="button"
              onClick={() => setSubMode('virtual_ram')}
              className={`min-h-[38px] rounded-lg border px-3.5 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                subMode === 'virtual_ram'
                  ? 'border-blue-600 bg-blue-600 text-white'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200'
              }`}
            >
              2. Runtime Virtual RAM Mod &amp; Exportar PPSSPP
            </button>
            <button
              type="button"
              onClick={() => setSubMode('cpu_source')}
              className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border px-3.5 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                subMode === 'cpu_source'
                  ? 'border-blue-600 bg-blue-600 text-white'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200'
              }`}
            >
              <Code2 className="h-3.5 w-3.5" />
              3. CPU MIPS Allegrex &amp; Código Fuente Core PSP
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <label htmlFor="psp-ram-hw" className="text-xs font-semibold text-slate-600 dark:text-slate-300">
              Perfil RAM PSP:
            </label>
            <select
              id="psp-ram-hw"
              value={hwRamMode}
              onChange={(e) => {
                setHwRamMode(e.target.value as EmulatorRamHardwareMode);
                setScreen('BOOT');
                setBootProgress(0);
              }}
              className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-1.5 text-xs font-mono font-semibold text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
            >
              <option value="32MB_PSP1000">PSP-1000 Real (32 MB / 24 MB User)</option>
              <option value="64MB_PSP2000">PSP-2000/3000 Slim (64 MB / 52 MB User)</option>
              <option value="128MB_PPSSPP">PPSSPP Expandido (128 MB / 116 MB User)</option>
              <option value="256MB_MOD_NATIVE">PPSSPP Mod Nativo (256 MB / 248 MB User · 0x18000000)</option>
            </select>
          </div>
        </div>
      </section>

      {subMode === 'native_port' ? (
        <section className="rounded-2xl border border-slate-800 bg-slate-950 p-4 sm:p-6 text-slate-100 shadow-lg">
          {/* Quick Screen Navigation Bar */}
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <button
                type="button"
                onClick={() => setScreen('LOBBY')}
                className={`rounded-lg px-3 py-1.5 font-semibold cursor-pointer ${
                  screen === 'LOBBY' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                Lobby 256 + Chibis
              </button>
              <button
                type="button"
                onClick={() => {
                  setMapCursor(saveState.selectedMap);
                  setScreen('MAPS');
                }}
                className={`rounded-lg px-3 py-1.5 font-semibold cursor-pointer ${
                  screen === 'MAPS' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                46 Mapas + Minimapa + Música
              </button>
              <button
                type="button"
                onClick={startBattleMatch}
                className={`inline-flex items-center gap-1 rounded-lg px-3 py-1.5 font-semibold cursor-pointer ${
                  screen === 'BATTLE' ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <Play className="h-3.5 w-3.5" />
                Combate Tag 2v2
              </button>
              <select
                value={activeGameMode}
                onChange={(e) => {
                  setActiveGameMode(e.target.value);
                  setStatusBanner(`Modo del juego activo: ${e.target.value} (Roster ${charCount} + ${mapCount} Mapas DLC)`);
                }}
                aria-label="Modo de juego oficial"
                className="rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs font-semibold text-amber-300"
              >
                <option value="Batalla Libre (Free Battle)">Batalla Libre (Free Battle)</option>
                <option value="Caminante Dragón (Dragon Walker)">Caminante Dragón (Historia)</option>
                <option value="Selección de Batalla (Batalla 100/Supervivencia)">Selección de Batalla</option>
                <option value="Multijugador (Ad-Hoc)">Multijugador (Ad-Hoc)</option>
                <option value="Personalizar (Puntos D)">Personalizar (Puntos D)</option>
                <option value="Entrenamiento (Training)">Entrenamiento (Training)</option>
                <option value="Opciones (Menú PCK1)">Opciones (Menú PCK1)</option>
              </select>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setAudioMuted((m) => !m)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800 cursor-pointer"
              >
                {audioMuted ? <VolumeX className="h-3.5 w-3.5 text-slate-400" /> : <Volume2 className="h-3.5 w-3.5 text-emerald-400" />}
                {audioMuted ? 'Música BGM Off' : 'Música BGM On'}
              </button>
              <button
                type="button"
                onClick={() => persistSave({ ...saveState, lastSavedAt: new Date().toLocaleTimeString('es-ES') })}
                className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-700 bg-emerald-950/60 px-3 py-1.5 text-xs font-semibold text-emerald-300 hover:bg-emerald-900/60 cursor-pointer"
              >
                <Save className="h-3.5 w-3.5" />
                Guardar Save 256
              </button>
              <button
                type="button"
                onClick={handleDownloadSaveBin}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800 cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                Exportar .BIN
              </button>
            </div>
          </div>

          {/* PSP Hardware Chassis: L/R shoulders + D-Pad + Stick Analógico + 480x272 Screen + Face Buttons */}
          <div className="rounded-3xl border-2 border-slate-800 bg-gradient-to-b from-slate-900 to-slate-950 p-3 sm:p-5">
            {/* Shoulder Buttons Row */}
            <div className="mb-3 flex items-center justify-between px-2">
              <button
                type="button"
                onClick={() => triggerPspButton('L')}
                className={`min-w-[84px] rounded-t-xl rounded-b-md border px-4 py-1.5 text-xs font-mono font-bold active:translate-y-0.5 cursor-pointer ${
                  activeBtnFlash === 'L'
                    ? 'border-cyan-400 bg-cyan-600 text-white'
                    : 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700'
                }`}
              >
                L (Tag / Pág-)
              </button>
              <div className="text-[11px] font-mono text-slate-400 text-center">
                RAM: <span className={isOomForHardware ? 'text-red-400 font-bold' : 'text-emerald-400 font-bold'}>{hwTotalMb} MB</span>
                {' · '}
                Uso: <span className="tabular-nums">{requiredActiveRamMb} MB</span>
                {' · '}
                Save: {saveState.lastSavedAt}
                {connectedGamepadName && (
                  <span className="ml-2 rounded bg-blue-900/70 px-1.5 py-0.5 text-[10px] text-blue-200">
                    Mando Conectado
                  </span>
                )}
              </div>
              <button
                type="button"
                onClick={() => triggerPspButton('R')}
                className={`min-w-[84px] rounded-t-xl rounded-b-md border px-4 py-1.5 text-xs font-mono font-bold active:translate-y-0.5 cursor-pointer ${
                  activeBtnFlash === 'R'
                    ? 'border-cyan-400 bg-cyan-600 text-white'
                    : 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700'
                }`}
              >
                R (Asist / Pág+)
              </button>
            </div>

            <div className="grid grid-cols-1 items-center gap-4 lg:grid-cols-[148px_1fr_148px]">
              {/* Left PSP D-Pad + Interactive Analog Stick */}
              <div className="flex flex-col items-center justify-center gap-3 select-none">
                <div className="flex flex-col items-center gap-1">
                  <button
                    type="button"
                    onClick={() => triggerPspButton('UP')}
                    className={`flex h-10 w-10 items-center justify-center rounded-lg border text-sm font-bold cursor-pointer ${
                      activeBtnFlash === 'UP'
                        ? 'border-blue-400 bg-blue-600 text-white'
                        : 'border-slate-700 bg-slate-800 hover:bg-slate-700'
                    }`}
                    aria-label="Arriba"
                  >
                    ▲
                  </button>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => triggerPspButton('LEFT')}
                      className={`flex h-10 w-10 items-center justify-center rounded-lg border text-sm font-bold cursor-pointer ${
                        activeBtnFlash === 'LEFT'
                          ? 'border-blue-400 bg-blue-600 text-white'
                          : 'border-slate-700 bg-slate-800 hover:bg-slate-700'
                      }`}
                      aria-label="Izquierda"
                    >
                      ◀
                    </button>
                    <div className="h-8 w-8 rounded-full border border-slate-700 bg-slate-900" />
                    <button
                      type="button"
                      onClick={() => triggerPspButton('RIGHT')}
                      className={`flex h-10 w-10 items-center justify-center rounded-lg border text-sm font-bold cursor-pointer ${
                        activeBtnFlash === 'RIGHT'
                          ? 'border-blue-400 bg-blue-600 text-white'
                          : 'border-slate-700 bg-slate-800 hover:bg-slate-700'
                      }`}
                      aria-label="Derecha"
                    >
                      ▶
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => triggerPspButton('DOWN')}
                    className={`flex h-10 w-10 items-center justify-center rounded-lg border text-sm font-bold cursor-pointer ${
                      activeBtnFlash === 'DOWN'
                        ? 'border-blue-400 bg-blue-600 text-white'
                        : 'border-slate-700 bg-slate-800 hover:bg-slate-700'
                    }`}
                    aria-label="Abajo"
                  >
                    ▼
                  </button>
                </div>

                {/* PSP Analog Stick Nub */}
                <div className="flex flex-col items-center gap-1">
                  <div
                    ref={analogStickDomRef}
                    onPointerDown={(e) => {
                      draggingAnalogRef.current = true;
                      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
                      const rect = e.currentTarget.getBoundingClientRect();
                      const maxR = rect.width / 2 - 8;
                      let dx = (e.clientX - (rect.left + rect.width / 2)) / Math.max(1, maxR);
                      let dy = (e.clientY - (rect.top + rect.height / 2)) / Math.max(1, maxR);
                      const l = Math.hypot(dx, dy);
                      if (l > 1) {
                        dx /= l;
                        dy /= l;
                      }
                      analogVectorRef.current = { x: dx, y: dy };
                      setAnalogUiPos({ x: dx, y: dy });
                    }}
                    onPointerMove={(e) => {
                      if (!draggingAnalogRef.current || !analogStickDomRef.current) return;
                      const rect = analogStickDomRef.current.getBoundingClientRect();
                      const maxR = rect.width / 2 - 8;
                      let dx = (e.clientX - (rect.left + rect.width / 2)) / Math.max(1, maxR);
                      let dy = (e.clientY - (rect.top + rect.height / 2)) / Math.max(1, maxR);
                      const l = Math.hypot(dx, dy);
                      if (l > 1) {
                        dx /= l;
                        dy /= l;
                      }
                      analogVectorRef.current = { x: dx, y: dy };
                      setAnalogUiPos({ x: dx, y: dy });
                    }}
                    onPointerUp={() => {
                      if (!draggingAnalogRef.current) return;
                      draggingAnalogRef.current = false;
                      const v = analogVectorRef.current;
                      if (screen !== 'BATTLE' && (Math.abs(v.x) > 0.45 || Math.abs(v.y) > 0.45)) {
                        if (Math.abs(v.x) >= Math.abs(v.y)) {
                          triggerPspButton(v.x > 0 ? 'RIGHT' : 'LEFT');
                        } else {
                          triggerPspButton(v.y > 0 ? 'DOWN' : 'UP');
                        }
                      }
                      analogVectorRef.current = { x: 0, y: 0 };
                      setAnalogUiPos({ x: 0, y: 0 });
                    }}
                    onPointerCancel={() => {
                      draggingAnalogRef.current = false;
                      analogVectorRef.current = { x: 0, y: 0 };
                      setAnalogUiPos({ x: 0, y: 0 });
                    }}
                    className="relative flex h-14 w-14 touch-none items-center justify-center rounded-full border-2 border-slate-700 bg-slate-900 shadow-inner cursor-grab active:cursor-grabbing"
                    title="Stick Analógico PSP (arrastra para mover luchador / cursor)"
                  >
                    <div
                      className="pointer-events-none absolute h-7 w-7 rounded-full border border-slate-500 bg-gradient-to-b from-slate-600 to-slate-800 shadow"
                      style={{
                        transform: `translate(${Math.round(analogUiPos.x * 14)}px, ${Math.round(
                          analogUiPos.y * 14
                        )}px)`,
                      }}
                    />
                  </div>
                  <span className="font-mono text-[9px] text-slate-400">ANALÓGICO</span>
                </div>
              </div>

              {/* 480x272 PSP Native LCD Viewport */}
              <div className="mx-auto w-full max-w-[640px] overflow-hidden rounded-xl border-4 border-slate-800 bg-black shadow-inner">
                <canvas
                  ref={canvasRef}
                  width={480}
                  height={272}
                  className="block h-auto w-full aspect-[16/9]"
                />
              </div>

              {/* Right PSP Action Buttons */}
              <div className="flex flex-col items-center justify-center gap-1 select-none">
                <button
                  type="button"
                  onClick={() => triggerPspButton('TRIANGLE')}
                  className={`flex h-10 w-10 items-center justify-center rounded-full border text-sm font-bold cursor-pointer ${
                    activeBtnFlash === 'TRIANGLE'
                      ? 'border-emerald-300 bg-emerald-600 text-white'
                      : 'border-emerald-700 bg-slate-800 text-emerald-400 hover:bg-slate-700'
                  }`}
                  title="Triángulo (Color / Cargar Ki)"
                >
                  △
                </button>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => triggerPspButton('SQUARE')}
                    className={`flex h-10 w-10 items-center justify-center rounded-full border text-sm font-bold cursor-pointer ${
                      activeBtnFlash === 'SQUARE'
                        ? 'border-pink-300 bg-pink-600 text-white'
                        : 'border-pink-700 bg-slate-800 text-pink-400 hover:bg-slate-700'
                    }`}
                    title="Cuadrado (Mapas / Dash)"
                  >
                    □
                  </button>
                  <button
                    type="button"
                    onClick={() => triggerPspButton('CIRCLE')}
                    className={`flex h-10 w-10 items-center justify-center rounded-full border text-sm font-bold cursor-pointer ${
                      activeBtnFlash === 'CIRCLE'
                        ? 'border-red-300 bg-red-600 text-white'
                        : 'border-red-700 bg-slate-800 text-red-400 hover:bg-slate-700'
                    }`}
                    title="Círculo (Volver / Ki Blast)"
                  >
                    ○
                  </button>
                </div>
                <button
                  type="button"
                  onClick={() => triggerPspButton('CROSS')}
                  className={`flex h-10 w-10 items-center justify-center rounded-full border text-sm font-bold cursor-pointer ${
                    activeBtnFlash === 'CROSS'
                      ? 'border-sky-300 bg-sky-600 text-white'
                      : 'border-sky-700 bg-slate-800 text-sky-400 hover:bg-slate-700'
                  }`}
                  title="Equis (Aceptar / Golpe)"
                >
                  ×
                </button>
              </div>
            </div>

            {/* Bottom PSP Bar: HOME / Audio / SELECT / START / Status */}
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-slate-800 pt-3">
              <div className="text-xs text-slate-400">{statusBanner}</div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerPspButton('HOME')}
                  className={`rounded-md border px-3 py-1 text-[11px] font-mono font-bold cursor-pointer ${
                    activeBtnFlash === 'HOME'
                      ? 'border-cyan-400 bg-cyan-600 text-white'
                      : 'border-slate-700 bg-slate-900 text-cyan-300 hover:bg-slate-800'
                  }`}
                >
                  HOME (Lobby/Mapas)
                </button>
                <button
                  type="button"
                  onClick={() => triggerPspButton('SELECT')}
                  className={`rounded-md border px-3 py-1 text-[11px] font-mono font-bold cursor-pointer ${
                    activeBtnFlash === 'SELECT'
                      ? 'border-amber-400 bg-amber-600 text-white'
                      : 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700'
                  }`}
                >
                  SELECT (Turno P1/P2/CPU)
                </button>
                <button
                  type="button"
                  onClick={() => triggerPspButton('START')}
                  className={`rounded-md border px-3 py-1 text-[11px] font-mono font-bold cursor-pointer ${
                    activeBtnFlash === 'START'
                      ? 'border-emerald-400 bg-emerald-600 text-white'
                      : 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700'
                  }`}
                >
                  START (Combate / Pausa)
                </button>
              </div>
            </div>
          </div>

          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400 font-mono">
            <span>
              Teclado físico y Mando USB/BT compatible: Flechas / Stick Analógico · Z = × · X = ○ · A = □ · S = △ · Q/E = L/R · Enter = START · Shift = SELECT · H = HOME.
            </span>
            <button
              type="button"
              onClick={() => setShowDlcInGameDrawer((v) => !v)}
              className="rounded border border-slate-700 bg-slate-900 px-2.5 py-1 text-[11px] font-semibold text-emerald-300 hover:bg-slate-800 cursor-pointer"
            >
              {showDlcInGameDrawer ? 'Ocultar' : 'Ver'} Contenido DLC Activo en Juego ({charCount} Chars · {mapCount} Mapas · {discoveredDlcPaths.length} Archivos)
            </button>
          </div>

          {showDlcInGameDrawer && (
            <div className="mt-3 rounded-xl border border-slate-800 bg-slate-900/70 p-3 text-xs">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
                <span className="font-semibold text-emerald-300">
                  Sincronización DLC → Juego Activa (Todo lo que aparece en DLC aparece en el juego)
                </span>
                <span className="font-mono text-[11px] text-slate-400">
                  Modo: {activeGameMode} · Menú PCK1: {initialModConfig?.freeBattlePreset ?? 'DARK_TEAM_ENEMY'}
                </span>
              </div>
              <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3 text-[11px]">
                <div className="rounded-lg border border-slate-800 bg-slate-950 p-2">
                  <div className="font-semibold text-blue-300">Personajes y Chibis ({charCount})</div>
                  <div className="mt-1 truncate font-mono text-slate-300">
                    P1: {resolveCharName(saveState.p1Slot)} · P2: {resolveCharName(saveState.p2Slot)}
                  </div>
                  <div className="truncate font-mono text-slate-400">
                    CPU: {resolveCharName(saveState.cpu1Slot)} / {resolveCharName(saveState.cpu2Slot)}
                  </div>
                </div>
                <div className="rounded-lg border border-slate-800 bg-slate-950 p-2">
                  <div className="font-semibold text-amber-300">Mapas DLC y BGM ({mapCount} / {musicTrackCount})</div>
                  <div className="mt-1 truncate font-mono text-slate-300">
                    Escenario #{saveState.selectedMap}: {resolveMapName(saveState.selectedMap)}
                  </div>
                  <div className="truncate font-mono text-slate-400">
                    Música: {resolveBgmName(saveState.selectedBgm)}
                  </div>
                </div>
                <div className="rounded-lg border border-slate-800 bg-slate-950 p-2">
                  <div className="font-semibold text-emerald-300">Rutas DLC Cargadas ({discoveredDlcPaths.length})</div>
                  <div className="mt-1 max-h-14 overflow-auto font-mono text-[10px] text-slate-400">
                    {discoveredDlcPaths.length > 0
                      ? discoveredDlcPaths.slice(0, 12).join(' · ')
                      : '/PSP_GAME/DLC/PERSONAJES · MAPAS · MINIMAPAS · MUSICA · PACKFILE.BIN'}
                  </div>
                </div>
              </div>
            </div>
          )}
        </section>
      ) : (
        /* Sub-mode 2: Virtual RAM Mod Telemetry + ISO/EBOOT Diagnosis + PPSSPP Export */
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <section className="lg:col-span-7 space-y-5 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between gap-3">
              <h3 className="flex items-center gap-2 text-base font-bold text-slate-900 dark:text-white">
                <MemoryStick className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                Mapa de Memoria PSP Modificada (0x08000000 → 0x{((0x08000000 + hwTotalMb * 1024 * 1024) >>> 0).toString(16).toUpperCase()})
              </h3>
              <span className={`font-mono text-xs font-bold ${isOomForHardware ? 'text-red-600 dark:text-red-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                {isOomForHardware ? 'EXCEDE RAM (OOM)' : 'ESPACIO SUFICIENTE'}
              </span>
            </div>

            {isOomForHardware && (
              <div className="flex items-start gap-2.5 rounded-lg border border-red-300 bg-red-50 p-3 text-xs text-red-800 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-300">
                <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
                <div>
                  <strong>Alerta de Hardware Real PSP:</strong> Con {charCount} personajes, {chibiCount} chibis y {mapCount} mapas activos el consumo alcanza{' '}
                  <span className="font-mono font-bold">{requiredActiveRamMb} MB</span>, superando los {hwUserLimitMb} MB libres del perfil actual. Cambia a{' '}
                  <button
                    type="button"
                    onClick={() => setHwRamMode('256MB_MOD_NATIVE')}
                    className="font-bold underline cursor-pointer"
                  >
                    PPSSPP Mod Nativo 256 MB
                  </button>{' '}
                  o exporta el parche C++ para compilar tu build extendida.
                </div>
              </div>
            )}

            {/* Memory Partition Breakdown */}
            <div className="space-y-3 text-xs">
              <div>
                <div className="mb-1 flex justify-between font-mono">
                  <span>Uso Total Activo en Combate 2v2 + Lobby 256</span>
                  <span className="font-bold tabular-nums">
                    {requiredActiveRamMb} MB / {hwUserLimitMb} MB libres
                  </span>
                </div>
                <div className="h-4 w-full overflow-hidden rounded-lg bg-slate-100 dark:bg-slate-800">
                  <div
                    className={`h-full transition-all ${isOomForHardware ? 'bg-red-600' : 'bg-blue-600'}`}
                    style={{ width: `${Math.min(100, Math.round((requiredActiveRamMb / hwUserLimitMb) * 100))}%` }}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                  <div className="text-slate-500">EBOOT / Tablas Lobby + 256 Chibis</div>
                  <div className="mt-1 font-mono font-bold tabular-nums text-slate-900 dark:text-white">
                    {(requiredActiveRamMb - ramBudget.totalActiveMb + ramBudget.tablesAndUiMb).toFixed(1)} MB
                  </div>
                </div>
                <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                  <div className="text-slate-500">4 Luchadores .GMO en Arena (Streaming)</div>
                  <div className="mt-1 font-mono font-bold tabular-nums text-slate-900 dark:text-white">
                    {ramBudget.fightersMb.toFixed(1)} MB
                  </div>
                </div>
                <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                  <div className="text-slate-500">Escenario MAPSxx + Minimapa .TM2</div>
                  <div className="mt-1 font-mono font-bold tabular-nums text-slate-900 dark:text-white">
                    {ramBudget.stageAndMinimapMb.toFixed(1)} MB
                  </div>
                </div>
                <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                  <div className="text-slate-500">Buffer Audio .AT3 ({musicTrackCount} pistas)</div>
                  <div className="mt-1 font-mono font-bold tabular-nums text-slate-900 dark:text-white">
                    {ramBudget.audioAndEffectsMb.toFixed(1)} MB
                  </div>
                </div>
              </div>
            </div>

            {/* Loaded ISO / EBOOT inspection summary */}
            <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/60">
              <h4 className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-white">
                <HardDrive className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                Estado de la ISO / EBOOT.BIN Cargado
              </h4>
              {analysis ? (
                <div className="mt-2 grid grid-cols-2 gap-2 text-xs font-mono">
                  <div>Archivo: <span className="font-semibold">{analysis.sourceName}</span></div>
                  <div>Formato: <span className="font-semibold">{analysis.format}</span></div>
                  <div>DISC_ID: <span className="font-semibold">{analysis.sfoInfo?.discId || detectedGameId}</span></div>
                  <div>MEMSIZE: <span className="font-semibold">{sfoHasMemsize ? '1 (Extendida)' : '0 / N/A'}</span></div>
                  <div>DLC Chars ISO: <span className="font-semibold">{isoDlcCounts.chars}</span></div>
                  <div>DLC Mapas/Mini: <span className="font-semibold">{isoDlcCounts.maps} / {isoDlcCounts.minimaps}</span></div>
                </div>
              ) : (
                <p className="mt-2 text-xs text-slate-600 dark:text-slate-400">
                  Aún no has cargado una ISO o EBOOT.BIN externa. El runtime virtual está usando el perfil DBZ Tag Team 256 ({charCount} Chars, {mapCount} Mapas).
                </p>
              )}
            </div>

            {/* Export Real PPSSPP / Hardware Files */}
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                type="button"
                onClick={handleDownloadSaveBin}
                className="inline-flex min-h-[40px] items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 cursor-pointer"
              >
                <Save className="h-4 w-4" />
                Descargar Save 256 ({saveState.gameId}_256_SAVE.BIN)
              </button>
              <button
                type="button"
                onClick={handleDownloadIniAndPatch}
                className="inline-flex min-h-[40px] items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
              >
                <Download className="h-4 w-4" />
                Descargar Parche RAM 256 MB PPSSPP (.patch + .ini)
              </button>
            </div>
          </section>

          {/* Right Column: Kernel I/O Trace + ISO Audio Player */}
          <section className="lg:col-span-5 space-y-5">
            <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <h3 className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
                <Cpu className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                Traza de Llamadas disc0:/ &amp; Kernel PSP
              </h3>
              <ul className="mt-3 max-h-64 space-y-1.5 overflow-y-auto font-mono text-[11px] text-slate-700 dark:text-slate-300">
                {ioTraceLogs.map((log, idx) => (
                  <li key={idx} className="rounded bg-slate-50 px-2.5 py-1.5 dark:bg-slate-950">
                    {log}
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <h3 className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
                <Music className="h-4 w-4 text-amber-500" />
                Audio DLC (.AT3 / WAV) en ISO Cargada
              </h3>
              {isoAudioEntries.length > 0 ? (
                <ul className="mt-3 max-h-52 space-y-1.5 overflow-y-auto text-xs">
                  {isoAudioEntries.map((f) => (
                    <li
                      key={f.path}
                      className="flex items-center justify-between gap-2 rounded-lg border border-slate-100 px-3 py-1.5 dark:border-slate-800"
                    >
                      <span className="truncate font-mono">{f.path}</span>
                      <button
                        type="button"
                        onClick={() => void handlePlayIsoAudio(f.path)}
                        className="shrink-0 rounded bg-blue-600 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-blue-700 cursor-pointer"
                      >
                        Reproducir
                      </button>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="mt-2 text-xs text-slate-600 dark:text-slate-400">
                  Carga una ISO con carpeta <span className="font-mono">DLC/MUSICA/</span> para listar sus pistas <span className="font-mono">.AT3 / .WAV</span> o activa el sintetizador BGM integrado en la pestaña Port Nativo.
                </p>
              )}
            </div>
          </section>
        </div>
      )}

      {subMode === 'cpu_source' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Left: Live MIPS R4000 Allegrex CPU + HLE Syscalls Interpreter */}
          <section className="lg:col-span-5 space-y-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
                <Cpu className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                Intérprete CPU MIPS R4000 Allegrex (PSP)
              </h3>
              <span className="font-mono text-[11px] font-bold text-emerald-700 dark:text-emerald-400">
                RAM: {hwTotalMb} MB
              </span>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400">
              {vmSnapshot?.loadedElfName?.includes('Stub')
                ? 'Sin ELF32 descifrado cargado (los EBOOT comerciales ~PSP van cifrados): ejecutando programa MIPS32 real de arranque DBZ Tag Team 256 + syscalls HLE.'
                : `ELF32 mapeado en RAM virtual PSP (0x08000000): ${vmSnapshot?.loadedElfName ?? 'EBOOT.BIN'}.`}
            </p>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => handleVmStep(1)}
                disabled={vmSnapshot?.halted}
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-700 disabled:opacity-50 cursor-pointer"
              >
                <StepForward className="h-3.5 w-3.5" />
                1 Paso (Step)
              </button>
              <button
                type="button"
                onClick={() => handleVmStep(10)}
                disabled={vmSnapshot?.halted}
                className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-slate-700 dark:hover:bg-slate-600 cursor-pointer"
              >
                <Play className="h-3.5 w-3.5" />
                Ejecutar 10 Ciclos
              </button>
              <button
                type="button"
                onClick={reloadAllegrexVm}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 cursor-pointer"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                Reiniciar CPU
              </button>
            </div>

            {vmSnapshot && (
              <>
                <div className="grid grid-cols-3 gap-2 rounded-lg border border-slate-200 bg-slate-50 p-2.5 text-[11px] font-mono dark:border-slate-800 dark:bg-slate-950">
                  <div>
                    <span className="text-slate-500">PC:</span>{' '}
                    <span className="font-bold text-blue-600 dark:text-blue-400">
                      0x{vmSnapshot.pc.toString(16).toUpperCase().padStart(8, '0')}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500">Ciclos:</span>{' '}
                    <span className="font-bold tabular-nums">{vmSnapshot.cycles}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">Estado:</span>{' '}
                    <span className={`font-bold ${vmSnapshot.halted ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'}`}>
                      {vmSnapshot.halted ? 'HALT OK' : 'ACTIVO'}
                    </span>
                  </div>
                </div>

                {vmSnapshot.haltReason && (
                  <div className="rounded-lg border border-emerald-300 bg-emerald-50 px-3 py-2 text-xs font-medium text-emerald-800 dark:border-emerald-900/60 dark:bg-emerald-950/30 dark:text-emerald-300">
                    {vmSnapshot.haltReason}
                  </div>
                )}

                {/* Live Disassembly Window */}
                <div>
                  <h4 className="mb-1.5 text-xs font-bold text-slate-800 dark:text-slate-200">
                    Desensamblado MIPS32 en Vivo
                  </h4>
                  <div className="max-h-48 overflow-y-auto rounded-lg border border-slate-800 bg-slate-950 p-2 font-mono text-[11px]">
                    {vmSnapshot.disasmWindow.map((row) => (
                      <div
                        key={row.addr}
                        className={`flex items-center justify-between gap-2 rounded px-2 py-0.5 ${
                          row.isCurrent ? 'bg-blue-600/30 text-amber-300 font-bold' : 'text-slate-300'
                        }`}
                      >
                        <span className="shrink-0 text-slate-400">
                          {row.isCurrent ? '▶ ' : '  '}0x{row.addr.toString(16).toUpperCase().padStart(8, '0')}
                        </span>
                        <span className="shrink-0 text-slate-500">
                          {row.word.toString(16).toUpperCase().padStart(8, '0')}
                        </span>
                        <span className="flex-1 truncate text-right">{row.text}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 32 MIPS GPR Registers */}
                <div>
                  <h4 className="mb-1.5 text-xs font-bold text-slate-800 dark:text-slate-200">
                    Registros GPR Allegrex ($zero – $ra)
                  </h4>
                  <div className="grid grid-cols-2 gap-1 rounded-lg border border-slate-200 bg-slate-50 p-2 font-mono text-[10px] dark:border-slate-800 dark:bg-slate-950 sm:grid-cols-4">
                    {MIPS_REG_NAMES.map((regName, idx) => {
                      const val = vmSnapshot.regs[idx] >>> 0;
                      return (
                        <div
                          key={regName}
                          className={`flex justify-between rounded px-1.5 py-0.5 ${
                            val !== 0 ? 'bg-blue-50 text-blue-800 dark:bg-blue-950/40 dark:text-blue-300 font-semibold' : 'text-slate-500'
                          }`}
                        >
                          <span>{regName}</span>
                          <span className="tabular-nums">{val.toString(16).toUpperCase().padStart(8, '0')}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* HLE Syscall Log */}
                <div>
                  <h4 className="mb-1.5 text-xs font-bold text-slate-800 dark:text-slate-200">
                    Registro Syscalls HLE &amp; Kernel PSP
                  </h4>
                  <ul className="max-h-36 space-y-1 overflow-y-auto font-mono text-[10px] text-slate-700 dark:text-slate-300">
                    {vmSnapshot.syscallLogs.map((log, i) => (
                      <li key={i} className="rounded bg-slate-100 px-2 py-1 dark:bg-slate-800/80">
                        {log}
                      </li>
                    ))}
                  </ul>
                </div>
              </>
            )}
          </section>

          {/* Right: Complete Exportable C++17 / CMake PSP Emulator Core Source Code */}
          <section className="lg:col-span-7 space-y-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
                  <FileCode className="h-4 w-4 text-amber-500" />
                  Código Fuente Core PSP (C++17 / CMake / Emscripten WASM)
                </h3>
                <p className="mt-0.5 text-xs text-slate-600 dark:text-slate-400">
                  Núcleo completo listo para compilar con soporte RAM {hwTotalMb} MB (<span className="font-mono">0x08000000</span>), mapa VRAM 8 MB y redirección <span className="font-mono">USRDIR → DLC</span> para {detectedGameId}.
                </p>
              </div>
              <button
                type="button"
                onClick={handleDownloadSourceZip}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700 cursor-pointer"
              >
                <Download className="h-4 w-4" />
                Descargar Core PSP (.ZIP)
              </button>
            </div>

            {/* Source File Tabs */}
            <div className="flex flex-wrap gap-1.5 border-b border-slate-200 pb-3 dark:border-slate-800">
              {pspSourceFiles.map((file, idx) => (
                <button
                  key={file.path}
                  type="button"
                  onClick={() => setSelectedSourceIdx(idx)}
                  className={`rounded-lg border px-2.5 py-1.5 text-[11px] font-mono font-semibold transition-colors cursor-pointer ${
                    selectedSourceIdx === idx
                      ? 'border-blue-600 bg-blue-600 text-white'
                      : 'border-slate-300 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200'
                  }`}
                >
                  {file.path.split('/').pop()}
                </button>
              ))}
            </div>

            {activeSourceFile && (
              <div className="space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="font-mono text-xs font-bold text-slate-900 dark:text-white">
                      {activeSourceFile.title}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">
                      {activeSourceFile.description}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {sourceCopyMsg && (
                      <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                        {sourceCopyMsg}
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={() => void handleCopySourceFile()}
                      className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 cursor-pointer"
                    >
                      <Copy className="h-3.5 w-3.5" />
                      Copiar
                    </button>
                    <button
                      type="button"
                      onClick={handleDownloadSourceFile}
                      className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 cursor-pointer"
                    >
                      <Download className="h-3.5 w-3.5" />
                      Guardar archivo
                    </button>
                  </div>
                </div>

                <pre className="max-h-[540px] overflow-auto rounded-xl border border-slate-800 bg-slate-950 p-4 font-mono text-[11px] leading-relaxed text-slate-200">
                  <code>{activeSourceFile.content}</code>
                </pre>
              </div>
            )}
          </section>
        </div>
      )}
    </div>
  );
};
