import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  Binary,
  CheckCircle2,
  Copy,
  Download,
  Film,
  FolderX,
  HardDrive,
  Pause,
  Play,
  RefreshCw,
  Replace,
  RotateCcw,
  Sparkles,
  Terminal,
  Trash2,
  Upload,
  Video,
} from 'lucide-react';
import { extractIsoFileBytes } from '../lib/iso9660';
import type { PackerEntry } from '../lib/isoPacker';
import {
  buildTagTeamTrailerPmf,
  createTagTeamTrailerFfmpegScript,
  getTrailerTargetIsoPath,
  inspectPmfHeader,
  PMF_SLOT_PRESETS,
  VIDEO_PMF_FOLDER_CANDIDATES,
  type PmfHeaderInspection,
  type PmfTrailerSlotPreset,
  type PmfTrailerTheme,
  type TagTeamTrailerConfig,
} from '../lib/pmfVideoTools';
import type { EbootAnalysis } from '../lib/types';

export interface IsoVideoEntryView {
  path: string;
  size: number;
  sourceKind: 'PACKER' | 'ISO_BASE' | 'MOD_OVERLAY';
  rawBytes?: Uint8Array;
  packerEntry?: PackerEntry;
}

interface IsoPmfVideoEditorProps {
  analysis: EbootAnalysis | null;
  isoFileBlob?: Blob | null;
  packerEntries?: PackerEntry[];
  packerEmptyDirs?: string[];
  /** Used in Packer mode to add/replace .PMF files directly into packerEntries */
  onUpsertPackerFiles?: (
    entries: Array<{ path: string; data: Uint8Array; origin?: PackerEntry['origin'] }>,
    notice?: string
  ) => void;
  /** Used in Packer mode to remove a single .PMF file or entire video folders */
  onDeleteVideoTargets?: (pathsToRemove: string[], folderPrefixes: string[], notice: string) => void;
  /** Used in DbzTagTeamPanel standalone mode to push generated/cleaned files straight to ISO Packer */
  onSendOverlayToIsoPacker?: (files: Array<{ file: File; relativePath: string }>) => void;
  /** Used in DbzTagTeamPanel to track overlay trailer file + deleted video folder preference */
  overlayTrailerFiles?: Array<{ path: string; data: Uint8Array }>;
  onChangeOverlayTrailerFiles?: (
    files: Array<{ path: string; data: Uint8Array }>,
    stripVideosPmfFolder: boolean
  ) => void;
  stripVideosPmfEnabled?: boolean;
  onToggleStripVideosPmf?: (next: boolean) => void;
  onInspectAssetBytes?: (bytes: Uint8Array, assetPath: string) => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes.toLocaleString('es-ES')} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

const THEME_PALETTES: Record<
  PmfTrailerTheme,
  {
    label: string;
    bgTop: string;
    bgBottom: string;
    accent: string;
    secondary: string;
    badge: string;
  }
> = {
  TAG_TEAM_SAIYAN: {
    label: 'Saiyan Dorado (Tag Team)',
    bgTop: '#0b1636',
    bgBottom: '#1c0c04',
    accent: '#f59e0b',
    secondary: '#38bdf8',
    badge: 'SUPER SAIYAN AURA',
  },
  DLC_256_SHOWCASE: {
    label: 'Showcase 256 DLC (Azul Ki)',
    bgTop: '#06152b',
    bgBottom: '#0b2948',
    accent: '#38bdf8',
    secondary: '#facc15',
    badge: '256 SLOTS EXPANDIDOS',
  },
  DARK_MAJIN_CLASH: {
    label: 'Majin Oscuro (Púrpura/Carmesí)',
    bgTop: '#1b0724',
    bgBottom: '#2d0618',
    accent: '#ec4899',
    secondary: '#a855f7',
    badge: 'MAJIN CLASH',
  },
  CELL_GAMES_ARENA: {
    label: 'Juegos de Cell (Esmeralda/Oro)',
    bgTop: '#071c15',
    bgBottom: '#0f291e',
    accent: '#10b981',
    secondary: '#fbbf24',
    badge: 'TORNEO DE CELL',
  },
};

export const IsoPmfVideoEditor: React.FC<IsoPmfVideoEditorProps> = ({
  analysis,
  isoFileBlob,
  packerEntries,
  packerEmptyDirs = [],
  onUpsertPackerFiles,
  onDeleteVideoTargets,
  onSendOverlayToIsoPacker,
  overlayTrailerFiles = [],
  onChangeOverlayTrailerFiles,
  stripVideosPmfEnabled = true,
  onToggleStripVideosPmf,
  onInspectAssetBytes,
}) => {
  const [trailerConfig, setTrailerConfig] = useState<TagTeamTrailerConfig>({
    slotPreset: 'ICON1_XMB',
    customPath: '/PSP_GAME/USRDIR/MOVIE/TRAILER_TAG_TEAM.PMF',
    title: 'DRAGON BALL Z: TENKAICHI TAG TEAM',
    subtitle: 'TRAILER OFICIAL · 256 PERSONAJES DLC + 46 MAPAS',
    footerTag: 'MOD EDITION · 29.97 FPS · START ISO',
    theme: 'TAG_TEAM_SAIYAN',
    durationSec: 8,
    fps: 29.97,
    width: 144,
    height: 80,
  includeAudioTrack: true,
  });

  const [isPlaying, setIsPlaying] = useState(true);
  const [playheadSec, setPlayheadSec] = useState(0);
  const [recordingWebm, setRecordingWebm] = useState(false);
  const [recordedWebmUrl, setRecordedWebmUrl] = useState<string | null>(null);
  const [uploadedPreviewVideoUrl, setUploadedPreviewVideoUrl] = useState<string | null>(null);
  const [uploadedPreviewName, setUploadedPreviewName] = useState<string | null>(null);
  const [selectedInspection, setSelectedInspection] = useState<PmfHeaderInspection | null>(null);
  const [selectedVideoBytes, setSelectedVideoBytes] = useState<{
    bytes: Uint8Array;
    path: string;
  } | null>(null);
  const [statusNotice, setStatusNotice] = useState<string | null>(null);
  const [showFfmpeg, setShowFfmpeg] = useState(false);
  const [copiedFfmpeg, setCopiedFfmpeg] = useState(false);
  const [replaceTargetPath, setReplaceTargetPath] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const uploadRealPmfInputRef = useRef<HTMLInputElement | null>(null);
  const uploadPreviewMp4InputRef = useRef<HTMLInputElement | null>(null);
  const replaceSingleInputRef = useRef<HTMLInputElement | null>(null);

  // Sync resolution when slot preset changes
  const handleSelectSlotPreset = (presetId: PmfTrailerSlotPreset) => {
    const found = PMF_SLOT_PRESETS.find((p) => p.id === presetId);
    setTrailerConfig((prev) => ({
      ...prev,
      slotPreset: presetId,
      width: found?.width ?? 480,
      height: found?.height ?? 272,
    }));
  };

  // Discover all .PMF files and video folders in Packer or Loaded ISO or Overlay
  const detectedVideos = useMemo<IsoVideoEntryView[]>(() => {
    const map = new Map<string, IsoVideoEntryView>();

    if (packerEntries && packerEntries.length > 0) {
      for (const e of packerEntries) {
        const up = e.path.toUpperCase();
        if (up.endsWith('.PMF') || up.includes('VIDEOS_PMF') || up.includes('/MOVIE/')) {
          map.set(up, {
            path: e.path,
            size: e.size,
            sourceKind: 'PACKER',
            rawBytes: e.source instanceof Uint8Array ? e.source : undefined,
            packerEntry: e,
          });
        }
      }
    } else if (analysis?.isoInfo) {
      for (const f of analysis.isoInfo.files) {
        if (f.isDirectory) continue;
        const up = f.path.toUpperCase();
        if (up.endsWith('.PMF') || up.includes('VIDEOS_PMF') || up.includes('/MOVIE/')) {
          map.set(up, {
            path: f.path,
            size: f.size,
            sourceKind: 'ISO_BASE',
          });
        }
      }
    }

    for (const ov of overlayTrailerFiles) {
      map.set(ov.path.toUpperCase(), {
        path: ov.path,
        size: ov.data.length,
        sourceKind: 'MOD_OVERLAY',
        rawBytes: ov.data,
      });
    }

    return Array.from(map.values()).sort((a, b) => a.path.localeCompare(b.path));
  }, [packerEntries, analysis?.isoInfo, overlayTrailerFiles]);

  const detectedVideoFolders = useMemo(() => {
    const dirs = new Set<string>();
    const checkDir = (dirPath: string) => {
      const up = dirPath.toUpperCase();
      if (
        up.includes('VIDEOS_PMF') ||
        up.endsWith('/VIDEOS') ||
        up.includes('/VIDEOS/') ||
        up.endsWith('/MOVIE') ||
        up.includes('/MOVIE/')
      ) {
        dirs.add(dirPath);
      }
    };

    for (const v of detectedVideos) {
      const parts = v.path.split('/').filter(Boolean);
      for (let i = 1; i < parts.length; i++) {
        checkDir('/' + parts.slice(0, i).join('/'));
      }
    }
    for (const empty of packerEmptyDirs) {
      checkDir(empty);
    }
    if (analysis?.isoInfo) {
      for (const f of analysis.isoInfo.files) {
        if (f.isDirectory) checkDir(f.path);
      }
    }
    return Array.from(dirs).sort();
  }, [detectedVideos, packerEmptyDirs, analysis?.isoInfo]);

  const totalVideoBytes = useMemo(
    () => detectedVideos.reduce((acc, v) => acc + v.size, 0),
    [detectedVideos]
  );

  // Playback loop for the Canvas trailer preview
  useEffect(() => {
    if (!isPlaying || uploadedPreviewVideoUrl) return;
    let rafId = 0;
    let lastTs = performance.now();
    const step = (now: number) => {
      const dt = Math.min(0.1, (now - lastTs) / 1000);
      lastTs = now;
      setPlayheadSec((prev) => {
        const next = prev + dt;
        return next >= trailerConfig.durationSec ? 0 : next;
      });
      rafId = requestAnimationFrame(step);
    };
    rafId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafId);
  }, [isPlaying, trailerConfig.durationSec, uploadedPreviewVideoUrl]);

  // Draw DBZ Tenkaichi Tag Team Trailer Frame onto Canvas (always 480x272 preview clarity, guides for 144x80 XMB)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    const palette = THEME_PALETTES[trailerConfig.theme];
    const t = playheadSec;
    const dur = Math.max(1, trailerConfig.durationSec);
    const progress = (t % dur) / dur;

    // Background gradient
    const grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, palette.bgTop);
    grad.addColorStop(1, palette.bgBottom);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // Dynamic anime speed lines radiating from center
    ctx.save();
    ctx.translate(W * 0.5, H * 0.5);
    for (let i = 0; i < 36; i++) {
      const angle = (i / 36) * Math.PI * 2 + t * 0.45;
      const rInner = 45 + ((i * 19 + t * 140) % 70);
      const rOuter = 290;
      ctx.strokeStyle = i % 3 === 0 ? `${palette.accent}55` : `${palette.secondary}30`;
      ctx.lineWidth = i % 4 === 0 ? 2 : 1;
      ctx.beginPath();
      ctx.moveTo(Math.cos(angle) * rInner, Math.sin(angle) * rInner);
      ctx.lineTo(Math.cos(angle) * rOuter, Math.sin(angle) * rOuter);
      ctx.stroke();
    }
    ctx.restore();

    // Pulsing Saiyan Ki Aura Rings
    const pulse = 0.5 + 0.5 * Math.sin(t * 6.5);
    const aura = ctx.createRadialGradient(W * 0.5, H * 0.48, 8, W * 0.5, H * 0.48, 90 + pulse * 48);
    aura.addColorStop(0, `${palette.accent}aa`);
    aura.addColorStop(0.5, `${palette.secondary}44`);
    aura.addColorStop(1, 'transparent');
    ctx.fillStyle = aura;
    ctx.fillRect(0, 0, W, H);

    // Energy clash / Tag Team 2v2 silhouette badges shifting over timeline
    const phase = progress < 0.33 ? 0 : progress < 0.66 ? 1 : 2;
    const fighters = [
      ['GOKU BASE / SSJ3', 'VEGETA SSJ2'],
      ['GOHAN DEFINITIVO', 'VEGETTO SS1'],
      ['CELL PERFECTO', 'PEQUEÑO BOO'],
    ][phase];

    ctx.fillStyle = 'rgba(15, 23, 42, 0.72)';
    ctx.strokeStyle = palette.accent;
    ctx.lineWidth = 1.5;

    // Left tag card
    const slideIn = Math.sin(Math.min(1, ((progress * 3) % 1) * 2.5) * (Math.PI / 2));
    const cardW = 148;
    const cardH = 34;
    ctx.fillRect(18 * slideIn, 24, cardW, cardH);
    ctx.strokeRect(18 * slideIn, 24, cardW, cardH);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 10px monospace';
    ctx.fillText(`J1 · ${fighters[0]}`, 26 * slideIn, 45);

    // Right tag card
    ctx.fillStyle = 'rgba(15, 23, 42, 0.72)';
    const rx = W - cardW - 18 * slideIn;
    ctx.fillRect(rx, 24, cardW, cardH);
    ctx.strokeRect(rx, 24, cardW, cardH);
    ctx.fillStyle = '#ffffff';
    ctx.fillText(`J2 · ${fighters[1]}`, rx + 10, 45);

    // Central VS Emblem
    ctx.save();
    ctx.translate(W * 0.5, H * 0.42);
    ctx.rotate(Math.sin(t * 2) * 0.04);
    ctx.fillStyle = palette.accent;
    ctx.font = '900 32px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('TAG TEAM', 0, -4);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 13px monospace';
    ctx.fillText(palette.badge, 0, 18);
    ctx.restore();

    // Main Title Banner
    ctx.fillStyle = 'rgba(2, 6, 23, 0.82)';
    ctx.fillRect(0, H - 84, W, 62);
    ctx.fillStyle = palette.accent;
    ctx.fillRect(0, H - 84, W, 2);
    ctx.fillRect(0, H - 22, W, 2);

    ctx.textAlign = 'center';
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 16px sans-serif';
    ctx.fillText(trailerConfig.title.slice(0, 44), W * 0.5, H - 56);

    ctx.fillStyle = palette.secondary;
    ctx.font = 'bold 11px monospace';
    ctx.fillText(trailerConfig.subtitle.slice(0, 56), W * 0.5, H - 36);

    // Bottom ISO Slot Ticker
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`${trailerConfig.footerTag}`, 12, H - 7);
    ctx.textAlign = 'right';
    ctx.fillStyle = palette.accent;
    ctx.fillText(
      `${trailerConfig.width}x${trailerConfig.height} · ${t.toFixed(2)}s/${dur.toFixed(0)}s`,
      W - 12,
      H - 7
    );
    ctx.textAlign = 'left';

    // XMB ICON1 safe box indicator if 144x80 preset is chosen
    if (trailerConfig.width === 144) {
      ctx.strokeStyle = 'rgba(250, 204, 21, 0.5)';
      ctx.setLineDash([4, 3]);
      ctx.strokeRect(10, 10, W - 20, H - 20);
      ctx.setLineDash([]);
    }
  }, [playheadSec, trailerConfig]);

  // Cleanup URLs on unmount
  useEffect(() => {
    return () => {
      if (recordedWebmUrl) URL.revokeObjectURL(recordedWebmUrl);
      if (uploadedPreviewVideoUrl) URL.revokeObjectURL(uploadedPreviewVideoUrl);
    };
  }, [recordedWebmUrl, uploadedPreviewVideoUrl]);

  const readVideoBytes = async (v: IsoVideoEntryView): Promise<Uint8Array | null> => {
    if (v.rawBytes) return v.rawBytes;
    if (v.packerEntry) {
      if (v.packerEntry.source instanceof Uint8Array) return v.packerEntry.source;
      if (v.packerEntry.source instanceof Blob) {
        return new Uint8Array(await v.packerEntry.source.arrayBuffer());
      }
    }
    if (v.sourceKind === 'ISO_BASE' && isoFileBlob && analysis?.isoInfo) {
      const entry = analysis.isoInfo.files.find(
        (f) => !f.isDirectory && f.path.toUpperCase() === v.path.toUpperCase()
      );
      if (entry) return extractIsoFileBytes(isoFileBlob, entry);
    }
    return null;
  };

  const handleInspectVideo = async (v: IsoVideoEntryView) => {
    const bytes = await readVideoBytes(v);
    if (!bytes) {
      setStatusNotice(`No se pudieron leer los bytes de ${v.path}.`);
      return;
    }
    setSelectedVideoBytes({ bytes, path: v.path });
    setSelectedInspection(inspectPmfHeader(bytes, v.path));
  };

  const handleDownloadVideo = async (v: IsoVideoEntryView) => {
    const bytes = await readVideoBytes(v);
    if (!bytes) return;
    const name = v.path.split('/').pop() || 'VIDEO.PMF';
    downloadBlob(new Blob([bytes as unknown as BlobPart], { type: 'application/octet-stream' }), name);
  };

  const handleDeleteAllVideosFolder = () => {
    const folderPrefixes = Array.from(
      new Set([
        ...VIDEO_PMF_FOLDER_CANDIDATES,
        ...detectedVideoFolders.filter(
          (d) =>
            d.toUpperCase().includes('VIDEOS_PMF') ||
            d.toUpperCase().endsWith('/VIDEOS') ||
            d.toUpperCase().includes('/MOVIE')
        ),
      ])
    );
    const matchingFiles = detectedVideos
      .filter((v) => {
        const up = v.path.toUpperCase();
        return folderPrefixes.some((p) => up.startsWith(`${p.toUpperCase()}/`));
      })
      .map((v) => v.path);

    if (onDeleteVideoTargets) {
      onDeleteVideoTargets(
        matchingFiles,
        folderPrefixes,
        `Carpeta VIDEOS_PMF / MOVIE borrada de la ISO (${matchingFiles.length} archivos eliminados).`
      );
    }

    if (onChangeOverlayTrailerFiles) {
      const kept = overlayTrailerFiles.filter((f) => {
        const up = f.path.toUpperCase();
        return !folderPrefixes.some((p) => up.startsWith(`${p.toUpperCase()}/`));
      });
      onChangeOverlayTrailerFiles(kept, true);
    }
    onToggleStripVideosPmf?.(true);
    setStatusNotice(
      `Carpeta VIDEOS_PMF eliminada (${matchingFiles.length} archivo(s) borrados). Ahora puedes crear o insertar el Trailer Tag Team al inicio de la ISO.`
    );
  };

  const handleDeleteSingleFolder = (folderPath: string) => {
    const upPrefix = folderPath.toUpperCase().replace(/\/+$/, '');
    const filesInFolder = detectedVideos
      .filter((v) => v.path.toUpperCase().startsWith(`${upPrefix}/`))
      .map((v) => v.path);

    if (onDeleteVideoTargets) {
      onDeleteVideoTargets(
        filesInFolder,
        [folderPath],
        `Carpeta ${folderPath}/ borrada (${filesInFolder.length} archivos eliminados de la ISO).`
      );
    }
    if (onChangeOverlayTrailerFiles) {
      const kept = overlayTrailerFiles.filter(
        (f) => !f.path.toUpperCase().startsWith(`${upPrefix}/`)
      );
      onChangeOverlayTrailerFiles(kept, true);
    }
    setStatusNotice(`Carpeta ${folderPath}/ eliminada de la cola ISO.`);
  };

  const handleDeleteSingleFile = (filePath: string) => {
    if (onDeleteVideoTargets) {
      onDeleteVideoTargets([filePath], [], `Archivo de video ${filePath} eliminado de la ISO.`);
    }
    if (onChangeOverlayTrailerFiles) {
      onChangeOverlayTrailerFiles(
        overlayTrailerFiles.filter((f) => f.path.toUpperCase() !== filePath.toUpperCase()),
        stripVideosPmfEnabled
      );
    }
    setStatusNotice(`Video ${filePath} eliminado de la ISO.`);
  };

  const handleCreateTagTeamTrailerInIso = (alsoDeleteVideosPmfFolder: boolean) => {
    const pmfBytes = buildTagTeamTrailerPmf(trailerConfig);
    const targetPath = getTrailerTargetIsoPath(trailerConfig);
    const inspection = inspectPmfHeader(pmfBytes, targetPath);
    setSelectedVideoBytes({ bytes: pmfBytes, path: targetPath });
    setSelectedInspection(inspection);

    if (alsoDeleteVideosPmfFolder) {
      handleDeleteAllVideosFolder();
    }

    if (onUpsertPackerFiles) {
      onUpsertPackerFiles(
        [{ path: targetPath, data: pmfBytes, origin: 'GENERATED' }],
        `Trailer Tag Team creado al inicio de la ISO en ${targetPath} (${formatBytes(pmfBytes.length)}, ${trailerConfig.width}×${trailerConfig.height}).`
      );
    }

    if (onChangeOverlayTrailerFiles) {
      const nextMap = new Map(overlayTrailerFiles.map((f) => [f.path.toUpperCase(), f]));
      if (alsoDeleteVideosPmfFolder) {
        for (const k of Array.from(nextMap.keys())) {
          if (k.includes('VIDEOS_PMF') || k.includes('/MOVIE/')) {
            nextMap.delete(k);
          }
        }
      }
      nextMap.set(targetPath.toUpperCase(), { path: targetPath, data: pmfBytes });
      onChangeOverlayTrailerFiles(Array.from(nextMap.values()), true);
    }

    setStatusNotice(
      alsoDeleteVideosPmfFolder
        ? `Carpeta VIDEOS_PMF borrada + Trailer Tag Team creado al inicio de la ISO en ${targetPath} (${formatBytes(pmfBytes.length)}).`
        : `Trailer Tag Team creado e inyectado en ${targetPath} (${formatBytes(pmfBytes.length)}).`
    );
  };

  const handleUploadRealPmfForSlot = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const bytes = new Uint8Array(await file.arrayBuffer());
    const targetPath = getTrailerTargetIsoPath(trailerConfig);
    const inspection = inspectPmfHeader(bytes, file.name);
    setSelectedVideoBytes({ bytes, path: targetPath });
    setSelectedInspection(inspection);

    if (!inspection.isValidPsmf && /\.(mp4|webm|mkv|avi|mov)$/i.test(file.name)) {
      if (uploadedPreviewVideoUrl) URL.revokeObjectURL(uploadedPreviewVideoUrl);
      setUploadedPreviewVideoUrl(URL.createObjectURL(file));
      setUploadedPreviewName(file.name);
      setStatusNotice(
        `Cargado "${file.name}" en el previsualizador del Editor. Para inyectarlo en PSP, conviértelo primero a .PMF (PSMF0014) con el comando FFmpeg + UmdStreamComposer.`
      );
      return;
    }

    if (onUpsertPackerFiles) {
      onUpsertPackerFiles(
        [{ path: targetPath, data: bytes, origin: 'LOCAL_FILE' }],
        `Video real ${file.name} (${formatBytes(bytes.length)}) inyectado en ${targetPath}.`
      );
    }
    if (onChangeOverlayTrailerFiles) {
      const next = overlayTrailerFiles.filter(
        (f) => f.path.toUpperCase() !== targetPath.toUpperCase()
      );
      next.push({ path: targetPath, data: bytes });
      onChangeOverlayTrailerFiles(next, true);
    }
    setStatusNotice(
      `Video .PMF "${file.name}" inyectado en ${targetPath} (${inspection.summary}).`
    );
  };

  const handleReplaceSingleFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !replaceTargetPath) return;
    const bytes = new Uint8Array(await file.arrayBuffer());
    const inspection = inspectPmfHeader(bytes, replaceTargetPath);
    setSelectedVideoBytes({ bytes, path: replaceTargetPath });
    setSelectedInspection(inspection);

    if (onUpsertPackerFiles) {
      onUpsertPackerFiles(
        [{ path: replaceTargetPath, data: bytes, origin: 'LOCAL_FILE' }],
        `Reemplazado ${replaceTargetPath} con ${file.name} (${formatBytes(bytes.length)}).`
      );
    }
    if (onChangeOverlayTrailerFiles) {
      const next = overlayTrailerFiles.filter(
        (f) => f.path.toUpperCase() !== replaceTargetPath.toUpperCase()
      );
      next.push({ path: replaceTargetPath, data: bytes });
      onChangeOverlayTrailerFiles(next, stripVideosPmfEnabled);
    }
    setStatusNotice(`Reemplazado ${replaceTargetPath} con ${file.name}.`);
    setReplaceTargetPath(null);
  };

  const handlePreviewMp4Upload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (uploadedPreviewVideoUrl) URL.revokeObjectURL(uploadedPreviewVideoUrl);
    setUploadedPreviewVideoUrl(URL.createObjectURL(file));
    setUploadedPreviewName(file.name);
    setStatusNotice(`Previsualizando "${file.name}" en la pantalla PSP del Editor de Videos.`);
  };

  const handleRecordTrailerWebm = () => {
    const canvas = canvasRef.current;
    if (!canvas || typeof MediaRecorder === 'undefined') {
      setStatusNotice('Tu navegador no soporta grabación MediaRecorder desde Canvas.');
      return;
    }
    setUploadedPreviewVideoUrl(null);
    setIsPlaying(true);
    setPlayheadSec(0);
    setRecordingWebm(true);

    const stream = canvas.captureStream(30);
    const mime = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
      ? 'video/webm;codecs=vp9'
      : 'video/webm';
    const recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 1_500_000 });
    const chunks: BlobPart[] = [];
    recorder.ondataavailable = (ev) => {
      if (ev.data.size > 0) chunks.push(ev.data);
    };
    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      const url = URL.createObjectURL(blob);
      setRecordedWebmUrl((prev) => {
        if (prev) URL.revokeObjectURL(prev);
        return url;
      });
      setRecordingWebm(false);
      downloadBlob(
        blob,
        trailerConfig.slotPreset === 'ICON1_XMB' ? 'trailer_icon1.webm' : 'trailer_tag_team.webm'
      );
      setStatusNotice(
        `Trailer grabado y descargado como .WEBM (${formatBytes(blob.size)}). Convierte a .PMF con FFmpeg + UmdStreamComposer y súbelo si deseas video real en hardware PSP.`
      );
    };
    recorder.start();
    const ms = Math.min(8000, Math.max(2500, trailerConfig.durationSec * 1000));
    setTimeout(() => {
      if (recorder.state !== 'inactive') recorder.stop();
    }, ms);
  };

  const ffmpegScript = useMemo(() => createTagTeamTrailerFfmpegScript(trailerConfig), [trailerConfig]);

  const handleCopyFfmpeg = async () => {
    try {
      await navigator.clipboard.writeText(ffmpegScript);
      setCopiedFfmpeg(true);
      setTimeout(() => setCopiedFfmpeg(false), 1500);
    } catch {
      // ignore
    }
  };

  return (
    <div className="space-y-6">
      <input
        ref={uploadRealPmfInputRef}
        type="file"
        accept=".pmf,.mps,.mp4,.webm,.mkv,.avi,*/*"
        onChange={(e) => void handleUploadRealPmfForSlot(e)}
        className="hidden"
      />
      <input
        ref={uploadPreviewMp4InputRef}
        type="file"
        accept="video/*,.mp4,.webm,.mkv,.avi,.mov"
        onChange={handlePreviewMp4Upload}
        className="hidden"
      />
      <input
        ref={replaceSingleInputRef}
        type="file"
        accept=".pmf,.mps,*/*"
        onChange={(e) => void handleReplaceSingleFileSelected(e)}
        className="hidden"
      />

      {/* Top Header & 1-Click Clean VIDEOS_PMF + Create Start Trailer */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-3xl">
            <h2 className="flex items-center gap-2 text-base font-semibold text-slate-900 dark:text-white">
              <Film className="h-5 w-5 text-amber-500" />
              Editor de Videos <span className="font-mono">.PMF</span> para la ISO (Limpiar <span className="font-mono">VIDEOS_PMF</span> + Trailer Tag Team al Inicio)
            </h2>
            <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
              Borra la carpeta <span className="font-mono">VIDEOS_PMF</span> o videos DLC sobrantes de la ISO y crea o inserta un video <span className="font-mono">.PMF</span> del <strong>Trailer Dragon Ball Z: Tenkaichi Tag Team</strong> directamente al inicio de la ISO (<span className="font-mono">/PSP_GAME/ICON1.PMF</span> para el menú XMB o <span className="font-mono">/PSP_GAME/USRDIR/MOVIE/OPENING_TRAILER.PMF</span> al arrancar el juego).
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleDeleteAllVideosFolder}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-red-300 bg-red-50 px-3.5 py-2 text-xs font-semibold text-red-700 hover:bg-red-100 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-300 whitespace-nowrap cursor-pointer"
            >
              <FolderX className="h-4 w-4" />
              Borrar Carpeta VIDEOS_PMF
            </button>
            <button
              type="button"
              onClick={() => handleCreateTagTeamTrailerInIso(true)}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-amber-600 px-4 py-2 text-xs font-semibold text-white hover:bg-amber-700 whitespace-nowrap cursor-pointer"
            >
              <Sparkles className="h-4 w-4" />
              Borrar VIDEOS_PMF + Crear Trailer al Inicio ISO
            </button>
            {onSendOverlayToIsoPacker && overlayTrailerFiles.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  const items = overlayTrailerFiles.map((f) => {
                    const cleanRel = f.path.replace(/^\/+/, '');
                    const name = cleanRel.split('/').pop() || 'TRAILER.PMF';
                    return {
                      file: new File([f.data as unknown as BlobPart], name, {
                        type: 'application/octet-stream',
                      }),
                      relativePath: cleanRel,
                    };
                  });
                  onSendOverlayToIsoPacker(items);
                }}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 whitespace-nowrap cursor-pointer"
              >
                <HardDrive className="h-4 w-4" />
                Enviar al Empaquetador ISO
              </button>
            )}
          </div>
        </div>

        {/* Video KPI Summary */}
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4 text-xs">
          <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
            <div className="text-slate-500 dark:text-slate-400">Videos .PMF en ISO</div>
            <div className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums dark:text-white">
              {detectedVideos.length} archivos
            </div>
          </div>
          <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
            <div className="text-slate-500 dark:text-slate-400">Peso Total Videos</div>
            <div className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums dark:text-white">
              {formatBytes(totalVideoBytes)}
            </div>
          </div>
          <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
            <div className="text-slate-500 dark:text-slate-400">Carpetas de Video</div>
            <div className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums dark:text-white">
              {detectedVideoFolders.length} carpetas
            </div>
          </div>
          <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
            <div className="text-slate-500 dark:text-slate-400">Destino Trailer Inicio</div>
            <div className="mt-1 truncate font-mono text-xs font-bold text-amber-600 dark:text-amber-400" title={getTrailerTargetIsoPath(trailerConfig)}>
              {getTrailerTargetIsoPath(trailerConfig)}
            </div>
          </div>
        </div>

        {onToggleStripVideosPmf && (
          <label className="mt-3 flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={stripVideosPmfEnabled}
              onChange={(e) => onToggleStripVideosPmf(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 text-amber-600 focus:ring-amber-500"
            />
            Excluir automáticamente la carpeta <span className="font-mono">/DLC/VIDEOS_PMF</span> al generar ZIP o enviar a la ISO (dejar solo el Trailer al inicio).
          </label>
        )}

        {statusNotice && (
          <div className="mt-3 rounded-lg border border-emerald-200 bg-emerald-50/70 px-3.5 py-2 text-xs text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-200">
            {statusNotice}
          </div>
        )}
      </section>

      {/* Main 2-Column Studio: Left = Interactive PSP Trailer Canvas + Controls, Right = ISO Video List & PSMF Inspector */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left Column: Tag Team Trailer Creator & Canvas Preview */}
        <section className="lg:col-span-6 space-y-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
              <Video className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              Estudio de Trailer Tag Team (Pantalla PSP 480×272 / ICON1)
            </h3>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => uploadPreviewMp4InputRef.current?.click()}
                className="inline-flex min-h-[30px] items-center gap-1 rounded border border-slate-300 px-2.5 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
              >
                <Upload className="h-3 w-3" />
                Probar .MP4/.WEBM
              </button>
              {uploadedPreviewVideoUrl && (
                <button
                  type="button"
                  onClick={() => {
                    URL.revokeObjectURL(uploadedPreviewVideoUrl);
                    setUploadedPreviewVideoUrl(null);
                    setUploadedPreviewName(null);
                  }}
                  className="inline-flex min-h-[30px] items-center gap-1 rounded border border-slate-300 px-2 py-1 text-[11px] text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 cursor-pointer"
                >
                  <RefreshCw className="h-3 w-3" />
                  Volver a Canvas
                </button>
              )}
            </div>
          </div>

          {/* PSP Screen Frame */}
          <div className="overflow-hidden rounded-xl border-4 border-slate-800 bg-slate-950 shadow-inner">
            {uploadedPreviewVideoUrl ? (
              <div className="relative aspect-[16/9] w-full bg-black">
                <video
                  src={uploadedPreviewVideoUrl}
                  controls
                  autoPlay
                  loop
                  className="h-full w-full object-contain"
                />
                <div className="absolute left-2 top-2 rounded bg-black/75 px-2 py-0.5 font-mono text-[10px] text-amber-300">
                  Preview: {uploadedPreviewName}
                </div>
              </div>
            ) : (
              <canvas
                ref={canvasRef}
                width={480}
                height={272}
                className="block aspect-[16/9] w-full bg-slate-950"
              />
            )}

            {!uploadedPreviewVideoUrl && (
              <div className="flex items-center justify-between gap-3 border-t border-slate-800 bg-slate-900 px-3 py-2 text-xs text-slate-200">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setIsPlaying((p) => !p)}
                    className="inline-flex h-7 w-7 items-center justify-center rounded bg-slate-800 hover:bg-slate-700 cursor-pointer"
                    aria-label={isPlaying ? 'Pausar trailer' : 'Reproducir trailer'}
                  >
                    {isPlaying ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPlayheadSec(0)}
                    className="inline-flex h-7 w-7 items-center justify-center rounded bg-slate-800 hover:bg-slate-700 cursor-pointer"
                    aria-label="Reiniciar trailer"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                  </button>
                </div>

                <input
                  type="range"
                  min={0}
                  max={trailerConfig.durationSec}
                  step={0.05}
                  value={playheadSec}
                  onChange={(e) => {
                    setIsPlaying(false);
                    setPlayheadSec(Number(e.target.value));
                  }}
                  aria-label="Línea de tiempo del trailer"
                  className="flex-1 accent-amber-500 cursor-pointer"
                />

                <span className="font-mono text-[11px] tabular-nums text-amber-300">
                  {playheadSec.toFixed(2)}s / {trailerConfig.durationSec}s
                </span>
              </div>
            )}
          </div>

          {/* Trailer Configuration Form */}
          <div className="space-y-3 text-xs">
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300">
                Slot al inicio de la ISO donde se colocará el Trailer
              </label>
              <select
                value={trailerConfig.slotPreset}
                onChange={(e) => handleSelectSlotPreset(e.target.value as PmfTrailerSlotPreset)}
                className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                {PMF_SLOT_PRESETS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.label}
                  </option>
                ))}
              </select>
              <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
                {PMF_SLOT_PRESETS.find((p) => p.id === trailerConfig.slotPreset)?.description}
              </p>
            </div>

            {trailerConfig.slotPreset === 'GAME_MOVIE_CUSTOM' && (
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300">
                  Ruta personalizada dentro de la ISO
                </label>
                <input
                  type="text"
                  value={trailerConfig.customPath}
                  onChange={(e) =>
                    setTrailerConfig((prev) => ({ ...prev, customPath: e.target.value }))
                  }
                  className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>
            )}

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300">
                  Tema Visual del Trailer
                </label>
                <select
                  value={trailerConfig.theme}
                  onChange={(e) =>
                    setTrailerConfig((prev) => ({
                      ...prev,
                      theme: e.target.value as PmfTrailerTheme,
                    }))
                  }
                  className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                >
                  {Object.entries(THEME_PALETTES).map(([id, pal]) => (
                    <option key={id} value={id}>
                      {pal.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300">
                  Duración Trailer (segundos)
                </label>
                <input
                  type="number"
                  min={3}
                  max={60}
                  value={trailerConfig.durationSec}
                  onChange={(e) =>
                    setTrailerConfig((prev) => ({
                      ...prev,
                      durationSec: Math.max(3, Math.min(60, Number(e.target.value) || 8)),
                    }))
                  }
                  className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 tabular-nums dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300">
                  Título en Trailer
                </label>
                <input
                  type="text"
                  value={trailerConfig.title}
                  onChange={(e) =>
                    setTrailerConfig((prev) => ({ ...prev, title: e.target.value }))
                  }
                  className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300">
                  Subtítulo / Roster
                </label>
                <input
                  type="text"
                  value={trailerConfig.subtitle}
                  onChange={(e) =>
                    setTrailerConfig((prev) => ({ ...prev, subtitle: e.target.value }))
                  }
                  className="mt-1 min-h-[36px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => handleCreateTagTeamTrailerInIso(false)}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
              >
                <Sparkles className="h-3.5 w-3.5" />
                Crear e Inyectar .PMF al Inicio ISO
              </button>
              <button
                type="button"
                onClick={() => uploadRealPmfInputRef.current?.click()}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-blue-600 bg-white px-3.5 py-2 text-xs font-semibold text-blue-600 hover:bg-blue-50 dark:border-blue-400 dark:bg-slate-900 dark:text-blue-400 cursor-pointer"
              >
                <Upload className="h-3.5 w-3.5" />
                Subir .PMF Real para este Slot
              </button>
              <button
                type="button"
                disabled={recordingWebm}
                onClick={handleRecordTrailerWebm}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
              >
                <Film className="h-3.5 w-3.5" />
                {recordingWebm ? 'Grabando .WEBM…' : 'Grabar Trailer .WEBM'}
              </button>
              <button
                type="button"
                onClick={() => {
                  const bytes = buildTagTeamTrailerPmf(trailerConfig);
                  const fname = getTrailerTargetIsoPath(trailerConfig).split('/').pop() || 'TRAILER.PMF';
                  downloadBlob(new Blob([bytes as unknown as BlobPart], { type: 'application/octet-stream' }), fname);
                }}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                Descargar .PMF
              </button>
              <button
                type="button"
                onClick={() => setShowFfmpeg((s) => !s)}
                className="inline-flex min-h-[38px] items-center gap-1.5 text-xs font-medium text-blue-600 hover:underline dark:text-blue-400 cursor-pointer"
              >
                <Terminal className="h-3.5 w-3.5" />
                {showFfmpeg ? 'Ocultar comando FFmpeg → .PMF' : 'Ver comando FFmpeg → .PMF'}
              </button>
            </div>

            <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
              Nota técnica: el botón <strong>Crear e Inyectar .PMF</strong> genera una cabecera/contenedor <span className="font-mono">PSMF0014</span> alineado a 2048 B con metadatos Tag Team para el arranque de la ISO. Para reproducir video real H.264/ATRAC3+ en consola PSP, graba el <span className="font-mono">.WEBM</span> o usa tu <span className="font-mono">.MP4</span> con FFmpeg + UmdStreamComposer y cárgalo con <strong>Subir .PMF Real</strong>.
            </p>

            {showFfmpeg && (
              <div className="rounded-lg border border-slate-200 bg-slate-950 p-3 dark:border-slate-800">
                <div className="mb-2 flex items-center justify-between">
                  <span className="font-mono text-[11px] font-semibold text-amber-300">
                    Pipeline H.264 Main L2.1 + WAV 48kHz → UmdStreamComposer → .PMF
                  </span>
                  <button
                    type="button"
                    onClick={() => void handleCopyFfmpeg()}
                    className="inline-flex items-center gap-1 rounded border border-slate-700 px-2 py-0.5 text-[11px] text-slate-200 hover:bg-slate-800 cursor-pointer"
                  >
                    <Copy className="h-3 w-3" />
                    {copiedFfmpeg ? 'Copiado' : 'Copiar'}
                  </button>
                </div>
                <pre className="overflow-x-auto font-mono text-[11px] leading-relaxed text-slate-100">
                  {ffmpegScript}
                </pre>
              </div>
            )}
          </div>
        </section>

        {/* Right Column: Detected Folders/Files + PSMF Inspector */}
        <div className="lg:col-span-6 space-y-4">
          {/* Folders & PMF Files inside ISO */}
          <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Carpetas de Video y Archivos .PMF en la ISO
              </h3>
              <span className="font-mono text-xs text-slate-500 dark:text-slate-400">
                {detectedVideos.length} archivos · {detectedVideoFolders.length} carpetas
              </span>
            </div>

            {/* Folder quick delete chips */}
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {detectedVideoFolders.length === 0 ? (
                <span className="text-xs text-emerald-700 dark:text-emerald-400">
                  Sin carpetas residuales <span className="font-mono">VIDEOS_PMF</span> detectadas en la cola.
                </span>
              ) : (
                detectedVideoFolders.map((dir) => (
                  <div
                    key={dir}
                    className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-[11px] text-slate-800 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
                  >
                    <span>{dir}/</span>
                    <button
                      type="button"
                      onClick={() => handleDeleteSingleFolder(dir)}
                      className="inline-flex items-center gap-1 rounded bg-red-600 px-2 py-0.5 font-sans text-[10px] font-semibold text-white hover:bg-red-700 cursor-pointer"
                    >
                      <Trash2 className="h-3 w-3" />
                      Borrar carpeta
                    </button>
                  </div>
                ))
              )}
            </div>

            {/* PMF Table */}
            <div className="mt-4 max-h-72 overflow-auto rounded-lg border border-slate-200 dark:border-slate-800">
              {detectedVideos.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500 dark:text-slate-400">
                  No hay archivos <span className="font-mono">.PMF</span> en la cola ISO actual. Usa el botón <strong>Crear e Inyectar .PMF al Inicio ISO</strong> o sube un archivo <span className="font-mono">.PMF</span> real.
                </div>
              ) : (
                <table className="w-full border-collapse text-left text-xs">
                  <thead className="sticky top-0 bg-slate-50 text-slate-600 dark:bg-slate-950 dark:text-slate-400">
                    <tr className="border-b border-slate-200 dark:border-slate-800">
                      <th className="px-3 py-2 font-semibold">Ruta ISO .PMF</th>
                      <th className="px-3 py-2 text-right font-semibold">Tamaño</th>
                      <th className="px-3 py-2 text-right font-semibold">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {detectedVideos.map((v) => (
                      <tr key={v.path} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                        <td className="max-w-[210px] truncate px-3 py-2 font-mono text-slate-900 dark:text-slate-100" title={v.path}>
                          {v.path}
                        </td>
                        <td className="px-3 py-2 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                          {formatBytes(v.size)}
                        </td>
                        <td className="px-3 py-2 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => void handleInspectVideo(v)}
                              className="rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                            >
                              Cabecera
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setReplaceTargetPath(v.path);
                                replaceSingleInputRef.current?.click();
                              }}
                              className="inline-flex items-center gap-1 rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                            >
                              <Replace className="h-3 w-3" />
                              Reemplazar
                            </button>
                            <button
                              type="button"
                              onClick={() => void handleDownloadVideo(v)}
                              aria-label={`Descargar ${v.path}`}
                              className="inline-flex items-center rounded border border-slate-200 px-2 py-1 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 cursor-pointer"
                            >
                              <Download className="h-3 w-3" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteSingleFile(v.path)}
                              aria-label={`Borrar ${v.path}`}
                              className="inline-flex items-center rounded border border-slate-200 px-2 py-1 text-red-600 hover:bg-red-50 dark:border-slate-700 dark:text-red-400 cursor-pointer"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </section>

          {/* PSMF Binary Inspector */}
          <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Inspector de Cabecera <span className="font-mono">PSMF0014</span>
              </h3>
              {selectedVideoBytes && onInspectAssetBytes && (
                <button
                  type="button"
                  onClick={() =>
                    onInspectAssetBytes(selectedVideoBytes.bytes, selectedVideoBytes.path)
                  }
                  className="inline-flex items-center gap-1 rounded border border-slate-300 px-2.5 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  <Binary className="h-3 w-3" />
                  Abrir en HxD
                </button>
              )}
            </div>

            {!selectedInspection ? (
              <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">
                Haz clic en <strong>Cabecera</strong> en cualquier video de la lista o crea el Trailer Tag Team para inspeccionar la estructura <span className="font-mono">PSMF0014</span>, resolución y alineación a sectores de 2048 B.
              </p>
            ) : (
              <div className="mt-3 space-y-3 text-xs">
                <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 dark:border-slate-800 dark:bg-slate-950">
                  <span className="font-mono font-semibold text-slate-900 dark:text-white">
                    {selectedInspection.fileName}
                  </span>
                  <span
                    className={`inline-flex items-center gap-1 font-mono text-[11px] font-bold ${
                      selectedInspection.isValidPsmf
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : 'text-red-600 dark:text-red-400'
                    }`}
                  >
                    {selectedInspection.isValidPsmf ? (
                      <CheckCircle2 className="h-3.5 w-3.5" />
                    ) : (
                      <AlertTriangle className="h-3.5 w-3.5" />
                    )}
                    {selectedInspection.isValidPsmf
                      ? `${selectedInspection.magic}${selectedInspection.version}`
                      : 'FIRMA INVÁLIDA'}
                  </span>
                </div>

                <dl className="grid grid-cols-2 gap-2 font-mono">
                  <div className="rounded border border-slate-200 p-2 dark:border-slate-800">
                    <dt className="font-sans text-[11px] text-slate-500">Offset Flujo BE</dt>
                    <dd className="mt-0.5 font-semibold text-slate-900 dark:text-white">
                      0x{selectedInspection.streamOffset.toString(16).toUpperCase().padStart(8, '0')}
                    </dd>
                  </div>
                  <div className="rounded border border-slate-200 p-2 dark:border-slate-800">
                    <dt className="font-sans text-[11px] text-slate-500">Tamaño Flujo BE</dt>
                    <dd className="mt-0.5 font-semibold text-slate-900 dark:text-white">
                      {formatBytes(selectedInspection.streamSize)}
                    </dd>
                  </div>
                  <div className="rounded border border-slate-200 p-2 dark:border-slate-800">
                    <dt className="font-sans text-[11px] text-slate-500">Resolución / FPS</dt>
                    <dd className="mt-0.5 font-semibold text-slate-900 dark:text-white">
                      {selectedInspection.width ?? '—'}×{selectedInspection.height ?? '—'} ·{' '}
                      {selectedInspection.fpsLabel}
                    </dd>
                  </div>
                  <div className="rounded border border-slate-200 p-2 dark:border-slate-800">
                    <dt className="font-sans text-[11px] text-slate-500">Alineación 2048 B</dt>
                    <dd className="mt-0.5 font-semibold text-slate-900 dark:text-white">
                      {selectedInspection.sectorAligned ? 'mod 2048 = 0 OK' : 'Alinear al empaquetar'}
                    </dd>
                  </div>
                </dl>

                {selectedInspection.warnings.length > 0 && (
                  <ul className="space-y-1 rounded-lg border border-amber-200 bg-amber-50/70 p-2.5 text-[11px] text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-200">
                    {selectedInspection.warnings.map((w, i) => (
                      <li key={i}>• {w}</li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};
