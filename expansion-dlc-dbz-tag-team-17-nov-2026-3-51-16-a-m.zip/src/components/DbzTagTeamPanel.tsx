import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Archive,
  Binary,
  CheckCircle2,
  Cpu,
  Download,
  FileImage,
  FileJson,
  FilePlus2,
  Film,
  FolderInput,
  Gamepad2,
  HardDrive,
  Layers,
  MapPin,
  MemoryStick,
  Route,
  Save,
  Upload,
} from 'lucide-react';
import {
  buildDbzCompleteDlcFolderFiles,
  buildDbzCwCheatAndPpssppIni,
  buildDbzDlcBundleZip,
  buildDefaultDbzRoster256Json,
  patchDbzTagTeamEboot,
  scanDbzTagTeamEboot,
  type DbzPatchedEbootOutput,
  type DbzRoster256JsonManifest,
  type DbzTargetAssetFolder,
} from '../lib/dbzTagTeamExpander';
import {
  computeDynamicRamImmediates,
  type DynamicRamAllocationConfig,
  type RamTargetProfile,
} from '../lib/ramExpander';
import type { EbootAnalysis } from '../lib/types';
import { DbzCharacterJsonMapper } from './DbzCharacterJsonMapper';
import {
  buildGimBindingsOverlayFiles,
  buildInitialGimAssignments,
  DbzGimModelTable,
  type GimModelAssignment,
} from './DbzGimModelTable';
import {
  buildInitialIsoMapMusicSlots,
  buildOverlayFilesFromMiniSlots,
  DbzIsoMapMusicSlots,
  type IsoMapMiniSlot,
  type IsoMusicMiniSlot,
} from './DbzIsoMapMusicSlots';
import {
  buildDefaultFreeBattleLayout,
  buildFreeBattleOverlayFiles,
  buildMasterPackfileFromSuiteState,
  DbzFreeBattleEditor,
  type FreeBattleLayoutConfig,
  type FreeBattlePresetId,
} from './DbzFreeBattleEditor';
import { buildGameEngineCompatibleJson } from '../lib/dbzScriptGenerator';
import { IsoPmfVideoEditor } from './IsoPmfVideoEditor';
import { buildTagTeamTrailerPmf } from '../lib/pmfVideoTools';

interface DbzTagTeamPanelProps {
  analysis: EbootAnalysis | null;
  isoFileBlob?: Blob | null;
  onJumpToHex?: (offset: number) => void;
  onInspectAssetBytes?: (bytes: Uint8Array, assetPath: string) => void;
  onApplyModifiedBytes?: (newBytes: Uint8Array) => void;
  onSendPatchedToIsoPacker?: (files: Array<{ file: File; relativePath: string }>) => void;
  onLaunchEmulatorWithMod?: (cfg: {
    ramProfile: RamTargetProfile;
    charCount: number;
    mapCount: number;
    lobbyCount: number;
    chibiCount: number;
    musicTrackCount: number;
    gameId: string;
    ebootPatched: boolean;
    freeBattlePreset?: FreeBattlePresetId;
    customCharNames?: string[];
    customMapNames?: string[];
    customMusicTitles?: string[];
    dlcAssetPaths?: string[];
  }) => void;
}

function hex(val: number, width = 6): string {
  return `0x${(val >>> 0).toString(16).toUpperCase().padStart(width, '0')}`;
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

const FOLDER_LABEL: Record<DbzTargetAssetFolder, string> = {
  PERSONAJES: 'DLC/PERSONAJES/',
  MAPAS: 'DLC/MAPAS/',
  MINIMAPAS: 'DLC/MINIMAPAS/',
  LOBBY: 'DLC/LOBBY/',
  CHIBIS: 'DLC/CHIBIS/',
  MUSICA: 'DLC/MUSICA/',
  SAVEDATA: 'SAVEDATA (256)',
};

export const DbzTagTeamPanel: React.FC<DbzTagTeamPanelProps> = ({
  analysis,
  isoFileBlob,
  onJumpToHex,
  onInspectAssetBytes,
  onApplyModifiedBytes,
  onSendPatchedToIsoPacker,
  onLaunchEmulatorWithMod,
}) => {
  const [uploadedFile, setUploadedFile] = useState<{
    name: string;
    bytes: Uint8Array;
  } | null>(null);
  const [oldBackupFile, setOldBackupFile] = useState<{
    name: string;
    bytes: Uint8Array;
  } | null>(null);

  // Expansion configuration
  const [charCount, setCharCount] = useState(256);
  const [mapCount, setMapCount] = useState(46);
  const [lobbyCount, setLobbyCount] = useState(256);
  const [chibiCount, setChibiCount] = useState(256);
  const [musicTrackCount, setMusicTrackCount] = useState(64);
  const [ramProfile, setRamProfile] = useState<RamTargetProfile>('256MB');
  const [dynamicRamConfig, setDynamicRamConfig] = useState<DynamicRamAllocationConfig>({
    targetRamMb: 64,
    kernelReserveMb: 8,
    rosterHeapAllocationMb: 18,
    streamingMode: 'STREAMING',
    setParamSfoMemsize: true,
  });
  const [expandBssMb, setExpandBssMb] = useState(8);
  const [includeSave256, setIncludeSave256] = useState(true);
  const [includeBackupOld, setIncludeBackupOld] = useState(true);

  const computedRam = useMemo(
    () => computeDynamicRamImmediates(dynamicRamConfig.targetRamMb, dynamicRamConfig.kernelReserveMb),
    [dynamicRamConfig.targetRamMb, dynamicRamConfig.kernelReserveMb]
  );

  const applyDynamicTargetRamMb = (mb: number) => {
    const clamped = Math.max(32, Math.min(256, Math.round(mb) || 64));
    const nextProfile: RamTargetProfile =
      clamped <= 80 ? '64MB' : clamped <= 160 ? '128MB' : '256MB';
    const nextManifestRam: 64 | 128 | 256 =
      clamped <= 80 ? 64 : clamped <= 160 ? 128 : 256;

    setDynamicRamConfig((prev) => ({
      ...prev,
      targetRamMb: clamped,
      setParamSfoMemsize: clamped > 32,
      rosterHeapAllocationMb: clamped <= 32 ? Math.min(prev.rosterHeapAllocationMb, 12) : prev.rosterHeapAllocationMb,
      streamingMode: clamped <= 48 ? 'STREAMING' : prev.streamingMode,
    }));
    setRamProfile(nextProfile);
    setRosterManifest((prev) => ({
      ...prev,
      ramBalance: {
        ...prev.ramBalance,
        targetRamMb: nextManifestRam,
      },
    }));
  };

  const [selectedLimitOffsets, setSelectedLimitOffsets] = useState<number[]>([]);
  const [pathEdits, setPathEdits] = useState<Record<number, string>>({});
  const [selectedPathOffsets, setSelectedPathOffsets] = useState<number[]>([]);
  const [categoryFilter, setCategoryFilter] = useState<DbzTargetAssetFolder | 'ALL'>('ALL');
  const [lastPatchOutput, setLastPatchOutput] = useState<DbzPatchedEbootOutput | null>(null);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [panelTab, setPanelTab] = useState<
    'eboot_dlc' | 'json_256' | 'iso_minislots' | 'gim_table' | 'free_battle' | 'videos_pmf'
  >('eboot_dlc');
  const [freeBattleLayout, setFreeBattleLayout] = useState<FreeBattleLayoutConfig>(() =>
    buildDefaultFreeBattleLayout('DARK_TEAM_ENEMY')
  );
  const [customFreeBattlePckBytes, setCustomFreeBattlePckBytes] = useState<Uint8Array | null>(null);
  const [masterPackfileBytes, setMasterPackfileBytes] = useState<Uint8Array | null>(null);
  const [includePackfileBin, setIncludePackfileBin] = useState(true);
  const [includeTrailerPmf, setIncludeTrailerPmf] = useState(true);
  const [stripVideosPmf, setStripVideosPmf] = useState(true);
  const [includeEmptyDlcPlaceholders, setIncludeEmptyDlcPlaceholders] = useState(true);
  const [emptyDlcPrefix, setEmptyDlcPrefix] = useState('DLC_VACIO');
  const [pmfTrailerFiles, setPmfTrailerFiles] = useState<Array<{ path: string; data: Uint8Array }>>([]);
  const [rosterManifest, setRosterManifest] = useState<DbzRoster256JsonManifest>(() =>
    buildDefaultDbzRoster256Json('ULUS10537', 256, 256)
  );
  const [gimAssignments, setGimAssignments] = useState<GimModelAssignment[]>(() =>
    buildInitialGimAssignments(buildDefaultDbzRoster256Json('ULUS10537', 256, 256))
  );
  const [mapSlots, setMapSlots] = useState<IsoMapMiniSlot[]>(() =>
    buildInitialIsoMapMusicSlots(analysis, 46, 64).maps
  );
  const [musicSlots, setMusicSlots] = useState<IsoMusicMiniSlot[]>(() =>
    buildInitialIsoMapMusicSlots(analysis, 46, 64).music
  );

  const handleUpdateGimAssignments = (nextGims: GimModelAssignment[]) => {
    setGimAssignments(nextGims);
    const bySlot = new Map(nextGims.map((g) => [g.slotId, g]));
    setRosterManifest((prev) => ({
      ...prev,
      characters: prev.characters.map((ch) => {
        const g = bySlot.get(ch.id);
        return g ? { ...ch, gimPortraitPath: g.dlcPath } : ch;
      }),
    }));
  };

  const ebootInputRef = useRef<HTMLInputElement | null>(null);
  const oldInputRef = useRef<HTMLInputElement | null>(null);

  const activeBytes = useMemo(() => {
    if (uploadedFile) return uploadedFile.bytes;
    if (analysis?.rawBytes) return analysis.rawBytes;
    return null;
  }, [uploadedFile, analysis]);

  const activeName = uploadedFile?.name ?? analysis?.targetBinaryPath ?? 'EBOOT.BIN';

  const scan = useMemo(() => {
    if (!activeBytes) return null;
    return scanDbzTagTeamEboot(
      activeBytes,
      activeName,
      uploadedFile ? null : analysis
    );
  }, [activeBytes, activeName, uploadedFile, analysis]);

  useEffect(() => {
    if (!scan) return;
    setSelectedLimitOffsets(
      scan.mipsLimitCandidates.filter((c) => c.selected).map((c) => c.fileOffset)
    );
    const map: Record<number, string> = {};
    const sel: number[] = [];
    for (const p of scan.pathCandidates) {
      map[p.offset] = p.suggestedDlcPath;
      if (p.selected) sel.push(p.offset);
    }
    setPathEdits(map);
    setSelectedPathOffsets(sel);
    setLastPatchOutput(null);
  }, [scan]);

  useEffect(() => {
    if (!analysis?.isoInfo) return;
    const init = buildInitialIsoMapMusicSlots(analysis, mapCount, musicTrackCount);
    setMapSlots(init.maps);
    setMusicSlots(init.music);
  }, [analysis?.isoInfo]);

  const handleUploadEboot = async (e: React.ChangeEvent<HTMLInputElement>, asOldBackup = false) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const buf = new Uint8Array(await file.arrayBuffer());
    e.target.value = '';
    if (asOldBackup) {
      setOldBackupFile({ name: file.name, bytes: buf });
      setStatusMsg(`Respaldo .OLD cargado: ${file.name} (${buf.length.toLocaleString('es-ES')} B).`);
      // If active main binary is encrypted ~PSP and this .OLD is editable ELF, promote .OLD as working base automatically
      if (scan?.isEncryptedPsp && buf[0] === 0x7f && buf[1] === 0x45) {
        setUploadedFile({ name: file.name, bytes: buf });
        setStatusMsg(
          `${file.name} contiene ELF32 desencriptado: seleccionado como base editable para parches 256 + DLC y guardado respaldo original.`
        );
      }
    } else {
      setUploadedFile({ name: file.name, bytes: buf });
      setStatusMsg(`Ejecutable cargado: ${file.name} (${buf.length.toLocaleString('es-ES')} B).`);
    }
  };

  const toggleLimitOffset = (off: number) => {
    setSelectedLimitOffsets((prev) =>
      prev.includes(off) ? prev.filter((x) => x !== off) : [...prev, off]
    );
  };

  const togglePathOffset = (off: number) => {
    setSelectedPathOffsets((prev) =>
      prev.includes(off) ? prev.filter((x) => x !== off) : [...prev, off]
    );
  };

  const filteredPaths = useMemo(() => {
    if (!scan) return [];
    if (categoryFilter === 'ALL') return scan.pathCandidates;
    return scan.pathCandidates.filter((p) => p.category === categoryFilter);
  }, [scan, categoryFilter]);

  const executePatch = (): DbzPatchedEbootOutput | null => {
    if (!activeBytes || !scan) return null;
    const customRelocations = selectedPathOffsets
      .map((off) => ({
        offset: off,
        newPath: pathEdits[off] ?? '',
      }))
      .filter((r) => r.newPath.length > 0);

    const res = patchDbzTagTeamEboot(activeBytes, scan, {
      ramProfile,
      dynamicRamConfig,
      selectedLimitOffsets,
      customRelocations,
      expandBssMb,
      paramSfoEntries: analysis?.sfoInfo?.entries ?? [
        { key: 'BOOTABLE', value: 1, format: 'int32' },
        { key: 'CATEGORY', value: 'UG', format: 'utf8' },
        { key: 'DISC_ID', value: scan.detectedGameId, format: 'utf8' },
        { key: 'DISC_VERSION', value: '1.00', format: 'utf8' },
        { key: 'PSP_SYSTEM_VER', value: '6.31', format: 'utf8' },
        { key: 'TITLE', value: 'DRAGON BALL Z TENKAICHI TAG TEAM 256 DLC', format: 'utf8' },
      ],
    });

    if (oldBackupFile) {
      res.backupOldEboot = new Uint8Array(oldBackupFile.bytes);
    }

    setLastPatchOutput(res);
    if (!uploadedFile && onApplyModifiedBytes) {
      onApplyModifiedBytes(res.patchedEboot);
    }
    setStatusMsg(
      `Parche aplicado (${computedRam.targetRamMb} MB RAM · Heap ${computedRam.userRamMb} MB · LUI Total 0x${computedRam.totalRamLuiImm.toString(16).toUpperCase().padStart(4, '0')}): ${res.limitPatchesApplied} límites MIPS 256/46, ${res.ramPatchesApplied} LUI RAM y ${res.pathsRelocatedInPlace + res.pathsRelocatedViaCave} rutas hacia /PSP_GAME/DLC/.`
    );
    return res;
  };

  const buildCombinedOverlayAndBundle = (
    patched: DbzPatchedEbootOutput | null,
    gameId: string
  ) => {
    const engineRosterJson = buildGameEngineCompatibleJson(rosterManifest, {
      baseIndexMode: '0x00_BASED',
      dlcBasePath: 'disc0:/PSP_GAME/DLC',
      customSlotPrefix: 'CHAR',
    });

    const customPortraitsBySlot = new Map<number, Uint8Array>();
    for (const ga of gimAssignments) {
      if (ga.customBytes && ga.customBytes.length > 0) {
        customPortraitsBySlot.set(ga.slotId, ga.customBytes);
      }
    }

    const trailerFiles: Array<{ path: string; data: Uint8Array }> = includeTrailerPmf
      ? pmfTrailerFiles.length > 0
        ? pmfTrailerFiles
        : [
            {
              path: '/PSP_GAME/ICON1.PMF',
              data: buildTagTeamTrailerPmf({
                slotPreset: 'ICON1_XMB',
                title: 'DRAGON BALL Z: TENKAICHI TAG TEAM',
                subtitle: 'TRAILER OFICIAL · 256 PERSONAJES DLC + 46 MAPAS',
                footerTag: 'MOD EDITION · 29.97 FPS · START ISO',
                theme: 'TAG_TEAM_SAIYAN',
                durationSec: 8,
                fps: 29.97,
                width: 144,
                height: 80,
                includeAudioTrack: true,
              }),
            },
          ]
      : pmfTrailerFiles;

    const safePrefix =
      emptyDlcPrefix
        .trim()
        .replace(/[^A-Za-z0-9._-]+/g, '_')
        .replace(/^_+|_+$/g, '') || 'DLC_VACIO';

    const emptyDlcFiles: Array<{ path: string; data: Uint8Array }> = includeEmptyDlcPlaceholders
      ? [
          { path: `/PSP_GAME/DLC/PERSONAJES/${safePrefix}_PERSONAJES.bin`, data: new Uint8Array(0) },
          { path: `/PSP_GAME/DLC/MAPAS/${safePrefix}_MAPAS.bin`, data: new Uint8Array(0) },
          { path: `/PSP_GAME/DLC/MINIMAPAS/${safePrefix}_MINIMAPAS.tm2`, data: new Uint8Array(0) },
          { path: `/PSP_GAME/DLC/LOBBY/${safePrefix}_LOBBY.bin`, data: new Uint8Array(0) },
          { path: `/PSP_GAME/DLC/CHIBIS/${safePrefix}_CHIBIS.gim`, data: new Uint8Array(0) },
          { path: `/PSP_GAME/DLC/MUSICA/${safePrefix}_MUSICA.at3`, data: new Uint8Array(0) },
          { path: `/PSP_GAME/DLC/UI/${safePrefix}_UI.pck`, data: new Uint8Array(0) },
          { path: `/PSP_GAME/MOD/DLC/CASILLAS_ROSTER/${safePrefix}_ROSTER.gim`, data: new Uint8Array(0) },
          { path: `/PSP_GAME/MOD/DLC/BARRA_DE_VIDA/${safePrefix}_HUD.gim`, data: new Uint8Array(0) },
          { path: `/PSP_GAME/MOD/DLC/OBJ/${safePrefix}_OBJ.obj`, data: new Uint8Array(0) },
        ]
      : [];

    const preIndexOverlay = [
      ...buildOverlayFilesFromMiniSlots(gameId, mapSlots, musicSlots),
      ...buildGimBindingsOverlayFiles(gameId, gimAssignments, rosterManifest),
      ...buildFreeBattleOverlayFiles(gameId, freeBattleLayout, customFreeBattlePckBytes),
      ...trailerFiles,
      ...emptyDlcFiles,
      {
        path: `/PSP_GAME/DLC/PERSONAJES/${gameId}_ENGINE_256_MAP.json`,
        data: new TextEncoder().encode(JSON.stringify(engineRosterJson, null, 2)),
      },
    ];

    const dlcInGameIndex = {
      schema: 'DBZ_DLC_IN_GAME_MASTER_INDEX_V1',
      gameId,
      syncRule: 'ALL_DLC_APPEARS_IN_GAME',
      charactersCount: Math.min(charCount, rosterManifest.characters.length || charCount),
      mapsCount: mapSlots.length,
      musicCount: musicSlots.length,
      freeBattleMenuPreset: freeBattleLayout.presetId,
      enabledMenuStyles: freeBattleLayout.enabledMenuStyles ?? [freeBattleLayout.presetId],
      officialModesEnabled: [
        'BATALLA_LIBRE',
        'DRAGON_WALKER',
        'SELECCION_BATALLA',
        'AD_HOC',
        'PERSONALIZAR',
        'ENTRENAMIENTO',
        'OPCIONES',
      ],
      videoPaths: trailerFiles.map((v) => v.path),
      emptyPlaceholderPaths: emptyDlcFiles.map((e) => e.path),
      customOverlayPaths: preIndexOverlay.map((f) => f.path),
    };
    const dlcIndexBytes = new TextEncoder().encode(JSON.stringify(dlcInGameIndex, null, 2));

    const packfileBin = includePackfileBin
      ? masterPackfileBytes ??
        buildMasterPackfileFromSuiteState({
          gameId,
          layout: freeBattleLayout,
          manifest: rosterManifest,
          mapSlots,
          musicSlots,
          customPortraitsBySlot,
          extraEntries: [
            { name: 'DLC_IN_GAME_INDEX.json', data: dlcIndexBytes, category: 'OTROS' },
          ],
        })
      : null;

    const overlayFiles = [
      ...preIndexOverlay,
      { path: '/PSP_GAME/DLC/DLC_IN_GAME_INDEX.json', data: dlcIndexBytes },
      ...(packfileBin
        ? [{ path: '/PSP_GAME/USRDIR/PACKFILE.BIN', data: packfileBin }]
        : []),
    ];

    let files = buildDbzCompleteDlcFolderFiles(
      {
        charCount,
        mapCount,
        lobbyCount,
        chibiCount,
        musicTrackCount,
        includeSave256,
        includeLegacyBackupOld: includeBackupOld,
        ramProfile,
        gameId,
      },
      patched,
      rosterManifest,
      overlayFiles
    );

    if (stripVideosPmf) {
      files = files.filter((f) => !f.path.toUpperCase().includes('VIDEOS_PMF'));
    }

    return files;
  };

  const handleDownloadFullPackageZip = () => {
    const patched = lastPatchOutput ?? executePatch();
    const gameId = scan?.detectedGameId ?? 'ULUS10537';
    const files = buildCombinedOverlayAndBundle(patched, gameId);
    const zipBlob = buildDbzDlcBundleZip(files);
    downloadBlob(zipBlob, `${gameId}_DBZ_TT_256_DLC_EBOOT_OLD_SAVE.zip`);
    setStatusMsg(
      `Paquete .ZIP generado con ${files.length} archivos (EBOOT.BIN/.OLD + PACKFILE.BIN + ICON1.PMF + FREE_BATTLE_UI.PCK + ${mapSlots.length} Mapas + ${musicSlots.length} Música + Save 256).`
    );
  };

  const handleSendAllToIsoPacker = () => {
    if (!onSendPatchedToIsoPacker) return;
    const patched = lastPatchOutput ?? executePatch();
    const gameId = scan?.detectedGameId ?? 'ULUS10537';
    const files = buildCombinedOverlayAndBundle(patched, gameId);

    const fileObjs = files.map((f) => {
      const cleanRel = f.path.replace(/^\/+/, '');
      const name = cleanRel.split('/').pop() || 'FILE.BIN';
      return {
        file: new File([f.data as unknown as BlobPart], name, {
          type: 'application/octet-stream',
        }),
        relativePath: cleanRel,
      };
    });
    onSendPatchedToIsoPacker(fileObjs);
  };

  return (
    <div className="space-y-6">
      <input
        ref={ebootInputRef}
        type="file"
        accept=".bin,.old,.elf,.prx,*/*"
        onChange={(e) => void handleUploadEboot(e, false)}
        className="hidden"
      />
      <input
        ref={oldInputRef}
        type="file"
        accept=".old,.bin,.elf,*/*"
        onChange={(e) => void handleUploadEboot(e, true)}
        className="hidden"
      />

      {/* Header & File Pair Loader (EBOOT.BIN + EBOOT.OLD) */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-3xl">
            <h2 className="flex items-center gap-2 text-lg font-semibold text-slate-900 dark:text-white">
              <Layers className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              DBZ Tenkaichi Tag Team: Expansor <span className="font-mono">EBOOT.BIN / .OLD</span> a 256 Slots + Reubicación <span className="font-mono">DLC/</span>
            </h2>
            <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
              Expande el ejecutable (<span className="font-mono">EBOOT.BIN</span> y respaldo <span className="font-mono">EBOOT.OLD</span>) a <strong>256 personajes</strong>, <strong>46 mapas + minimapas</strong>, <strong>Lobby 256 con Chibis</strong>, <strong>Música .AT3</strong>, <strong>Save en juego 256</strong> y <strong>RAM de 256 MB</strong> reubicando las rutas hacia <span className="font-mono">disc0:/PSP_GAME/DLC/</span>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => ebootInputRef.current?.click()}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Upload className="h-3.5 w-3.5" />
              Cargar EBOOT.BIN / .OLD
            </button>
            <button
              type="button"
              onClick={() => oldInputRef.current?.click()}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Upload className="h-3.5 w-3.5" />
              Cargar Respaldo .OLD
            </button>
            {onLaunchEmulatorWithMod && (
              <button
                type="button"
                onClick={() => {
                  const bundle = buildCombinedOverlayAndBundle(
                    lastPatchOutput,
                    scan?.detectedGameId ?? 'ULUS10537'
                  );
                  onLaunchEmulatorWithMod({
                    ramProfile,
                    charCount,
                    mapCount,
                    lobbyCount,
                    chibiCount,
                    musicTrackCount,
                    gameId: scan?.detectedGameId ?? 'ULUS10537',
                    ebootPatched: Boolean(lastPatchOutput),
                    freeBattlePreset: freeBattleLayout.presetId,
                    customCharNames: rosterManifest.characters.map((c) => c.displayName),
                    customMapNames: mapSlots.map((m) => m.name),
                    customMusicTitles: musicSlots.map((t) => t.title),
                    dlcAssetPaths: bundle.map((f) => f.path),
                  });
                }}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-emerald-700 dark:hover:bg-emerald-800 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Gamepad2 className="h-4 w-4" />
                Emular PSP / Nativo Tag Team
              </button>
            )}
          </div>
        </div>

        {statusMsg && (
          <div className="mt-3 rounded-lg border border-emerald-200 bg-emerald-50/70 px-3.5 py-2.5 text-xs text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-200">
            {statusMsg}
          </div>
        )}

        {/* Active binary diagnostics */}
        {scan ? (
          <div className="mt-4 space-y-3">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-5 text-xs">
              <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                <div className="text-slate-500 dark:text-slate-400">Ejecutable Base</div>
                <div className="mt-1 truncate font-mono font-bold text-slate-900 dark:text-white" title={scan.fileName}>
                  {scan.fileName}
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                <div className="text-slate-500 dark:text-slate-400">ID Tag Team</div>
                <div className="mt-1 font-mono font-bold text-blue-600 dark:text-blue-400">
                  {scan.detectedGameId}
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                <div className="text-slate-500 dark:text-slate-400">Límites MIPS 256/46</div>
                <div className="mt-1 font-mono font-bold tabular-nums text-slate-900 dark:text-white">
                  {scan.mipsLimitCandidates.length} hallazgos
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                <div className="text-slate-500 dark:text-slate-400">Límites RAM LUI</div>
                <div className="mt-1 font-mono font-bold tabular-nums text-slate-900 dark:text-white">
                  {scan.ramLuiCount} instrucciones
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                <div className="text-slate-500 dark:text-slate-400">Rutas disc0:/ → DLC</div>
                <div className="mt-1 font-mono font-bold tabular-nums text-emerald-700 dark:text-emerald-400">
                  {scan.pathCandidates.length} rutas
                </div>
              </div>
            </div>

            <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-300">
              {scan.notes.map((n, i) => (
                <li key={i}>• {n}</li>
              ))}
            </ul>
          </div>
        ) : (
          <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50 p-4 text-xs text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300">
            Carga tu archivo <span className="font-mono font-semibold">EBOOT.BIN</span> o <span className="font-mono font-semibold">EBOOT.OLD</span> de Dragon Ball Z: Tenkaichi Tag Team (o una ISO completa desde el botón superior) para escanear los límites MIPS y rutas <span className="font-mono">disc0:/</span>. También puedes definir abajo el JSON de 256 personajes o agregar Mapas/Música DLC por minicasillas.
          </div>
        )}

        {/* Integrated PPSSPP Reference Screens -> Quick Jump to Matching Interactive Modules */}
        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
          <button
            type="button"
            onClick={() => setPanelTab('iso_minislots')}
            className="group overflow-hidden rounded-xl border border-slate-200 bg-slate-50 text-left transition-colors hover:border-blue-500 dark:border-slate-800 dark:bg-slate-950 cursor-pointer"
          >
            <img
              src="/assets/aistudio/20261117_025451_c7673c50.jpg"
              alt="Selección de Mapa y Música 9. Explosión"
              className="h-24 w-full object-cover"
            />
            <div className="p-2.5 text-xs">
              <div className="font-semibold text-slate-900 group-hover:text-blue-600 dark:text-white dark:group-hover:text-blue-400">
                Selección de Mapa + Música (9. Explosión)
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                Abrir Minicasillas Mapas DLC, Senzu y BGM →
              </div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setPanelTab('json_256')}
            className="group overflow-hidden rounded-xl border border-slate-200 bg-slate-50 text-left transition-colors hover:border-blue-500 dark:border-slate-800 dark:bg-slate-950 cursor-pointer"
          >
            <img
              src="/assets/aistudio/20261117_025541_80e1b231.jpg"
              alt="Selección de Personaje Página 1 (Goku)"
              className="h-24 w-full object-cover"
            />
            <div className="p-2.5 text-xs">
              <div className="font-semibold text-slate-900 group-hover:text-blue-600 dark:text-white dark:group-hover:text-blue-400">
                Roster 4×6 Pág. 1 (J1–J4 · Goku a Raditz)
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                Abrir Mapeo JSON 256 (.PMF/.GIM + RAM) →
              </div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => {
              const bundle = buildCombinedOverlayAndBundle(
                lastPatchOutput,
                scan?.detectedGameId ?? 'ULUS10537'
              );
              onLaunchEmulatorWithMod?.({
                ramProfile,
                charCount,
                mapCount,
                lobbyCount,
                chibiCount,
                musicTrackCount,
                gameId: scan?.detectedGameId ?? 'ULUS10537',
                ebootPatched: Boolean(lastPatchOutput),
                freeBattlePreset: freeBattleLayout.presetId,
                customCharNames: rosterManifest.characters.map((c) => c.displayName),
                customMapNames: mapSlots.map((m) => m.name),
                customMusicTitles: musicSlots.map((t) => t.title),
                dlcAssetPaths: bundle.map((f) => f.path),
              });
            }}
            className="group overflow-hidden rounded-xl border border-slate-200 bg-slate-50 text-left transition-colors hover:border-blue-500 dark:border-slate-800 dark:bg-slate-950 cursor-pointer"
          >
            <img
              src="/assets/aistudio/20261117_025527_97b55a5b.jpg"
              alt="Selección de Personaje Página 2 (Pequeño Bu)"
              className="h-24 w-full object-cover"
            />
            <div className="p-2.5 text-xs">
              <div className="font-semibold text-slate-900 group-hover:text-blue-600 dark:text-white dark:group-hover:text-blue-400">
                Roster Pág. 2+ (Pequeño Bu a 256 DLC)
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                Probar en Port Nativo / Emulador PSP →
              </div>
            </div>
          </button>
        </div>

        {/* 3-Tab Sub-Workspace inside DbzTagTeamPanel */}
        <div className="mt-5 flex flex-wrap gap-2 border-t border-slate-100 pt-4 dark:border-slate-800">
          <button
            type="button"
            onClick={() => setPanelTab('eboot_dlc')}
            className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-semibold transition-colors cursor-pointer ${
              panelTab === 'eboot_dlc'
                ? 'border-blue-600 bg-blue-600 text-white'
                : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200'
            }`}
          >
            <Cpu className="h-3.5 w-3.5" />
            1. EBOOT.BIN/.OLD + Parches DLC
          </button>
          <button
            type="button"
            onClick={() => setPanelTab('json_256')}
            className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-semibold transition-colors cursor-pointer ${
              panelTab === 'json_256'
                ? 'border-blue-600 bg-blue-600 text-white'
                : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200'
            }`}
          >
            <FileJson className="h-3.5 w-3.5" />
            2. Mapeo JSON + Generador Scripts 256 IDs
          </button>
          <button
            type="button"
            onClick={() => setPanelTab('iso_minislots')}
            className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-semibold transition-colors cursor-pointer ${
              panelTab === 'iso_minislots'
                ? 'border-blue-600 bg-blue-600 text-white'
                : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200'
            }`}
          >
            <MapPin className="h-3.5 w-3.5" />
            3. Minicasillas ISO: Mapas DLC y Música ({mapSlots.length}M / {musicSlots.length}B)
          </button>
          <button
            type="button"
            onClick={() => setPanelTab('gim_table')}
            className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-semibold transition-colors cursor-pointer ${
              panelTab === 'gim_table'
                ? 'border-blue-600 bg-blue-600 text-white'
                : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200'
            }`}
          >
            <FileImage className="h-3.5 w-3.5" />
            4. Tabla Modelos .GIM (IDs 0–255 + Drag &amp; Drop)
          </button>
          <button
            type="button"
            onClick={() => setPanelTab('free_battle')}
            className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-semibold transition-colors cursor-pointer ${
              panelTab === 'free_battle'
                ? 'border-blue-600 bg-blue-600 text-white'
                : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200'
            }`}
          >
            <Layers className="h-3.5 w-3.5" />
            5. Batalla Libre + Opciones PCK1
          </button>
          <button
            type="button"
            onClick={() => setPanelTab('videos_pmf')}
            className={`inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-semibold transition-colors cursor-pointer ${
              panelTab === 'videos_pmf'
                ? 'border-amber-600 bg-amber-600 text-white'
                : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200'
            }`}
          >
            <Film className="h-3.5 w-3.5" />
            6. Video DBZ .PMF ISO (ICON1 / Trailer)
          </button>
        </div>
      </section>

      {panelTab === 'json_256' ? (
        <DbzCharacterJsonMapper
          gameId={scan?.detectedGameId ?? 'ULUS10537'}
          charCount={charCount}
          manifest={rosterManifest}
          onChangeManifest={(next) => {
            setRosterManifest(next);
            setCharCount(next.characters.length);
            setRamProfile(
              next.ramBalance.targetRamMb === 64
                ? '64MB'
                : next.ramBalance.targetRamMb === 128
                ? '128MB'
                : '256MB'
            );
            setGimAssignments((prev) => {
              const prevBySlot = new Map(prev.map((g) => [g.slotId, g]));
              return next.characters.map((ch, idx) => {
                const existing = prevBySlot.get(ch.id);
                if (existing) {
                  return {
                    ...existing,
                    dlcPath: ch.gimPortraitPath,
                    fileName: ch.gimPortraitPath.split('/').pop() || existing.fileName,
                  };
                }
                const gimId = Math.max(0, Math.min(255, idx));
                return {
                  slotId: ch.id,
                  gimId,
                  fileName: ch.gimPortraitPath.split('/').pop() || `MODEL_${String(gimId).padStart(3, '0')}.GIM`,
                  dlcPath: ch.gimPortraitPath,
                  sourceKind: 'DEFAULT_TEMPLATE',
                  hasPspGimMagic: false,
                  fileSizeBytes: 0,
                };
              });
            });
          }}
        />
      ) : panelTab === 'iso_minislots' ? (
        <DbzIsoMapMusicSlots
          analysis={analysis}
          gameId={scan?.detectedGameId ?? 'ULUS10537'}
          mapCount={mapCount}
          musicTrackCount={musicTrackCount}
          mapSlots={mapSlots}
          musicSlots={musicSlots}
          onChangeMapSlots={setMapSlots}
          onChangeMusicSlots={setMusicSlots}
          onUpdateCounts={(nextMaps, nextMusic) => {
            setMapCount(nextMaps);
            setMusicTrackCount(nextMusic);
          }}
          onSendMapMusicToIsoPacker={
            onSendPatchedToIsoPacker ? handleSendAllToIsoPacker : undefined
          }
        />
      ) : panelTab === 'gim_table' ? (
        <DbzGimModelTable
          analysis={analysis}
          gameId={scan?.detectedGameId ?? 'ULUS10537'}
          manifest={rosterManifest}
          assignments={gimAssignments}
          onChangeAssignments={handleUpdateGimAssignments}
          onInspectAssetBytes={onInspectAssetBytes}
        />
      ) : panelTab === 'videos_pmf' ? (
        <IsoPmfVideoEditor
          analysis={analysis}
          isoFileBlob={isoFileBlob}
          overlayTrailerFiles={pmfTrailerFiles}
          onChangeOverlayTrailerFiles={(nextFiles, stripFlag) => {
            setPmfTrailerFiles(nextFiles);
            setStripVideosPmf(stripFlag);
            if (nextFiles.length > 0) setIncludeTrailerPmf(true);
          }}
          stripVideosPmfEnabled={stripVideosPmf}
          onToggleStripVideosPmf={setStripVideosPmf}
          onSendOverlayToIsoPacker={onSendPatchedToIsoPacker}
          onInspectAssetBytes={onInspectAssetBytes}
        />
      ) : panelTab === 'free_battle' ? (
        <DbzFreeBattleEditor
          analysis={analysis}
          isoFileBlob={isoFileBlob}
          gameId={scan?.detectedGameId ?? 'ULUS10537'}
          manifest={rosterManifest}
          mapSlots={mapSlots}
          musicSlots={musicSlots}
          layout={freeBattleLayout}
          onChangeLayout={setFreeBattleLayout}
          onSyncBuiltPckBinary={setCustomFreeBattlePckBytes}
          onSyncMasterPackfile={setMasterPackfileBytes}
          onSendPackfileToIsoPacker={onSendPatchedToIsoPacker}
          onInspectAssetBytes={onInspectAssetBytes}
          onLaunchEmulatorWithPreset={
            onLaunchEmulatorWithMod
              ? (preset) => {
                  const bundle = buildCombinedOverlayAndBundle(
                    lastPatchOutput,
                    scan?.detectedGameId ?? 'ULUS10537'
                  );
                  onLaunchEmulatorWithMod({
                    ramProfile,
                    charCount,
                    mapCount,
                    lobbyCount,
                    chibiCount,
                    musicTrackCount,
                    gameId: scan?.detectedGameId ?? 'ULUS10537',
                    ebootPatched: Boolean(lastPatchOutput),
                    freeBattlePreset: preset,
                    customCharNames: rosterManifest.characters.map((c) => c.displayName),
                    customMapNames: mapSlots.map((m) => m.name),
                    customMusicTitles: musicSlots.map((t) => t.title),
                    dlcAssetPaths: bundle.map((f) => f.path),
                  });
                }
              : undefined
          }
        />
      ) : (
        <>
      {/* Expansion Target Configuration: 256 Chars + Maps + Minimaps + 256 Lobby + Chibis + Music + Save + RAM */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3 dark:border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Configuración de Expansión DLC 256 + RAM + Save en Juego
            </h3>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              Define cuántos slots se generarán en <span className="font-mono">/PSP_GAME/DLC/</span> y el perfil de memoria RAM del ejecutable.
            </p>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6 text-xs">
          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-400">
              Personajes DLC (×8 col)
            </label>
            <input
              type="number"
              min={70}
              max={256}
              value={charCount}
              onChange={(e) => setCharCount(Math.max(1, Math.min(256, Number(e.target.value) || 256)))}
              className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-slate-900 tabular-nums dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-400">
              Mapas + Minimapas
            </label>
            <input
              type="number"
              min={11}
              max={99}
              value={mapCount}
              onChange={(e) => setMapCount(Math.max(1, Math.min(99, Number(e.target.value) || 46)))}
              className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-slate-900 tabular-nums dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-400">
              Casillas Lobby 256
            </label>
            <input
              type="number"
              min={70}
              max={256}
              value={lobbyCount}
              onChange={(e) => setLobbyCount(Math.max(1, Math.min(256, Number(e.target.value) || 256)))}
              className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-slate-900 tabular-nums dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-400">
              Personajes Chibis (.GIM)
            </label>
            <input
              type="number"
              min={70}
              max={256}
              value={chibiCount}
              onChange={(e) => setChibiCount(Math.max(1, Math.min(256, Number(e.target.value) || 256)))}
              className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-slate-900 tabular-nums dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-400">
              Música DLC (.AT3)
            </label>
            <input
              type="number"
              min={16}
              max={256}
              value={musicTrackCount}
              onChange={(e) => setMusicTrackCount(Math.max(1, Math.min(256, Number(e.target.value) || 64)))}
              className="mt-1 min-h-[38px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-slate-900 tabular-nums dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-600 dark:text-slate-400">
              RAM Objetivo (EBOOT)
            </label>
            <div className="mt-1 flex min-h-[38px] items-center justify-between rounded-lg border border-blue-200 bg-blue-50/70 px-3 font-mono font-bold text-blue-800 dark:border-blue-900/60 dark:bg-blue-950/30 dark:text-blue-300">
              <span>{computedRam.targetRamMb} MB</span>
              <span className="text-[11px]">{computedRam.totalRamHex}</span>
            </div>
          </div>
        </div>

        {/* Dynamic Memory Selector for EBOOT.BIN (32MB -> 64MB -> 256MB) */}
        <div className="mt-5 rounded-xl border border-slate-200 bg-slate-50/80 p-4 dark:border-slate-800 dark:bg-slate-950/70">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3 dark:border-slate-800">
            <div>
              <h4 className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-slate-900 dark:text-white">
                <MemoryStick className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                Selector Dinámico de Memoria RAM (32 MB – 256 MB) para EBOOT.BIN (256 Personajes)
              </h4>
              <p className="mt-0.5 text-[11px] text-slate-600 dark:text-slate-400">
                Ajusta dinámicamente los valores <span className="font-mono">LUI</span> de tamaño de RAM, límite de Heap usuario (<span className="font-mono">sceKernelMaxFreeMemSize</span>) y reserva de memoria para los 256 slots al parchear el ejecutable.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              {[
                { mb: 32, label: '32 MB (PSP-1000)' },
                { mb: 48, label: '48 MB' },
                { mb: 64, label: '64 MB (PSP Slim)' },
                { mb: 96, label: '96 MB' },
                { mb: 128, label: '128 MB' },
                { mb: 256, label: '256 MB (Full DLC)' },
              ].map((preset) => (
                <button
                  key={preset.mb}
                  type="button"
                  onClick={() => applyDynamicTargetRamMb(preset.mb)}
                  className={`rounded-md border px-2.5 py-1 text-[11px] font-mono font-semibold transition-colors cursor-pointer ${
                    dynamicRamConfig.targetRamMb === preset.mb
                      ? 'border-blue-600 bg-blue-600 text-white'
                      : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200'
                  }`}
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-12">
            {/* Slider & Custom MB Controls */}
            <div className="lg:col-span-7 space-y-3 text-xs">
              <div>
                <div className="mb-1 flex items-center justify-between">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">
                    Asignación Total de RAM PSP (Paso dinámico):
                  </span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <input
                      type="number"
                      min={32}
                      max={256}
                      step={4}
                      value={dynamicRamConfig.targetRamMb}
                      onChange={(e) => applyDynamicTargetRamMb(Number(e.target.value))}
                      className="w-16 rounded border border-slate-300 bg-white px-2 py-0.5 text-right font-bold text-slate-900 tabular-nums dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                    />
                    <span className="font-bold text-blue-600 dark:text-blue-400">MB</span>
                  </div>
                </div>
                <input
                  type="range"
                  min={32}
                  max={256}
                  step={4}
                  value={dynamicRamConfig.targetRamMb}
                  onChange={(e) => applyDynamicTargetRamMb(Number(e.target.value))}
                  aria-label="Selector dinámico de RAM en megabytes"
                  className="w-full accent-blue-600 cursor-pointer"
                />
                <div className="flex justify-between font-mono text-[10px] text-slate-400">
                  <span>32 MB (0x0A000000)</span>
                  <span>64 MB (0x0C000000)</span>
                  <span>128 MB (0x10000000)</span>
                  <span>256 MB (0x18000000)</span>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div>
                  <label className="block font-medium text-slate-600 dark:text-slate-400">
                    Reserva Kernel PSP
                  </label>
                  <select
                    value={dynamicRamConfig.kernelReserveMb}
                    onChange={(e) =>
                      setDynamicRamConfig((prev) => ({
                        ...prev,
                        kernelReserveMb: Number(e.target.value) || 8,
                      }))
                    }
                    className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-300 bg-white px-2 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                  >
                    <option value={8}>8 MB (PSP Estándar)</option>
                    <option value={12}>12 MB (Slim / Expandido)</option>
                    <option value={16}>16 MB (Kernel + Plugins)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-600 dark:text-slate-400">
                    Pool RAM 256 Personajes
                  </label>
                  <input
                    type="number"
                    min={4}
                    max={64}
                    value={dynamicRamConfig.rosterHeapAllocationMb}
                    onChange={(e) =>
                      setDynamicRamConfig((prev) => ({
                        ...prev,
                        rosterHeapAllocationMb: Math.max(4, Math.min(64, Number(e.target.value) || 12)),
                      }))
                    }
                    className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-300 bg-white px-2.5 font-mono text-slate-900 tabular-nums dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-600 dark:text-slate-400">
                    Estrategia en Combate
                  </label>
                  <select
                    value={dynamicRamConfig.streamingMode}
                    onChange={(e) =>
                      setDynamicRamConfig((prev) => ({
                        ...prev,
                        streamingMode: e.target.value as DynamicRamAllocationConfig['streamingMode'],
                      }))
                    }
                    className="mt-1 min-h-[34px] w-full rounded-lg border border-slate-300 bg-white px-2 font-mono text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                  >
                    <option value="STREAMING">Streaming (Seguro 32–64M)</option>
                    <option value="HYBRID">Caché Híbrida (64–128M)</option>
                    <option value="PRELOAD">Precarga Completa (256M)</option>
                  </select>
                </div>
              </div>

              <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={dynamicRamConfig.setParamSfoMemsize}
                  onChange={(e) =>
                    setDynamicRamConfig((prev) => ({
                      ...prev,
                      setParamSfoMemsize: e.target.checked,
                    }))
                  }
                  className="h-4 w-4 rounded border-slate-300 accent-blue-600"
                />
                Escribir <span className="font-mono font-semibold">MEMSIZE={dynamicRamConfig.targetRamMb > 32 && dynamicRamConfig.setParamSfoMemsize ? 1 : 0}</span> en <span className="font-mono">PARAM.SFO</span> (desbloquea memoria extendida en hardware real/PPSSPP)
              </label>
            </div>

            {/* Live MIPS LUI Immediate Preview */}
            <div className="lg:col-span-5 rounded-lg border border-slate-200 bg-white p-3.5 text-xs dark:border-slate-800 dark:bg-slate-900">
              <div className="mb-2 font-bold text-slate-900 dark:text-white">
                Valores MIPS Aplicados al Parchear EBOOT.BIN
              </div>
              <div className="space-y-1.5 font-mono text-[11px]">
                <div className="flex justify-between rounded bg-slate-50 px-2.5 py-1 dark:bg-slate-950">
                  <span className="text-slate-500">Tamaño Total RAM:</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {computedRam.targetRamMb} MB · LUI 0x{computedRam.totalRamLuiImm.toString(16).toUpperCase().padStart(4, '0')}
                  </span>
                </div>
                <div className="flex justify-between rounded bg-slate-50 px-2.5 py-1 dark:bg-slate-950">
                  <span className="text-slate-500">Heap Usuario Libre:</span>
                  <span className="font-bold text-emerald-700 dark:text-emerald-400">
                    {computedRam.userRamMb} MB · LUI 0x{computedRam.heapSizeLuiImm.toString(16).toUpperCase().padStart(4, '0')}
                  </span>
                </div>
                <div className="flex justify-between rounded bg-slate-50 px-2.5 py-1 dark:bg-slate-950">
                  <span className="text-slate-500">Fin Virtual RAM:</span>
                  <span className="font-bold text-blue-600 dark:text-blue-400">
                    {computedRam.ramEndAddressHex} · LUI 0x{computedRam.ramEndLuiImm.toString(16).toUpperCase().padStart(4, '0')}
                  </span>
                </div>
              </div>

              {/* Allocation Bar */}
              <div className="mt-3">
                <div className="mb-1 flex justify-between text-[10px] font-mono text-slate-500">
                  <span>Distribución: Kernel {computedRam.kernelReserveMb}M + 256 Roster {dynamicRamConfig.rosterHeapAllocationMb}M</span>
                  <span>
                    Margen Arena: {Math.max(0, computedRam.userRamMb - dynamicRamConfig.rosterHeapAllocationMb)} MB
                  </span>
                </div>
                <div className="flex h-2.5 w-full overflow-hidden rounded bg-slate-200 dark:bg-slate-800">
                  <div
                    className="bg-slate-600"
                    style={{ width: `${Math.round((computedRam.kernelReserveMb / computedRam.targetRamMb) * 100)}%` }}
                    title={`Kernel PSP: ${computedRam.kernelReserveMb} MB`}
                  />
                  <div
                    className="bg-blue-600"
                    style={{ width: `${Math.min(75, Math.round((dynamicRamConfig.rosterHeapAllocationMb / computedRam.targetRamMb) * 100))}%` }}
                    title={`Tabla 256 Personajes + Chibis: ${dynamicRamConfig.rosterHeapAllocationMb} MB`}
                  />
                  <div className="flex-1 bg-emerald-500" title="Arena + 4 Luchadores + Audio .AT3" />
                </div>
                {computedRam.userRamMb - dynamicRamConfig.rosterHeapAllocationMb < 16 && (
                  <p className="mt-1.5 text-[10px] font-semibold text-amber-700 dark:text-amber-400">
                    Margen ajustado para 4 luchadores simultáneos; considera subir a 64 MB+ o reducir el Pool de 256 Chars.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-4 border-t border-slate-100 pt-4 text-xs dark:border-slate-800">
          <div className="flex flex-wrap items-center gap-5">
            <label className="inline-flex items-center gap-2 text-slate-700 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={includeSave256}
                onChange={(e) => setIncludeSave256(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 accent-blue-600"
              />
              <Save className="h-3.5 w-3.5 text-slate-500" />
              Incluir Save en Juego 256 Slots + CWCheat INI
            </label>
            <label className="inline-flex items-center gap-2 text-slate-700 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={includeBackupOld}
                onChange={(e) => setIncludeBackupOld(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 accent-blue-600"
              />
              Guardar respaldo <span className="font-mono">EBOOT.OLD</span>
            </label>
            <label className="inline-flex items-center gap-2 text-slate-700 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={includePackfileBin}
                onChange={(e) => setIncludePackfileBin(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 accent-emerald-600"
              />
              Incluir <span className="font-mono">/PSP_GAME/USRDIR/PACKFILE.BIN</span> (Roster + Mapas + Imágenes + Menús PCK1)
            </label>
            <label className="inline-flex items-center gap-2 text-slate-700 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={includeTrailerPmf}
                onChange={(e) => setIncludeTrailerPmf(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 accent-amber-600"
              />
              Agregar Video DBZ <span className="font-mono">/PSP_GAME/ICON1.PMF</span> al inicio ISO
            </label>
            <label className="inline-flex items-center gap-2 text-slate-700 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={stripVideosPmf}
                onChange={(e) => setStripVideosPmf(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 accent-red-600"
              />
              Excluir <span className="font-mono">VIDEOS_PMF</span>
            </label>
            <label className="inline-flex items-center gap-2 text-slate-700 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={includeEmptyDlcPlaceholders}
                onChange={(e) => setIncludeEmptyDlcPlaceholders(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 accent-blue-600"
              />
              <FilePlus2 className="h-3.5 w-3.5 text-slate-500" />
              Archivos vacíos (0 B) renombrados en DLC
            </label>
            {includeEmptyDlcPlaceholders && (
              <input
                type="text"
                value={emptyDlcPrefix}
                onChange={(e) => setEmptyDlcPrefix(e.target.value)}
                placeholder="DLC_VACIO"
                aria-label="Prefijo de archivos vacíos renombrados DLC"
                className="w-32 rounded-md border border-slate-300 bg-slate-50 px-2 py-1 font-mono text-[11px] text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            )}
            <label className="inline-flex items-center gap-2 text-slate-700 dark:text-slate-200">
              <span>Expandir .bss / Cave:</span>
              <select
                value={expandBssMb}
                onChange={(e) => setExpandBssMb(Number(e.target.value))}
                className="rounded-md border border-slate-200 bg-slate-50 px-2 py-1 font-mono dark:border-slate-700 dark:bg-slate-950"
              >
                <option value={0}>+0 MB</option>
                <option value={8}>+8 MB</option>
                <option value={16}>+16 MB</option>
                <option value={32}>+32 MB</option>
              </select>
            </label>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {scan && (
              <button
                type="button"
                disabled={!scan.isElfEditable}
                onClick={() => executePatch()}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-blue-600 bg-white px-3.5 py-2 text-xs font-semibold text-blue-600 hover:bg-blue-50 disabled:opacity-40 dark:border-blue-500 dark:bg-slate-900 dark:text-blue-400 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Cpu className="h-3.5 w-3.5" />
                Parchear EBOOT.BIN + .OLD ahora
              </button>
            )}
            <button
              type="button"
              onClick={handleDownloadFullPackageZip}
              className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Archive className="h-4 w-4" />
              Descargar Todo (.ZIP DLC 256 + EBOOT + Save)
            </button>
            {onSendPatchedToIsoPacker && (
              <button
                type="button"
                onClick={handleSendAllToIsoPacker}
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <HardDrive className="h-3.5 w-3.5" />
                Enviar al Empaquetador ISO
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Relocation Table: disc0:/PSP_GAME/USRDIR/... -> disc0:/PSP_GAME/DLC/... */}
      {scan && scan.pathCandidates.length > 0 && (
        <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-4 dark:border-slate-800">
            <div>
              <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
                <Route className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                Reubicación de Rutas a Carpeta <span className="font-mono">/PSP_GAME/DLC/</span> y Save ({filteredPaths.length})
              </h3>
              <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                Si la nueva ruta cabe in-place se sobrescribe directo; si es más larga se inserta en el <strong>String Cave</strong> del <span className="font-mono">PT_LOAD</span> actualizando los pares MIPS <span className="font-mono">lui + addiu</span> automáticamente.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-1">
              {(['ALL', 'PERSONAJES', 'MAPAS', 'MINIMAPAS', 'LOBBY', 'CHIBIS', 'MUSICA', 'SAVEDATA'] as const).map(
                (cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategoryFilter(cat)}
                    className={`min-h-[30px] rounded px-2.5 text-[11px] font-medium cursor-pointer ${
                      categoryFilter === cat
                        ? 'bg-slate-900 text-white dark:bg-blue-600'
                        : 'border border-slate-200 bg-slate-50 text-slate-700 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300'
                    }`}
                  >
                    {cat === 'ALL' ? 'Todas' : FOLDER_LABEL[cat]}
                  </button>
                )
              )}
            </div>
          </div>

          <div className="max-h-80 overflow-auto">
            <table className="w-full border-collapse text-left text-xs">
              <thead className="sticky top-0 z-10 border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                <tr>
                  <th className="px-3 py-2 font-semibold">Reubicar</th>
                  <th className="px-3 py-2 font-semibold">Offset / RAM</th>
                  <th className="px-3 py-2 font-semibold">Ruta Original</th>
                  <th className="px-3 py-2 font-semibold">Nueva Ruta en DLC / Save</th>
                  <th className="px-3 py-2 font-semibold">Modo</th>
                  <th className="px-3 py-2 text-right font-semibold">HxD</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredPaths.slice(0, 120).map((p) => {
                  const edited = pathEdits[p.offset] ?? p.suggestedDlcPath;
                  const fits = edited.length <= p.originalPath.length;
                  return (
                    <tr key={p.offset} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                      <td className="px-3 py-2">
                        <input
                          type="checkbox"
                          checked={selectedPathOffsets.includes(p.offset)}
                          onChange={() => togglePathOffset(p.offset)}
                          className="h-4 w-4 rounded border-slate-300 accent-blue-600"
                        />
                      </td>
                      <td className="px-3 py-2 font-mono text-[11px] tabular-nums whitespace-nowrap">
                        <div className="text-slate-800 dark:text-slate-200">{hex(p.offset)}</div>
                        <div className="text-blue-600 dark:text-blue-400">{hex(p.ramAddress, 8)}</div>
                      </td>
                      <td className="px-3 py-2 font-mono text-[11px] text-slate-700 dark:text-slate-300 max-w-xs truncate" title={p.originalPath}>
                        {p.originalPath}
                      </td>
                      <td className="px-3 py-2 min-w-[260px]">
                        <input
                          type="text"
                          value={edited}
                          onChange={(e) =>
                            setPathEdits((prev) => ({ ...prev, [p.offset]: e.target.value }))
                          }
                          className="w-full rounded border border-slate-200 bg-slate-50 px-2 py-1 font-mono text-[11px] text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                        />
                      </td>
                      <td className="px-3 py-2 font-mono text-[11px] whitespace-nowrap">
                        {fits ? (
                          <span className="text-emerald-700 dark:text-emerald-400">In-Place OK</span>
                        ) : p.pointerCount > 0 ? (
                          <span className="text-blue-600 dark:text-blue-400">
                            Cave ({p.pointerCount} ptrs)
                          </span>
                        ) : (
                          <span className="text-amber-600 dark:text-amber-400">Ajustar largo</span>
                        )}
                      </td>
                      <td className="px-3 py-2 text-right">
                        {onJumpToHex && !uploadedFile && (
                          <button
                            type="button"
                            onClick={() => onJumpToHex(p.offset)}
                            className="inline-flex min-h-[28px] items-center gap-1 rounded bg-slate-900 px-2 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
                          >
                            <Binary className="h-3 w-3" />
                            HxD
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* MIPS Character (256) & Map (46) Limits Table */}
      {scan && scan.mipsLimitCandidates.length > 0 && (
        <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 p-4 dark:border-slate-800">
            <div>
              <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
                <MemoryStick className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                Instrucciones MIPS de Límite (Expandir Personajes/Chibis a 256 y Mapas a 46)
              </h3>
              <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                Marca las instrucciones <span className="font-mono">sltiu / slti / li</span> que deseas ampliar en <span className="font-mono">.text</span>.
              </p>
            </div>
          </div>
          <div className="max-h-64 overflow-auto">
            <table className="w-full border-collapse text-left text-xs">
              <thead className="sticky top-0 z-10 border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                <tr>
                  <th className="px-3 py-2 font-semibold">Parchear</th>
                  <th className="px-3 py-2 font-semibold">Offset / RAM</th>
                  <th className="px-3 py-2 font-semibold">Instrucción</th>
                  <th className="px-3 py-2 font-semibold">Objetivo</th>
                  <th className="px-3 py-2 font-semibold">Descripción</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {scan.mipsLimitCandidates.slice(0, 80).map((c) => (
                  <tr key={c.fileOffset} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="px-3 py-2">
                      <input
                        type="checkbox"
                        checked={selectedLimitOffsets.includes(c.fileOffset)}
                        onChange={() => toggleLimitOffset(c.fileOffset)}
                        className="h-4 w-4 rounded border-slate-300 accent-blue-600"
                      />
                    </td>
                    <td className="px-3 py-2 font-mono text-[11px] tabular-nums">
                      {hex(c.fileOffset)} · <span className="text-blue-600 dark:text-blue-400">{hex(c.ramAddress, 8)}</span>
                    </td>
                    <td className="px-3 py-2 font-mono font-semibold text-slate-900 dark:text-white">
                      {c.mnemonic}
                    </td>
                    <td className="px-3 py-2 font-mono font-semibold text-emerald-700 dark:text-emerald-400">
                      → 0x{c.targetImm.toString(16).toUpperCase().padStart(2, '0')}
                    </td>
                    <td className="px-3 py-2 text-slate-600 dark:text-slate-300">{c.description}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* Patch Result Summary & Individual Downloads */}
      {lastPatchOutput && (
        <section className="rounded-xl border border-emerald-200 bg-emerald-50/60 p-5 dark:border-emerald-900/50 dark:bg-emerald-950/20">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-emerald-950 dark:text-emerald-200">
              <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
              EBOOT.BIN + EBOOT.OLD + PARAM.SFO Parcheados Listos
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  downloadBlob(
                    new Blob([lastPatchOutput.patchedEboot as unknown as BlobPart]),
                    'EBOOT.BIN'
                  )
                }
                className="inline-flex min-h-[34px] items-center gap-1 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                Descargar EBOOT.BIN
              </button>
              <button
                type="button"
                onClick={() =>
                  downloadBlob(
                    new Blob([lastPatchOutput.backupOldEboot as unknown as BlobPart]),
                    'EBOOT.OLD'
                  )
                }
                className="inline-flex min-h-[34px] items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                Descargar EBOOT.OLD
              </button>
              {onInspectAssetBytes && (
                <button
                  type="button"
                  onClick={() => onInspectAssetBytes(lastPatchOutput.patchedEboot, 'EBOOT_DBZ_256.BIN')}
                  className="inline-flex min-h-[34px] items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
                >
                  <Binary className="h-3.5 w-3.5" />
                  Ver en HxD
                </button>
              )}
              <button
                type="button"
                onClick={() => {
                  const { cwCheatIni } = buildDbzCwCheatAndPpssppIni(scan?.detectedGameId ?? 'ULUS10537');
                  downloadBlob(
                    new Blob([cwCheatIni], { type: 'text/plain;charset=utf-8' }),
                    `${scan?.detectedGameId ?? 'ULUS10537'}.ini`
                  );
                }}
                className="inline-flex min-h-[34px] items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
              >
                <FolderInput className="h-3.5 w-3.5" />
                CWCheat 256 (.ini)
              </button>
            </div>
          </div>
          {lastPatchOutput.logLines.length > 0 && (
            <pre className="mt-3 max-h-40 overflow-auto rounded-lg border border-emerald-200 bg-slate-950 p-3 font-mono text-[11px] text-emerald-200 dark:border-emerald-900/50">
              {lastPatchOutput.logLines.join('\n')}
            </pre>
          )}
        </section>
      )}
        </>
      )}
    </div>
  );
};
