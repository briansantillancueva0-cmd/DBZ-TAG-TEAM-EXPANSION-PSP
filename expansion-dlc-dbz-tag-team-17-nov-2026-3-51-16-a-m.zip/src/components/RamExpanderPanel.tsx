import React, { useMemo, useState } from 'react';
import {
  Binary,
  Check,
  Copy,
  Cpu,
  Download,
  FolderPlus,
  MemoryStick,
  Wrench,
} from 'lucide-react';
import {
  analyzeEbootRamLayout,
  applyEbootRamPatch,
  buildObjOptimizerPythonScript,
  buildPatchedParamSfoWithMemsize,
  buildPpsspp256MbUnifiedDiff,
  buildPpssppCppRamPatchGuide,
  calculateDlcRamBudget,
  type RamTargetProfile,
} from '../lib/ramExpander';
import type { EbootAnalysis } from '../lib/types';

interface RamExpanderPanelProps {
  analysis: EbootAnalysis;
  onJumpToHex: (offset: number) => void;
  onApplyModifiedBytes?: (newBytes: Uint8Array) => void;
  onSendPatchedToIso?: (items: Array<{ path: string; data: Uint8Array }>) => void;
}

function hex(val: number, width = 8): string {
  return `0x${(val >>> 0).toString(16).toUpperCase().padStart(width, '0')}`;
}

function downloadBytes(data: Uint8Array, filename: string, mime = 'application/octet-stream') {
  const blob = new Blob([data.buffer as ArrayBuffer], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export const RamExpanderPanel: React.FC<RamExpanderPanelProps> = ({
  analysis,
  onJumpToHex,
  onApplyModifiedBytes,
  onSendPatchedToIso,
}) => {
  const ramInfo = useMemo(() => analyzeEbootRamLayout(analysis), [analysis]);

  const [targetProfile, setTargetProfile] = useState<RamTargetProfile>('256MB');
  const [extraBssMb, setExtraBssMb] = useState<number>(0);
  const [selectedOffsets, setSelectedOffsets] = useState<number[]>(() =>
    ramInfo.candidates.map((c) => c.fileOffset)
  );
  const [patchStatus, setPatchStatus] = useState<string | null>(null);

  // Calculator state
  const [fightersOnScreen, setFightersOnScreen] = useState<2 | 4>(4);
  const [modelType, setModelType] = useState<'GMO_OPTIMIZED' | 'OBJ_HEAVY'>('GMO_OPTIMIZED');
  const [loadingMode, setLoadingMode] = useState<'STREAMING' | 'PRELOAD_ALL'>('STREAMING');
  const [audioMb, setAudioMb] = useState<number>(10);

  // Dev code viewer
  const [devGuideTab, setDevGuideTab] = useState<'diff' | 'cpp' | 'obj_py'>('diff');
  const [forceAlways256, setForceAlways256] = useState(true);
  const [kernelMb, setKernelMb] = useState<8 | 12>(8);
  const [exposeCompatFlag, setExposeCompatFlag] = useState(true);
  const [copiedCode, setCopiedCode] = useState(false);

  const budget = useMemo(
    () =>
      calculateDlcRamBudget({
        fightersOnScreen,
        modelType,
        loadingMode,
        extraAudioBufferMb: audioMb,
      }),
    [fightersOnScreen, modelType, loadingMode, audioMb]
  );

  const diffPatchText = useMemo(
    () =>
      buildPpsspp256MbUnifiedDiff({
        forceAlways256,
        kernelMb,
        exposeCompatFlag,
      }),
    [forceAlways256, kernelMb, exposeCompatFlag]
  );
  const cppGuide = useMemo(() => buildPpssppCppRamPatchGuide(), []);
  const objPyScript = useMemo(() => buildObjOptimizerPythonScript(), []);
  const activeDevText =
    devGuideTab === 'diff'
      ? diffPatchText
      : devGuideTab === 'cpp'
      ? cppGuide
      : objPyScript;

  const toggleOffset = (off: number) => {
    setSelectedOffsets((prev) =>
      prev.includes(off) ? prev.filter((x) => x !== off) : [...prev, off]
    );
  };

  const runPatch = (downloadAfter: boolean) => {
    const res = applyEbootRamPatch(analysis.rawBytes, ramInfo, targetProfile, {
      selectedCandidateOffsets: selectedOffsets,
      extraBssMb,
    });
    if (onApplyModifiedBytes) {
      onApplyModifiedBytes(res.patchedBytes);
    }
    setPatchStatus(
      `Parche ${targetProfile} aplicado: ${res.mipsPatchesApplied} instrucciones LUI actualizadas${
        res.bssExpandedBytes > 0
          ? ` + ${(res.bssExpandedBytes / (1024 * 1024)).toFixed(0)} MB añadidos a PT_LOAD/.bss`
          : ''
      }.`
    );
    if (downloadAfter) {
      downloadBytes(res.patchedBytes, 'EBOOT_RAM_EXPANDIDA.BIN');
    }
  };

  const handleDownloadPatchedSfo = () => {
    if (!analysis.sfoInfo) return;
    const sfoBytes = buildPatchedParamSfoWithMemsize(analysis.sfoInfo.entries);
    downloadBytes(sfoBytes, 'PARAM.SFO');
    setPatchStatus('PARAM.SFO exportado con MEMSIZE=1 (habilita modo 64 MB / memoria extendida).');
  };

  const handleSendToIso = () => {
    if (!onSendPatchedToIso) return;
    const res = applyEbootRamPatch(analysis.rawBytes, ramInfo, targetProfile, {
      selectedCandidateOffsets: selectedOffsets,
      extraBssMb,
    });
    const batch: Array<{ path: string; data: Uint8Array }> = [
      { path: '/PSP_GAME/SYSDIR/EBOOT.BIN', data: res.patchedBytes },
    ];
    if (analysis.sfoInfo) {
      batch.push({
        path: '/PSP_GAME/PARAM.SFO',
        data: buildPatchedParamSfoWithMemsize(analysis.sfoInfo.entries),
      });
    }
    onSendPatchedToIso(batch);
  };

  const handleCopyDev = async () => {
    try {
      await navigator.clipboard.writeText(activeDevText);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 1500);
    } catch {
      // ignore
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. Header & KPI Strip */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-3xl">
            <h2 className="flex items-center gap-2 text-lg font-semibold text-slate-900 dark:text-white">
              <MemoryStick className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              Expansión de Memoria RAM de EBOOT.BIN (64 MB / 128 MB / 256 MB)
            </h2>
            <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
              Inspecciona los segmentos <span className="font-mono">PT_LOAD</span>, la sección <span className="font-mono">.bss</span>, el flag <span className="font-mono">MEMSIZE</span> de <span className="font-mono">PARAM.SFO</span> y las instrucciones MIPS <span className="font-mono">lui</span> de tope de heap/RAM para adaptar tu expansión masiva (256 personajes × 8 colores + 46 mapas).
            </p>
          </div>

          {analysis.sfoInfo && (
            <button
              type="button"
              onClick={handleDownloadPatchedSfo}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              Exportar PARAM.SFO (MEMSIZE=1)
            </button>
          )}
        </div>

        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4 text-xs">
          <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
            <div className="text-slate-500 dark:text-slate-400">PARAM.SFO MEMSIZE</div>
            <div className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums dark:text-white">
              {ramInfo.hasSfoMemsize ? `MEMSIZE = ${ramInfo.sfoMemsizeValue}` : 'No activo (24 MB)'}
            </div>
          </div>
          <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
            <div className="text-slate-500 dark:text-slate-400">Fin virtual PT_LOAD</div>
            <div className="mt-1 font-mono text-lg font-bold text-blue-600 tabular-nums dark:text-blue-400">
              {ramInfo.highestVaddrEnd > 0 ? hex(ramInfo.highestVaddrEnd) : 'Sin ELF'}
            </div>
          </div>
          <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
            <div className="text-slate-500 dark:text-slate-400">Sección .bss reservada</div>
            <div className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums dark:text-white">
              {ramInfo.bssSizeBytes.toLocaleString('es-ES')} B
            </div>
          </div>
          <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
            <div className="text-slate-500 dark:text-slate-400">Límites RAM en .text</div>
            <div className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums dark:text-white">
              {ramInfo.candidates.length} instrucciones LUI
            </div>
          </div>
        </div>

        <ul className="mt-3 space-y-1 text-xs text-slate-600 dark:text-slate-300">
          {ramInfo.notes.map((n, i) => (
            <li key={i}>• {n}</li>
          ))}
        </ul>

        {patchStatus && (
          <div className="mt-3 rounded-lg border border-emerald-300 bg-emerald-50/70 px-4 py-2.5 text-xs text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/30 dark:text-emerald-200">
            {patchStatus}
          </div>
        )}
      </section>

      {/* 2. Binary Patcher */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
              <Wrench className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              Parcheador Directo de Heap / RAM en EBOOT.BIN
            </h3>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              Selecciona el perfil objetivo y actualiza las constantes <span className="font-mono">lui</span> de tamaño de Heap / límite virtual y el tamaño reservado en <span className="font-mono">PT_LOAD/.bss</span>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
              {(['64MB', '128MB', '256MB'] as const).map((prof) => (
                <button
                  key={prof}
                  type="button"
                  onClick={() => setTargetProfile(prof)}
                  className={`min-h-[34px] rounded-md px-3 text-xs font-semibold transition-colors cursor-pointer ${
                    targetProfile === prof
                      ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-300'
                  }`}
                >
                  {prof === '64MB'
                    ? '64 MB (Slim)'
                    : prof === '128MB'
                    ? '128 MB (Mínimo)'
                    : '256 MB (Recomendado)'}
                </button>
              ))}
            </div>

            <select
              value={extraBssMb}
              onChange={(e) => setExtraBssMb(Number(e.target.value))}
              aria-label="Expansión adicional .bss"
              className="min-h-[38px] rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-800 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            >
              <option value={0}>.bss sin cambios (+0 MB)</option>
              <option value={4}>Expandir .bss / p_memsz (+4 MB)</option>
              <option value={16}>Expandir .bss / p_memsz (+16 MB)</option>
              <option value={32}>Expandir .bss / p_memsz (+32 MB)</option>
            </select>
          </div>
        </div>

        {ramInfo.candidates.length === 0 ? (
          <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50 p-4 text-xs text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300">
            {ramInfo.isElfEditable
              ? 'No se detectaron constantes LUI estándar de 24/32/52/64 MB en .text; aún puedes ampliar .bss / p_memsz o habilitar MEMSIZE=1 en PARAM.SFO.'
              : 'Binario sellado como ~PSP: desencripta primero a ELF32 para parchear instrucciones MIPS en .text.'}
          </div>
        ) : (
          <div className="mt-4 max-h-64 overflow-auto rounded-lg border border-slate-200 dark:border-slate-800">
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                  <th className="px-3 py-2 font-semibold">Aplicar</th>
                  <th className="px-3 py-2 font-semibold">Offset</th>
                  <th className="px-3 py-2 font-semibold">RAM PSP</th>
                  <th className="px-3 py-2 font-semibold">Instrucción actual</th>
                  <th className="px-3 py-2 font-semibold">Nuevo valor ({targetProfile})</th>
                  <th className="px-3 py-2 font-semibold">Significado</th>
                  <th className="px-3 py-2 text-right font-semibold">HxD</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {ramInfo.candidates.map((c) => {
                  const newImm =
                    targetProfile === '64MB'
                      ? c.suggestedImm64
                      : targetProfile === '128MB'
                      ? c.suggestedImm128
                      : c.suggestedImm256;
                  return (
                    <tr key={c.fileOffset} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                      <td className="px-3 py-2">
                        <input
                          type="checkbox"
                          checked={selectedOffsets.includes(c.fileOffset)}
                          onChange={() => toggleOffset(c.fileOffset)}
                          className="h-4 w-4 rounded border-slate-300 text-blue-600"
                        />
                      </td>
                      <td className="px-3 py-2 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                        {hex(c.fileOffset, 6)}
                      </td>
                      <td className="px-3 py-2 font-mono font-semibold tabular-nums text-blue-600 dark:text-blue-400">
                        {hex(c.ramAddress)}
                      </td>
                      <td className="px-3 py-2 font-mono text-slate-900 dark:text-slate-100">
                        {c.mnemonic}
                      </td>
                      <td className="px-3 py-2 font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                        lui {c.rtReg}, 0x{newImm.toString(16).toUpperCase().padStart(4, '0')}
                      </td>
                      <td className="max-w-xs truncate px-3 py-2 text-slate-600 dark:text-slate-300">
                        {c.meaning}
                      </td>
                      <td className="px-3 py-2 text-right">
                        <button
                          type="button"
                          onClick={() => onJumpToHex(c.fileOffset)}
                          className="inline-flex min-h-[28px] items-center gap-1 rounded bg-slate-900 px-2 py-1 text-[11px] font-medium text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
                        >
                          <Binary className="h-3 w-3" />
                          HxD
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        <div className="mt-4 flex flex-wrap items-center justify-end gap-2">
          <button
            type="button"
            disabled={!ramInfo.isElfEditable}
            onClick={() => runPatch(false)}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 cursor-pointer"
          >
            <Cpu className="h-3.5 w-3.5" />
            Aplicar Parche en Memoria Activa
          </button>
          <button
            type="button"
            disabled={!ramInfo.isElfEditable}
            onClick={() => runPatch(true)}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-40 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            Descargar EBOOT.BIN Parcheado
          </button>
          {onSendPatchedToIso && analysis.isoInfo && (
            <button
              type="button"
              disabled={!ramInfo.isElfEditable}
              onClick={handleSendToIso}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-emerald-600 bg-emerald-50 px-4 py-2 text-xs font-semibold text-emerald-700 hover:bg-emerald-100 disabled:opacity-40 dark:border-emerald-500 dark:bg-emerald-950/30 dark:text-emerald-300 cursor-pointer"
            >
              <FolderPlus className="h-3.5 w-3.5" />
              Inyectar EBOOT + PARAM.SFO en la ISO
            </button>
          )}
        </div>
      </section>

      {/* 3. Calculadora de RAM para Expansión 256 Personajes + 46 Mapas */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
          Calculadora de Consumo RAM (256 Personajes × 8 Colores + 46 Mapas + Audio .AT3)
        </h3>
        <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-12">
          <div className="space-y-3 text-xs lg:col-span-5">
            <div>
              <div className="font-medium text-slate-600 dark:text-slate-400">Luchadores simultáneos</div>
              <div className="mt-1 inline-flex rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
                <button
                  type="button"
                  onClick={() => setFightersOnScreen(2)}
                  className={`min-h-[34px] rounded-md px-3 font-medium cursor-pointer ${
                    fightersOnScreen === 2 ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white' : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  2 Luchadores (1vs1)
                </button>
                <button
                  type="button"
                  onClick={() => setFightersOnScreen(4)}
                  className={`min-h-[34px] rounded-md px-3 font-medium cursor-pointer ${
                    fightersOnScreen === 4 ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white' : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  4 Luchadores (Tag 2vs2)
                </button>
              </div>
            </div>

            <div>
              <div className="font-medium text-slate-600 dark:text-slate-400">Formato de modelos en combate</div>
              <div className="mt-1 inline-flex rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
                <button
                  type="button"
                  onClick={() => setModelType('GMO_OPTIMIZED')}
                  className={`min-h-[34px] rounded-md px-3 font-medium cursor-pointer ${
                    modelType === 'GMO_OPTIMIZED' ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white' : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  .GMO/.AMO Optimizado (&lt;8 MB)
                </button>
                <button
                  type="button"
                  onClick={() => setModelType('OBJ_HEAVY')}
                  className={`min-h-[34px] rounded-md px-3 font-medium cursor-pointer ${
                    modelType === 'OBJ_HEAVY' ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white' : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  Pesado desde .OBJ (16 MB c/u)
                </button>
              </div>
            </div>

            <div>
              <div className="font-medium text-slate-600 dark:text-slate-400">Estrategia de carga (Streaming vs Precarga)</div>
              <div className="mt-1 inline-flex rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
                <button
                  type="button"
                  onClick={() => setLoadingMode('STREAMING')}
                  className={`min-h-[34px] rounded-md px-3 font-medium cursor-pointer ${
                    loadingMode === 'STREAMING' ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white' : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  Streaming por Combate
                </button>
                <button
                  type="button"
                  onClick={() => setLoadingMode('PRELOAD_ALL')}
                  className={`min-h-[34px] rounded-md px-3 font-medium cursor-pointer ${
                    loadingMode === 'PRELOAD_ALL' ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white' : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  Precargar todo en RAM
                </button>
              </div>
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                Búfer Audio .AT3 y Voces ({audioMb} MB)
              </label>
              <input
                type="range"
                min={4}
                max={20}
                value={audioMb}
                onChange={(e) => setAudioMb(Number(e.target.value))}
                className="mt-1 w-full max-w-xs accent-blue-600"
              />
            </div>
          </div>

          <div className="space-y-3 text-xs lg:col-span-7">
            <dl className="divide-y divide-slate-100 rounded-lg border border-slate-200 px-4 dark:divide-slate-800 dark:border-slate-800">
              <div className="flex justify-between py-2">
                <dt className="text-slate-500">Tablas Maestras + Roster (.tm2 64×64)</dt>
                <dd className="font-mono font-semibold text-slate-900 tabular-nums dark:text-white">{budget.tablesAndUiMb} MB</dd>
              </div>
              <div className="flex justify-between py-2">
                <dt className="text-slate-500">Escenario Activo + Minimapa (128×128)</dt>
                <dd className="font-mono font-semibold text-slate-900 tabular-nums dark:text-white">{budget.stageAndMinimapMb} MB</dd>
              </div>
              <div className="flex justify-between py-2">
                <dt className="text-slate-500">Luchadores en Batalla ({fightersOnScreen})</dt>
                <dd className="font-mono font-semibold text-slate-900 tabular-nums dark:text-white">{budget.fightersMb} MB</dd>
              </div>
              <div className="flex justify-between py-2">
                <dt className="text-slate-500">Música .AT3 y Voces</dt>
                <dd className="font-mono font-semibold text-slate-900 tabular-nums dark:text-white">{budget.audioAndEffectsMb} MB</dd>
              </div>
              <div className="flex justify-between py-2.5 text-sm">
                <dt className="font-semibold text-slate-900 dark:text-white">Consumo Activo Total PSP</dt>
                <dd className="font-mono font-bold text-blue-600 tabular-nums dark:text-blue-400">{budget.totalActiveMb} MB</dd>
              </div>
            </dl>

            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 text-[11px]">
              <div className={`rounded-lg border p-2.5 ${budget.fitsPsp1000 ? 'border-emerald-300 text-emerald-700' : 'border-red-200 text-red-600 dark:border-red-900/50 dark:text-red-400'}`}>
                <div className="font-semibold">PSP-1000 (24 MB)</div>
                <div className="font-mono">{budget.fitsPsp1000 ? 'OK' : 'Desbordado'}</div>
              </div>
              <div className={`rounded-lg border p-2.5 ${budget.fitsPsp2000 ? 'border-emerald-300 text-emerald-700' : 'border-amber-200 text-amber-600 dark:border-amber-900/50 dark:text-amber-400'}`}>
                <div className="font-semibold">PSP Slim (52 MB)</div>
                <div className="font-mono">{budget.fitsPsp2000 ? 'OK' : 'Desbordado'}</div>
              </div>
              <div className={`rounded-lg border p-2.5 ${budget.fitsPpsspp128 ? 'border-emerald-300 text-emerald-700 dark:border-emerald-800 dark:text-emerald-400' : 'border-red-200 text-red-600'}`}>
                <div className="font-semibold">PPSSPP 128 MB</div>
                <div className="font-mono">{budget.fitsPpsspp128 ? 'Estable' : 'Insuficiente'}</div>
              </div>
              <div className={`rounded-lg border p-2.5 ${budget.fitsPpsspp256 ? 'border-emerald-300 text-emerald-700 dark:border-emerald-800 dark:text-emerald-400' : 'border-red-200 text-red-600'}`}>
                <div className="font-semibold">PPSSPP 256 MB</div>
                <div className="font-mono">{budget.fitsPpsspp256 ? 'Cero cierres' : 'Ajustar streaming'}</div>
              </div>
            </div>

            <p className="text-slate-600 dark:text-slate-300">
              <strong>Diagnóstico:</strong> {budget.verdict} (En APK nativo OpenGL ES equivale a ~{budget.androidNativeAppMb} MB; se recomienda teléfono con {budget.recommendedAndroidRamGb} GB de RAM física).
            </p>
          </div>
        </div>
      </section>

      {/* 4. Parche Diff + Código C++ PPSSPP (256 MB RAM) + Script Optimizador .OBJ */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="inline-flex flex-wrap rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
            <button
              type="button"
              onClick={() => setDevGuideTab('diff')}
              className={`min-h-[36px] rounded-md px-3 text-xs font-semibold cursor-pointer ${
                devGuideTab === 'diff' ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white' : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              Generar Parche Diff PPSSPP (.patch 256 MB)
            </button>
            <button
              type="button"
              onClick={() => setDevGuideTab('cpp')}
              className={`min-h-[36px] rounded-md px-3 text-xs font-semibold cursor-pointer ${
                devGuideTab === 'cpp' ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white' : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              Referencia C++ PPSSPP (256 MB)
            </button>
            <button
              type="button"
              onClick={() => setDevGuideTab('obj_py')}
              className={`min-h-[36px] rounded-md px-3 text-xs font-semibold cursor-pointer ${
                devGuideTab === 'obj_py' ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-700 dark:text-white' : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              Optimizador .OBJ Python (&lt; 8 MB RAM)
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => void handleCopyDev()}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
            >
              {copiedCode ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
              {copiedCode ? 'Copiado' : devGuideTab === 'diff' ? 'Copiar .patch' : 'Copiar'}
            </button>
            <button
              type="button"
              onClick={() =>
                downloadBytes(
                  new TextEncoder().encode(activeDevText),
                  devGuideTab === 'diff'
                    ? 'ppsspp_256mb_ram.patch'
                    : devGuideTab === 'cpp'
                    ? 'ppsspp_256mb_ram_patch.cpp'
                    : 'optimizar_obj_psp.py',
                  'text/plain;charset=utf-8'
                )
              }
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              {devGuideTab === 'diff' ? 'Descargar .PATCH' : 'Descargar'}
            </button>
          </div>
        </div>

        {devGuideTab === 'diff' && (
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs dark:border-slate-800 dark:bg-slate-950/60">
            <div className="flex flex-wrap items-center gap-4">
              <label className="inline-flex items-center gap-2 text-slate-700 dark:text-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={forceAlways256}
                  onChange={(e) => setForceAlways256(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-blue-600"
                />
                <span>Forzar siempre 256 MB (0x10000000)</span>
              </label>

              <label className="inline-flex items-center gap-2 text-slate-700 dark:text-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={exposeCompatFlag}
                  onChange={(e) => setExposeCompatFlag(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-blue-600"
                />
                <span>Incluir flag Ram256MB en compat.ini</span>
              </label>

              <select
                value={kernelMb}
                onChange={(e) => setKernelMb(Number(e.target.value) === 12 ? 12 : 8)}
                aria-label="Reserva Kernel PSP"
                className="min-h-[34px] rounded-md border border-slate-300 bg-white px-2.5 text-xs text-slate-800 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
              >
                <option value={8}>Kernel 8 MB (0x08800000 → 248 MB Usuario)</option>
                <option value={12}>Kernel 12 MB (0x08C00000 → 244 MB Usuario)</option>
              </select>
            </div>

            <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
              git apply ppsspp_256mb_ram.patch
            </span>
          </div>
        )}

        {devGuideTab === 'diff' ? (
          <pre className="mt-3 max-h-96 overflow-auto rounded-xl border border-slate-200 bg-slate-950 p-4 font-mono text-[11px] leading-relaxed text-slate-200 dark:border-slate-800">
            {diffPatchText.split('\n').map((line, i) => {
              const cls = line.startsWith('+++') || line.startsWith('---') || line.startsWith('diff --git')
                ? 'font-bold text-white'
                : line.startsWith('@@')
                ? 'text-cyan-400'
                : line.startsWith('+')
                ? 'bg-emerald-950/60 text-emerald-300'
                : line.startsWith('-')
                ? 'bg-red-950/60 text-red-300'
                : 'text-slate-300';
              return (
                <div key={i} className={cls}>
                  {line || ' '}
                </div>
              );
            })}
          </pre>
        ) : (
          <pre className="mt-3 max-h-80 overflow-auto rounded-xl border border-slate-200 bg-slate-950 p-4 font-mono text-xs leading-relaxed text-slate-100 dark:border-slate-800">
            {activeDevText}
          </pre>
        )}
      </section>
    </div>
  );
};
