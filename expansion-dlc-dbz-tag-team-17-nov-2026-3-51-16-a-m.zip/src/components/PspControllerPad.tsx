import React, { useEffect, useRef, useState } from 'react';
import { Gamepad2, Keyboard } from 'lucide-react';

export type PspHardwareButton =
  | 'UP'
  | 'DOWN'
  | 'LEFT'
  | 'RIGHT'
  | 'CROSS'
  | 'CIRCLE'
  | 'TRIANGLE'
  | 'SQUARE'
  | 'L'
  | 'R'
  | 'START'
  | 'SELECT'
  | 'HOME';

interface PspControllerPadProps {
  onButtonPress: (btn: PspHardwareButton) => void;
  onAnalogChange?: (dx: number, dy: number) => void;
  activeButton?: PspHardwareButton | null;
  enableKeyboard?: boolean;
  enableGamepad?: boolean;
  compact?: boolean;
  title?: string;
  hints?: Partial<Record<PspHardwareButton, string>>;
}

export const PspControllerPad: React.FC<PspControllerPadProps> = ({
  onButtonPress,
  onAnalogChange,
  activeButton = null,
  enableKeyboard: initialKeyboard = true,
  enableGamepad = true,
  compact = false,
  title = 'Controles Hardware PSP (D-Pad + Stick Analógico + Botones)',
  hints,
}) => {
  const [keyboardEnabled, setKeyboardEnabled] = useState(initialKeyboard);
  const [localPressed, setLocalPressed] = useState<PspHardwareButton | null>(null);
  const [analogPos, setAnalogPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [gamepadConnectedName, setGamepadConnectedName] = useState<string | null>(null);

  const stickRef = useRef<HTMLDivElement | null>(null);
  const draggingRef = useRef(false);
  const lastGpButtonsRef = useRef<boolean[]>([]);
  const lastGpAxisDirRef = useRef<string | null>(null);

  const firePress = (btn: PspHardwareButton) => {
    setLocalPressed(btn);
    onButtonPress(btn);
    window.setTimeout(() => {
      setLocalPressed((prev) => (prev === btn ? null : prev));
    }, 140);
  };

  // Keyboard listener
  useEffect(() => {
    if (!keyboardEnabled) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement ||
        e.target instanceof HTMLSelectElement
      ) {
        return;
      }
      const k = e.key.toLowerCase();
      let mapped: PspHardwareButton | null = null;
      if (k === 'arrowup' || k === 'w') mapped = 'UP';
      else if (k === 'arrowdown' || k === 's' && e.ctrlKey) mapped = 'DOWN';
      else if (k === 'arrowdown') mapped = 'DOWN';
      else if (k === 'arrowleft') mapped = 'LEFT';
      else if (k === 'arrowright') mapped = 'RIGHT';
      else if (k === 'z') mapped = 'CROSS';
      else if (k === 'x') mapped = 'CIRCLE';
      else if (k === 'a') mapped = 'SQUARE';
      else if (k === 's') mapped = 'TRIANGLE';
      else if (k === 'q') mapped = 'L';
      else if (k === 'e') mapped = 'R';
      else if (k === 'enter') mapped = 'START';
      else if (k === 'shift') mapped = 'SELECT';
      else if (k === 'h') mapped = 'HOME';

      if (mapped) {
        if (k.startsWith('arrow') || k === 'enter') e.preventDefault();
        firePress(mapped);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  });

  // Web Gamepad API Polling (USB / Bluetooth controllers)
  useEffect(() => {
    if (!enableGamepad || typeof navigator === 'undefined' || !navigator.getGamepads) return;
    let rafId = 0;

    const poll = () => {
      try {
        const pads = navigator.getGamepads();
        const gp = pads?.[0] ?? null;
        if (gp) {
          setGamepadConnectedName((prev) => (prev === gp.id ? prev : gp.id));
          const btnMap: Array<[number, PspHardwareButton]> = [
            [0, 'CROSS'],
            [1, 'CIRCLE'],
            [2, 'SQUARE'],
            [3, 'TRIANGLE'],
            [4, 'L'],
            [5, 'R'],
            [8, 'SELECT'],
            [9, 'START'],
            [12, 'UP'],
            [13, 'DOWN'],
            [14, 'LEFT'],
            [15, 'RIGHT'],
            [16, 'HOME'],
          ];
          const prevStates = lastGpButtonsRef.current;
          btnMap.forEach(([idx, pspBtn]) => {
            const pressedNow = Boolean(gp.buttons[idx]?.pressed);
            if (pressedNow && !prevStates[idx]) {
              firePress(pspBtn);
            }
            prevStates[idx] = pressedNow;
          });

          const ax = Math.abs(gp.axes[0] ?? 0) > 0.18 ? gp.axes[0] : 0;
          const ay = Math.abs(gp.axes[1] ?? 0) > 0.18 ? gp.axes[1] : 0;
          if (ax !== 0 || ay !== 0) {
            setAnalogPos({ x: ax, y: ay });
            onAnalogChange?.(ax, ay);
            const dir =
              Math.abs(ax) > Math.abs(ay)
                ? ax > 0.55
                  ? 'RIGHT'
                  : ax < -0.55
                  ? 'LEFT'
                  : null
                : ay > 0.55
                ? 'DOWN'
                : ay < -0.55
                ? 'UP'
                : null;
            if (dir && dir !== lastGpAxisDirRef.current) {
              firePress(dir as PspHardwareButton);
            }
            lastGpAxisDirRef.current = dir;
          } else if (lastGpAxisDirRef.current !== null) {
            lastGpAxisDirRef.current = null;
            setAnalogPos({ x: 0, y: 0 });
            onAnalogChange?.(0, 0);
          }
        } else {
          setGamepadConnectedName((prev) => (prev === null ? null : null));
        }
      } catch {
        // ignore Gamepad permission sandbox errors
      }
      rafId = window.requestAnimationFrame(poll);
    };
    rafId = window.requestAnimationFrame(poll);
    return () => window.cancelAnimationFrame(rafId);
  });

  // Analog stick pointer dragging
  const updateAnalogFromPointer = (clientX: number, clientY: number) => {
    const el = stickRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxR = rect.width / 2 - 8;
    let dx = (clientX - cx) / Math.max(1, maxR);
    let dy = (clientY - cy) / Math.max(1, maxR);
    const len = Math.hypot(dx, dy);
    if (len > 1) {
      dx /= len;
      dy /= len;
    }
    setAnalogPos({ x: dx, y: dy });
    onAnalogChange?.(dx, dy);
  };

  const releaseAnalog = () => {
    if (!draggingRef.current) return;
    draggingRef.current = false;
    // Trigger step move on release if flicked past threshold
    if (Math.abs(analogPos.x) > 0.48 || Math.abs(analogPos.y) > 0.48) {
      if (Math.abs(analogPos.x) >= Math.abs(analogPos.y)) {
        firePress(analogPos.x > 0 ? 'RIGHT' : 'LEFT');
      } else {
        firePress(analogPos.y > 0 ? 'DOWN' : 'UP');
      }
    }
    setAnalogPos({ x: 0, y: 0 });
    onAnalogChange?.(0, 0);
  };

  const isHighlighted = (btn: PspHardwareButton) =>
    localPressed === btn || activeButton === btn;

  return (
    <div
      className={`rounded-2xl border-2 border-slate-800 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 text-slate-100 shadow-lg select-none ${
        compact ? 'p-3' : 'p-4'
      }`}
    >
      {/* Top Status + Shoulder L / R */}
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <button
          type="button"
          onClick={() => firePress('L')}
          className={`min-w-[88px] rounded-t-xl rounded-b-md border px-3.5 py-1.5 font-mono text-xs font-bold transition-transform cursor-pointer ${
            isHighlighted('L')
              ? 'translate-y-0.5 border-cyan-400 bg-cyan-600 text-white'
              : 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700'
          }`}
        >
          L {hints?.L ? `· ${hints.L}` : ''}
        </button>

        <div className="flex flex-wrap items-center gap-2 text-[11px]">
          <span className="inline-flex items-center gap-1 font-semibold text-slate-300">
            <Gamepad2 className="h-3.5 w-3.5 text-cyan-400" />
            {title}
          </span>
          <button
            type="button"
            onClick={() => setKeyboardEnabled((v) => !v)}
            className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 font-mono text-[10px] font-semibold cursor-pointer ${
              keyboardEnabled
                ? 'border-emerald-600 bg-emerald-950/60 text-emerald-300'
                : 'border-slate-700 bg-slate-800 text-slate-400'
            }`}
            title="Activar o desactivar atajos de teclado para controles PSP"
          >
            <Keyboard className="h-3 w-3" />
            Teclado {keyboardEnabled ? 'ON' : 'OFF'}
          </button>
          {gamepadConnectedName && (
            <span className="rounded bg-blue-900/60 px-2 py-0.5 font-mono text-[10px] text-blue-200">
              Mando USB/BT Conectado
            </span>
          )}
        </div>

        <button
          type="button"
          onClick={() => firePress('R')}
          className={`min-w-[88px] rounded-t-xl rounded-b-md border px-3.5 py-1.5 font-mono text-xs font-bold transition-transform cursor-pointer ${
            isHighlighted('R')
              ? 'translate-y-0.5 border-cyan-400 bg-cyan-600 text-white'
              : 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700'
          }`}
        >
          R {hints?.R ? `· ${hints.R}` : ''}
        </button>
      </div>

      {/* Main Controls Strip: D-Pad + Analog Stick + Center Strip + Action Face Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        {/* Left Side: D-Pad + Analog Stick */}
        <div className="flex items-center gap-4">
          {/* PSP D-Pad */}
          <div className="flex flex-col items-center gap-1">
            <button
              type="button"
              onClick={() => firePress('UP')}
              aria-label="PSP Arriba"
              className={`flex h-9 w-9 items-center justify-center rounded-lg border text-xs font-bold cursor-pointer ${
                isHighlighted('UP')
                  ? 'border-blue-400 bg-blue-600 text-white'
                  : 'border-slate-700 bg-slate-800 hover:bg-slate-700'
              }`}
            >
              ▲
            </button>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => firePress('LEFT')}
                aria-label="PSP Izquierda"
                className={`flex h-9 w-9 items-center justify-center rounded-lg border text-xs font-bold cursor-pointer ${
                  isHighlighted('LEFT')
                    ? 'border-blue-400 bg-blue-600 text-white'
                    : 'border-slate-700 bg-slate-800 hover:bg-slate-700'
                }`}
              >
                ◀
              </button>
              <div className="h-7 w-7 rounded-full border border-slate-700 bg-slate-900" />
              <button
                type="button"
                onClick={() => firePress('RIGHT')}
                aria-label="PSP Derecha"
                className={`flex h-9 w-9 items-center justify-center rounded-lg border text-xs font-bold cursor-pointer ${
                  isHighlighted('RIGHT')
                    ? 'border-blue-400 bg-blue-600 text-white'
                    : 'border-slate-700 bg-slate-800 hover:bg-slate-700'
                }`}
              >
                ▶
              </button>
            </div>
            <button
              type="button"
              onClick={() => firePress('DOWN')}
              aria-label="PSP Abajo"
              className={`flex h-9 w-9 items-center justify-center rounded-lg border text-xs font-bold cursor-pointer ${
                isHighlighted('DOWN')
                  ? 'border-blue-400 bg-blue-600 text-white'
                  : 'border-slate-700 bg-slate-800 hover:bg-slate-700'
              }`}
            >
              ▼
            </button>
          </div>

          {/* Interactive PSP Analog Stick (Nub) */}
          <div className="flex flex-col items-center gap-1">
            <div
              ref={stickRef}
              onPointerDown={(e) => {
                draggingRef.current = true;
                (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
                updateAnalogFromPointer(e.clientX, e.clientY);
              }}
              onPointerMove={(e) => {
                if (draggingRef.current) {
                  updateAnalogFromPointer(e.clientX, e.clientY);
                }
              }}
              onPointerUp={releaseAnalog}
              onPointerCancel={releaseAnalog}
              className="relative flex h-16 w-16 touch-none items-center justify-center rounded-full border-2 border-slate-700 bg-slate-900 shadow-inner cursor-grab active:cursor-grabbing"
              title="Stick Analógico PSP (arrastra para mover cursor / personaje)"
            >
              <div className="pointer-events-none h-11 w-11 rounded-full border border-slate-800/80" />
              <div
                className="pointer-events-none absolute h-7 w-7 rounded-full border border-slate-500 bg-gradient-to-b from-slate-600 to-slate-800 shadow-md"
                style={{
                  transform: `translate(${Math.round(analogPos.x * 16)}px, ${Math.round(
                    analogPos.y * 16
                  )}px)`,
                }}
              />
            </div>
            <span className="font-mono text-[9px] text-slate-400">ANALÓGICO</span>
          </div>
        </div>

        {/* Center PSP Function Bar */}
        <div className="flex flex-col items-center gap-2">
          <div className="flex flex-wrap items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => firePress('SELECT')}
              className={`rounded-full border px-3 py-1 font-mono text-[10px] font-bold cursor-pointer ${
                isHighlighted('SELECT')
                  ? 'border-amber-400 bg-amber-600 text-white'
                  : 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700'
              }`}
            >
              SELECT{hints?.SELECT ? ` (${hints.SELECT})` : ''}
            </button>
            <button
              type="button"
              onClick={() => firePress('HOME')}
              className={`rounded-full border px-3 py-1 font-mono text-[10px] font-bold cursor-pointer ${
                isHighlighted('HOME')
                  ? 'border-cyan-400 bg-cyan-700 text-white'
                  : 'border-slate-700 bg-slate-900 text-cyan-300 hover:bg-slate-800'
              }`}
            >
              HOME{hints?.HOME ? ` (${hints.HOME})` : ''}
            </button>
            <button
              type="button"
              onClick={() => firePress('START')}
              className={`rounded-full border px-3 py-1 font-mono text-[10px] font-bold cursor-pointer ${
                isHighlighted('START')
                  ? 'border-emerald-400 bg-emerald-600 text-white'
                  : 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700'
              }`}
            >
              START{hints?.START ? ` (${hints.START})` : ''}
            </button>
          </div>
          <div className="text-center font-mono text-[10px] text-slate-400">
            Teclado: Flechas = Pad · Z = × · X = ○ · A = □ · S = △ · Q/E = L/R
          </div>
        </div>

        {/* Right Side: PSP Face Buttons (△ ○ × □) */}
        <div className="flex flex-col items-center gap-1">
          <button
            type="button"
            onClick={() => firePress('TRIANGLE')}
            title={hints?.TRIANGLE ?? 'Triángulo'}
            className={`flex h-9 w-9 items-center justify-center rounded-full border text-sm font-bold cursor-pointer ${
              isHighlighted('TRIANGLE')
                ? 'border-emerald-300 bg-emerald-600 text-white'
                : 'border-emerald-700 bg-slate-800 text-emerald-400 hover:bg-slate-700'
            }`}
          >
            △
          </button>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => firePress('SQUARE')}
              title={hints?.SQUARE ?? 'Cuadrado'}
              className={`flex h-9 w-9 items-center justify-center rounded-full border text-sm font-bold cursor-pointer ${
                isHighlighted('SQUARE')
                  ? 'border-pink-300 bg-pink-600 text-white'
                  : 'border-pink-700 bg-slate-800 text-pink-400 hover:bg-slate-700'
              }`}
            >
              □
            </button>
            <button
              type="button"
              onClick={() => firePress('CIRCLE')}
              title={hints?.CIRCLE ?? 'Círculo'}
              className={`flex h-9 w-9 items-center justify-center rounded-full border text-sm font-bold cursor-pointer ${
                isHighlighted('CIRCLE')
                  ? 'border-red-300 bg-red-600 text-white'
                  : 'border-red-700 bg-slate-800 text-red-400 hover:bg-slate-700'
              }`}
            >
              ○
            </button>
          </div>
          <button
            type="button"
            onClick={() => firePress('CROSS')}
            title={hints?.CROSS ?? 'Equis'}
            className={`flex h-9 w-9 items-center justify-center rounded-full border text-sm font-bold cursor-pointer ${
              isHighlighted('CROSS')
                ? 'border-sky-300 bg-sky-600 text-white'
                : 'border-sky-700 bg-slate-800 text-sky-400 hover:bg-slate-700'
            }`}
          >
            ×
          </button>
        </div>
      </div>
    </div>
  );
};
