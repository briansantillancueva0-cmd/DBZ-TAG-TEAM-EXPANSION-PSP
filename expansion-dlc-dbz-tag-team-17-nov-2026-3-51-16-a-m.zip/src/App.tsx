import React, { useEffect, useRef, useState } from 'react';
import {
  Binary,
  BookOpen,
  Compass,
  FileCode2,
  FileText,
  FolderOpen,
  Gamepad2,
  HardDrive,
  Languages,
  Layers,
  LockOpen,
  Moon,
  Package,
  Sparkles,
  Sun,
  Terminal,
  Upload,
} from 'lucide-react';
import { AddressExplorer } from './components/AddressExplorer';
import { AssetReportView, type AssetSubTab } from './components/AssetReportView';
import { DbzTagTeamPanel } from './components/DbzTagTeamPanel';
import { DlcAutomationView } from './components/DlcAutomationView';
import { GuideAndApkView } from './components/GuideAndApkView';
import { HxdEditor } from './components/HxdEditor';
import { IndexedReportView } from './components/IndexedReportView';
import { IsoPackerExtractorPanel } from './components/IsoPackerExtractorPanel';
import {
  PspTagTeamEmulator,
  type EmulatorModConfig,
} from './components/PspTagTeamEmulator';
import { PWAInstallButton } from './components/PWAInstallButton';
import {
  UniversalMediaAndTextView,
  type UniversalSubTab,
} from './components/UniversalMediaAndTextView';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { analyzeEbootBytes } from './lib/ebootParser';
import { extractIsoFileBytes, inspectPspIso } from './lib/iso9660';
import { readDroppedItemsWithFolders } from './lib/isoPacker';
import { buildSamplePspIsoBlob } from './lib/sampleBuilder';
import type { TextEncodingMode } from './lib/codeTable';
import type { EbootAnalysis, IsoFileEntry, IsoInspectionResult } from './lib/types';

type ActiveTab =
  | 'overview'
  | 'assets'
  | 'addresses'
  | 'hxd'
  | 'report'
  | 'guide'
  | 'dlc_automation'
  | 'iso_packer'
  | 'universal_lab'
  | 'dbz_tag_team'
  | 'psp_emulator';

function hex(val: number | null | undefined, width = 8): string {
  if (val === null || val === undefined || Number.isNaN(val)) return 'N/A';
  return `0x${(val >>> 0).toString(16).toUpperCase().padStart(width, '0')}`;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');
  const [analysis, setAnalysis] = useState<EbootAnalysis | null>(null);
  const [isoFileBlob, setIsoFileBlob] = useState<File | Blob | null>(null);
  const [standalonePackBlob, setStandalonePackBlob] = useState<File | Blob | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [hxdTargetOffset, setHxdTargetOffset] = useState<number | null>(null);
  const [hxdInitialEncoding, setHxdInitialEncoding] = useState<TextEncodingMode | null>(null);
  const [hxdAssetOverride, setHxdAssetOverride] = useState<EbootAnalysis | null>(null);
  const [assetSubTab, setAssetSubTab] = useState<AssetSubTab>('inventory');
  const [universalSubTab, setUniversalSubTab] = useState<UniversalSubTab>('identifier');
  const [droppedFolderItems, setDroppedFolderItems] = useState<Array<{
    file: File;
    relativePath: string;
  }> | null>(null);
  const [emulatorModConfig, setEmulatorModConfig] = useState<EmulatorModConfig | null>(null);
  const [darkMode, setDarkMode] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const isOnline = useOnlineStatus();

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
  }, [darkMode]);

  const openFilePicker = () => {
    fileInputRef.current?.click();
  };

  const processFile = async (file: Blob, fileName: string, kind: 'ISO' | 'STANDALONE' | 'SAMPLE') => {
    setLoading(true);
    setErrorMsg(null);

    try {
      const lower = fileName.toLowerCase();
      const headBuf = new Uint8Array(await file.slice(0, 16).arrayBuffer());
      const headAscii = new TextDecoder('ascii', { fatal: false }).decode(headBuf.subarray(0, 4));
      const looksLikeIso =
        lower.endsWith('.iso') ||
        (file.size >= 34816 && headAscii !== '~PSP' && headBuf[0] !== 0x7f && headAscii !== '\0PBP');

      if (looksLikeIso) {
        try {
          const isoRes: IsoInspectionResult = await inspectPspIso(file);
          const primaryEntry: IsoFileEntry | null = isoRes.ebootEntry ?? isoRes.bootEntry;
          if (!primaryEntry) {
            throw new Error(
              'La imagen ISO se leyó correctamente, pero no contiene /PSP_GAME/SYSDIR/EBOOT.BIN ni BOOT.BIN.'
            );
          }
          const ebootBytes = await extractIsoFileBytes(file, primaryEntry);
          const altPath =
            isoRes.ebootEntry && isoRes.bootEntry && primaryEntry.path !== isoRes.bootEntry.path
              ? isoRes.bootEntry.path
              : null;

          const parsed = analyzeEbootBytes(ebootBytes, {
            sourceName: fileName,
            sourceKind: kind === 'SAMPLE' ? 'SAMPLE' : 'ISO',
            targetBinaryPath: primaryEntry.path,
            isoInfo: isoRes,
            sfoInfo: isoRes.sfo,
            alternativeBootBinaryPath: altPath,
          });
          setIsoFileBlob(file);
          setStandalonePackBlob(null);
          setAnalysis(parsed);
          setHxdAssetOverride(null);
          setHxdTargetOffset(0);
          setActiveTab('overview');
          return;
        } catch (isoErr) {
          if (lower.endsWith('.iso')) {
            throw isoErr;
          }
          // Otherwise fall through to direct binary / PACKFILE inspection
        }
      }

      const isPckFile = lower.endsWith('.pck') || headAscii === 'PCK1';
      const isPackContainer =
        isPckFile ||
        /(packfile|pack|archive|resource)\.(bin|pac|cpk|afs|arc|pak|dat)$/i.test(lower) ||
        /\.(cpk|afs|pak)$/i.test(lower) ||
        headAscii === 'PACK' ||
        headAscii === 'AFS\0' ||
        headAscii === 'CPK ' ||
        (file.size > 32 * 1024 * 1024 && headAscii !== '~PSP' && headBuf[0] !== 0x7f && headAscii !== '\0PBP');

      if (isPackContainer) {
        const previewLen = Math.min(file.size, 2 * 1024 * 1024);
        const headSlice = new Uint8Array(await file.slice(0, previewLen).arrayBuffer());
        const parsed = analyzeEbootBytes(headSlice, {
          sourceName: fileName,
          sourceKind: kind,
          targetBinaryPath: fileName,
        });
        parsed.fileSize = file.size;
        parsed.analyzedNotes = [
          `Contenedor PSP PACKFILE / PCK1 detectado (${file.size.toLocaleString('es-ES')} bytes).`,
          'Lectura por streaming activada: HxD muestra los primeros 2 MB de cabecera mientras el escáner indexa y descomprime todo el contenedor sin saturar la RAM.',
          ...parsed.analyzedNotes.slice(0, 2),
        ];
        setIsoFileBlob(null);
        setStandalonePackBlob(file);
        setAnalysis(parsed);
        setHxdAssetOverride(null);
        setHxdTargetOffset(0);
        setAssetSubTab(isPckFile ? 'pck1' : 'inventory');
        setActiveTab('assets');
        return;
      }

      if (file.size > 64 * 1024 * 1024) {
        throw new Error('El binario directo supera 64 MB. Para imágenes completas usa formato .ISO o carga un archivo PACKFILE.BIN.');
      }

      const raw = new Uint8Array(await file.arrayBuffer());
      const parsed = analyzeEbootBytes(raw, {
        sourceName: fileName,
        sourceKind: kind,
        targetBinaryPath: fileName,
      });
      setIsoFileBlob(null);
      setStandalonePackBlob(null);
      setAnalysis(parsed);
      setHxdAssetOverride(null);
      setHxdTargetOffset(0);
      setActiveTab('overview');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'No se pudo analizar el archivo seleccionado.');
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      void processFile(file, file.name, 'STANDALONE');
    }
    e.target.value = '';
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragActive(false);
    const items = await readDroppedItemsWithFolders(e.dataTransfer);
    const hasSubfolder = items.some((it) => it.relativePath.includes('/'));
    if (hasSubfolder || items.length > 1) {
      setDroppedFolderItems(items);
      setActiveTab('iso_packer');
      return;
    }
    const file = items[0]?.file ?? e.dataTransfer.files?.[0];
    if (file) {
      void processFile(file, file.name, 'STANDALONE');
    }
  };

  const handleLoadSampleIso = () => {
    const sampleBlob = buildSamplePspIsoBlob();
    void processFile(sampleBlob, 'PSP_SAMPLE_LAB.ISO', 'SAMPLE');
  };

  const handleSwitchIsoBinary = async (entryPath: string) => {
    if (!analysis?.isoInfo || !isoFileBlob) return;
    const target = analysis.isoInfo.files.find((f) => !f.isDirectory && f.path === entryPath);
    if (!target) return;
    setLoading(true);
    try {
      const bytes = await extractIsoFileBytes(isoFileBlob, target);
      const otherBoot =
        analysis.isoInfo.ebootEntry && analysis.isoInfo.ebootEntry.path !== target.path
          ? analysis.isoInfo.ebootEntry.path
          : analysis.isoInfo.bootEntry && analysis.isoInfo.bootEntry.path !== target.path
          ? analysis.isoInfo.bootEntry.path
          : null;

      const parsed = analyzeEbootBytes(bytes, {
        sourceName: analysis.sourceName,
        sourceKind: analysis.sourceKind,
        targetBinaryPath: target.path,
        isoInfo: analysis.isoInfo,
        sfoInfo: analysis.sfoInfo,
        alternativeBootBinaryPath: otherBoot,
      });
      setAnalysis(parsed);
      setHxdTargetOffset(0);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Error al extraer el binario alternativo.');
    } finally {
      setLoading(false);
    }
  };

  const handleJumpToHex = (offset: number) => {
    setHxdAssetOverride(null);
    setHxdTargetOffset(offset);
    setActiveTab('hxd');
  };

  const handleInspectIsoAssetBytes = (
    bytes: Uint8Array,
    assetPath: string,
    preferredEncoding?: TextEncodingMode,
    preferredOffset?: number
  ) => {
    const assetAnalysis = analyzeEbootBytes(bytes, {
      sourceName: analysis?.sourceName ?? assetPath,
      sourceKind: analysis?.sourceKind ?? 'STANDALONE',
      targetBinaryPath: assetPath,
      isoInfo: analysis?.isoInfo ?? null,
      sfoInfo: analysis?.sfoInfo ?? null,
    });
    if (!analysis) {
      setAnalysis(assetAnalysis);
      setHxdAssetOverride(null);
    } else {
      setHxdAssetOverride(assetAnalysis);
    }
    setHxdInitialEncoding(preferredEncoding ?? null);
    setHxdTargetOffset(preferredOffset ?? 0);
    setActiveTab('hxd');
  };

  const handleReanalyzeModified = (newBytes: Uint8Array) => {
    if (hxdAssetOverride) {
      setHxdAssetOverride({
        ...hxdAssetOverride,
        rawBytes: newBytes,
        fileSize: newBytes.length,
      });
      return;
    }
    if (!analysis) return;
    const updated = analyzeEbootBytes(newBytes, {
      sourceName: analysis.sourceName,
      sourceKind: analysis.sourceKind,
      targetBinaryPath: analysis.targetBinaryPath,
      isoInfo: analysis.isoInfo,
      sfoInfo: analysis.sfoInfo,
      alternativeBootBinaryPath: analysis.alternativeBootBinaryPath,
    });
    setAnalysis(updated);
  };

  const navItems: Array<{ key: ActiveTab; label: string; mobileLabel: string; icon: React.ReactNode }> = [
    { key: 'overview', label: 'Resumen', mobileLabel: 'Resumen', icon: <Layers className="h-4 w-4" /> },
    { key: 'assets', label: 'Activos', mobileLabel: 'Activos', icon: <Package className="h-4 w-4" /> },
    { key: 'addresses', label: 'Direcciones', mobileLabel: 'Direcciones', icon: <Compass className="h-4 w-4" /> },
    { key: 'hxd', label: 'HxD Editor', mobileLabel: 'HxD', icon: <Binary className="h-4 w-4" /> },
    { key: 'report', label: 'Informe', mobileLabel: 'Informe', icon: <FileText className="h-4 w-4" /> },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 pb-20 md:pb-8">
      <input
        ref={fileInputRef}
        type="file"
        onChange={handleFileChange}
        className="hidden"
        accept=".iso,.bin,.prx,.elf,.pbp,.pck,*/*"
      />

      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/95">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-8 px-4 sm:px-6">
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('overview');
            }}
            className="text-lg font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0"
          >
            PSP EBOOT Inspector
          </a>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300">
            {navItems.map((item) => (
              <button
                key={item.key}
                type="button"
                onClick={() => {
                  if (item.key === 'assets') setAssetSubTab('inventory');
                  setActiveTab(item.key);
                }}
                className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === item.key
                    ? 'text-blue-600 underline decoration-2 underline-offset-8 dark:text-blue-400'
                    : 'hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('psp_emulator')}
              title="Abrir Emulador PSP con RAM Modificada y Port Nativo DBZ Tag Team 256"
              aria-label="Emular PSP Tag Team con RAM modificada"
              className={`inline-flex min-h-[40px] items-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'psp_emulator'
                  ? 'border-amber-500 bg-amber-500 text-slate-950'
                  : 'border-slate-300 bg-white text-slate-800 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-amber-300 dark:hover:bg-slate-700'
              }`}
            >
              <Gamepad2 className="h-4 w-4" />
              <span className="hidden sm:inline">Emular PSP</span>
            </button>
            <button
              type="button"
              onClick={openFilePicker}
              className="inline-flex min-h-[40px] items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Upload className="h-4 w-4" />
              Cargar ISO / BIN
            </button>
          </div>
        </div>
      </header>

      {/* Workspace Secondary Action Bar */}
      <div className="no-print border-b border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-2.5 sm:px-6">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            {analysis ? (
              <>
                <span className="font-semibold text-slate-900 dark:text-white">{analysis.sourceName}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono">{analysis.targetBinaryPath}</span>
                <span aria-hidden="true">·</span>
                <span>{analysis.format}</span>
              </>
            ) : (
              <span>Lectura local directa en tu dispositivo · Sin subida a servidores externos</span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleLoadSampleIso}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <FileCode2 className="h-4 w-4" />
              Probar ISO de Muestra
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('iso_packer')}
              className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'iso_packer'
                  ? 'border-blue-600 bg-blue-50 text-blue-700 dark:border-blue-500 dark:bg-blue-950/40 dark:text-blue-300'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              <HardDrive className="h-4 w-4" />
              Extraer / Empaquetar ISO
            </button>
            <button
              type="button"
              onClick={() => {
                setUniversalSubTab('identifier');
                setActiveTab('universal_lab');
              }}
              className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'universal_lab'
                  ? 'border-blue-600 bg-blue-50 text-blue-700 dark:border-blue-500 dark:bg-blue-950/40 dark:text-blue-300'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              <LockOpen className="h-4 w-4" />
              Identificador / Desencriptador / Textos
            </button>
            <button
              type="button"
              onClick={() => {
                setUniversalSubTab('oreimo_patch');
                setActiveTab('universal_lab');
              }}
              className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'universal_lab' && universalSubTab === 'oreimo_patch'
                  ? 'border-blue-600 bg-blue-50 text-blue-700 dark:border-blue-500 dark:bg-blue-950/40 dark:text-blue-300'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              <Languages className="h-4 w-4" />
              Parche Traducción Oreimo
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('dbz_tag_team')}
              className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'dbz_tag_team'
                  ? 'border-blue-600 bg-blue-50 text-blue-700 dark:border-blue-500 dark:bg-blue-950/40 dark:text-blue-300'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              <Sparkles className="h-4 w-4 text-amber-500" />
              DBZ Tag Team 256 (EBOOT/.OLD + DLC)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('psp_emulator')}
              className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'psp_emulator'
                  ? 'border-blue-600 bg-blue-50 text-blue-700 dark:border-blue-500 dark:bg-blue-950/40 dark:text-blue-300'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              <Gamepad2 className="h-4 w-4" />
              Port Nativo / Emulador PSP (RAM Mod)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('dlc_automation')}
              className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'dlc_automation'
                  ? 'border-blue-600 bg-blue-50 text-blue-700 dark:border-blue-500 dark:bg-blue-950/40 dark:text-blue-300'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              <Terminal className="h-4 w-4" />
              Automatización DLC
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('guide')}
              className={`inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'guide'
                  ? 'border-blue-600 bg-blue-50 text-blue-700 dark:border-blue-500 dark:bg-blue-950/40 dark:text-blue-300'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800'
              }`}
            >
              <BookOpen className="h-4 w-4" />
              Guía y APK Kotlin
            </button>
            <PWAInstallButton />
            <button
              type="button"
              onClick={() => setDarkMode((d) => !d)}
              className="inline-flex min-h-[40px] min-w-[40px] items-center justify-center rounded-lg border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
              aria-label="Cambiar tema claro u oscuro"
              title="Cambiar tema"
            >
              {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </div>

      {!isOnline && (
        <div className="bg-amber-600 px-4 py-2 text-center text-xs font-medium text-white">
          Modo sin conexión activo: el analizador ISO/ELF, el editor HxD y la generación de informes funcionan localmente.
        </div>
      )}

      {/* Main Content */}
      <main id="top" className="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-8">
        {errorMsg && (
          <div className="mb-6 rounded-xl border border-red-300 bg-red-50 p-4 text-sm text-red-800 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-300">
            <strong className="font-semibold">Error de lectura:</strong> {errorMsg}
          </div>
        )}

        {loading && (
          <div className="mb-6 rounded-xl border border-slate-200 bg-white p-6 text-sm text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300">
            Analizando estructura ISO 9660, cabeceras binarias y direcciones de memoria...
          </div>
        )}

        {/* Guide, DLC Automation, ISO Packer/Extractor & Universal Lab views work with or without a loaded file */}
        {activeTab === 'guide' ? (
          <GuideAndApkView />
        ) : activeTab === 'dlc_automation' ? (
          <DlcAutomationView />
        ) : activeTab === 'iso_packer' ? (
          <IsoPackerExtractorPanel
            analysis={analysis}
            isoFileBlob={isoFileBlob}
            onRequestLoadFile={openFilePicker}
            onLoadSampleIso={handleLoadSampleIso}
            onInspectIsoAssetBytes={handleInspectIsoAssetBytes}
            onLoadGeneratedIso={(blob, fileName) => void processFile(blob, fileName, 'ISO')}
            initialDroppedItems={droppedFolderItems}
            onConsumeInitialDroppedItems={() => setDroppedFolderItems(null)}
          />
        ) : activeTab === 'universal_lab' ? (
          <UniversalMediaAndTextView
            analysis={analysis}
            isoFileBlob={isoFileBlob}
            initialSubTab={universalSubTab}
            onInspectAssetBytes={handleInspectIsoAssetBytes}
            onJumpToHex={handleJumpToHex}
            onSendPatchedToIsoPacker={(files) => {
              setDroppedFolderItems(files);
              setActiveTab('iso_packer');
            }}
          />
        ) : activeTab === 'dbz_tag_team' ? (
          <DbzTagTeamPanel
            analysis={analysis}
            isoFileBlob={isoFileBlob}
            onJumpToHex={handleJumpToHex}
            onInspectAssetBytes={handleInspectIsoAssetBytes}
            onApplyModifiedBytes={handleReanalyzeModified}
            onSendPatchedToIsoPacker={(files) => {
              setDroppedFolderItems(files);
              setActiveTab('iso_packer');
            }}
            onLaunchEmulatorWithMod={(cfg) => {
              setEmulatorModConfig(cfg);
              setActiveTab('psp_emulator');
            }}
          />
        ) : activeTab === 'psp_emulator' ? (
          <PspTagTeamEmulator
            analysis={analysis}
            isoFileBlob={isoFileBlob}
            initialModConfig={emulatorModConfig}
            onOpenDbzExpander={() => setActiveTab('dbz_tag_team')}
          />
        ) : !analysis ? (
          <div className="grid grid-cols-1 items-stretch gap-6 lg:grid-cols-12">
            {/* Primary Upload / Dropzone */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragActive(true);
              }}
              onDragLeave={() => setDragActive(false)}
              onDrop={(e) => void handleDrop(e)}
              className={`lg:col-span-7 flex flex-col justify-between rounded-2xl border-2 border-dashed p-8 transition-colors ${
                dragActive
                  ? 'border-blue-600 bg-blue-50/60 dark:border-blue-500 dark:bg-blue-950/20'
                  : 'border-slate-300 bg-white dark:border-slate-800 dark:bg-slate-900'
              }`}
            >
              <div>
                <h1 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl dark:text-white [text-wrap:balance]">
                  Analizador de EBOOT.BIN e Imágenes ISO de PSP
                </h1>
                <p className="mt-3 max-w-xl text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                  Selecciona o arrastra aquí un archivo <span className="font-mono">.ISO</span>, una carpeta extraída con <span className="font-mono">PSP_GAME/</span> o ejecutables <span className="font-mono">EBOOT.BIN</span>, <span className="font-mono">.PRX</span>, <span className="font-mono">.AWB</span>, <span className="font-mono">.DAT</span> o <span className="font-mono">.PMF</span>.
                </p>
              </div>

              <div className="mt-8 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={openFilePicker}
                  className="inline-flex min-h-[48px] items-center gap-2 rounded-xl bg-blue-600 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-blue-700 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <FolderOpen className="h-4 w-4" />
                  Seleccionar Archivo ISO / EBOOT.BIN
                </button>
                <button
                  type="button"
                  onClick={handleLoadSampleIso}
                  className="inline-flex min-h-[48px] items-center gap-2 rounded-xl border border-slate-300 bg-white px-5 py-3 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Cargar ISO PSP de Prueba
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('iso_packer')}
                  className="inline-flex min-h-[48px] items-center gap-2 rounded-xl border border-slate-300 bg-white px-5 py-3 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <HardDrive className="h-4 w-4" />
                  Extraer / Empaquetar ISO PSP
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setUniversalSubTab('identifier');
                    setActiveTab('universal_lab');
                  }}
                  className="inline-flex min-h-[48px] items-center gap-2 rounded-xl border border-slate-300 bg-white px-5 py-3 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <LockOpen className="h-4 w-4" />
                  Desencriptar / Identificar Carpeta y Textos
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('dbz_tag_team')}
                  className="inline-flex min-h-[48px] items-center gap-2 rounded-xl border border-amber-300 bg-amber-50 px-5 py-3 text-sm font-semibold text-amber-900 transition-colors hover:bg-amber-100 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-200 dark:hover:bg-amber-950/60 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Sparkles className="h-4 w-4" />
                  DBZ Tag Team 256 (EBOOT/.OLD + DLC)
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('psp_emulator')}
                  className="inline-flex min-h-[48px] items-center gap-2 rounded-xl bg-slate-900 px-5 py-3 text-sm font-semibold text-amber-400 transition-colors hover:bg-slate-800 dark:bg-slate-800 dark:text-amber-300 dark:hover:bg-slate-700 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Gamepad2 className="h-4 w-4" />
                  Emulador PSP &amp; Port Nativo Tag Team
                </button>
              </div>
            </div>

            {/* Technical Capabilities Summary */}
            <div className="lg:col-span-5 flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <div>
                <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
                  Qué obtiene el analizador
                </h2>
                <ul className="mt-4 space-y-3 text-sm text-slate-600 dark:text-slate-300">
                  <li>
                    <strong className="font-semibold text-slate-900 dark:text-white">1. Lectura ISO 9660 por sectores:</strong> Extrae <span className="font-mono">PARAM.SFO</span>, <span className="font-mono">EBOOT.BIN</span> y <span className="font-mono">BOOT.BIN</span> sin cargar gigabytes completos en RAM.
                  </li>
                  <li>
                    <strong className="font-semibold text-slate-900 dark:text-white">2. Diagnóstico de Cabeceras:</strong> Distingue binarios <span className="font-mono">~PSP</span>, ejecutables <span className="font-mono">ELF32 MIPS</span> y paquetes <span className="font-mono">PBP</span>, mostrando <span className="font-mono">sceModuleInfo</span> y librerías NID.
                  </li>
                  <li>
                    <strong className="font-semibold text-slate-900 dark:text-white">3. Buscador de Direcciones:</strong> Localiza Entry Point, secciones, llamadas <span className="font-mono">JAL</span>, punteros <span className="font-mono">LUI+ADDIU</span> y rutas <span className="font-mono">disc0:/</span> con Offset y RAM PSP.
                  </li>
                  <li>
                    <strong className="font-semibold text-slate-900 dark:text-white">4. Editor HxD e Informe Indexado:</strong> Edita bytes en vivo, inspecciona enteros/flotantes y exporta el informe indexado en <span className="font-mono">.TXT</span>, <span className="font-mono">.MD</span>, <span className="font-mono">.CSV</span> o <span className="font-mono">.JSON</span>.
                  </li>
                </ul>
              </div>

              <div className="mt-6 flex flex-wrap items-center gap-4 border-t border-slate-100 pt-4 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setActiveTab('dlc_automation')}
                  className="text-xs font-semibold text-blue-600 hover:underline dark:text-blue-400 cursor-pointer"
                >
                  Abrir Automatización DLC (script Python 2048 B) →
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('guide')}
                  className="text-xs font-semibold text-slate-700 hover:underline dark:text-slate-300 cursor-pointer"
                >
                  Ver guía de EBOOT.BIN y código Kotlin →
                </button>
              </div>
            </div>
          </div>
        ) : (
          <>
            {/* Active Tab View Switcher */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* 4-column KPI Strip */}
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                    <div className="text-xs text-slate-500 dark:text-slate-400">Formato detectado</div>
                    <div className="mt-1 text-base font-semibold text-slate-900 dark:text-white">
                      {analysis.formatLabel}
                    </div>
                  </div>
                  <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                    <div className="text-xs text-slate-500 dark:text-slate-400">Entry Point / Base RAM</div>
                    <div className="mt-1 font-mono text-base font-semibold text-blue-600 tabular-nums dark:text-blue-400">
                      {analysis.elfHeader
                        ? hex(analysis.elfHeader.entryPoint)
                        : analysis.pspHeader
                        ? hex(analysis.pspHeader.bootEntry)
                        : hex(analysis.baseRamAddress)}
                    </div>
                  </div>
                  <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                    <div className="text-xs text-slate-500 dark:text-slate-400">Tamaño del binario</div>
                    <div className="mt-1 font-mono text-base font-semibold text-slate-900 tabular-nums dark:text-white">
                      {analysis.fileSize.toLocaleString('es-ES')} B
                    </div>
                  </div>
                  <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                    <div className="text-xs text-slate-500 dark:text-slate-400">Direcciones indexadas</div>
                    <div className="mt-1 font-mono text-base font-semibold text-slate-900 tabular-nums dark:text-white">
                      {analysis.addresses.length} hallazgos
                    </div>
                  </div>
                </div>

                {/* Diagnostic Notes & Alternative Binary Switcher */}
                <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <h2 className="text-base font-semibold text-slate-900 dark:text-white">
                      Diagnóstico y Propósito de este Archivo
                    </h2>
                    <div className="flex flex-wrap items-center gap-2">
                      {analysis.alternativeBootBinaryPath && (
                        <button
                          type="button"
                          onClick={() => void handleSwitchIsoBinary(analysis.alternativeBootBinaryPath!)}
                          className="min-h-[38px] rounded-lg border border-blue-600 px-3 py-1.5 text-xs font-semibold text-blue-600 hover:bg-blue-50 dark:border-blue-400 dark:text-blue-400 dark:hover:bg-blue-950/30 cursor-pointer"
                        >
                          Analizar {analysis.alternativeBootBinaryPath.split('/').pop()}
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setActiveTab('hxd')}
                        className="min-h-[38px] rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-700 cursor-pointer"
                      >
                        Abrir en Editor HxD
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setAssetSubTab('pck1');
                          setActiveTab('assets');
                        }}
                        className="min-h-[38px] rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        Descomprimir PCK1 / AT3
                      </button>
                      <button
                        type="button"
                        onClick={() => setActiveTab('iso_packer')}
                        className="min-h-[38px] rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        Extraer / Empaquetar ISO
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setUniversalSubTab('identifier');
                          setActiveTab('universal_lab');
                        }}
                        className="min-h-[38px] rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        Identificador y Desencriptador
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setUniversalSubTab('text_analyzer');
                          setActiveTab('universal_lab');
                        }}
                        className="min-h-[38px] rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        Analizador de Textos
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setAssetSubTab('iso_expand');
                          setActiveTab('assets');
                        }}
                        className="min-h-[38px] rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        Expandir ISO / MOD DLC
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setAssetSubTab('ram');
                          setActiveTab('assets');
                        }}
                        className="min-h-[38px] rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        Expandir RAM EBOOT
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setAssetSubTab('translator');
                          setActiveTab('assets');
                        }}
                        className="min-h-[38px] rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        Traductor de Idiomas
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setAssetSubTab('dlc');
                          setActiveTab('assets');
                        }}
                        className="min-h-[38px] rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        Auditar DLC / disc0:/
                      </button>
                      <button
                        type="button"
                        onClick={() => setActiveTab('dbz_tag_team')}
                        className="min-h-[38px] rounded-lg border border-amber-400 bg-amber-50 px-3.5 py-1.5 text-xs font-semibold text-amber-900 hover:bg-amber-100 dark:border-amber-700 dark:bg-amber-950/40 dark:text-amber-200 dark:hover:bg-amber-950/60 cursor-pointer"
                      >
                        DBZ Tag Team 256 (.BIN/.OLD + DLC)
                      </button>
                      <button
                        type="button"
                        onClick={() => setActiveTab('psp_emulator')}
                        className="min-h-[38px] rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-semibold text-amber-400 hover:bg-slate-800 dark:bg-slate-800 dark:text-amber-300 cursor-pointer"
                      >
                        Emular PSP / Port Nativo Tag Team
                      </button>
                      <button
                        type="button"
                        onClick={() => setActiveTab('report')}
                        className="min-h-[38px] rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        Ver Informe Indexado
                      </button>
                    </div>
                  </div>

                  <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
                    Este archivo es el ejecutable principal encargado de arrancar el módulo en la CPU MIPS Allegrex de PSP, enlazar las funciones del sistema operativo (pantalla, controles, sistema de archivos UMD/Memory Stick) y cargar los recursos del juego en memoria.
                  </p>

                  <ul className="mt-3 space-y-1.5 text-xs text-slate-600 dark:text-slate-400">
                    {analysis.analyzedNotes.map((n, i) => (
                      <li key={i}>• {n}</li>
                    ))}
                  </ul>
                </section>

                {/* Two-Column Details: Metadata + Module/Header */}
                <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                  <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                    <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                      Metadatos de ISO y PARAM.SFO
                    </h3>
                    {analysis.sfoInfo || analysis.isoInfo ? (
                      <dl className="mt-3 divide-y divide-slate-100 text-xs dark:divide-slate-800">
                        {analysis.sfoInfo && (
                          <>
                            <div className="flex justify-between py-2">
                              <dt className="text-slate-500">Título del juego / app</dt>
                              <dd className="font-semibold text-slate-900 dark:text-white">{analysis.sfoInfo.title}</dd>
                            </div>
                            <div className="flex justify-between py-2">
                              <dt className="text-slate-500">DISC_ID</dt>
                              <dd className="font-mono text-slate-900 dark:text-white">{analysis.sfoInfo.discId}</dd>
                            </div>
                            <div className="flex justify-between py-2">
                              <dt className="text-slate-500">Firmware requerido</dt>
                              <dd className="font-mono text-slate-900 dark:text-white">{analysis.sfoInfo.pspSystemVer}</dd>
                            </div>
                            <div className="flex justify-between py-2">
                              <dt className="text-slate-500">Categoría</dt>
                              <dd className="text-slate-800 dark:text-slate-200">{analysis.sfoInfo.categoryLabel}</dd>
                            </div>
                          </>
                        )}
                        {analysis.isoInfo && (
                          <>
                            <div className="flex justify-between py-2">
                              <dt className="text-slate-500">Volumen ISO</dt>
                              <dd className="font-mono text-slate-900 dark:text-white">{analysis.isoInfo.volume.volumeId}</dd>
                            </div>
                            <div className="flex justify-between py-2">
                              <dt className="text-slate-500">Contenido en disco</dt>
                              <dd className="font-mono tabular-nums text-slate-800 dark:text-slate-200">
                                {analysis.isoInfo.totalFiles} archivos · {analysis.isoInfo.totalDirs} directorios
                              </dd>
                            </div>
                          </>
                        )}
                      </dl>
                    ) : (
                      <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">
                        Archivo binario independiente (sin contenedor ISO 9660 ni PARAM.SFO).
                      </p>
                    )}
                  </section>

                  <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                    <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                      Cabecera Binaria y Módulo PSP
                    </h3>
                    {analysis.elfHeader ? (
                      <dl className="mt-3 divide-y divide-slate-100 text-xs dark:divide-slate-800">
                        <div className="flex justify-between py-2">
                          <dt className="text-slate-500">Arquitectura</dt>
                          <dd className="font-mono text-slate-900 dark:text-white">{analysis.elfHeader.machineLabel}</dd>
                        </div>
                        <div className="flex justify-between py-2">
                          <dt className="text-slate-500">Tipo ELF</dt>
                          <dd className="font-mono text-slate-900 dark:text-white">{analysis.elfHeader.typeLabel}</dd>
                        </div>
                        {analysis.moduleInfo && (
                          <>
                            <div className="flex justify-between py-2">
                              <dt className="text-slate-500">Módulo (sceModuleInfo)</dt>
                              <dd className="font-mono font-semibold text-slate-900 dark:text-white">
                                {analysis.moduleInfo.name} v{analysis.moduleInfo.versionMajor}.{analysis.moduleInfo.versionMinor}
                              </dd>
                            </div>
                            <div className="flex justify-between py-2">
                              <dt className="text-slate-500">Puntero Global ($gp)</dt>
                              <dd className="font-mono text-blue-600 tabular-nums dark:text-blue-400">
                                {hex(analysis.moduleInfo.gpValue)}
                              </dd>
                            </div>
                          </>
                        )}
                      </dl>
                    ) : analysis.pspHeader ? (
                      <dl className="mt-3 divide-y divide-slate-100 text-xs dark:divide-slate-800">
                        <div className="flex justify-between py-2">
                          <dt className="text-slate-500">Nombre Módulo (~PSP)</dt>
                          <dd className="font-mono font-semibold text-slate-900 dark:text-white">
                            {analysis.pspHeader.modName}
                          </dd>
                        </div>
                        <div className="flex justify-between py-2">
                          <dt className="text-slate-500">Atributos</dt>
                          <dd className="text-slate-800 dark:text-slate-200">
                            {analysis.pspHeader.modAttrLabels.join(' · ')}
                          </dd>
                        </div>
                        <div className="flex justify-between py-2">
                          <dt className="text-slate-500">Tamaño ELF / PSP</dt>
                          <dd className="font-mono tabular-nums text-slate-800 dark:text-slate-200">
                            {analysis.pspHeader.elfSize.toLocaleString('es-ES')} B / {analysis.pspHeader.pspSize.toLocaleString('es-ES')} B
                          </dd>
                        </div>
                        <div className="flex justify-between py-2">
                          <dt className="text-slate-500">Devkit SDK</dt>
                          <dd className="font-mono text-slate-800 dark:text-slate-200">
                            {analysis.pspHeader.devkitVersionLabel}
                          </dd>
                        </div>
                      </dl>
                    ) : (
                      <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">
                        Formato sin cabecera ELF32 o ~PSP estándar.
                      </p>
                    )}
                  </section>
                </div>

                {/* Sections & Libraries quick preview */}
                {analysis.sections.length > 0 && (
                  <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                        Secciones ELF32 ({analysis.sections.length})
                      </h3>
                      <button
                        type="button"
                        onClick={() => setActiveTab('addresses')}
                        className="text-xs font-medium text-blue-600 hover:underline dark:text-blue-400 cursor-pointer"
                      >
                        Explorar todas las direcciones →
                      </button>
                    </div>
                    <div className="mt-3 overflow-x-auto">
                      <table className="w-full border-collapse text-left text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-800">
                            <th className="py-2 pr-3 font-semibold">Nombre</th>
                            <th className="py-2 px-3 font-semibold">Offset Archivo</th>
                            <th className="py-2 px-3 font-semibold">Dirección RAM</th>
                            <th className="py-2 px-3 font-semibold">Tamaño</th>
                            <th className="py-2 pl-3 font-semibold">Qué contiene</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                          {analysis.sections.map((sec) => (
                            <tr key={sec.index}>
                              <td className="py-2 pr-3 font-mono font-semibold text-slate-900 dark:text-white">
                                {sec.name}
                              </td>
                              <td className="py-2 px-3 font-mono tabular-nums">
                                {sec.offset > 0 ? (
                                  <button
                                    type="button"
                                    onClick={() => handleJumpToHex(sec.offset)}
                                    className="text-blue-600 hover:underline dark:text-blue-400 cursor-pointer"
                                  >
                                    {hex(sec.offset, 6)}
                                  </button>
                                ) : (
                                  '—'
                                )}
                              </td>
                              <td className="py-2 px-3 font-mono tabular-nums text-slate-800 dark:text-slate-200">
                                {sec.vaddr > 0 ? hex(sec.vaddr) : '—'}
                              </td>
                              <td className="py-2 px-3 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                                {sec.size.toLocaleString('es-ES')} B
                              </td>
                              <td className="py-2 pl-3 text-slate-600 dark:text-slate-400">{sec.purpose}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </section>
                )}
              </div>
            )}

            {activeTab === 'assets' && (
              <AssetReportView
                key={`assets-${assetSubTab}`}
                analysis={analysis}
                isoFileBlob={isoFileBlob}
                standalonePackBlob={standalonePackBlob}
                onInspectEbootOffset={handleJumpToHex}
                onInspectIsoAssetBytes={handleInspectIsoAssetBytes}
                onApplyModifiedBytes={handleReanalyzeModified}
                onLoadGeneratedIso={(blob, fileName) => void processFile(blob, fileName, 'ISO')}
                initialSubTab={assetSubTab}
              />
            )}

            {activeTab === 'addresses' && (
              <AddressExplorer addresses={analysis.addresses} onInspectHex={handleJumpToHex} />
            )}

            {activeTab === 'hxd' && (
              <div className="space-y-3">
                {hxdAssetOverride && (
                  <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-blue-200 bg-blue-50/70 px-4 py-2.5 text-xs text-slate-800 dark:border-blue-900/50 dark:bg-blue-950/30 dark:text-slate-200">
                    <span>
                      Editando activo ISO: <strong className="font-mono">{hxdAssetOverride.targetBinaryPath}</strong>
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setHxdAssetOverride(null);
                        setHxdTargetOffset(0);
                      }}
                      className="font-semibold text-blue-600 hover:underline dark:text-blue-400 cursor-pointer"
                    >
                      Volver a {analysis.targetBinaryPath}
                    </button>
                  </div>
                )}
                <HxdEditor
                  analysis={hxdAssetOverride ?? analysis}
                  initialOffset={hxdTargetOffset}
                  initialEncoding={hxdInitialEncoding}
                  onApplyModifiedBytes={handleReanalyzeModified}
                />
              </div>
            )}

            {activeTab === 'report' && (
              <IndexedReportView analysis={analysis} onJumpToHex={handleJumpToHex} />
            )}
          </>
        )}
      </main>

      {/* Mobile Thumb-Zone Bottom Tab Bar (<= 15% mobile height) */}
      <nav
        aria-label="Navegación móvil"
        className="no-print fixed bottom-0 left-0 right-0 z-40 grid h-14 grid-cols-5 border-t border-slate-200 bg-white/95 backdrop-blur-md md:hidden dark:border-slate-800 dark:bg-slate-900/95"
      >
        {navItems.map((item) => {
          const active = activeTab === item.key;
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => setActiveTab(item.key)}
              className={`flex min-h-[44px] flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors cursor-pointer ${
                active
                  ? 'text-blue-600 dark:text-blue-400'
                  : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
              }`}
            >
              {item.icon}
              <span>{item.mobileLabel}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
